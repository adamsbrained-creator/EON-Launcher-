package ix.app.eon

import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.pager.PagerState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.GraphicsLayerScope
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import kotlin.math.abs

/**
 * Animation settings. Everything is Compose state, so a change shows straight away.
 *
 * home:   what the icons do when you come back to the home screen: none, fade, rise, fall (Free fall) or pop.
 * page:   what pages do while you swipe between them: slide (plain), fade, zoom or depth.
 * drawer: how the app drawer opens and closes: slide, zoom, fade or sheet.
 * press:  icons shrink a little under your finger.
 */
object AnimConfig {
    var home by mutableStateOf("fall")
        private set
    var page by mutableStateOf("slide")
        private set
    var drawer by mutableStateOf("slide")
        private set
    var press by mutableStateOf(true)
        private set

    /**
     * Progress of the home animation, 0 to 1 over the whole animation. Every icon reads it and works out its own
     * part (they start one after another), so one clock drives the lot. Starts at 0 so nothing flashes at launch.
     */
    val intro = Animatable(0f)

    /** Goes up each time Eon comes back on screen; the home screen plays the animation when it changes. */
    var introTick by mutableIntStateOf(0)

    private var prefs: Prefs? = null

    fun load(p: Prefs) {
        prefs = p
        home = p.getString("animHome").ifEmpty { "fall" }
        page = p.getString("animPage").ifEmpty { "slide" }
        drawer = p.getString("animDrawer").ifEmpty { "slide" }
        press = p.getBool("animPress", true)
    }

    fun chooseHome(v: String) { home = v; prefs?.putString("animHome", v) }
    fun choosePage(v: String) { page = v; prefs?.putString("animPage", v) }
    fun chooseDrawer(v: String) { drawer = v; prefs?.putString("animDrawer", v) }
    fun choosePress(v: Boolean) { press = v; prefs?.putBool("animPress", v) }

    /** How long the whole home animation lasts. */
    fun introMs(mode: String): Int = when (mode) {
        "fade" -> 450
        "rise" -> 650
        "pop" -> 800
        "fall" -> 1250
        else -> 0
    }

    /** Hides the icons while Eon is off screen, so they are ready to animate in when it comes back. */
    suspend fun arm() {
        if (home != "none") intro.snapTo(0f)
    }

    suspend fun play() {
        if (home == "none") {
            intro.snapTo(1f)
            return
        }
        intro.snapTo(0f)
        intro.animateTo(1f, tween(introMs(home), easing = LinearEasing))
    }
}

private fun easeOutCubic(u: Float): Float {
    val v = 1f - u
    return 1f - v * v * v
}

private fun easeOutBack(u: Float): Float {
    val c1 = 1.70158f
    val c3 = c1 + 1f
    val v = u - 1f
    return 1f + c3 * v * v * v + c1 * v * v
}

/**
 * Height of an icon above its place while it falls: it drops from above, lands, and hops twice, smaller each time.
 * Negative means above. [u] runs 0 to 1.
 */
private fun fallOffset(u: Float, travel: Float, hop: Float): Float {
    val a = 0.60f
    val b = 0.82f
    val c = 0.93f
    return when {
        u < a -> {
            val s = u / a
            -travel * (1f - s * s)
        }
        u < b -> {
            val s = (u - a) / (b - a)
            -hop * 4f * s * (1f - s)
        }
        u < c -> {
            val s = (u - b) / (c - b)
            -hop * 0.35f * 4f * s * (1f - s)
        }
        else -> 0f
    }
}

/**
 * One icon's look at moment [t] (0 to 1) of the home animation.
 * [order] (0 to 1) is where it comes in the sequence, [travel] how far above its place it starts when falling, in px.
 */
fun GraphicsLayerScope.applyIntro(mode: String, t: Float, order: Float, travel: Float) {
    if (mode == "none" || t >= 1f) return
    val u = ((t - order * 0.45f) / 0.55f).coerceIn(0f, 1f)
    if (u >= 1f) return
    when (mode) {
        "fade" -> {
            val e = easeOutCubic(u)
            alpha = e
            val s = 0.9f + 0.1f * e
            scaleX = s
            scaleY = s
        }
        "rise" -> {
            translationY = (1f - easeOutCubic(u)) * 40.dp.toPx()
            alpha = easeOutCubic((u * 1.6f).coerceAtMost(1f))
        }
        "pop" -> {
            val s = (0.35f + 0.65f * easeOutBack(u)).coerceAtLeast(0f)
            scaleX = s
            scaleY = s
            alpha = (u * 3f).coerceAtMost(1f)
        }
        "fall" -> {
            translationY = fallOffset(u, travel, 26.dp.toPx())
            alpha = (u * 8f).coerceAtMost(1f)
        }
    }
}

/**
 * The home animation for one icon, folder or widget. [order] is its place in the sequence and [travel] how far
 * it falls. Dock icons rise instead of falling, so they do not drop through the icons above them.
 */
fun Modifier.homeIntro(order: Float, travel: Float, dock: Boolean = false): Modifier = graphicsLayer {
    val mode = if (dock && AnimConfig.home == "fall") "rise" else AnimConfig.home
    applyIntro(mode, AnimConfig.intro.value, order, travel)
}

/** What a home page does while you swipe past it. */
fun Modifier.pageEffect(pager: PagerState, index: Int): Modifier {
    val mode = AnimConfig.page
    if (mode == "slide") return this
    return graphicsLayer {
        // 0 when the page is in the middle, 1 or more when it has gone one page to the left, -1 to the right.
        val p = (pager.currentPage - index) + pager.currentPageOffsetFraction
        val d = abs(p).coerceIn(0f, 1f)
        when (mode) {
            "fade" -> alpha = 1f - d
            "zoom" -> {
                val s = 1f - 0.18f * d
                scaleX = s
                scaleY = s
                alpha = 1f - d
            }
            "depth" -> {
                // The page you leave stays put and sinks behind, while the next one slides over it.
                if (p > 0f) {
                    translationX = p * size.width
                    val s = 1f - 0.12f * d
                    scaleX = s
                    scaleY = s
                    alpha = 1f - d
                }
            }
        }
    }
}

/**
 * Tells you when a finger is resting on this, until it lifts, moves off or becomes a long press.
 * Only watches: it never takes the touch from anything else.
 */
fun Modifier.pressFeedback(onPressed: (Boolean) -> Unit): Modifier = pointerInput(Unit) {
    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
        onPressed(true)
        try {
            withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
                while (true) {
                    val ev = awaitPointerEvent(PointerEventPass.Initial)
                    val c = ev.changes.firstOrNull { it.id == down.id } ?: break
                    if (!c.pressed || (c.position - down.position).getDistance() > viewConfiguration.touchSlop) break
                }
            }
        } finally {
            onPressed(false)
        }
    }
}

fun drawerEnter(mode: String): EnterTransition = when (mode) {
    "zoom" -> scaleIn(tween(340, easing = Motion.Decel), initialScale = 0.9f) + fadeIn(tween(260, easing = Motion.Decel))
    "fade" -> fadeIn(tween(260, easing = Motion.Decel))
    "sheet" -> slideInVertically(tween(420, easing = Motion.Decel)) { it } + fadeIn(tween(180))
    else -> slideInVertically(tween(400, easing = Motion.Decel)) { it / 4 } + fadeIn(tween(280, easing = Motion.Decel))
}

fun drawerExit(mode: String): ExitTransition = when (mode) {
    "zoom" -> scaleOut(tween(220, easing = Motion.Accel), targetScale = 0.92f) + fadeOut(tween(200, easing = Motion.Accel))
    "fade" -> fadeOut(tween(200, easing = Motion.Accel))
    "sheet" -> slideOutVertically(tween(300, easing = Motion.Accel)) { it } + fadeOut(tween(200, delayMillis = 90))
    else -> slideOutVertically(tween(280, easing = Motion.Accel)) { it / 4 } + fadeOut(tween(220, easing = Motion.Accel))
}
