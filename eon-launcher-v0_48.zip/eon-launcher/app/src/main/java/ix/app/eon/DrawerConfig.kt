package ix.app.eon

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.toArgb

/** A ready-made look for the drawer: background, text and tile colours in one tap. */
class DrawerPreset(
    val name: String, val bg: Color, val opacity: Float, val gradient: Boolean,
    val text: Color, val accent: Color, val tile: Color, val tileOpacity: Float,
)

val DRAWER_PRESETS = listOf(
    DrawerPreset("Smoke", Color.Black, 0.65f, true, Color(0xFFF5F5F6), Color.White, Color.White, 0.22f),
    DrawerPreset("Midnight", Color(0xFF070B1F), 0.85f, true, Color(0xFFE8EEFF), Color(0xFF5C9DFF), Color(0xFF5C9DFF), 0.18f),
    DrawerPreset("Frost", Color.White, 0.55f, true, Color(0xFF101114), Color(0xFF101114), Color.White, 0.45f),
    DrawerPreset("Amoled", Color.Black, 0.97f, false, Color(0xFFF5F5F6), Color(0xFF35D6F0), Color.White, 0.12f),
    DrawerPreset("Clear", Color.Black, 0.15f, false, Color.White, Color.White, Color.White, 0.18f),
)

/** How the A to Z order of the drawer can be changed. */
val DRAWER_SORTS = listOf("A to Z", "Z to A", "Newest first", "Most used", "Recently used")

/**
 * Everything you can change about the drawers (Settings > Drawer). Compose state, so a change shows in the
 * drawer straight away. The first group is used by both drawers, then the bar style, then the App Library.
 */
object DrawerConfig {
    // ---- both drawers
    var bgColor by mutableStateOf(Color.Black)
    var bgOpacity by mutableFloatStateOf(0.65f)
    var bgGradient by mutableStateOf(true)
    var textColor by mutableStateOf(Color(0xFFF5F5F6))
    var accentColor by mutableStateOf(Color.White)

    var iconDp by mutableIntStateOf(68)
    var columns by mutableIntStateOf(4)
    var rowGap by mutableIntStateOf(14)
    var showLabels by mutableStateOf(true)
    var labelSp by mutableFloatStateOf(12f)
    var twoLine by mutableStateOf(false)

    var sort by mutableIntStateOf(0)
    var autoKeyboard by mutableStateOf(false)

    // ---- bar style
    var panelPct by mutableIntStateOf(50)
    var showTitle by mutableStateOf(true)
    var titleSp by mutableIntStateOf(28)
    var titleCenter by mutableStateOf(false)
    var barIconDp by mutableIntStateOf(24)
    var barIndicator by mutableStateOf(true)
    var barPill by mutableStateOf(true)
    var showBar by mutableStateOf(true)
    var transition by mutableIntStateOf(0)

    // Grid
    var autoFit by mutableStateOf(false)
    var customPadding by mutableStateOf(false)
    var padSide by mutableIntStateOf(14)
    var padTop by mutableIntStateOf(12)
    var padBottom by mutableIntStateOf(20)

    // Advanced
    var searchIndex by mutableStateOf(false)
    var hidePlayStore by mutableStateOf(false)
    var hideIconPacks by mutableStateOf(false)
    var moveDown by mutableStateOf(false)
    var stackBottom by mutableStateOf(false)
    var closeAfterLaunch by mutableStateOf(true)

    /** True when a rule in Advanced hides this app from the drawer. */
    fun hiddenByRules(app: AppEntry): Boolean {
        if (hidePlayStore && app.packageName == "com.android.vending") return true
        if (hideIconPacks) {
            val hay = (app.label + " " + app.packageName).lowercase()
            if ("icon pack" in hay || "iconpack" in hay || "icon_pack" in hay || "icon.pack" in hay) return true
        }
        return false
    }
    var swipeCategories by mutableStateOf(true)

    // ---- App Library
    var libColumns by mutableIntStateOf(2)
    var tileColor by mutableStateOf(Color.White)
    var tileOpacity by mutableFloatStateOf(0.22f)
    var tileRadius by mutableIntStateOf(28)
    var tileBorder by mutableStateOf(true)
    var showRecent by mutableStateOf(true)
    var showOther by mutableStateOf(true)

    /** The dim layer behind the drawer: one colour, fading from lighter at the top to stronger at the bottom. */
    fun scrim(): Brush {
        val a = bgOpacity.coerceIn(0f, 1f)
        return if (bgGradient) {
            Brush.verticalGradient(
                listOf(bgColor.copy(alpha = a * 2f / 3f), bgColor.copy(alpha = (a * 4f / 3f).coerceAtMost(1f))),
            )
        } else {
            SolidColor(bgColor.copy(alpha = a))
        }
    }

    fun applyPreset(p: DrawerPreset) {
        bgColor = p.bg
        bgOpacity = p.opacity
        bgGradient = p.gradient
        textColor = p.text
        accentColor = p.accent
        tileColor = p.tile
        tileOpacity = p.tileOpacity
    }

    fun reset() {
        bgColor = Color.Black
        bgOpacity = 0.65f
        bgGradient = true
        textColor = Color(0xFFF5F5F6)
        accentColor = Color.White
        iconDp = 68
        columns = 4
        rowGap = 14
        showLabels = true
        labelSp = 12f
        twoLine = false
        sort = 0
        autoKeyboard = false
        panelPct = 50
        showTitle = true
        titleSp = 28
        titleCenter = false
        barIconDp = 24
        barIndicator = true
        barPill = true
        showBar = true
        transition = 0
        autoFit = false
        customPadding = false
        padSide = 14
        padTop = 12
        padBottom = 20
        searchIndex = false
        hidePlayStore = false
        hideIconPacks = false
        moveDown = false
        stackBottom = false
        closeAfterLaunch = true
        swipeCategories = true
        libColumns = 2
        tileColor = Color.White
        tileOpacity = 0.22f
        tileRadius = 28
        tileBorder = true
        showRecent = true
        showOther = true
    }

    fun load(p: Prefs) {
        bgColor = Color(p.getInt("drBg", Color.Black.toArgb()))
        bgOpacity = p.getFloat("drBgOpacity", 0.65f)
        bgGradient = p.getBool("drBgGradient", true)
        textColor = Color(p.getInt("drText", Color(0xFFF5F5F6).toArgb()))
        accentColor = Color(p.getInt("drAccent", Color.White.toArgb()))
        iconDp = p.getInt("drIcon", 68).coerceIn(44, 88)
        columns = p.getInt("drCols", 4).coerceIn(3, 6)
        rowGap = p.getInt("drRowGap", 14).coerceIn(0, 32)
        showLabels = p.getBool("drLabels", true)
        labelSp = p.getFloat("drLabelSp", 12f)
        twoLine = p.getBool("drTwoLine", false)
        sort = p.getInt("drSort", 0).coerceIn(0, DRAWER_SORTS.size - 1)
        autoKeyboard = p.getBool("drKeyboard", false)
        panelPct = p.getInt("drPanel", 50).coerceIn(30, 75)
        showTitle = p.getBool("drTitle", true)
        titleSp = p.getInt("drTitleSp", 28).coerceIn(18, 40)
        titleCenter = p.getBool("drTitleCenter", false)
        barIconDp = p.getInt("drBarIcon", 24).coerceIn(18, 32)
        barIndicator = p.getBool("drBarIndicator", true)
        barPill = p.getBool("drBarPill", true)
        showBar = p.getBool("drShowBar", true)
        transition = p.getInt("drTransition", 0).coerceIn(0, DRAWER_TRANSITIONS.size - 1)
        autoFit = p.getBool("drAutoFit", false)
        customPadding = p.getBool("drCustomPad", false)
        padSide = p.getInt("drPadSide", 14).coerceIn(0, 40)
        padTop = p.getInt("drPadTop", 12).coerceIn(0, 60)
        padBottom = p.getInt("drPadBottom", 20).coerceIn(0, 60)
        searchIndex = p.getBool("drIndex", false)
        hidePlayStore = p.getBool("drHidePlay", false)
        hideIconPacks = p.getBool("drHidePacks", false)
        moveDown = p.getBool("drMoveDown", false)
        stackBottom = p.getBool("drStack", false)
        closeAfterLaunch = p.getBool("drClose", true)
        swipeCategories = p.getBool("drSwipe", true)
        libColumns = p.getInt("drLibCols", 2).coerceIn(2, 3)
        tileColor = Color(p.getInt("drTile", Color.White.toArgb()))
        tileOpacity = p.getFloat("drTileOpacity", 0.22f)
        tileRadius = p.getInt("drTileRadius", 28).coerceIn(8, 40)
        tileBorder = p.getBool("drTileBorder", true)
        showRecent = p.getBool("drRecent", true)
        showOther = p.getBool("drOther", true)
    }

    fun save(p: Prefs) {
        p.putInt("drBg", bgColor.toArgb())
        p.putFloat("drBgOpacity", bgOpacity)
        p.putBool("drBgGradient", bgGradient)
        p.putInt("drText", textColor.toArgb())
        p.putInt("drAccent", accentColor.toArgb())
        p.putInt("drIcon", iconDp)
        p.putInt("drCols", columns)
        p.putInt("drRowGap", rowGap)
        p.putBool("drLabels", showLabels)
        p.putFloat("drLabelSp", labelSp)
        p.putBool("drTwoLine", twoLine)
        p.putInt("drSort", sort)
        p.putBool("drKeyboard", autoKeyboard)
        p.putInt("drPanel", panelPct)
        p.putBool("drTitle", showTitle)
        p.putInt("drTitleSp", titleSp)
        p.putBool("drTitleCenter", titleCenter)
        p.putInt("drBarIcon", barIconDp)
        p.putBool("drBarIndicator", barIndicator)
        p.putBool("drBarPill", barPill)
        p.putBool("drShowBar", showBar)
        p.putInt("drTransition", transition)
        p.putBool("drAutoFit", autoFit)
        p.putBool("drCustomPad", customPadding)
        p.putInt("drPadSide", padSide)
        p.putInt("drPadTop", padTop)
        p.putInt("drPadBottom", padBottom)
        p.putBool("drIndex", searchIndex)
        p.putBool("drHidePlay", hidePlayStore)
        p.putBool("drHidePacks", hideIconPacks)
        p.putBool("drMoveDown", moveDown)
        p.putBool("drStack", stackBottom)
        p.putBool("drClose", closeAfterLaunch)
        p.putBool("drSwipe", swipeCategories)
        p.putInt("drLibCols", libColumns)
        p.putInt("drTile", tileColor.toArgb())
        p.putFloat("drTileOpacity", tileOpacity)
        p.putInt("drTileRadius", tileRadius)
        p.putBool("drTileBorder", tileBorder)
        p.putBool("drRecent", showRecent)
        p.putBool("drOther", showOther)
    }
}

/** How the apps slide when you change category. */
val DRAWER_TRANSITIONS = listOf("Default", "Fade", "Zoom", "Rotate")

/** The apps in the order chosen in Drawer settings. [apps] arrives sorted A to Z. */
fun sortApps(apps: List<AppEntry>, mode: Int): List<AppEntry> = when (mode) {
    1 -> apps.sortedByDescending { it.label.lowercase() }
    2 -> apps.sortedByDescending { it.firstInstall }
    3 -> apps.sortedWith(compareByDescending<AppEntry> { Usage.count(it.key, 30) }.thenBy { it.label.lowercase() })
    4 -> apps.sortedByDescending { Usage.last(it.key) }
    else -> apps
}
