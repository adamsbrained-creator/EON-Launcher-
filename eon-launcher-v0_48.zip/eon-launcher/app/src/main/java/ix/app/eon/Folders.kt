package ix.app.eon

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** What a folder looks like on the home screen: a rounded square with the first four apps inside, and its name. */
@Composable
fun FolderIconBody(
    folder: Item, apps: List<AppEntry>, iconSize: Dp, showLabel: Boolean,
    labelSp: Float = 12f, twoLine: Boolean = false, labelColor: Color = Eon.Text,
) {
    val preview = folder.members.mapNotNull { k -> apps.firstOrNull { it.key == k } }.take(4)
    val shape = RoundedCornerShape(iconSize * 0.28f)
    val mini = iconSize * 0.36f
    // Folders shrink a little under a finger too, like app icons.
    var pressed by remember { mutableStateOf(false) }
    val pressScale by androidx.compose.animation.core.animateFloatAsState(
        if (pressed && AnimConfig.press) 0.9f else 1f, Motion.snappy(), label = "folderPress",
    )
    Column(
        Modifier.pressFeedback { pressed = it }
            .graphicsLayer { scaleX = pressScale; scaleY = pressScale }
            .padding(vertical = 4.dp, horizontal = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        val bg = if (folder.iconColor != 0) Color(folder.iconColor) else Color(0x40FFFFFF)
        val picture = folder.iconKind == "image"
        Box(
            Modifier.size(iconSize).clip(shape).background(bg)
                .border(if (picture) 1.dp else 1.5.dp, if (picture) SolidColor(Color(0x44FFFFFF)) else Eon.Button, shape),
            contentAlignment = Alignment.Center,
        ) {
            when (folder.iconKind) {
                "glyph" -> Icon(catIcon(folder.iconValue), null, tint = Color.White, modifier = Modifier.size(iconSize * 0.52f))
                "emoji" -> Text(folder.iconValue, fontSize = (iconSize.value * 0.5f).sp, textAlign = TextAlign.Center)
                "image" -> {
                    val bmp = remember(folder.iconValue) {
                        try {
                            android.graphics.BitmapFactory.decodeFile(folder.iconValue)?.asImageBitmap()
                        } catch (_: Exception) {
                            null
                        }
                    }
                    if (bmp != null) {
                        Image(bitmap = bmp, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                    }
                }
                else -> Column(verticalArrangement = Arrangement.spacedBy(iconSize * 0.06f)) {
                    preview.chunked(2).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(iconSize * 0.06f)) {
                            row.forEach { app -> Image(bitmap = app.icon, contentDescription = null, modifier = Modifier.size(mini)) }
                        }
                    }
                }
            }
        }
        if (showLabel) {
            Gap(6)
            Text(
                folder.name.ifBlank { "Folder" }, color = labelColor, fontSize = labelSp.sp,
                maxLines = if (twoLine) 2 else 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                style = TextStyle(shadow = Shadow(Color(0x99000000), Offset(0f, 1f), 4f)),
            )
        }
    }
}

/**
 * An open folder: its name (tap to rename) and its apps. Tap an app to open it, long-press for its menu
 * (which has Take out of folder). Tapping outside closes it.
 */
@Composable
fun FolderPopup(
    state: EonState, folder: Item, apps: List<AppEntry>,
    onLaunch: (AppEntry) -> Unit, onMenu: (AppEntry) -> Unit, onClose: () -> Unit,
) {
    val members = folder.members.mapNotNull { k -> apps.firstOrNull { it.key == k } }
    var name by remember(folder.key) { mutableStateOf(folder.name) }
    var pickingIcon by remember(folder.key) { mutableStateOf(false) }
    // Save the name however the popup closes.
    DisposableEffect(folder.key) { onDispose { state.commitLayout() } }
    Box(
        Modifier.fillMaxSize().background(Color(0x99000000))
            .pointerInput(Unit) { detectTapGestures(onTap = { onClose() }) },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier.padding(horizontal = 24.dp).fillMaxWidth()
                .glass(RoundedCornerShape(30.dp))
                .pointerInput(Unit) { detectTapGestures(onTap = { }) }
                .padding(horizontal = 18.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            BasicTextField(
                value = name,
                onValueChange = { name = it.take(24); folder.name = name },
                singleLine = true,
                textStyle = TextStyle(color = Eon.Text, fontSize = 22.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center),
                cursorBrush = SolidColor(Eon.Accent),
                modifier = Modifier.fillMaxWidth(),
                decorationBox = { inner ->
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        if (name.isEmpty()) Text("Folder", color = Eon.Faint, fontSize = 22.sp)
                        inner()
                    }
                },
            )
            Gap(16)
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                modifier = Modifier.heightIn(max = 380.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(members, key = { it.key }) { app ->
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        AppIcon(app, 52.dp, true, { onLaunch(app) }, { onMenu(app) })
                    }
                }
            }
            Gap(14)
            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                Box(
                    Modifier.clip(CircleShape).clickable {
                        state.gestureEditor = GestureTarget("f", folder.key, folder.name.ifBlank { "Folder" })
                        onClose()
                    }.padding(horizontal = 10.dp, vertical = 8.dp),
                ) { Text("Gestures", color = Eon.Accent, fontSize = 14.sp, fontWeight = FontWeight.Medium) }
                Box(
                    Modifier.clip(CircleShape).clickable { pickingIcon = true }
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                ) { Text("Change icon", color = Eon.Accent, fontSize = 14.sp, fontWeight = FontWeight.Medium) }
                Box(
                    Modifier.clip(CircleShape).clickable { state.disbandFolder(folder.key) }
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                ) { Text("Remove folder", color = Eon.Muted, fontSize = 14.sp, fontWeight = FontWeight.Medium) }
            }
        }
        if (pickingIcon) FolderIconDialog(state, folder, apps) { pickingIcon = false }
    }
}
