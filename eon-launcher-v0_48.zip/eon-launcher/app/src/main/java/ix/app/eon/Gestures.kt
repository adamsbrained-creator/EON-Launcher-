package ix.app.eon

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** What the double tap and the swipes on empty space on the home screen do. Swipe up opens the drawer unless you change it. */
object GestureConfig {
    var doubleTap by mutableStateOf(Act.NONE)
    var swipeDown by mutableStateOf(Act.NOTIF)
    var swipeUp by mutableStateOf(Act.DRAWER)
    var twoUp by mutableStateOf(Act.NONE)
    var twoDown by mutableStateOf(Act.NONE)

    private fun read(p: Prefs, key: String, legacyKey: String, legacyDef: Int): String {
        val s = p.getString(key)
        return if (s.isNotEmpty()) s else Act.fromLegacy(p.getInt(legacyKey, legacyDef))
    }

    fun load(p: Prefs) {
        doubleTap = read(p, "gestureDoubleS", "gestureDouble", 0)
        swipeDown = read(p, "gestureDownS", "gestureDown", 4)
        swipeUp = p.getString("gestureUpS").ifEmpty { Act.DRAWER }
        twoUp = p.getString("gestureTwoUpS").ifEmpty { Act.NONE }
        twoDown = p.getString("gestureTwoDownS").ifEmpty { Act.NONE }
    }

    fun save(p: Prefs) {
        p.putString("gestureDoubleS", doubleTap)
        p.putString("gestureDownS", swipeDown)
        p.putString("gestureUpS", swipeUp)
        p.putString("gestureTwoUpS", twoUp)
        p.putString("gestureTwoDownS", twoDown)
    }
}

/** Needed so Eon can lock the screen. Android asks the user to turn it on the first time. */
class EonAdminReceiver : DeviceAdminReceiver()

/** Locks the screen. The first time, opens Android's screen to make Eon a device administrator. */
fun lockScreen(ctx: Context) {
    try {
        val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val admin = ComponentName(ctx, EonAdminReceiver::class.java)
        if (dpm.isAdminActive(admin)) {
            dpm.lockNow()
        } else {
            ctx.startActivity(
                Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
                    .putExtra(
                        DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                        "Eon only uses this to lock the screen when you use the lock gesture.",
                    )
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
        }
    } catch (_: Exception) {
    }
}
