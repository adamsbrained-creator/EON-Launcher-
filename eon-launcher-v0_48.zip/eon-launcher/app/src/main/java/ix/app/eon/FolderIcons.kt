package ix.app.eon

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

private val FOLDER_COLORS = listOf(
    0xFF35D6F0.toInt(), 0xFF4F8CFF.toInt(), 0xFF9B7BFF.toInt(), 0xFFF25CCB.toInt(), 0xFFFF7A66.toInt(),
    0xFFFFA63D.toInt(), 0xFF4CD98A.toInt(), 0xFF2A2A2E.toInt(), 0xFFF5F5F6.toInt(),
)

private val FOLDER_EMOJI = listOf(
    "📁", "⭐", "❤️", "🔥", "🎮", "🎵", "🎬", "📷", "📚", "💼", "🛒", "✈️", "🏠", "💰", "🍔", "☕",
    "⚽", "🚗", "🔒", "🧰", "🎨", "📱", "💬", "🌍", "🎓", "🏋️", "🩺", "🌙", "☀️", "🍿", "🎧", "📰",
)

/** Crops the picture to a square, shrinks it and keeps it in the app's own files. Returns the path, or null. */
fun saveFolderImage(ctx: Context, key: String, uri: Uri): String? {
    try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 1024 || bounds.outHeight / sample > 1024) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
        val side = minOf(bmp.width, bmp.height)
        val square = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
        val small = Bitmap.createScaledBitmap(square, 384, 384, true)
        val dir = File(ctx.filesDir, "folder-icons").apply { mkdirs() }
        dir.listFiles()?.filter { it.name.startsWith("$key-") }?.forEach { it.delete() }
        val file = File(dir, "$key-${System.currentTimeMillis()}.png")
        FileOutputStream(file).use { small.compress(Bitmap.CompressFormat.PNG, 100, it) }
        return file.absolutePath
    } catch (_: Exception) {
        return null
    }
}

/**
 * Choose what a folder looks like: a symbol, an emoji or a photo of your own, on a colour you pick.
 * Every choice shows at once on the folder; "Default" brings back the preview of the apps inside.
 */
@Composable
fun FolderIconDialog(
    state: EonState, folder: Item, apps: List<AppEntry>,
    onChange: (kind: String, value: String, color: Int) -> Unit = { k, v, c -> state.setFolderIcon(folder.key, k, v, c) },
    onDismiss: () -> Unit,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(if (folder.iconKind == "emoji") 1 else if (folder.iconKind == "image") 2 else 0) }
    var typed by remember { mutableStateOf("") }
    val glyphs = remember { CAT_ICONS.keys.toList() }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                val path = withContext(Dispatchers.IO) { saveFolderImage(ctx, folder.key, uri) }
                if (path != null) onChange("image", path, folder.iconColor)
            }
        }
    }
    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier.width(330.dp).glass(RoundedCornerShape(28.dp)).padding(horizontal = 18.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("Folder icon", color = Eon.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Gap(14)
            FolderIconBody(folder, apps, 72.dp, false)
            Gap(14)
            // Tabs
            Row(
                Modifier.fillMaxWidth().clip(CircleShape).background(Color(0x1FFFFFFF)).padding(3.dp),
                horizontalArrangement = Arrangement.spacedBy(3.dp),
            ) {
                listOf("Symbol", "Emoji", "Photo").forEachIndexed { i, label ->
                    Box(
                        Modifier.weight(1f).clip(CircleShape).accentFill(tab == i, Color.Transparent)
                            .clickable { tab = i }.padding(vertical = 9.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            label, color = if (tab == i) Eon.OnAccent else Eon.Soft, fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                        )
                    }
                }
            }
            Gap(12)
            when (tab) {
                0 -> LazyVerticalGrid(
                    columns = GridCells.Fixed(6),
                    modifier = Modifier.heightIn(max = 190.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(glyphs, key = { it }) { g ->
                        val on = folder.iconKind == "glyph" && folder.iconValue == g
                        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Box(
                                Modifier.size(40.dp).clip(CircleShape).accentFill(on, Color(0x1FFFFFFF))
                                    .clickable { onChange("glyph", g, folder.iconColor) },
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(catIcon(g), null, tint = if (on) Eon.OnAccent else Eon.Text, modifier = Modifier.size(20.dp))
                            }
                        }
                    }
                }
                1 -> Column {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(8),
                        modifier = Modifier.heightIn(max = 150.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        items(FOLDER_EMOJI, key = { it }) { e ->
                            Box(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                                    .clickable { onChange("emoji", e, folder.iconColor) }
                                    .padding(vertical = 4.dp),
                                contentAlignment = Alignment.Center,
                            ) { Text(e, fontSize = 20.sp) }
                        }
                    }
                    Gap(10)
                    Box(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0x1FFFFFFF))
                            .padding(horizontal = 14.dp, vertical = 11.dp),
                    ) {
                        if (typed.isEmpty()) Text("Or type any emoji", color = Eon.Faint, fontSize = 15.sp)
                        BasicTextField(
                            value = typed,
                            onValueChange = {
                                typed = it.take(6)
                                if (typed.isNotBlank()) onChange("emoji", typed.trim(), folder.iconColor)
                            },
                            singleLine = true,
                            textStyle = TextStyle(color = Eon.Text, fontSize = 15.sp),
                            cursorBrush = SolidColor(Eon.Accent),
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
                else -> Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        "Pick any picture. Eon crops it to a square.", color = Eon.Muted, fontSize = 13.sp,
                        textAlign = TextAlign.Center,
                    )
                    Gap(12)
                    Box(
                        Modifier.clip(CircleShape).background(Eon.Button)
                            .clickable { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
                            .padding(horizontal = 22.dp, vertical = 11.dp),
                    ) { Text("Choose a photo", color = Eon.OnAccent, fontSize = 14.sp, fontWeight = FontWeight.Bold) }
                }
            }
            Gap(14)
            Text("Colour", color = Eon.Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.Start))
            Gap(8)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                // First swatch: no colour, the default glass.
                Box(
                    Modifier.size(26.dp).clip(CircleShape).background(Color(0x40FFFFFF))
                        .border(if (folder.iconColor == 0) 2.dp else 1.dp, if (folder.iconColor == 0) SolidColor(Eon.Text) else SolidColor(Color(0x44FFFFFF)), CircleShape)
                        .clickable { onChange(folder.iconKind, folder.iconValue, 0) },
                )
                FOLDER_COLORS.forEach { c ->
                    Box(
                        Modifier.size(26.dp).clip(CircleShape).background(Color(c))
                            .border(if (folder.iconColor == c) 2.dp else 0.dp, if (folder.iconColor == c) SolidColor(Eon.Text) else SolidColor(Color.Transparent), CircleShape)
                            .clickable { onChange(folder.iconKind, folder.iconValue, c) },
                    )
                }
            }
            Gap(16)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Default", color = Eon.Muted, fontSize = 14.sp, fontWeight = FontWeight.Medium,
                    modifier = Modifier.clip(CircleShape).clickable { onChange("", "", 0) }
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                )
                Box(
                    Modifier.clip(CircleShape).background(Eon.Button).clickable(onClick = onDismiss)
                        .padding(horizontal = 24.dp, vertical = 10.dp),
                ) { Text("Done", color = Eon.OnAccent, fontSize = 14.sp, fontWeight = FontWeight.Bold) }
            }
        }
    }
}
