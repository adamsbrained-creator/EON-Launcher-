package ix.app.eon

import android.content.ComponentName
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.LauncherActivityInfo
import android.content.pm.LauncherApps
import android.graphics.Bitmap
import android.os.UserHandle
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import android.graphics.BitmapFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.ConcurrentHashMap

/**
 * Words that put an app in a category by its package name or label. Matching is loose on purpose: an app can
 * fit several categories. Favorites and your own categories are never filled this way.
 */
private val KEYWORDS: List<Pair<String, List<String>>> = listOf(
    "contacts" to listOf("dialer", "contact", "messag", "mms", "sms"),
    "internet" to listOf("browser", "chrome", "firefox", "brave", "opera", "vivaldi", "duckduckgo", "msedge"),
    "photography" to listOf("camera", "gallery", "photos", "snapseed", "lightroom"),
    "music" to listOf("music", "spotify", "podcast", "radio", "soundcloud", "deezer", "shazam"),
    "entertainment" to listOf("netflix", "youtube", "twitch", "disney", "hbo", "movie", "cinema", "plex", "kodi"),
    "weather" to listOf("weather", "meteo"),
    "finance" to listOf("bank", "wallet", "paypal", "revolut", "finance", "invest", "crypto", "money"),
    "fitness" to listOf("fitness", "health", "workout", "strava", "gym", "steps"),
    "medical" to listOf("medic", "pharma", "doctor", "clinic"),
    "navigation" to listOf("maps", "navigation", "waze", "transit", "citymapper"),
    "shopping" to listOf("shop", "amazon", "ebay", "aliexpress", "etsy", "zalando"),
    "travel" to listOf("booking", "airbnb", "flight", "hotel", "skyscanner", "uber", "trainline", "airline"),
    "education" to listOf("duolingo", "khan", "coursera", "udemy", "dictionary", "translate", "quizlet", "anki"),
    "lifestyle" to listOf("recipe", "food", "restaurant", "delivery", "fashion", "dating", "cooking"),
    "personalization" to listOf("wallpaper", "launcher", "theme", "widget"),
    "reading" to listOf("kindle", "book", "news"),
    "productivity" to listOf("calendar", "note", "docs", "sheets", "slides", "office", "drive", "gmail", "outlook", "todo", "task"),
    "social" to listOf("whatsapp", "telegram", "instagram", "facebook", "twitter", "reddit", "snapchat", "tiktok", "discord", "signal", "messenger", "linkedin", "mastodon", "bluesky"),
    "games" to listOf("game", "puzzle"),
    "tools" to listOf("calculator", "clock", "flashlight", "files", "documentsui", "recorder", "scanner", "vpn", "backup"),
)

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("eon", Context.MODE_PRIVATE)

    fun getString(key: String): String = sp.getString(key, "") ?: ""
    fun putString(key: String, v: String) { sp.edit().putString(key, v).apply() }
    fun getInt(key: String, def: Int): Int = sp.getInt(key, def)
    fun putInt(key: String, v: Int) { sp.edit().putInt(key, v).apply() }
    fun getFloat(key: String, def: Float): Float = sp.getFloat(key, def)
    fun putFloat(key: String, v: Float) { sp.edit().putFloat(key, v).apply() }
    fun getBool(key: String, def: Boolean): Boolean = sp.getBoolean(key, def)
    fun putBool(key: String, v: Boolean) { sp.edit().putBoolean(key, v).apply() }

    var onboarded: Boolean
        get() = sp.getBoolean("onboarded", false)
        set(v) { sp.edit().putBoolean("onboarded", v).apply() }

    /** "glassy" or "flat" */
    var look: String
        get() = sp.getString("look", "glassy") ?: "glassy"
        set(v) { sp.edit().putString("look", v).apply() }

    /** "dark", "light", "auto" (follow the phone's dark mode) or "schedule" (light between [themeFrom] and [themeTo]). */
    var theme: String
        get() = sp.getString("theme", "dark") ?: "dark"
        set(v) { sp.edit().putString("theme", v).apply() }

    /** Schedule theme: the hour (0 to 23) the light theme starts, and the hour it ends. */
    var themeFrom: Int
        get() = sp.getInt("themeFrom", 7).coerceIn(0, 23)
        set(v) { sp.edit().putInt("themeFrom", v.coerceIn(0, 23)).apply() }
    var themeTo: Int
        get() = sp.getInt("themeTo", 19).coerceIn(0, 23)
        set(v) { sp.edit().putInt("themeTo", v.coerceIn(0, 23)).apply() }

    /** Component names of apps pinned to the home screen, in order. */
    var pinned: List<String>
        get() = (sp.getString("pinned", "") ?: "").split("\n").filter { it.isNotBlank() }
        set(v) { sp.edit().putString("pinned", v.joinToString("\n")).apply() }

    /** Home pages as JSON: [{"pinned":[...],"widgets":[...]}]. Empty means "not migrated yet". */
    var pagesJson: String
        get() = sp.getString("pages", "") ?: ""
        set(v) { sp.edit().putString("pages", v).apply() }

    /** App widget ids shown on the home screen, in order. */
    var widgets: List<Int>
        get() = (sp.getString("widgets", "") ?: "").split(",").mapNotNull { it.trim().toIntOrNull() }
        set(v) { sp.edit().putString("widgets", v.joinToString(",")).apply() }

    /** Where the search pill sits, as a share of the grid's width and height (Y -1 = the default spot at the bottom). */
    var searchX: Float
        get() = sp.getFloat("searchX", 0.5f)
        set(v) { sp.edit().putFloat("searchX", v).apply() }
    var searchY: Float
        get() = sp.getFloat("searchY", -1f)
        set(v) { sp.edit().putFloat("searchY", v).apply() }
    var searchHidden: Boolean
        get() = sp.getBoolean("searchHidden", false)
        set(v) { sp.edit().putBoolean("searchHidden", v).apply() }

    /** Apps can be dropped anywhere on the home screen instead of on grid cells. */
    var freeIcons: Boolean
        get() = sp.getBoolean("freeIcons", false)
        set(v) { sp.edit().putBoolean("freeIcons", v).apply() }

    /** Snap widgets to whole grid cells while editing them. */
    var snapToGrid: Boolean
        get() = sp.getBoolean("snap", true)
        set(v) { sp.edit().putBoolean("snap", v).apply() }

    /** Package names hidden from the drawer. */
    var hidden: Set<String>
        get() = sp.getStringSet("hidden", emptySet()) ?: emptySet()
        set(v) { sp.edit().putStringSet("hidden", HashSet(v)).apply() }

    /** Manual category per package. */
    var overrides: Map<String, String>
        get() = (sp.getStringSet("cats", emptySet()) ?: emptySet()).mapNotNull {
            val i = it.indexOf('|')
            if (i > 0) it.substring(0, i) to it.substring(i + 1) else null
        }.toMap()
        set(v) { sp.edit().putStringSet("cats", v.map { "${it.key}|${it.value}" }.toHashSet()).apply() }
}

data class AppEntry(
    val label: String,
    val packageName: String,
    val component: ComponentName,
    val user: UserHandle,
    val icon: ImageBitmap,
    /** The main category Eon found: social, media, games, productivity, reading, navigation, tools or other. */
    val autoCategory: String,
    /** Every category Eon thinks the app fits (the main one plus matches by name). */
    val autoCategories: Set<String>,
    /** When the app was first installed (milliseconds), for the App Library's "Recently added" folder. */
    val firstInstall: Long = 0L,
    /** Your own size for this icon (1.0 is normal), see Change icon > Icon size. */
    val iconScale: Float = 1f,
    /** The name the app has on its own, before you renamed it. Search looks at both. */
    val originalLabel: String = "",
) {
    val key: String = component.flattenToString()
}

class AppRepo(private val context: Context) {
    companion object {
        private const val CACHE_DIR = "app-icons"
        private const val CACHE_VERSION = 1

        /** The last app list. Eon shows it the moment it opens, while the fresh one loads. */
        @Volatile var last: List<AppEntry> = emptyList()

        private val iconCache = ConcurrentHashMap<String, Pair<String, ImageBitmap>>()
    }

    private val launcherApps =
        context.getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps

    /** The app's main category, and every category it also fits. */
    private fun categoriesOf(pkg: String, label: String): Pair<String, Set<String>> {
        val info = try {
            context.packageManager.getApplicationInfo(pkg, 0)
        } catch (_: Exception) {
            return "other" to setOf("other")
        }
        val extra = LinkedHashSet<String>()
        val main = when (info.category) {
            ApplicationInfo.CATEGORY_SOCIAL -> "social"
            ApplicationInfo.CATEGORY_AUDIO -> {
                extra.add("music")
                "media"
            }
            ApplicationInfo.CATEGORY_VIDEO -> "media"
            ApplicationInfo.CATEGORY_IMAGE -> {
                extra.add("photography")
                "media"
            }
            ApplicationInfo.CATEGORY_GAME -> "games"
            ApplicationInfo.CATEGORY_PRODUCTIVITY -> "productivity"
            ApplicationInfo.CATEGORY_NEWS -> "reading"
            ApplicationInfo.CATEGORY_MAPS -> "navigation"
            else -> if (info.flags and ApplicationInfo.FLAG_SYSTEM != 0) "tools" else "other"
        }
        val hay = "$pkg $label".lowercase()
        for ((id, words) in KEYWORDS) {
            if (words.any { hay.contains(it) }) extra.add(id)
        }
        val all = LinkedHashSet<String>()
        // "Other" only when nothing better was found.
        if (!(main == "other" && extra.isNotEmpty())) all.add(main)
        all.addAll(extra)
        return main to all
    }

    /**
     * Builds the app list. Icons are the slow part (each one is drawn and cut to the shape), so:
     *  - an icon that was already built with the same settings is reused from memory;
     *  - otherwise it is read from the disk cache, which survives Eon being closed by Android;
     *  - only what is still missing is drawn, several at a time.
     */
    suspend fun load(): List<AppEntry> = withContext(Dispatchers.Default) {
        // Big enough for the largest home screen icon size (84 dp), so changing the size never makes icons blurry.
        val px = (context.resources.displayMetrics.density * 84f).toInt().coerceAtLeast(128)
        val pack = IconPacks.active(context)
        val packStamp = if (pack != null) packStamp(pack.pkg) else 0L
        val dir = File(context.cacheDir, CACHE_DIR).also { it.mkdirs() }
        val fresh = ConcurrentHashMap<String, Boolean>()

        val infos = launcherApps.profiles.flatMap { user ->
            launcherApps.getActivityList(null, user).map { user to it }
        }.filter { (_, info) -> info.componentName.packageName != context.packageName }

        val list = coroutineScope {
            infos.map { (user, info) ->
                async {
                    val cn = info.componentName
                    val pkg = cn.packageName
                    val key = cn.flattenToString()
                    val original = info.label.toString()
                    val (main, matches) = categoriesOf(pkg, original)
                    val sig = signature(info, user, px, pack, packStamp)
                    val file = File(dir, fileName(key, user, sig))
                    fresh[file.name] = true
                    val icon = iconCache[key]?.takeIf { it.first == sig }?.second
                        ?: readDisk(file)?.asImageBitmap()
                        ?: buildIcon(info, px, pack).also { writeDisk(file, it) }.asImageBitmap()
                    iconCache[key] = sig to icon
                    AppEntry(
                        // Your own name, if you gave the app one. Categories still go by the real name.
                        label = IconCustom.labelFor(key) ?: original,
                        packageName = pkg,
                        component = cn,
                        user = user,
                        icon = icon,
                        autoCategory = main,
                        autoCategories = matches,
                        firstInstall = try {
                            info.firstInstallTime
                        } catch (_: Exception) {
                            0L
                        },
                        iconScale = IconCustom.scaleFor(key),
                        originalLabel = original,
                    )
                }
            }.awaitAll()
        }.sortedBy { it.label.lowercase() }

        last = list
        // Forget icons of apps that are gone, and cache files nobody asks for any more.
        val keys = list.mapTo(HashSet()) { it.key }
        iconCache.keys.retainAll(keys)
        dir.listFiles()?.forEach { if (fresh[it.name] != true) it.delete() }
        list
    }

    /** Everything that changes how an app's icon looks. When this is the same, the icon is the same. */
    private fun signature(info: LauncherActivityInfo, user: UserHandle, px: Int, pack: IconPack?, packStamp: Long): String {
        val key = info.componentName.flattenToString()
        val updated = try {
            File(info.applicationInfo.sourceDir).lastModified()
        } catch (_: Exception) {
            0L
        }
        return listOf(
            CACHE_VERSION, px, IconShaper.shapeIndex, IconStyle.signature(), IconAuto.signature(), updated, user.hashCode(),
            pack?.pkg.orEmpty(), packStamp, IconCustom.reshapePack, IconCustom.iconSpec(key).orEmpty(),
        ).joinToString("|")
    }

    private fun packStamp(pkg: String): Long = try {
        context.packageManager.getPackageInfo(pkg, 0).lastUpdateTime
    } catch (_: Exception) {
        0L
    }

    private fun fileName(key: String, user: UserHandle, sig: String): String =
        Integer.toHexString("$key|${user.hashCode()}".hashCode()) + "_" + Integer.toHexString(sig.hashCode()) + ".webp"

    private fun readDisk(file: File): Bitmap? = try {
        if (file.exists()) BitmapFactory.decodeFile(file.absolutePath) else null
    } catch (_: Exception) {
        null
    } catch (_: OutOfMemoryError) {
        null
    }

    private fun writeDisk(file: File, bmp: Bitmap) {
        try {
            val tmp = File(file.parentFile, file.name + ".tmp")
            FileOutputStream(tmp).use { bmp.compress(Bitmap.CompressFormat.WEBP_LOSSLESS, 100, it) }
            if (!tmp.renameTo(file)) tmp.delete()
        } catch (_: Exception) {
        }
    }

    /** The icon to show: the one you picked, else the icon pack's, else the app's own cut to the Eon shape. */
    private fun buildIcon(info: LauncherActivityInfo, px: Int, pack: IconPack?): Bitmap =
        IconAuto.apply(buildIconRaw(info, px, pack), px)

    private fun buildIconRaw(info: LauncherActivityInfo, px: Int, pack: IconPack?): Bitmap {
        val cn = info.componentName
        IconCustom.iconSpec(cn.flattenToString())?.let { spec ->
            IconCustom.bitmapFor(context, spec, px)?.let { return it }
        }
        if (pack != null) {
            pack.iconFor(cn)?.let { d ->
                return if (IconCustom.reshapePack) IconShaper.shape(d, px) else IconShaper.plain(d, px)
            }
            pack.fallback(info.getBadgedIcon(0), px, cn.packageName)?.let { return it }
        }
        return IconShaper.shape(info.getBadgedIcon(0), px)
    }

    /** Opens [app]. A locked app (see [AppLock]) asks for your fingerprint or screen lock first. */
    fun launch(app: AppEntry) = AppLock.guard(app) { launchNow(app) }

    private fun launchNow(app: AppEntry) {
        Haptics.tap()
        Usage.record(app.key)
        // The app opens from the icon you touched: it grows out of that spot, like on iOS.
        val view = LaunchOrigin.view
        var bounds: android.graphics.Rect? = null
        var options: android.os.Bundle? = null
        try {
            if (view != null && LaunchOrigin.half > 0) {
                val h = LaunchOrigin.half
                bounds = android.graphics.Rect(LaunchOrigin.x - h, LaunchOrigin.y - h, LaunchOrigin.x + h, LaunchOrigin.y + h)
                options = android.app.ActivityOptions.makeScaleUpAnimation(view, bounds.left, bounds.top, h * 2, h * 2).toBundle()
            }
        } catch (_: Exception) {
            bounds = null
            options = null
        }
        try {
            launcherApps.startMainActivity(app.component, app.user, bounds, options)
        } catch (_: Exception) {
            try {
                launcherApps.startMainActivity(app.component, app.user, null, null)
            } catch (_: Exception) {
            }
        }
    }

    /**
     * Opens two apps side by side. Best effort, because Android has no plain call for it: the first app opens, the Eon gesture
     * helper (when it is on) asks the system for split screen, and the second app is then asked to open beside it.
     */
    fun launchPair(a: AppEntry, b: AppEntry) {
        AppLock.guard(a) { AppLock.guard(b) { launchPairNow(a, b) } }
    }

    private fun launchPairNow(a: AppEntry, b: AppEntry) {
        Usage.record(a.key)
        Usage.record(b.key)
        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        try {
            launcherApps.startMainActivity(a.component, a.user, null, null)
        } catch (_: Exception) {
        }
        handler.postDelayed({
            val helper = EonAccessibilityService.run(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_TOGGLE_SPLIT_SCREEN)
            handler.postDelayed({
                try {
                    val intent = android.content.Intent(android.content.Intent.ACTION_MAIN)
                        .addCategory(android.content.Intent.CATEGORY_LAUNCHER)
                        .setComponent(b.component)
                        .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT)
                    context.startActivity(intent)
                } catch (_: Exception) {
                }
                if (!helper) {
                    android.widget.Toast.makeText(
                        context, "For split screen, turn on the Eon gesture helper in Settings > Gestures", android.widget.Toast.LENGTH_LONG,
                    ).show()
                }
            }, 700L)
        }, 900L)
    }

    /** Calls [onChange] when apps are installed, removed or updated. Returns an unregister function. */
    fun watch(onChange: () -> Unit): () -> Unit {
        val callback = object : LauncherApps.Callback() {
            override fun onPackageRemoved(packageName: String, user: UserHandle) = onChange()
            override fun onPackageAdded(packageName: String, user: UserHandle) = onChange()
            override fun onPackageChanged(packageName: String, user: UserHandle) = onChange()
            override fun onPackagesAvailable(
                packageNames: Array<out String>, user: UserHandle, replacing: Boolean,
            ) = onChange()
            override fun onPackagesUnavailable(
                packageNames: Array<out String>, user: UserHandle, replacing: Boolean,
            ) = onChange()
        }
        launcherApps.registerCallback(callback)
        return { launcherApps.unregisterCallback(callback) }
    }
}

/** Where the last touch was, so an app opens out of the icon that was tapped. Home keeps it current. */
object LaunchOrigin {
    var view: android.view.View? = null
    var x = 0
    var y = 0
    /** Half the size of the opening square, in pixels. */
    var half = 0
}
