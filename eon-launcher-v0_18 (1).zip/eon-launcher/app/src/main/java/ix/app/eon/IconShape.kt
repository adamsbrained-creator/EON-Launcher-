package ix.app.eon

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap

/** How big an app icon is drawn on the home screen and in the drawer. */
val ICON_SIZE: Dp = 60.dp

/**
 * Corner radius as a share of the icon's side. Measured from the Smart Launcher screenshots:
 * a plain rounded square with round corners of about 26% of the side.
 */
const val ICON_CORNER = 0.26f

private val PlateLight = Color.rgb(245, 245, 246)
private val PlateDark = Color.rgb(27, 28, 31)

/**
 * Turns any app icon into the same rounded square, so the whole grid looks uniform:
 * - adaptive icons are drawn full size and cut to the shape;
 * - old square-ish icons that fill their frame are cut to the shape;
 * - old icons with a transparent margin are centred on a light or dark plate.
 */
object IconShaper {
    fun shape(src: Drawable, px: Int): Bitmap {
        val content = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val c = Canvas(content)
        if (src is AdaptiveIconDrawable) {
            val bg = src.background
            if (bg == null) c.drawColor(PlateDark)
            // Adaptive layers are 108dp wide but only the middle 72dp is visible.
            val inset = (px * 0.25f).toInt()
            bg?.let { it.setBounds(-inset, -inset, px + inset, px + inset); it.draw(c) }
            src.foreground?.let { it.setBounds(-inset, -inset, px + inset, px + inset); it.draw(c) }
        } else {
            val glyph = src.toBitmap(px, px)
            val (edge, light) = measure(glyph)
            if (edge >= 0.9f) {
                c.drawBitmap(glyph, 0f, 0f, null)
            } else {
                c.drawColor(if (light < 0.6f) PlateLight else PlateDark)
                val pad = px * 0.14f
                c.drawBitmap(glyph, null, RectF(pad, pad, px - pad, px - pad), Paint(Paint.FILTER_BITMAP_FLAG))
            }
        }
        // Cut the shape with a shader so the edge is smooth.
        val out = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = BitmapShader(content, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        }
        val r = px * ICON_CORNER
        Canvas(out).drawRoundRect(RectF(0f, 0f, px.toFloat(), px.toFloat()), r, r, paint)
        content.recycle()
        return out
    }

    /** Returns (how opaque the outer edge is, 0..1; how light the visible pixels are, 0..1). */
    private fun measure(bmp: Bitmap): Pair<Float, Float> {
        val n = 24
        val small = Bitmap.createScaledBitmap(bmp, n, n, true)
        var edgeAlpha = 0f
        var edgeCount = 0
        var lum = 0f
        var weight = 0f
        for (y in 0 until n) for (x in 0 until n) {
            val p = small.getPixel(x, y)
            val a = Color.alpha(p) / 255f
            if (x == 0 || y == 0 || x == n - 1 || y == n - 1) {
                edgeAlpha += a
                edgeCount++
            }
            lum += a * (0.299f * Color.red(p) + 0.587f * Color.green(p) + 0.114f * Color.blue(p)) / 255f
            weight += a
        }
        if (small !== bmp) small.recycle()
        return (edgeAlpha / edgeCount) to (if (weight > 0f) lum / weight else 0.5f)
    }
}
