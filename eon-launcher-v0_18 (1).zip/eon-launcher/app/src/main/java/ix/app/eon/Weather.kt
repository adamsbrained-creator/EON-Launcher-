package ix.app.eon

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

const val W_WEATHER = -3

/** Latest weather, in degrees Celsius. */
object WeatherState {
    var temp by mutableStateOf<Int?>(null)
    var feels by mutableStateOf<Int?>(null)
    var code by mutableIntStateOf(-1)
    var isDay by mutableStateOf(true)
    var note by mutableStateOf("")
    var cacheLoaded = false
}

private fun prefsOf(ctx: Context) = ctx.getSharedPreferences("eon", Context.MODE_PRIVATE)

fun loadCachedWeather(ctx: Context) {
    if (WeatherState.cacheLoaded) return
    WeatherState.cacheLoaded = true
    val p = prefsOf(ctx)
    if (p.contains("w_temp")) {
        WeatherState.temp = p.getInt("w_temp", 0)
        WeatherState.feels = p.getInt("w_feels", 0)
        WeatherState.code = p.getInt("w_code", -1)
        WeatherState.isDay = p.getBoolean("w_day", true)
    }
}

private fun lastLocation(ctx: Context): Pair<Double, Double>? {
    if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION)
        != PackageManager.PERMISSION_GRANTED
    ) return null
    val p = prefsOf(ctx)
    val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    val best = listOf(LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
        .mapNotNull { provider -> try { lm.getLastKnownLocation(provider) } catch (_: Exception) { null } }
        .maxByOrNull { it.time }
    if (best != null) {
        p.edit().putFloat("w_lat", best.latitude.toFloat()).putFloat("w_lon", best.longitude.toFloat()).apply()
        return best.latitude to best.longitude
    }
    return if (p.contains("w_lat")) p.getFloat("w_lat", 0f).toDouble() to p.getFloat("w_lon", 0f).toDouble() else null
}

private fun hasLocationPermission(ctx: Context): Boolean =
    ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

/** Asks the phone for a fresh coarse fix when it has no saved one. */
private suspend fun freshLocation(ctx: Context): Pair<Double, Double>? {
    if (!hasLocationPermission(ctx)) return null
    val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    return withTimeoutOrNull(12_000L) {
        suspendCancellableCoroutine<Pair<Double, Double>?> { cont ->
            try {
                if (!lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                    cont.resume(null)
                } else {
                    lm.getCurrentLocation(LocationManager.NETWORK_PROVIDER, null, ctx.mainExecutor) { loc ->
                        if (cont.isActive) cont.resume(loc?.let { it.latitude to it.longitude })
                    }
                }
            } catch (_: Exception) {
                if (cont.isActive) cont.resume(null)
            }
        }
    }
}

/** Asks Open-Meteo (no account needed) for the weather at the phone's coarse location. */
suspend fun refreshWeather(ctx: Context) = withContext(Dispatchers.IO) {
    if (!hasLocationPermission(ctx)) {
        WeatherState.note = "Allow location"
        return@withContext
    }
    val where = lastLocation(ctx) ?: freshLocation(ctx)?.also { (la, lo) ->
        prefsOf(ctx).edit().putFloat("w_lat", la.toFloat()).putFloat("w_lon", lo.toFloat()).apply()
    }
    if (where == null) {
        if (WeatherState.temp == null) WeatherState.note = "No location fix"
        return@withContext
    }
    try {
        val lat = "%.2f".format(Locale.US, where.first)
        val lon = "%.2f".format(Locale.US, where.second)
        val url = URL(
            "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                "&current=temperature_2m,apparent_temperature,weather_code,is_day&timezone=auto",
        )
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = 8000
        conn.readTimeout = 8000
        val text = try {
            conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
        val cur = JSONObject(text).getJSONObject("current")
        val t = cur.getDouble("temperature_2m").roundToInt()
        val f = cur.getDouble("apparent_temperature").roundToInt()
        val c = cur.getInt("weather_code")
        val d = cur.getInt("is_day") == 1
        WeatherState.temp = t
        WeatherState.feels = f
        WeatherState.code = c
        WeatherState.isDay = d
        WeatherState.note = ""
        prefsOf(ctx).edit().putInt("w_temp", t).putInt("w_feels", f).putInt("w_code", c).putBoolean("w_day", d).apply()
    } catch (_: Exception) {
        if (WeatherState.temp == null) WeatherState.note = "No connection"
    }
}

private fun polygon(s: Float, dy: Float, vararg xy: Float): Path = Path().apply {
    moveTo(xy[0] * s, (xy[1] + dy) * s)
    var i = 2
    while (i < xy.size) {
        lineTo(xy[i] * s, (xy[i + 1] + dy) * s)
        i += 2
    }
    close()
}

/** Weather icon drawn with straight lines, in Eon's angular style. */
@Composable
fun WeatherIcon(code: Int, isDay: Boolean, size: Dp) {
    val color = Color.White
    Canvas(Modifier.size(size)) {
        val s = this.size.minDimension
        val w = s * 0.07f
        val stroke = Stroke(width = w, miter = 10f, cap = StrokeCap.Butt, join = StrokeJoin.Miter)
        fun cloud(dy: Float) = polygon(
            s, dy, 0.12f, 0.70f, 0.08f, 0.52f, 0.24f, 0.44f, 0.32f, 0.28f,
            0.56f, 0.24f, 0.68f, 0.40f, 0.88f, 0.48f, 0.92f, 0.70f,
        )
        when {
            code == 0 && isDay -> {
                val c = Offset(s / 2, s / 2)
                drawCircle(color, radius = s * 0.18f, center = c, style = stroke)
                for (i in 0 until 8) {
                    val a = i * PI.toFloat() / 4f
                    drawLine(
                        color,
                        Offset(c.x + cos(a) * s * 0.30f, c.y + sin(a) * s * 0.30f),
                        Offset(c.x + cos(a) * s * 0.44f, c.y + sin(a) * s * 0.44f),
                        strokeWidth = w,
                    )
                }
            }
            code == 0 -> drawPath(
                polygon(
                    s, 0f, 0.60f, 0.18f, 0.40f, 0.26f, 0.28f, 0.44f, 0.30f, 0.64f,
                    0.44f, 0.80f, 0.64f, 0.84f, 0.80f, 0.74f, 0.62f, 0.70f, 0.52f, 0.56f, 0.52f, 0.40f,
                ),
                color, style = stroke,
            )
            code == 45 || code == 48 -> for (i in 0..2) {
                val y = (0.34f + i * 0.17f) * s
                drawLine(color, Offset(0.14f * s, y), Offset(0.86f * s, y), strokeWidth = w)
            }
            code in 51..67 || code in 80..82 -> {
                drawPath(cloud(-0.12f), color, style = stroke)
                for (i in 0..2) {
                    drawLine(
                        color,
                        Offset((0.32f + i * 0.18f) * s, 0.74f * s),
                        Offset((0.26f + i * 0.18f) * s, 0.90f * s),
                        strokeWidth = w,
                    )
                }
            }
            code in 71..77 || code in 85..86 -> {
                drawPath(cloud(-0.12f), color, style = stroke)
                for (i in 0..2) {
                    drawRect(color, Offset((0.28f + i * 0.18f) * s, 0.78f * s), Size(w * 1.2f, w * 1.2f))
                }
            }
            code >= 95 -> {
                drawPath(cloud(-0.14f), color, style = stroke)
                drawPath(
                    polygon(s, 0f, 0.52f, 0.62f, 0.38f, 0.84f, 0.50f, 0.84f, 0.45f, 0.99f, 0.66f, 0.74f, 0.55f, 0.74f),
                    color,
                )
            }
            else -> drawPath(cloud(0f), color, style = stroke)
        }
        Unit
    }
}

private class Quote(val text: String, val author: String)

private val QUOTES = listOf(
    Quote("Don’t sidestep suffering. You have to go through it to get where you’re going.", "Katherine Anne Porter"),
    Quote("The best way out is always through.", "Robert Frost"),
    Quote("Lost time is never found again.", "Benjamin Franklin"),
    Quote("Time is what we want most, but what we use worst.", "William Penn"),
    Quote("We are what we repeatedly do. Excellence, then, is not an act, but a habit.", "Will Durant"),
    Quote("The journey of a thousand miles begins with a single step.", "Lao Tzu"),
    Quote("The unexamined life is not worth living.", "Socrates"),
    Quote("Courage is grace under pressure.", "Ernest Hemingway"),
)

/** Weather on the left, a daily quote on the right. Tap the weather to refresh, the quote for another. */
@Composable
fun WeatherQuoteWidget() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val askLocation = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        scope.launch { refreshWeather(ctx) }
    }
    LaunchedEffect(Unit) {
        loadCachedWeather(ctx)
        while (true) {
            refreshWeather(ctx)
            delay(30 * 60 * 1000L)
        }
    }
    var qi by remember { mutableIntStateOf(LocalDate.now().dayOfYear % QUOTES.size) }
    val quote = QUOTES[qi]
    val useF = remember { Locale.getDefault().country == "US" }
    fun show(c: Int?): String =
        if (c == null) "–°" else "${if (useF) (c * 9f / 5f + 32f).roundToInt() else c}°"
    val shadow = Shadow(Color(0x99000000), Offset(0f, 2f), 6f)

    Row(
        Modifier.fillMaxSize().padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(24.dp),
    ) {
        Column(
            Modifier.width(110.dp).clickable {
                val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) ==
                    PackageManager.PERMISSION_GRANTED
                if (granted) scope.launch { refreshWeather(ctx) }
                else askLocation.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
            },
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(Icons.Outlined.Refresh, null, tint = Color.White, modifier = Modifier.size(14.dp))
                Text(
                    if (WeatherState.temp != null) "Feels like: ${show(WeatherState.feels)}" else WeatherState.note,
                    style = TextStyle(color = Color.White, fontSize = 12.sp, shadow = shadow), maxLines = 1,
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                WeatherIcon(WeatherState.code, WeatherState.isDay, 36.dp)
                Text(
                    show(WeatherState.temp),
                    style = TextStyle(color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Light, shadow = shadow),
                )
            }
        }
        Column(Modifier.weight(1f).clickable { qi = (qi + 1) % QUOTES.size }) {
            Text(
                quote.text,
                style = TextStyle(color = Color.White, fontSize = 14.sp, lineHeight = 20.sp, shadow = shadow),
            )
            Text(
                "- ${quote.author}",
                style = TextStyle(
                    color = Color.White, fontSize = 13.sp, fontStyle = FontStyle.Italic,
                    textAlign = TextAlign.End, shadow = shadow,
                ),
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
            )
        }
    }
}
