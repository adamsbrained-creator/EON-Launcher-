package ix.app.eon

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** The Eon glyph: an angular, italic infinity made of four straight lines. */
@Composable
fun EonMark(modifier: Modifier = Modifier, progress: Float = 1f, brush: Brush? = null, rainbow: Boolean = false) {
    Canvas(modifier) {
        val s = size.minDimension / 100f
        val full = Path().apply {
            moveTo(26.9f * s, 32.2f * s)
            lineTo(76.6f * s, 67.8f * s)
            lineTo(82f * s, 32.2f * s)
            lineTo(21.6f * s, 67.8f * s)
            close()
        }
        val shown = if (progress >= 0.999f) full else Path().also {
            val pm = PathMeasure()
            pm.setPath(full, false)
            pm.getSegment(0f, pm.length * progress, it, true)
        }
        val paint = brush
            ?: if (rainbow) {
                // Same colours as the app icon: green, cyan, violet, magenta, coral, orange from left to right.
                Brush.linearGradient(
                    colorStops = arrayOf(
                        0f to Color(0xFF00FB5E), 0.28f to Color(0xFF00D1FF), 0.52f to Color(0xFF7A66FF),
                        0.74f to Color(0xFFEA5BE2), 0.9f to Color(0xFFEC5F63), 1f to Color(0xFFEA915A),
                    ),
                    start = Offset(21.6f * s, 0f), end = Offset(82f * s, 0f),
                )
            } else {
                Brush.verticalGradient(listOf(Color.White, Color(0xFFC4C6CC)), 0f, size.height)
            }
        drawPath(
            shown, paint,
            style = Stroke(width = 7.1f * s, miter = 10f, cap = StrokeCap.Butt, join = StrokeJoin.Miter),
        )
    }
}

/** The glassy app icon tile with the glyph inside. */
@Composable
fun EonTile(tile: Dp, modifier: Modifier = Modifier, progress: Float = 1f) {
    val shape = RoundedCornerShape(tile * 0.24f)
    Box(
        modifier.size(tile).clip(shape).background(Eon.Tile).border(1.dp, Color(0x40FFFFFF), shape),
        contentAlignment = Alignment.Center,
    ) {
        EonMark(Modifier.fillMaxSize(0.82f), progress)
    }
}

/** Welcome logo: the glyph draws itself, then the tile glows and a shimmer sweeps across. */
@Composable
fun AnimatedLogo(tile: Dp) {
    val draw = remember { Animatable(0f) }
    LaunchedEffect(Unit) { draw.animateTo(1f, tween(1800, easing = FastOutSlowInEasing)) }
    val transition = rememberInfiniteTransition(label = "logo")
    val glow by transition.animateFloat(
        0.35f, 0.85f, infiniteRepeatable(tween(1500, easing = LinearEasing), RepeatMode.Reverse), label = "glow",
    )
    val sweep by transition.animateFloat(
        -0.4f, 1.4f, infiniteRepeatable(tween(3400, easing = LinearEasing)), label = "sweep",
    )
    val shape = RoundedCornerShape(tile * 0.24f)
    Box(
        Modifier.size(tile * 1.9f).drawBehind {
            drawCircle(
                Brush.radialGradient(
                    listOf(Eon.Accent.copy(alpha = glow * 0.6f), Color.Transparent),
                ),
                radius = this.size.minDimension / 2f,
            )
        },
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier
                .size(tile)
                .clip(shape)
                .background(Color.Black)
                .drawWithContent {
                    drawContent()
                    val w = this.size.width
                    val x = sweep * w
                    drawRect(
                        Brush.horizontalGradient(
                            listOf(Color.Transparent, Color(0x59FFFFFF), Color.Transparent),
                            startX = x - w * 0.25f,
                            endX = x + w * 0.25f,
                        ),
                    )
                }
                .border(1.dp, Color(0x40FFFFFF), shape),
            contentAlignment = Alignment.Center,
        ) {
            EonMark(Modifier.fillMaxSize(0.82f), draw.value, rainbow = true)
        }
    }
}
