package ix.app.eon

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ImageDecoder
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.drawable.Drawable
import android.net.Uri
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Your own names and icons for apps, and the icon pack you picked.
 *
 * Everything is stored against the app's component name (the same key as [AppEntry.key]).
 * An icon is saved as a short text:
 *  - "img:<file>" a picture from your gallery, copied into Eon's own storage;
 *  - "pack:<package>|<drawable>" one icon taken from an installed icon pack.
 */
object IconCustom {
    private val labels = ConcurrentHashMap<String, String>()
    private val icons = ConcurrentHashMap<String, String>()
    private lateinit var prefs: Prefs
    private lateinit var appCtx: Context

    /** Package name of the icon pack in use, or "" for Eon's own icons. */
    @Volatile var pack: String = ""

    /** When on, icons that come from a pack are cut to the Eon icon shape too. */
    @Volatile var reshapePack: Boolean = false

    fun init(ctx: Context, p: Prefs) {
        appCtx = ctx.applicationContext
        prefs = p
        pack = p.getString("iconPack")
        reshapePack = p.getBool("packReshape", false)
        readMap(p.getString("customLabels"), labels)
        readMap(p.getString("customIcons"), icons)
    }

    private fun readMap(json: String, into: MutableMap<String, String>) {
        into.clear()
        if (json.isBlank()) return
        try {
            val o = JSONObject(json)
            o.keys().forEach { k -> into[k] = o.getString(k) }
        } catch (_: Exception) {
        }
    }

    private fun writeMap(name: String, map: Map<String, String>) {
        val o = JSONObject()
        map.forEach { (k, v) -> o.put(k, v) }
        prefs.putString(name, o.toString())
    }

    fun labelFor(key: String): String? = labels[key]
    fun iconSpec(key: String): String? = icons[key]
    val renamedCount: Int get() = labels.size
    val customIconCount: Int get() = icons.size

    /** A blank [label] puts the original name back. */
    fun setLabel(key: String, label: String?) {
        val clean = label?.trim().orEmpty()
        if (clean.isEmpty()) labels.remove(key) else labels[key] = clean
        writeMap("customLabels", labels)
    }

    /** A null [spec] puts the app's normal icon back. */
    fun setIcon(key: String, spec: String?) {
        val old = icons[key]
        if (spec == null) icons.remove(key) else icons[key] = spec
        writeMap("customIcons", icons)
        if (old != null && old != spec) deleteImageIfUnused(old)
    }

    fun setPack(pkg: String) {
        pack = pkg
        prefs.putString("iconPack", pkg)
    }

    fun setReshape(on: Boolean) {
        reshapePack = on
        prefs.putBool("packReshape", on)
    }

    fun resetAll() {
        labels.clear()
        icons.clear()
        writeMap("customLabels", labels)
        writeMap("customIcons", icons)
        File(appCtx.filesDir, "icons").listFiles()?.forEach { it.delete() }
    }

    private fun deleteImageIfUnused(spec: String) {
        if (!spec.startsWith("img:")) return
        if (icons.values.any { it == spec }) return
        File(imageDir(), spec.removePrefix("img:")).delete()
    }

    private fun imageDir(): File = File(appCtx.filesDir, "icons").also { it.mkdirs() }

    /** Copies the picture at [uri] into Eon's storage as a square PNG and returns its file name, or null. */
    suspend fun importImage(uri: Uri): String? = withContext(Dispatchers.IO) {
        try {
            val source = ImageDecoder.createSource(appCtx.contentResolver, uri)
            val bmp = ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE)
                val shortest = minOf(info.size.width, info.size.height)
                if (shortest > 512) {
                    val k = 512f / shortest
                    decoder.setTargetSize(
                        max(1, (info.size.width * k).roundToInt()),
                        max(1, (info.size.height * k).roundToInt()),
                    )
                }
            }
            val side = minOf(bmp.width, bmp.height)
            val square = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
            val name = "i_${System.currentTimeMillis()}.png"
            FileOutputStream(File(imageDir(), name)).use { out -> square.compress(Bitmap.CompressFormat.PNG, 100, out) }
            if (square !== bmp) bmp.recycle()
            name
        } catch (e: Exception) {
            null
        } catch (e: OutOfMemoryError) {
            null
        }
    }

    /** Builds the icon for a saved [spec], or null when the picture or the pack icon is gone. */
    fun bitmapFor(ctx: Context, spec: String, px: Int): Bitmap? {
        try {
            if (spec.startsWith("img:")) {
                val f = File(imageDir(), spec.removePrefix("img:"))
                if (!f.exists()) return null
                val bmp = android.graphics.BitmapFactory.decodeFile(f.absolutePath) ?: return null
                return IconShaper.fitCustom(bmp, px)
            }
            if (spec.startsWith("pack:")) {
                val rest = spec.removePrefix("pack:")
                val i = rest.indexOf('|')
                if (i <= 0) return null
                val pk = IconPacks.get(ctx, rest.substring(0, i)) ?: return null
                val d = pk.drawable(rest.substring(i + 1)) ?: return null
                return if (reshapePack) IconShaper.shape(d, px) else IconShaper.plain(d, px)
            }
        } catch (_: Exception) {
        } catch (_: OutOfMemoryError) {
        }
        return null
    }
}

class PackInfo(val pkg: String, val label: String)

/** Finds the icon packs that are installed and keeps the one in use ready. */
object IconPacks {
    // The actions icon packs announce themselves with (ADW, Nova, Apex and GO Launcher style packs).
    private val ACTIONS = listOf(
        "org.adw.launcher.THEMES",
        "com.novalauncher.THEME",
        "com.anddoes.launcher.THEME",
        "com.gau.go.launcherex.theme",
        "org.adw.launcher.icons.ACTION_PICK_ICON",
    )

    private val cache = HashMap<String, Pair<Long, IconPack>>()

    @Suppress("DEPRECATION")
    fun installed(ctx: Context): List<PackInfo> {
        val pm = ctx.packageManager
        val found = LinkedHashMap<String, PackInfo>()
        for (action in ACTIONS) {
            val list = try {
                pm.queryIntentActivities(Intent(action), 0)
            } catch (_: Exception) {
                emptyList()
            }
            for (ri in list) {
                val pkg = ri.activityInfo.packageName
                if (pkg == ctx.packageName || found.containsKey(pkg)) continue
                found[pkg] = PackInfo(pkg, ri.loadLabel(pm).toString())
            }
        }
        return found.values.sortedBy { it.label.lowercase() }
    }

    /** The loaded pack, or null if it is not installed or cannot be read. */
    @Synchronized
    fun get(ctx: Context, pkg: String): IconPack? {
        if (pkg.isBlank()) return null
        val stamp = try {
            ctx.packageManager.getPackageInfo(pkg, 0).lastUpdateTime
        } catch (_: Exception) {
            cache.remove(pkg)
            return null
        }
        cache[pkg]?.let { if (it.first == stamp) return it.second }
        val loaded = try {
            IconPack(ctx, pkg)
        } catch (_: Exception) {
            return null
        }
        cache[pkg] = stamp to loaded
        return loaded
    }

    fun active(ctx: Context): IconPack? = get(ctx, IconCustom.pack)
}

/**
 * One icon pack. Reads its appfilter.xml (the standard file that says which icon belongs to which app)
 * and the optional background, mask and overlay it uses for apps it has no icon for.
 */
class IconPack(ctx: Context, val pkg: String) {
    private val res: Resources = ctx.packageManager.getResourcesForApplication(pkg)

    private val byComponent = HashMap<String, String>()
    private val byPackage = HashMap<String, String>()
    private val backs = ArrayList<String>()
    private var maskName: String? = null
    private var uponName: String? = null
    private var scale = 1f

    /** Every icon name in the pack, for the picker. */
    val names: List<String>

    init {
        val all = LinkedHashSet<String>()
        try {
            parse(all)
        } catch (_: Exception) {
        }
        names = all.toList()
    }

    private fun parse(all: MutableSet<String>) {
        val xmlId = res.getIdentifier("appfilter", "xml", pkg)
        if (xmlId != 0) {
            readFilter(res.getXml(xmlId), all)
            return
        }
        try {
            res.assets.open("appfilter.xml").use { stream ->
                val p = android.util.Xml.newPullParser()
                p.setInput(stream, null)
                readFilter(p, all)
            }
        } catch (_: Exception) {
        }
    }

    private fun readFilter(p: XmlPullParser, all: MutableSet<String>) {
        var event = p.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG) {
                when (p.name) {
                    "item" -> {
                        val component = p.getAttributeValue(null, "component")
                        val drawable = p.getAttributeValue(null, "drawable")
                        if (component != null && drawable != null) {
                            val open = component.indexOf('{')
                            val close = component.lastIndexOf('}')
                            if (open >= 0 && close > open) {
                                val cn = component.substring(open + 1, close).trim()
                                byComponent.putIfAbsent(cn, drawable)
                                val slash = cn.indexOf('/')
                                if (slash > 0) byPackage.putIfAbsent(cn.substring(0, slash), drawable)
                            }
                            all.add(drawable)
                        }
                    }
                    "iconback" -> for (i in 0 until p.attributeCount) {
                        if (p.getAttributeName(i).startsWith("img")) backs.add(p.getAttributeValue(i))
                    }
                    "iconmask" -> if (p.attributeCount > 0) maskName = p.getAttributeValue(0)
                    "iconupon" -> if (p.attributeCount > 0) uponName = p.getAttributeValue(0)
                    "scale" -> p.getAttributeValue(null, "factor")?.toFloatOrNull()?.let { scale = it }
                }
            }
            event = p.next()
        }
    }

    /** The pack's icon called [name], or null. */
    fun drawable(name: String): Drawable? {
        for (type in listOf("drawable", "mipmap")) {
            val id = res.getIdentifier(name, type, pkg)
            if (id != 0) {
                try {
                    return res.getDrawable(id, null)
                } catch (_: Exception) {
                }
            }
        }
        return null
    }

    /** The name of the pack's icon for this app, or null if the pack has none. */
    fun nameFor(cn: ComponentName): String? =
        byComponent["${cn.packageName}/${cn.className}"] ?: byPackage[cn.packageName]

    fun iconFor(cn: ComponentName): Drawable? = nameFor(cn)?.let { drawable(it) }

    /**
     * For an app the pack has no icon for: the app's own icon on the pack's background, with its mask and
     * overlay. Returns null when the pack does not ask for any of that.
     */
    fun fallback(src: Drawable, px: Int, seed: String): Bitmap? {
        if (backs.isEmpty() && maskName == null && uponName == null) return null
        return try {
            val out = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
            val c = Canvas(out)
            if (backs.isNotEmpty()) {
                drawable(backs[abs(seed.hashCode()) % backs.size])?.toBitmap(px, px)?.let { c.drawBitmap(it, 0f, 0f, null) }
            }
            val inner = (px * scale).roundToInt().coerceAtLeast(1)
            val layer = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
            val lc = Canvas(layer)
            val icon = src.toBitmap(inner, inner)
            val off = (px - inner) / 2f
            lc.drawBitmap(icon, off, off, Paint(Paint.FILTER_BITMAP_FLAG))
            maskName?.let { n ->
                drawable(n)?.toBitmap(px, px)?.let {
                    lc.drawBitmap(it, 0f, 0f, Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT) })
                }
            }
            c.drawBitmap(layer, 0f, 0f, null)
            uponName?.let { n -> drawable(n)?.toBitmap(px, px)?.let { c.drawBitmap(it, 0f, 0f, null) } }
            out
        } catch (_: Exception) {
            null
        }
    }
}
