package ix.app.eon

import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import androidx.compose.ui.util.lerp
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import kotlin.math.abs
import kotlin.math.roundToInt

val LocalLook = compositionLocalOf { "glassy" }

/** Columns in the home grid (set in Grid properties). */
val GRID_COLS: Int get() = HomeConfig.cols

/**
 * Something placed on a home page: an app ("a"), a folder of apps ("f") or a widget ("w"). Position and size are in grid cells.
 * Apps always sit on whole cells; widgets can sit anywhere (steps of 0.05 cell) and overlap, in which
 * case the higher [z] is drawn on top.
 */
class Item(val kind: String, val key: String, col: Float, row: Float, w: Float, h: Float, z: Int = 0) {
    var col by mutableStateOf(col)
    var row by mutableStateOf(row)
    var w by mutableStateOf(w)
    var h by mutableStateOf(h)
    var z by mutableStateOf(z)

    /** Folders ("f") only: the name, and the keys of the apps inside. */
    var name by mutableStateOf("")
    val members = mutableStateListOf<String>()
}

/** Smallest a widget can be made, in cells. */
const val MIN_SIZE = 0.25f

/** Rounds to a whole cell when snapping, otherwise to steps of 0.05 cell (with a pull towards whole cells). */
fun snapValue(v: Float, snap: Boolean): Float {
    val whole = v.roundToInt().toFloat()
    if (snap) return whole
    // Free: steps of 0.05, but it clicks onto a whole cell when you are close, which makes lining things up easy.
    return if (abs(v - whole) < 0.08f) whole else (v * 20f).roundToInt() / 20f
}

/** 2 -> "2", 1.5 -> "1.50" */
fun cellText(v: Float): String =
    if (v == v.toInt().toFloat()) v.toInt().toString() else String.format(java.util.Locale.US, "%.2f", v)

/** One home page. The legacy lists only hold data from versions before v0.9 until it is migrated. */
class PageData(
    var legacyPinned: List<String> = emptyList(),
    var legacyWidgets: List<Int> = emptyList(),
) {
    val items = mutableStateListOf<Item>()
}

private fun JSONArray.strings(): List<String> = (0 until length()).map { getString(it) }
private fun JSONArray.ints(): List<Int> = (0 until length()).map { getInt(it) }

/** Everything the user can change, kept in memory and saved to [Prefs]. */
class EonState(private val prefs: Prefs) {
    // Must come first: loading the pages below needs the grid size.
    init {
        HomeConfig.load(prefs)
        WallpaperConfig.load(prefs)
        GestureConfig.load(prefs)
        DrawerConfig.load(prefs)
    }

    var look by mutableStateOf(prefs.look)
        private set
    val pages = mutableStateListOf<PageData>().also { it.addAll(loadPages()) }

    /** The dock's pages. Apps here sit on whole cells of the dock's own grid (columns and rows from the Dock settings). */
    val dock = mutableStateListOf<PageData>().also { it.addAll(loadDock()) }

    init {
        refitDock()
    }
    var currentPage by mutableIntStateOf(0)
    /** Size of the area the grid fills, and the height of one row when rows are automatic. */
    private var areaHeightPx by mutableStateOf(1500f)
    private var autoCellPx by mutableStateOf(250f)

    /** Rows in the grid: the chosen number, or as many as fit when set to automatic. */
    val gridRows: Int
        get() = if (HomeConfig.rowsSetting > 0) HomeConfig.rowsSetting else maxOf(1, (areaHeightPx / autoCellPx).toInt())

    /** Height of one grid row in pixels. With a chosen number of rows the grid stretches to fill the area. */
    val cellHeightPx: Float
        get() = if (HomeConfig.rowsSetting > 0) areaHeightPx / HomeConfig.rowsSetting else autoCellPx

    /** Set when a setting that changes the grid's room was changed; the items are re-fitted once the new size is known. */
    private var pendingRefit = false

    fun setArea(heightPx: Float, autoCell: Float) {
        areaHeightPx = heightPx
        autoCellPx = autoCell
        if (pendingRefit && heightPx > autoCell * 2f) {
            pendingRefit = false
            refitItems()
        }
    }

    fun saveHome() {
        HomeConfig.save(prefs)
        pendingRefit = true
    }

    /** Call after changing any drawer setting. */
    fun saveDrawer() {
        DrawerConfig.save(prefs)
    }

    /** The icon shape (an index into ICON_SHAPES). Changing it rebuilds every icon. */
    var iconShape by mutableIntStateOf(prefs.getInt("iconShape", 1).also { IconShaper.shapeIndex = it })
        private set

    /** Goes up when the icons must be rebuilt; the app list reloads when it changes. */
    var iconReload by mutableIntStateOf(0)
        private set

    fun chooseIconShape(index: Int) {
        if (index == iconShape) return
        iconShape = index
        IconShaper.shapeIndex = index
        prefs.putInt("iconShape", index)
        iconReload++
    }

    /** The icon pack in use ("" for Eon's own icons). */
    var iconPack by mutableStateOf(IconCustom.pack)
        private set
    var reshapePack by mutableStateOf(IconCustom.reshapePack)
        private set

    /** Goes up whenever a name or an icon is changed, so settings pages can refresh their counts. */
    var customTick by mutableIntStateOf(0)
        private set

    fun renameApp(key: String, label: String?) {
        IconCustom.setLabel(key, label)
        customTick++
        iconReload++
    }

    fun setAppIcon(key: String, spec: String?) {
        IconCustom.setIcon(key, spec)
        customTick++
        iconReload++
    }

    fun chooseIconPack(pkg: String) {
        if (pkg == iconPack) return
        iconPack = pkg
        IconCustom.choosePack(pkg)
        iconReload++
    }

    fun chooseReshapePack(on: Boolean) {
        reshapePack = on
        IconCustom.setReshape(on)
        iconReload++
    }

    fun resetCustomIcons() {
        IconCustom.resetAll()
        customTick++
        iconReload++
    }

    /** Call after changing a gesture. */
    fun saveGestures() {
        GestureConfig.save(prefs)
    }

    /** Call after changing any wallpaper setting. */
    fun saveWallpaper() {
        WallpaperConfig.save(prefs)
    }

    /** Call after changing a Dock setting. */
    fun dockChanged() {
        saveHome()
        refitDock()
    }

    // ---- dock
    private fun loadDock(): List<PageData> {
        val raw = prefs.getString("dockJson")
        if (raw.isBlank()) return listOf(PageData())
        return try {
            val arr = JSONObject(raw).getJSONArray("pages")
            (0 until arr.length()).map { i ->
                val page = PageData()
                val items = arr.getJSONObject(i).getJSONArray("items")
                for (j in 0 until items.length()) {
                    val o = items.getJSONObject(j)
                    page.items.add(Item("a", o.getString("k"), o.getInt("c").toFloat(), o.getInt("r").toFloat(), 1f, 1f))
                }
                page
            }.ifEmpty { listOf(PageData()) }
        } catch (_: Exception) {
            listOf(PageData())
        }
    }

    private fun saveDock() {
        val pagesArr = JSONArray()
        dock.forEach { p ->
            val items = JSONArray()
            p.items.forEach { i ->
                items.put(JSONObject().put("k", i.key).put("c", i.col.roundToInt()).put("r", i.row.roundToInt()))
            }
            pagesArr.put(JSONObject().put("items", items))
        }
        prefs.putString("dockJson", JSONObject().put("pages", pagesArr).toString())
    }

    fun isInDock(key: String): Boolean = dock.any { p -> p.items.any { it.key == key } }

    /** First empty dock cell as (page, column, row), or null when the dock is full. */
    private fun dockFreeSpot(): Triple<Int, Int, Int>? {
        for (pi in dock.indices) {
            for (r in 0 until HomeConfig.dockRows) {
                for (c in 0 until HomeConfig.dockCols) {
                    if (dock[pi].items.none { it.col.roundToInt() == c && it.row.roundToInt() == r }) return Triple(pi, c, r)
                }
            }
        }
        return null
    }

    /** Takes an app off the home pages and puts it in the dock. Returns false (and changes nothing) if the dock is full. */
    fun moveToDock(key: String): Boolean {
        if (isInDock(key)) return true
        val spot = dockFreeSpot() ?: return false
        var changedHome = false
        if (isPinned(key)) changedHome = true
        detach(key, false)
        dock[spot.first].items.add(Item("a", key, spot.second.toFloat(), spot.third.toFloat(), 1f, 1f))
        if (changedHome) savePages()
        saveDock()
        return true
    }

    fun removeFromDock(key: String) {
        dock.forEach { p -> p.items.removeAll { it.key == key } }
        saveDock()
    }

    /** Takes an app out of the dock and onto the current home page. Returns false if that page has no free cell. */
    fun dockToHome(key: String): Boolean {
        val page = pages.getOrNull(currentPage) ?: return false
        if (!place(page, "a", key, 1, 1)) return false
        removeFromDock(key)
        savePages()
        return true
    }

    /** Dragging inside the dock: moves to the cell if it is free, otherwise swaps with the icon there. */
    fun moveDockApp(pageIndex: Int, key: String, col: Int, row: Int) {
        val page = dock.getOrNull(pageIndex) ?: return
        val me = page.items.firstOrNull { it.key == key } ?: return
        val c = col.coerceIn(0, HomeConfig.dockCols - 1)
        val r = row.coerceIn(0, HomeConfig.dockRows - 1)
        val other = page.items.firstOrNull { it !== me && it.col.roundToInt() == c && it.row.roundToInt() == r }
        if (other != null) {
            other.col = me.col
            other.row = me.row
        }
        me.col = c.toFloat()
        me.row = r.toFloat()
        saveDock()
    }

    /** After the Dock settings change: matches the number of pages and moves icons that no longer fit into free cells. */
    fun refitDock() {
        val cols = HomeConfig.dockCols
        val rows = HomeConfig.dockRows
        val n = maxOf(1, HomeConfig.dockPages)
        val loose = mutableListOf<String>()
        while (dock.size > n) dock.removeAt(dock.size - 1).items.forEach { loose.add(it.key) }
        while (dock.size < n) dock.add(PageData())
        dock.forEach { p ->
            val out = p.items.filter { it.col.roundToInt() >= cols || it.row.roundToInt() >= rows }
            if (out.isNotEmpty()) {
                out.forEach { loose.add(it.key) }
                p.items.removeAll(out)
            }
        }
        loose.forEach { k ->
            val spot = dockFreeSpot()
            if (spot != null) dock[spot.first].items.add(Item("a", k, spot.second.toFloat(), spot.third.toFloat(), 1f, 1f))
        }
        saveDock()
    }

    fun chooseCols(n: Int) {
        HomeConfig.cols = n.coerceIn(3, 8)
        saveHome()
        refitItems()
    }

    /** 0 = automatic. */
    fun chooseRows(n: Int) {
        HomeConfig.rowsSetting = if (n <= 0) 0 else n.coerceIn(3, 14)
        saveHome()
        refitItems()
    }

    fun choosePreset(cols: Int, rows: Int) {
        HomeConfig.cols = cols
        HomeConfig.rowsSetting = rows
        saveHome()
        refitItems()
    }

    /** After the grid changes size: pulls widgets back inside it and moves apps that no longer fit to the nearest free cell. */
    fun refitItems() {
        val cols = GRID_COLS
        val rows = maxOf(gridRows, 1)
        pages.forEach { p ->
            p.items.filter { it.kind == "w" }.forEach {
                val w = it.w.coerceIn(MIN_SIZE, cols.toFloat())
                val h = it.h.coerceIn(MIN_SIZE, rows.toFloat())
                it.w = w
                it.h = h
                it.col = it.col.coerceIn(0f, cols - w)
                it.row = it.row.coerceIn(0f, rows - h)
            }
            if (freeIcons) {
                p.items.filter { it.kind != "w" }.forEach {
                    it.col = it.col.coerceIn(0f, cols - 1f)
                    it.row = it.row.coerceIn(0f, rows - 1f)
                }
            }
        }
        if (!freeIcons) snapAppsToGrid() else savePages()
    }
    val hidden = mutableStateListOf<String>().also { it.addAll(prefs.hidden) }
    // Manual category per app, by category id. Older versions stored the display name, so convert it.
    val overrides = mutableStateMapOf<String, String>().also { m ->
        prefs.overrides.forEach { e -> m[e.key] = legacyCategory(e.value) }
    }

    // ---- drawer categories
    /** The drawer's bottom bar: All apps first, then the categories you added. */
    val categories = mutableStateListOf<DrawerCat>().also { it.addAll(loadCategories()) }

    /** The category the drawer shows (the one you were in last). */
    var drawerCategory by mutableStateOf(prefs.getString("drawerSel").ifBlank { CAT_ALL })
        private set

    /** "bar" is the Smart Launcher style drawer with a category bar; "library" is the iOS style App Library. */
    var drawerStyle by mutableStateOf(prefs.getString("drawerStyle").ifBlank { "bar" })
        private set

    fun chooseDrawerStyle(value: String) {
        drawerStyle = value
        prefs.putString("drawerStyle", value)
    }

    private fun loadCategories(): List<DrawerCat> {
        val parsed: List<DrawerCat> = try {
            val arr = JSONArray(prefs.getString("drawerCats"))
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                DrawerCat(o.getString("id"), o.getString("name"), o.optString("icon", "folder"))
            }
        } catch (_: Exception) {
            emptyList()
        }
        val list = parsed.distinctBy { it.id }
        if (list.isEmpty()) return defaultCategories()
        // All apps is always there, and always first.
        val all = list.firstOrNull { it.id == CAT_ALL } ?: DrawerCat(CAT_ALL, "All apps", "apps")
        return listOf(all) + list.filter { it.id != CAT_ALL }
    }

    private fun saveCategories() {
        val arr = JSONArray()
        categories.forEach { arr.put(JSONObject().put("id", it.id).put("name", it.name).put("icon", it.icon)) }
        prefs.putString("drawerCats", arr.toString())
    }

    fun selectCategory(id: String) {
        if (id == drawerCategory) return
        drawerCategory = id
        prefs.putString("drawerSel", id)
    }

    /** Adds a ready-made category to the bar (or finds it if it is already there). Returns its id. */
    fun addCategory(def: CatDef): String {
        if (categories.none { it.id == def.id }) {
            categories.add(DrawerCat(def.id, def.name, def.icon))
            saveCategories()
        }
        return def.id
    }

    /** Adds an empty category of your own. Returns its id. */
    fun addCustomCategory(): String {
        val id = "c" + System.currentTimeMillis()
        categories.add(DrawerCat(id, "New category", "folder"))
        saveCategories()
        return id
    }

    fun renameCategory(id: String, name: String) {
        val i = categories.indexOfFirst { it.id == id }
        if (i < 0 || name.isBlank()) return
        categories[i] = categories[i].copy(name = name.trim())
        saveCategories()
    }

    fun setCategoryIcon(id: String, icon: String) {
        val i = categories.indexOfFirst { it.id == id }
        if (i < 0) return
        categories[i] = categories[i].copy(icon = icon)
        saveCategories()
    }

    /** Takes a category off the bar. Apps you put in it by hand go back to their automatic category. */
    fun removeCategory(id: String) {
        if (id == CAT_ALL) return
        categories.removeAll { it.id == id }
        val stale = overrides.filterValues { it == id }.keys.toList()
        if (stale.isNotEmpty()) {
            stale.forEach { overrides.remove(it) }
            prefs.overrides = overrides.toMap()
        }
        if (drawerCategory == id) selectCategory(CAT_ALL)
        saveCategories()
    }

    fun categoryName(id: String): String =
        categories.firstOrNull { it.id == id }?.name
            ?: CATALOG.firstOrNull { it.id == id }?.name
            ?: id.replaceFirstChar { it.uppercase() }

    /** True when the app belongs in this category: the one you chose for it, or else the ones Eon found. */
    fun inCategory(app: AppEntry, id: String): Boolean {
        val chosen = overrides[app.packageName]
        return if (chosen != null) chosen == id else id in app.autoCategories
    }

    /** Back to the automatic category for an app. */
    fun clearCategory(pkg: String) {
        overrides.remove(pkg)
        prefs.overrides = overrides.toMap()
    }

    // ---- saving and loading
    private fun loadPages(): List<PageData> {
        val raw = prefs.pagesJson
        if (raw.isBlank()) return listOf(PageData(prefs.pinned, prefs.widgets))
        return try {
            val root = JSONTokener(raw).nextValue()
            if (root is JSONObject) {
                val arr = root.getJSONArray("pages")
                (0 until arr.length()).map { i ->
                    val page = PageData()
                    val items = arr.getJSONObject(i).getJSONArray("items")
                    for (j in 0 until items.length()) {
                        val o = items.getJSONObject(j)
                        val item = Item(
                            o.getString("t"), o.getString("k"),
                            o.getDouble("c").toFloat(), o.getDouble("r").toFloat(),
                            o.getDouble("w").toFloat(), o.getDouble("h").toFloat(),
                            o.optInt("z", 0),
                        )
                        if (item.kind == "f") {
                            item.name = o.optString("n", "")
                            o.optJSONArray("m")?.let { m -> item.members.addAll(m.strings()) }
                        }
                        page.items.add(item)
                    }
                    page
                }.ifEmpty { listOf(PageData()) }
            } else {
                // v0.5 to v0.8 format: plain lists per page
                val arr = root as JSONArray
                (0 until arr.length()).map { i ->
                    val o = arr.getJSONObject(i)
                    PageData(o.getJSONArray("pinned").strings(), o.getJSONArray("widgets").ints())
                }.ifEmpty { listOf(PageData()) }
            }
        } catch (_: Exception) {
            listOf(PageData(prefs.pinned, prefs.widgets))
        }
    }

    private fun savePages() {
        val pagesArr = JSONArray()
        pages.forEach { p ->
            val items = JSONArray()
            p.items.forEach { i ->
                val o = JSONObject().put("t", i.kind).put("k", i.key)
                    .put("c", i.col.toDouble()).put("r", i.row.toDouble()).put("w", i.w.toDouble()).put("h", i.h.toDouble())
                    .put("z", i.z)
                if (i.kind == "f") {
                    o.put("n", i.name)
                    o.put("m", JSONArray(i.members.toList()))
                }
                items.put(o)
            }
            pagesArr.put(JSONObject().put("items", items))
        }
        prefs.pagesJson = JSONObject().put("v", 2).put("pages", pagesArr).toString()
    }

    /** Moves data from older versions onto the grid: widgets first, then apps, in the order they had. */
    fun migrate(sizeOf: (Int) -> Pair<Int, Int>) {
        var changed = false
        pages.forEach { p ->
            if (p.legacyWidgets.isNotEmpty() || p.legacyPinned.isNotEmpty()) {
                changed = true
                p.legacyWidgets.forEach { id ->
                    val (w, h) = sizeOf(id)
                    place(p, "w", id.toString(), w, h, 20)
                }
                p.legacyPinned.forEach { k -> place(p, "a", k, 1, 1, 20) }
                p.legacyWidgets = emptyList()
                p.legacyPinned = emptyList()
            }
        }
        if (changed) savePages()
    }

    fun chooseLook(value: String) {
        look = value
        prefs.look = value
    }

    /** Whether snapping to whole cells is on while editing widgets. */
    var snapToGrid by mutableStateOf(prefs.snapToGrid)
        private set

    fun chooseSnap(on: Boolean) {
        snapToGrid = on
        prefs.snapToGrid = on
    }

    /** True when app icons can be placed anywhere; false when they sit on grid cells. */
    var freeIcons by mutableStateOf(prefs.freeIcons)
        private set

    fun chooseFreeIcons(on: Boolean) {
        freeIcons = on
        prefs.freeIcons = on
        if (!on) snapAppsToGrid()
    }

    /** The search pill's centre as a share of the grid's width and height. searchY < 0 means the default spot. */
    var searchX by mutableStateOf(prefs.searchX)
        private set
    var searchY by mutableStateOf(prefs.searchY)
        private set
    var searchHidden by mutableStateOf(prefs.searchHidden)
        private set

    fun setSearchPos(x: Float, y: Float) {
        searchX = x
        searchY = y
    }

    fun commitSearch() {
        prefs.searchX = searchX
        prefs.searchY = searchY
    }

    fun resetSearch() {
        searchX = 0.5f
        searchY = -1f
        commitSearch()
    }

    fun chooseSearchHidden(hidden: Boolean) {
        searchHidden = hidden
        prefs.searchHidden = hidden
    }

    /** Key of what is being edited on the home screen (a widget's key, or "search" for the search pill), or null. */
    var editing by mutableStateOf<String?>(null)

    /** True while a finger is down on a widget, so the page does not also open its own long-press menu. */
    @Volatile var widgetTouch = false

    /** After dragging with Snap to grid on: eases the widget onto the nearest cell lines. */
    suspend fun glideToCells(item: Item) {
        val l = item.col.roundToInt().toFloat()
        val t = item.row.roundToInt().toFloat()
        var r = (item.col + item.w).roundToInt().toFloat()
        var b = (item.row + item.h).roundToInt().toFloat()
        if (r <= l) r = l + 1f
        if (b <= t) b = t + 1f
        val c0 = item.col
        val r0 = item.row
        val w0 = item.w
        val h0 = item.h
        animate(0f, 1f, animationSpec = tween(170)) { f, _ ->
            setRect(item, lerp(c0, l, f), lerp(r0, t, f), lerp(w0, r - l, f), lerp(h0, b - t, f))
        }
        setRect(item, l, t, r - l, b - t)
        savePages()
    }

    // ---- grid helpers
    private fun fits(p: PageData, c: Float, r: Float, w: Float, h: Float, rows: Int, ignore: Item? = null): Boolean {
        val e = 0.001f
        if (c < -e || r < -e || w < MIN_SIZE - e || h < MIN_SIZE - e || c + w > GRID_COLS + e || r + h > rows + e) return false
        return p.items.none {
            it !== ignore && c < it.col + it.w - e && c + w > it.col + e && r < it.row + it.h - e && r + h > it.row + e
        }
    }

    private fun firstFree(p: PageData, w: Int, h: Int, rows: Int): Pair<Int, Int>? {
        for (r in 0..(rows - h)) {
            for (c in 0..(GRID_COLS - w)) {
                if (fits(p, c.toFloat(), r.toFloat(), w.toFloat(), h.toFloat(), rows)) return c to r
            }
        }
        return null
    }

    private fun place(p: PageData, kind: String, key: String, w: Int, h: Int, rows: Int = gridRows): Boolean {
        val spot = firstFree(p, w, h, rows) ?: return false
        p.items.add(Item(kind, key, spot.first.toFloat(), spot.second.toFloat(), w.toFloat(), h.toFloat()))
        return true
    }

    // ---- folders
    /** Key of the folder whose popup is open, or null. */
    var openFolder by mutableStateOf<String?>(null)

    /** Which dock page is showing, so a drop on the dock knows where it lands. */
    var dockPage by mutableIntStateOf(0)

    fun findFolder(key: String): Item? = pages.firstNotNullOfOrNull { p -> p.items.firstOrNull { it.kind == "f" && it.key == key } }

    /** The folder an app is in, or null. */
    fun folderOf(key: String): Item? =
        pages.firstNotNullOfOrNull { p -> p.items.firstOrNull { it.kind == "f" && key in it.members } }

    private fun newFolderKey(): String =
        "folder:" + java.lang.Long.toString(System.currentTimeMillis(), 36) + pages.sumOf { it.items.size }

    /** A folder with fewer than two apps goes away: the last app takes its place. */
    private fun tidyFolder(p: PageData, f: Item) {
        if (f.members.size >= 2) return
        p.items.remove(f)
        f.members.firstOrNull()?.let { p.items.add(Item("a", it, f.col, f.row, 1f, 1f)) }
        if (openFolder == f.key) openFolder = null
    }

    /** Takes an app away from wherever it is on the home screen: a page, a folder, and with [dockToo] the dock. */
    private fun detach(key: String, dockToo: Boolean) {
        pages.forEach { p ->
            p.items.removeAll { it.kind == "a" && it.key == key }
            p.items.filter { it.kind == "f" && key in it.members }.forEach { f ->
                f.members.remove(key)
                tidyFolder(p, f)
            }
        }
        if (dockToo && isInDock(key)) removeFromDock(key)
    }

    /** Puts [base] and the app [key] together in a new folder where [base] was. */
    private fun makeFolder(p: PageData, base: Item, key: String) {
        p.items.remove(base)
        val f = Item("f", newFolderKey(), base.col, base.row, 1f, 1f)
        f.members.add(base.key)
        f.members.add(key)
        p.items.add(f)
    }

    private fun addToFolder(f: Item, key: String) {
        if (key !in f.members) f.members.add(key)
    }

    /** Takes an app out of its folder and puts it on the current page. False if that page is full. */
    fun takeOutOfFolder(key: String): Boolean {
        if (folderOf(key) == null) return false
        val page = pages.getOrNull(currentPage) ?: return false
        if (firstFree(page, 1, 1, gridRows) == null) return false
        detach(key, false)
        place(page, "a", key, 1, 1)
        savePages()
        return true
    }

    /** Takes apps that are no longer installed out of folders. */
    fun pruneFolders(installed: Set<String>) {
        var changed = false
        pages.forEach { p ->
            p.items.filter { it.kind == "f" }.forEach { f ->
                if (f.members.removeAll { it !in installed }) {
                    changed = true
                    tidyFolder(p, f)
                }
            }
        }
        if (changed) savePages()
    }

    /** Removes a folder; its apps go to free cells on its page (they stay in the drawer either way). */
    fun disbandFolder(key: String) {
        val p = pages.firstOrNull { pg -> pg.items.any { it.kind == "f" && it.key == key } } ?: return
        val f = p.items.first { it.kind == "f" && it.key == key }
        p.items.remove(f)
        // Apps that do not fit on this page go to the first other page with room.
        f.members.forEach { k -> if (!place(p, "a", k, 1, 1)) pages.firstOrNull { it !== p && place(it, "a", k, 1, 1) } }
        if (openFolder == key) openFolder = null
        savePages()
    }

    // ---- apps on pages
    /** True when the app is on a home page, including inside a folder. */
    fun isPinned(key: String): Boolean =
        pages.any { p -> p.items.any { (it.kind == "a" && it.key == key) || (it.kind == "f" && key in it.members) } }

    /** Pins or unpins an app. Returns false when there is no free cell on the current page. */
    fun togglePin(key: String): Boolean {
        if (isPinned(key)) {
            detach(key, false)
            savePages()
            return true
        }
        val page = pages.getOrNull(currentPage) ?: return false
        val ok = place(page, "a", key, 1, 1)
        if (ok) savePages()
        return ok
    }

    /**
     * Drops an app or folder on a cell: moves it if the cell is free. An app dropped on another app makes a
     * folder, and dropped on a folder it joins it. Folders swap places. Widgets are ignored.
     */
    fun moveApp(pageIndex: Int, key: String, col: Int, row: Int) {
        val page = pages.getOrNull(pageIndex) ?: return
        val me = page.items.firstOrNull { it.kind != "w" && it.key == key } ?: return
        val cx = col + 0.5f
        val cy = row + 0.5f
        val other = page.items.firstOrNull {
            it !== me && cx >= it.col && cx < it.col + it.w && cy >= it.row && cy < it.row + it.h
        }
        when {
            other == null -> {
                me.col = col.toFloat()
                me.row = row.toFloat()
            }
            other.kind == "w" -> return
            me.kind == "a" && other.kind == "a" -> {
                page.items.remove(me)
                makeFolder(page, other, me.key)
            }
            me.kind == "a" && other.kind == "f" -> {
                page.items.remove(me)
                addToFolder(other, me.key)
            }
            else -> {
                other.col = me.col
                other.row = me.row
                me.col = col.toFloat()
                me.row = row.toFloat()
            }
        }
        savePages()
    }

    /**
     * Drops an app dragged out of the drawer onto a page. Dropped on an app it makes a folder, on a folder it
     * joins it. Otherwise it goes to the spot, or the nearest free cell; an app already on a page moves there.
     * False if the page is full.
     */
    fun placeApp(pageIndex: Int, key: String, col: Float, row: Float): Boolean {
        val page = pages.getOrNull(pageIndex) ?: return false
        val rows = maxOf(gridRows, 1)
        val old = pages.firstNotNullOfOrNull { p -> p.items.firstOrNull { it.kind == "a" && it.key == key } }
        var c = col.coerceIn(0f, GRID_COLS - 1f)
        var r = row.coerceIn(0f, (rows - 1).toFloat())
        val occupant = if (freeIcons) {
            page.items.firstOrNull { it !== old && it.kind != "w" && abs(it.col - c) < 0.6f && abs(it.row - r) < 0.6f }
        } else {
            val cx = c.roundToInt() + 0.5f
            val cy = r.roundToInt() + 0.5f
            page.items.firstOrNull {
                it !== old && it.kind != "w" && cx >= it.col && cx < it.col + it.w && cy >= it.row && cy < it.row + it.h
            }
        }
        if (occupant != null) {
            if (occupant.kind == "f" && key in occupant.members) return true
            detach(key, true)
            if (occupant.kind == "a") makeFolder(page, occupant, key) else addToFolder(occupant, key)
            savePages()
            return true
        }
        if (!freeIcons) {
            c = c.roundToInt().toFloat()
            r = r.roundToInt().toFloat()
            if (!fits(page, c, r, 1f, 1f, rows, old)) {
                var best: Pair<Int, Int>? = null
                var bestD = Float.MAX_VALUE
                for (rr in 0 until rows) {
                    for (cc in 0 until GRID_COLS) {
                        if (fits(page, cc.toFloat(), rr.toFloat(), 1f, 1f, rows, old)) {
                            val d = (cc - c) * (cc - c) + (rr - r) * (rr - r)
                            if (d < bestD) {
                                bestD = d
                                best = cc to rr
                            }
                        }
                    }
                }
                val spot = best ?: return false
                c = spot.first.toFloat()
                r = spot.second.toFloat()
            }
        }
        detach(key, true)
        page.items.add(Item("a", key, c, r, 1f, 1f))
        savePages()
        return true
    }

    /**
     * Drops an app dragged out of the drawer onto the dock, on the cell if it is free, otherwise on the first
     * free dock cell. False if the dock is full.
     */
    fun dropToDock(key: String, pageIndex: Int, col: Int, row: Int): Boolean {
        if (dock.isEmpty()) return false
        val pi = pageIndex.coerceIn(0, dock.size - 1)
        val c = col.coerceIn(0, HomeConfig.dockCols - 1)
        val r = row.coerceIn(0, HomeConfig.dockRows - 1)
        fun free(pg: Int, cc: Int, rr: Int) =
            dock[pg].items.none { it.key != key && it.col.roundToInt() == cc && it.row.roundToInt() == rr }
        var spot: Triple<Int, Int, Int>? = if (free(pi, c, r)) Triple(pi, c, r) else null
        if (spot == null) {
            search@ for (pg in dock.indices) {
                for (rr in 0 until HomeConfig.dockRows) {
                    for (cc in 0 until HomeConfig.dockCols) {
                        if (free(pg, cc, rr)) {
                            spot = Triple(pg, cc, rr)
                            break@search
                        }
                    }
                }
            }
        }
        val where = spot ?: return false
        detach(key, true)
        dock[where.first].items.add(Item("a", key, where.second.toFloat(), where.third.toFloat(), 1f, 1f))
        savePages()
        saveDock()
        return true
    }

    /** Free placement: drops an app or folder at an exact spot. On top of another icon it makes or joins a folder. */
    fun dropApp(pageIndex: Int, key: String, col: Float, row: Float) {
        val page = pages.getOrNull(pageIndex) ?: return
        val me = page.items.firstOrNull { it.kind != "w" && it.key == key } ?: return
        val c = snapValue(col.coerceIn(0f, GRID_COLS - 1f), false)
        val r = snapValue(row.coerceIn(0f, maxOf(gridRows, 1) - 1f), false)
        val other = page.items.firstOrNull { it !== me && it.kind != "w" && abs(it.col - c) < 0.6f && abs(it.row - r) < 0.6f }
        if (other != null) {
            if (me.kind == "a") {
                page.items.remove(me)
                if (other.kind == "a") makeFolder(page, other, me.key) else addToFolder(other, me.key)
                savePages()
            }
            return
        }
        me.col = c
        me.row = r
        savePages()
    }

    /** Back to grid placement: every app goes to the nearest free cell. */
    private fun snapAppsToGrid() {
        val rows = maxOf(gridRows, 1)
        pages.forEach { p ->
            p.items.filter { it.kind != "w" }.forEach { me ->
                val tc = me.col.roundToInt().coerceIn(0, GRID_COLS - 1)
                val tr = me.row.roundToInt().coerceIn(0, rows - 1)
                if (fits(p, tc.toFloat(), tr.toFloat(), 1f, 1f, rows, me)) {
                    me.col = tc.toFloat()
                    me.row = tr.toFloat()
                } else {
                    var best: Pair<Int, Int>? = null
                    var bestD = Int.MAX_VALUE
                    for (r in 0 until rows) {
                        for (c in 0 until GRID_COLS) {
                            if (fits(p, c.toFloat(), r.toFloat(), 1f, 1f, rows, me)) {
                                val d = (c - tc) * (c - tc) + (r - tr) * (r - tr)
                                if (d < bestD) {
                                    bestD = d
                                    best = c to r
                                }
                            }
                        }
                    }
                    best?.let {
                        me.col = it.first.toFloat()
                        me.row = it.second.toFloat()
                    }
                }
            }
        }
        savePages()
    }

    // ---- widgets
    fun widgetItems(): List<Item> = pages.getOrNull(currentPage)?.items?.filter { it.kind == "w" } ?: emptyList()

    fun allWidgets(): List<Int> =
        pages.flatMap { p -> p.items.filter { it.kind == "w" }.mapNotNull { it.key.toIntOrNull() } }

    /** Returns false when the current page has no room for a widget of this size. */
    fun addWidget(id: Int, w: Int, h: Int): Boolean {
        val page = pages.getOrNull(currentPage) ?: return false
        if (page.items.any { it.kind == "w" && it.key == id.toString() }) return true
        val ok = place(page, "w", id.toString(), w, h)
        if (ok) savePages()
        return ok
    }

    fun removeWidget(id: Int) {
        pages.forEach { p -> p.items.removeAll { it.kind == "w" && it.key == id.toString() } }
        savePages()
    }

    fun nudgeWidget(key: String, dc: Int, dr: Int) {
        val p = pages.getOrNull(currentPage) ?: return
        val it = p.items.firstOrNull { x -> x.kind == "w" && x.key == key } ?: return
        if (fits(p, it.col + dc, it.row + dr, it.w, it.h, gridRows, it)) {
            it.col += dc
            it.row += dr
            savePages()
        }
    }

    fun resizeWidget(key: String, dw: Int, dh: Int) {
        val p = pages.getOrNull(currentPage) ?: return
        val it = p.items.firstOrNull { x -> x.kind == "w" && x.key == key } ?: return
        val w = (it.w + dw).coerceIn(1f, GRID_COLS.toFloat())
        val h = (it.h + dh).coerceIn(1f, 4f)
        if (fits(p, it.col, it.row, w, h, gridRows, it)) {
            it.w = w
            it.h = h
            savePages()
        }
    }

    /** Sets a widget's position and size in cells, keeping it inside the page. */
    fun setRect(item: Item, col: Float, row: Float, w: Float, h: Float) {
        val ww = w.coerceIn(MIN_SIZE, GRID_COLS.toFloat())
        val hh = h.coerceIn(MIN_SIZE, maxOf(gridRows, 1).toFloat())
        item.w = ww
        item.h = hh
        item.col = col.coerceIn(0f, GRID_COLS - ww)
        item.row = row.coerceIn(0f, maxOf(gridRows, 1) - hh)
    }

    /** Draw order of overlapping items: higher is on top. */
    fun raise(item: Item, by: Int) {
        item.z = (item.z + by).coerceIn(-99, 99)
        savePages()
    }

    /** Saves after a drag or a button press while editing. */
    fun commitLayout() = savePages()

    // ---- pages
    fun addPage(index: Int) {
        pages.add(index.coerceIn(0, pages.size), PageData())
        savePages()
    }

    fun removePage(index: Int) {
        if (pages.size > 1 && index in pages.indices && pages[index].items.isEmpty()) {
            pages.removeAt(index)
            savePages()
        }
    }

    // ---- hidden apps and categories
    fun hide(pkg: String) {
        if (pkg !in hidden) hidden.add(pkg)
        prefs.hidden = hidden.toSet()
    }

    fun showAllApps() {
        hidden.clear()
        prefs.hidden = emptySet()
    }

    fun setCategory(pkg: String, category: String) {
        overrides[pkg] = category
        prefs.overrides = overrides.toMap()
    }
}
