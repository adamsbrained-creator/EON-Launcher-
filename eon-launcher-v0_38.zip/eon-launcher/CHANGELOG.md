# Eon: what's new

## v0.24.1
- Fixes the build error in v0.24.0 (a name clash in the icon pack code). Rename, Change icon and Icon packs are the same as described in v0.24.0.

## v0.24.0
- Rename apps. Long-press an app (home screen, dock, drawer or Library) and tap Rename. Type the new name and Save. Reset, or saving the original name, puts it back. The drawer, search and sorting use the new name; categories still go by the real one.
- Custom icons. Long-press an app > Change icon: pick a picture from the gallery (it is cropped to a square and kept inside Eon), or pick one icon from an installed icon pack. "Use the normal icon" undoes it. A picture that fills its frame is cut to your icon shape; a logo with a transparent edge stays as it is.
- Icon packs. New Settings > Icon packs page lists the icon packs on the phone (ADW, Nova, Apex and GO style packs, such as Lawnicons). Choose one and every app it has an icon for changes at once. Apps the pack does not cover keep their own icon, or get the pack's background, mask and overlay if it has them.
- Reshape pack icons: a switch that cuts pack icons to your icon shape too (off by default, since packs bring their own shape).
- The picker for one app shows the pack's icon for that app first, then every icon, with a search box.
- Your changes: the Icon packs page shows how many apps you renamed or gave their own icon, and has Reset all names and icons.
- A custom icon you pick for one app always wins over the icon pack.

## v0.23.0
- Drawer: "Fit the grid to the apps". With few apps (a small category) the icons get bigger and use fewer columns; with many they get smaller and more columns, so everything fits without scrolling.
- Icon shape: eleven shapes (square, rounded, squircle, circle, hexagon, octagon, pentagon, diamond, teardrop, leaf, flower) in Settings > Drawer. Every icon follows the one you choose.
- Custom padding (sides, top, bottom), a switch for the category bar, and a category transition effect (Default, Fade, Zoom, Rotate).
- Advanced: A to Z index strip, hide the Play Store icon, hide icon packs, move icons down, stack apps from the bottom, and close the drawer after launching an app (on by default).

## v0.22.0
- New category bar in the drawer (Bar style). The icons now sit in a rounded glass pill and spread evenly across it, like the reference. The icon you are on grows a little and fades to the selected colour, a small marker slides in under it, and changing category gives a soft tick. It still scrolls sideways when there are more icons than fit.
- Settings > Drawer has a Pill background switch if you prefer the loose icons, and the live preview shows the pill. The pill takes its tint from your text colour, so it follows the presets.

## v0.21.0
- New Settings > Drawer page, with a live preview at the top that follows every change. It covers both drawers.
- Background: colour, opacity (0 to 100%) and whether it fades from lighter at the top to stronger at the bottom. Five presets (Smoke, Midnight, Frost, Amoled, Clear) set colours and opacity in one tap.
- Apps and labels: text colour (a swatch row, or Custom with hue, saturation and brightness), icon size, columns (3 to 6), row spacing, show or hide labels, label size and two-line labels.
- Category bar (the Bar style): how much of the screen the apps take, show or hide the category title, its size and centring, bar icon size, selected icon colour, the little marker under the selected icon, and whether swiping the apps changes category.
- App Library: folders per row (2 or 3), folder colour, opacity, corner roundness and outline, and whether the Recently added and Other apps folders show.
- Sort and search: order apps A to Z, Z to A or newest first, and open the keyboard together with the drawer.
- Reset drawer settings puts everything back.
- Menus: the category menu (the ⋮ button or long-press on a category icon in the Bar, long-press on one of your folders in the Library) now also has Switch to Library or Bar and Drawer settings. The Library has a Drawer settings button under the folders. Drawer settings opens straight on this page and Back returns you to where you were.
- Settings has a Drawer tile. Drawer style is also still in Quick settings.
- The dim background is a bit different from before: the new default is 65% opacity, fading from about 43% at the top to about 87% at the bottom.

## v0.20.0
- App Library, an iOS style drawer as a second choice. Settings > Quick settings > Drawer style: Bar (the Smart Launcher style drawer with the category bar, as before) or Library.
- The Library is a search pill and a two-column grid of folders. Each folder shows the first apps of a category as big icons and, with more than four, a small cluster of the next ones in the last slot. Tap the folder (or the cluster) to open all its apps in a panel; tap outside it to close.
- It uses the same categories as the bar. Recently added comes first, then your categories (an empty one shows its icon), then Other apps for anything no folder holds. Long-press one of your folders for Add category, Edit icon, Rename and Remove. Add category is also the last row.
- Tap the search pill for an A to Z list of every app; type to filter. Cancel goes back. Fling down at the top of the Library to close it.
- Big icons in a folder work like in the bar drawer: tap to open, long-press for the app menu and shortcuts, long-press and drag to drop it on the home screen or the dock.

## v0.19.1
- Smoother, exact resizing. Dragging a widget's edge dots, or the widget itself, now follows your finger to any size or position: no more steps or sticky spots. With Snap to grid on, the widget eases onto the nearest cell lines when you let go; with it off it stays exactly where you left it. Widgets can be made smaller (down to a quarter of a cell), and an app's widget is told its new size only when you pause, so nothing stutters.
- Holding a widget or one of its dots no longer also opens the home screen's long-press menu. While you edit, only the editing bar shows.
- The editing bar has a new look, with no arrow pad: Move has X and Y, Resize has Width and Height (grow from a corner or from the centre), Layer has the layer number and Remove. Each has a minus, the number and a plus; hold one to keep going. STEP sets how far a tap moves: 0.01, 0.1 or a whole cell. The search pill's bar uses the same steppers.
- The colours were not changed here: v0.15 already moved everything to the rainbow on black.

## v0.19.0
- Gestures. New Gestures tile in Settings. Pick what a double tap on empty space does, and what a swipe down does: None, Lock screen, Open drawer, Search, Notifications or Settings. Swipe down still opens the notification shade, and swipe up still opens the drawer.
- Lock screen: Eon locks the phone with Android's device administrator permission, which is asked for the first time you use it. Eon uses it for nothing else (it can only lock the screen). Turn it off under Settings > Security > Device admin apps.

## v0.18.0
- App shortcuts. Long-press an app, on the home screen or in the drawer, and the app's own shortcuts (Camera: Selfie, Messages: New chat and so on) show at the top of its menu, up to four. Tap one to open it. Android only shows them to the home app, so they appear once Eon is your default home app.

## v0.17.0
- The Grid, Dock and Wallpaper settings pages now match the settings hub: black panels with a thin outline, a coloured line before each section title, rainbow switches, bold row titles and darker chips and buttons. The home screen still shows above the panel so you see changes live.
- A page that was made by holding at the edge while dragging from the drawer is removed again if you drop somewhere else and it stays empty.
- Apps you uninstall are taken out of folders, and a folder left with one app turns back into that app.

## v0.16.0
- Folders. Drop an icon on another icon on the home screen and they become a folder, with a rainbow outline and the first four apps showing inside. Drop an icon on a folder to add it. Tap a folder to open it: tap its name to rename it, tap an app to open it, long-press an app for its menu (it has Take out of folder), and Remove folder sends the apps back to the home screen. A folder with one app left turns back into that app. Folders can be dragged around like apps and work in Free placement too.
- Drag from the drawer to the dock: drop an app on a dock cell (or any free dock cell if that one is taken). The dock lights up where it will land.
- Drag from the drawer past the last page: hold at the right edge and Eon adds a new page for you (when the last page has something on it).
- Dragging an icon from the drawer onto another icon outlines the target in rainbow, to show it will make or join a folder.
- Two icons on the home screen no longer swap when you drop one on the other (it makes a folder instead). Folders still swap with icons.

## v0.15.0
- New colours everywhere: the old green is gone. Eon now uses the rainbow from its icon (cyan, blue, violet, pink, orange) on black, the same as the settings page.
- Buttons, selected chips, the step bars in the welcome screens, notification badges, the Done button, picked tabs and the wallpaper and widget pickers are filled with the rainbow, with black text on top.
- Switches, cursors, selected borders and links use the cyan from the start of the rainbow, since they need one solid colour. The welcome screens glow violet, cyan and orange at the bottom instead of green, and the logo glows violet.
- Settings tiles: the first tile is blue now instead of green.

## v0.14.0
- Drag apps from the drawer onto the home screen. Long-press an icon in the drawer and move your finger: the drawer fades away, the icon follows your finger and the cell it will land on is outlined. Let go to drop it there. Hold at the left or right edge to go to the next page.
- If the spot is taken, the app goes to the nearest free cell. If the app is already on a page, it moves to where you drop it. Free placement drops it exactly where you let go.
- Long-press and let go without moving still opens the app menu (Add to home screen, Change category and so on). Dropping outside the grid brings the drawer back.

## v0.13.0
- New app drawer, modelled on Smart Launcher. The title of the category you are in sits above the apps in the lower half of the screen, with Search and a ⋮ menu on the right. The open wallpaper above is a tap target: tap it or pull it down to close.
- Category bar at the bottom: one icon per category. Tap an icon, or swipe the apps sideways, to change category. The little bar under an icon shows where you are. If there are more icons than fit, the bar scrolls. Eon remembers the category you were in.
- Long-press an icon (or use ⋮) for Add category, Edit icon, Rename and Remove. Remove is not offered for All apps. Removing a category never removes apps; they stay in All apps.
- Add category: a full-screen list (Contacts, Education, Entertainment, Favorites, Finance, Fitness, Internet, Lifestyle, Media, Medical, Music, Navigation, Personalization, Photography, Productivity and more). Ones already in the bar are left out. Custom category at the top makes an empty one you name yourself.
- Eon fills the ready-made categories from each app's type and name, so an app can show up in more than one (Spotify in Media and Music, say). Favorites and your own categories start empty: long-press an app and choose Change category. Change category now lists the categories in your bar, with Automatic to undo.
- Search is now the magnifier in the drawer's header, and looks through every app. Tapping the search pill on the home screen still opens the drawer with the keyboard up.
- New installs start with All apps, Social, Media, Games, Productivity and Tools. Categories you had set by hand in v0.12 carry over. Apps that were only in Reading, Maps or Other now show under All apps until you add those categories.

## v0.12.1
- New widget picker. Search at the top finds widgets by name, by app or by kind. Chips filter by what a widget is (Clock, Weather, Music, Calendar and so on). Eon's own widgets sit in a row of previews, and below them every app is listed A to Z with how many widgets it has; slide along the strip on the right to jump to a letter.
- Tap an app, or a widget in the results, to open a sheet with that app's widgets as previews and their sizes. Pick one, filter by size if you like, and press Add.
- After adding, the widget is already in edit mode on the home screen, so you can place it straight away. The widgets you already have are under "On this page".
- Widget edit panel redesigned into a bottom bar: the position and size always showing, Done, and Move, Resize and Layer tabs. Remove is under Layer.
- The kind of a widget is guessed from its name and its app's name, so a few will land under Other; they are always listed under their app too.

## v0.12.0
- New settings page: a hub of six coloured tiles, one for each colour in the Eon icon. Each tile shows its current state: Grid and icons, Dock, Wallpaper, Notifications, Hidden apps and About Eon. Tap one to open its page; Notifications opens Android's notification access screen.
- Quick settings under the tiles: Look (Glassy or Flat), Icon placement (Grid or Free) and Page indicator, changed right there with small switches.
- Search settings at the top filters the tiles and quick settings as you type.
- Grid properties and Dock now open straight from their tiles (the old Home screen list page is gone). Hidden apps and About Eon (version, show the greeting again) have their own pages.

## v0.11.0
- Live wallpaper: Eon is now also a real Android live wallpaper. In Settings > Wallpaper choose "Set as live wallpaper" and Android's own preview lets you pick home screen, lock screen or both. The picture moves as you tilt the phone on both, with your Range, Speed, Dim, Direction and effects settings. When it is active, the home screen shifts it as you swipe between pages and sends your touches to it (for Ripple), and Eon stops drawing its own copy.
- Still picture: "Home", "Lock" or "Both" under it set the picture as a normal system wallpaper, with no motion.
- Rain now has big glass drops: round drops that show the picture upside down, with a rim and a highlight. They slide down now and then. Settings: Glass drops on/off, Drop amount, Drop size, Drop slide speed, plus Rain streaks on/off and Lightning (the wallpaper flashes now and then; it does not change your screen brightness).
- Ripple has a Rain lines switch.
- Transition animation (Fade, Dissolve, Pixelate, Wipe, Blur, Zoom) for when you pick another picture, and Animation speed (0.25x to 4x) for the effects and the transition. Blur works only on the in-Eon wallpaper; the live wallpaper fades instead.
- Not yet: slideshow.

## v0.10.0
- New: gyro wallpaper. Pick a picture and Eon draws it behind the home screen and slides it as you tilt the phone (it reads the accelerometer, so no extra permission). Nothing changes until you turn it on: with it off Eon still shows your normal system wallpaper.
- Open it from Settings > Wallpaper, or long-press empty space on the home screen and choose Wallpaper. Add pictures with the + tile (they are copied into Eon, so they stay even if you delete them from the gallery), tap one to use it, long-press one to delete it.
- Wallpaper settings, with the wallpaper visible above the panel so you can tilt and watch: Direction (Horizontal, Vertical or Both), Range, Speed, Dim, Reverse direction, Wallpaper scrolling (the picture also shifts as you swipe between pages), Power saver mode (stop reading the sensor in battery saver) and Quality (High, Standard, Low = 16-bit colour).
- The centre follows where you hold the phone, so the picture settles back to the middle if you keep it at a new angle or put it down.
- Effects: an optional overlay of Rain, Ripple (starts where you touch, or also at random) or Snow, each with its own sliders.
- Not yet: slideshow, other transition animations, the lock screen.

## v0.9.13
- New: the Dock. A rounded, see-through bar at the bottom of the home screen, like iOS, that stays put while you swipe between pages. It is off until you turn it on in Settings > Home screen > Dock.
- Dock settings: Enable, Columns (1 to 6), Rows (1 to 3), Icon size, Pages (1 to 5, swipe the dock sideways) and Icon label visibility. The home screen stays visible below the panel, so you watch the dock change as you set it up.
- Add an app by long-pressing it and choosing Move to dock. In the dock, long-press and drag an icon to rearrange; long-press an icon without moving for Move to home or Remove from dock.
- The home grid gives up the space the dock uses. Icons that no longer fit are moved to the nearest free cell, nothing is deleted.

## v0.9.12
- New Settings > Home screen, with Grid properties and a Show indicator switch (hides the page dots).
- Grid properties, in Eon's own look. The home screen stays visible above the panel so you see every change live:
  - Presets 4x7, 5x8 and 6x10, plus Columns (3 to 8) and Rows (Auto or 3 to 14). With a chosen number of rows the grid stretches to fill the screen.
  - Icon size (40 to 84 dp), with a reset button.
  - Icon label visibility, Label size (8 to 16 pt) and Allow two-line labels.
  - Use custom padding: side, top and bottom space around the grid.
- When you change the grid, widgets are pulled back inside it and any icon that no longer fits moves to the nearest free cell. Nothing is deleted.
- The drawer keeps its own icon size, so changing the home screen does not change it.

## v0.9.11
- The Search apps pill now floats and can go anywhere. Long-press it to edit: drag it, nudge it with the arrows (half a cell with Snap to grid on, 0.05 cell with it off), reset it to the bottom, or hide it. Open it with a tap as before.
- The home grid now reaches all the way down to the page dots, so you can put icons where the search pill used to be (a dock-style row at the bottom, like in Smart Launcher). Icons you already placed stay where they are.
- If you hide the pill, long-press empty space on the home screen and choose "Show search pill" to bring it back.
- Page swiping is paused while you edit a widget or the pill.

## v0.9.10
- Smoother icons: an icon now settles from where you let go instead of jumping back first, lifts with a little spring when you pick it up, and swaps glide. The grid fades in and out instead of popping.
- More precise placing: while you drag, a ghost outline shows exactly where the icon will land (the cell in Grid mode, the exact spot in Free mode). In Free mode, and when moving or resizing widgets with Snap to grid off, positions click onto a whole cell when you are close.
- You feel it too: a small tick each time the icon moves into a new cell, and when a widget lands exactly on a cell.
- The edit panel now shows the widget's position and size all the time, and updates as you drag.

## v0.9.9
- Quick switch: long-press empty space on the home screen and choose "Place icons freely" or "Snap icons to grid". It is the same setting as in Eon settings.

## v0.9.8
- New setting, Icon placement: Grid (icons snap to cells, as before) or Free (drop an icon anywhere on the home screen; positions go in steps of 0.05 cell, and a drop that would land on top of another icon is ignored). Switching back to Grid moves each icon to the nearest free cell.
- Fixed three type errors in the app-drag code that came in with v0.9.7 and would have stopped the build.

## v0.9.7
- Edit widgets right on the home screen: long-press a widget. A faint grid appears, you drag the widget to move it and drag the dots on its edges to resize it. A small panel gives you exact steps (Resize, Move, Elevation), a Snap to grid switch and Remove. Tap anywhere else, press Done or go back to finish.
- Widgets can now sit anywhere, not just on whole cells. With Snap to grid off, moves and resizes go in steps of 0.05 cell; with it on they snap to whole cells (this is the default).
- Elevation: when widgets overlap, the one with the higher Z number is on top.
- The grid also shows while you drag an app, so you can see where it will land.
- While a widget is being edited, swiping between pages and swiping up for the drawer are paused.

## v0.9.6
- App icon: the glyph is back to its original size (it was too big in 0.9.5) and sits comfortably inside the black background. Same rainbow colours.

## v0.9.5
- New app icon: the Eon symbol in a rainbow gradient (green, cyan, violet, magenta, coral, orange) on a pure black background. The welcome screen logo matches it.
- Removed the built-in clock and date from the top of the home screen, since it could not be moved or removed like a widget. The home grid now starts at the top, so apps you placed earlier sit about two rows higher; drag them back if you want.

## v0.9.4
- New icon shape: every app icon is now the same rounded square (about 26% rounded corners, measured from Smart Launcher), in the drawer, on the home grid and in the app menu. Adaptive icons are cut to the shape; old icons with a transparent margin sit centred on a light or dark plate so the grid looks even.
- Icons are a little bigger (60 dp instead of 56 dp). The size and corner radius are two values at the top of IconShape.kt.

## v0.9.3
- New colours: Eon moves from blue to near-black with soft grey text and a green accent (selected chips, badges, toggles, the playing dot). Panels are smoked black glass instead of blue, the welcome screen and the app icon are charcoal, and the Week widget and cover art match.

## v0.9.2
- Removed the dock: the home screen is now just the clock, your pages and the search pill. "Add to dock" is gone from the app menu. The dark fade at the bottom is shorter now that there is no dock behind it.

## v0.9.1
- Fixed: the build failed on one line in the home menu that still used the old way of checking whether a page is empty. Nothing else changed, so v0.9.1 has everything from v0.9.

## v0.9.0
- Free home grid: apps and widgets now sit on a 4-column grid. Long-press an app and drag it to any empty spot (or onto another app to swap); a highlight shows where it will land. Your existing home screen is moved onto the grid automatically.
- Widgets on the grid: each widget takes a number of cells. In the Widgets screen, the "On this page" tab lets you nudge a widget left, right, up or down and make it taller, shorter, wider or narrower. If a page is full, Eon says there is no space.
- Fixed: weather said "Allow location" even when location was allowed. It now asks the phone for a fresh coarse location itself, and says "No location fix" if there is none. Now playing also shows how many players it can see, to help find out why it stays empty.
- Not yet: dragging widgets directly, moving apps between pages.

## v0.8.0
- Fixed: long-pressing empty space on the home screen did nothing since pages arrived in v0.5, because the page swiper was catching the touch; it now opens the home menu (widgets, pages, settings) again, and long-pressing an app no longer risks opening it twice.
- New: tapping the page marker at the bottom also opens the home menu, as a second way in.

## v0.7.1
- Fixed: the build failed because two functions in the settings state had the same internal name (a naming clash on the look setting). Nothing else changed, so v0.7.1 has everything from v0.5 to v0.7, including home pages, the Eon widgets and weather.

## v0.7.0
- Weather and quote: a new Eon widget with the local weather on the left (angular icon, temperature, feels like) and a daily quote on the right; tap the weather to refresh or to allow location, tap the quote for another one. Weather comes from Open-Meteo using your last known coarse location, so Eon now asks for internet access.
- Not yet: your own quotes, folders, dragging apps between pages.

## v0.6.0
- Eon widgets: two built-in widgets under "EON" in the widget picker. Now playing shows the track and artist as plain text with a round cover and a green dot while playing (tap to open the player; needs notification access), and Week shows seven days around today with the month and the time.
- Gesture: swipe down on the home screen to pull the notification shade.
- Not yet: weather, folders, dragging apps between pages.

## v0.5.0
- Home pages: swipe sideways between pages, each with its own pinned apps and widgets; the marker at the bottom shows where you are, with the Eon glyph always standing for page one.
- Page controls: long-press empty space to add a page to the left or right, or to remove an empty one; pressing Home takes you back to page one.
- Changed: pinning an app or adding a widget now goes to the page you are on, and the widget manager shows that page's widgets.
- Not yet: dragging apps between pages, resizing widgets, folders.

## v0.4.0
- Widgets: long-press empty space and choose Widgets to add any widget from any app, then move or remove them in the "On this page" tab; they sit above your pinned apps.

## v0.3.0
- Drag to rearrange: long-press a pinned app or a dock app and drag it to a new spot; long-press and release still opens the app menu, which can now add or remove dock apps.

## v0.2.0
- Every app now shows in the drawer, Eon appears in the notification access list, and icons get notification counts.
- The drawer has category chips with search across all apps; long-press an app to pin, recategorize, hide, open app info or uninstall.
- Eon settings (Glassy or Flat look, notification access, hidden apps) and a more solid drawer background.

## v0.1.0
- First build: greeting flow, home with clock and dock, app drawer with search.
