package ix.app.eon

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.Remove
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * A box opened: a sheet that rises from the bottom over the dimmed Library, with the box's round badge, its name, how
 * many apps and how long you used them today. Choose how the apps sort (the chips), add apps to a box of your own and
 * use Arrange to take apps out or move them earlier and later. Pull the handle down or tap outside to close.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun LibBoxSheet(
    tile: LibTile, state: EonState, allApps: List<AppEntry>,
    onLaunch: (AppEntry) -> Unit, onMenu: (AppEntry) -> Unit,
    drag: DragState, onDrop: (AppEntry, Offset) -> Unit, origin: androidx.compose.ui.geometry.Rect? = null, onClose: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    var arranging by remember { mutableStateOf(false) }
    var adding by remember { mutableStateOf(false) }
    var shown by remember { mutableStateOf(false) }
    var closing by remember { mutableStateOf(false) }
    val pullY = remember { Animatable(0f) }
    // Slides up and settles without bouncing; closes a little quicker.
    val appear by animateFloatAsState(
        if (shown) 0f else 1f,
        tween(if (shown) 280 else 200, easing = LibEase),
        label = "sheet",
    )
    val screenH = LocalContext.current.resources.displayMetrics.heightPixels.toFloat()
    val closeAt = with(LocalDensity.current) { 140.dp.toPx() }
    LaunchedEffect(Unit) { shown = true }
    val dismiss = {
        if (!closing) {
            closing = true
            shown = false
            scope.launch {
                delay(210)
                onClose()
            }
        }
    }
    BackHandler { dismiss() }
    BackHandler(enabled = arranging) { arranging = false }

    val apps = tile.apps
    val tint = libTintFor(tile.id)
    val canSort = tile.id != "~recent" && tile.id != "~suggest"
    val sheetShape = RoundedCornerShape(topStart = 34.dp, topEnd = 34.dp)
    val timeToday = apps.sumOf { ScreenTime.today[it.packageName] ?: 0L }
    val sub = "${apps.size} apps" + if (ScreenTime.granted && timeToday >= 60_000L) " \u00B7 ${ScreenTime.format(timeToday)} today" else ""

    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.7f * (1f - appear.coerceIn(0f, 1f))))
            .pointerInput(Unit) { detectTapGestures(onTap = { dismiss() }) },
    ) {
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().heightIn(max = (LocalConfiguration.current.screenHeightDp * 0.78f).dp)
                .graphicsLayer {
                    // Rises while growing gently out of the box you tapped (pivot on the box), fading in. No bounce.
                    val o = origin
                    val sc = 1f - 0.1f * appear
                    scaleX = sc
                    scaleY = sc
                    if (o != null) {
                        transformOrigin = androidx.compose.ui.graphics.TransformOrigin(
                            (o.center.x / size.width).coerceIn(0f, 1f), (o.center.y - (screenH - size.height)) / size.height,
                        )
                    }
                    translationY = appear * size.height * 0.55f + pullY.value
                    alpha = (1f - appear * 1.6f).coerceIn(0f, 1f)
                }
                .clip(sheetShape).background(Color(0xFF121218))
                .background(Brush.verticalGradient(listOf(Color(0x0FFFFFFF), Color(0x03FFFFFF))))
                .border(1.dp, Color(0x2EFFFFFF), sheetShape)
                .pointerInput(Unit) { detectTapGestures(onTap = { }) }
                .padding(start = 16.dp, end = 16.dp, top = 10.dp),
        ) {
            // The handle and the header: pull them down to close the sheet.
            Column(
                Modifier.pointerInput(Unit) {
                    detectVerticalDragGestures(
                        onDragEnd = { if (pullY.value > closeAt) dismiss() else scope.launch { pullY.animateTo(0f, spring()) } },
                        onDragCancel = { scope.launch { pullY.animateTo(0f, spring()) } },
                        onVerticalDrag = { change, d ->
                            change.consume()
                            scope.launch { pullY.snapTo((pullY.value + d).coerceAtLeast(0f)) }
                        },
                    )
                },
            ) {
                Box(
                    Modifier.align(Alignment.CenterHorizontally).width(36.dp).height(4.dp).clip(RoundedCornerShape(2.dp))
                        .background(Color(0x59FFFFFF)),
                )
                Row(
                    Modifier.fillMaxWidth().padding(start = 6.dp, end = 4.dp, top = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Box(
                        Modifier.size(46.dp).clip(CircleShape).background(Brush.linearGradient(listOf(tint.a, tint.b))),
                        contentAlignment = Alignment.Center,
                    ) { Icon(catIcon(tile.icon ?: "folder"), null, tint = tint.ink, modifier = Modifier.size(23.dp)) }
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                        Text(
                            tile.name, color = Eon.DText, fontSize = 24.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.4).sp,
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                        Text(sub, color = Eon.DText.copy(alpha = 0.74f), fontSize = 12.sp, maxLines = 1)
                    }
                    if (tile.manage && apps.isNotEmpty()) {
                        Box(
                            Modifier.height(36.dp).clip(RoundedCornerShape(18.dp)).background(Color(0x1AFFFFFF))
                                .border(1.dp, Color(0x29FFFFFF), RoundedCornerShape(18.dp)).clickable { arranging = !arranging }
                                .padding(horizontal = 14.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(if (arranging) "Done" else "Arrange", color = Eon.DAccent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }

            if (canSort) {
              Box(Modifier.fillMaxWidth()) {
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(top = 16.dp, bottom = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    BOX_SORTS.forEach { (key, label) ->
                        val on = LibraryConfig.sortOf(tile.id) == key
                        Box(
                            Modifier.height(34.dp).clip(RoundedCornerShape(17.dp))
                                .then(if (on) Modifier.background(libGrad3()) else Modifier.background(Color(0x1AFFFFFF)))
                                .clickable { LibraryConfig.setSort(tile.id, key) }
                                .padding(horizontal = 14.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                label, color = if (on) Eon.DInk else Color(0xFFD5D8DE), fontSize = 13.sp,
                                fontWeight = if (on) FontWeight.Bold else FontWeight.Medium, maxLines = 1,
                            )
                        }
                    }
                }
                Box(
                    Modifier.align(Alignment.CenterEnd).padding(top = 10.dp).width(44.dp).height(34.dp)
                        .background(Brush.horizontalGradient(listOf(Color(0x00121218), Color(0xFF121218)))),
                )
              }
            }

            val gridRows = (apps.size + 3) / 4
            // The grid is as tall as its rows (the sheet wraps it) and scrolls inside once the sheet reaches its cap.
            val gridH = (gridRows * 88 + (gridRows - 1).coerceAtLeast(0) * 12 + 18).dp
            Box(Modifier.weight(1f, fill = false).fillMaxWidth().then(if (apps.isEmpty()) Modifier else Modifier.height(gridH))) {
                if (apps.isEmpty()) {
                    Box(Modifier.fillMaxWidth().height(160.dp).padding(horizontal = 40.dp), contentAlignment = Alignment.Center) {
                        Text(
                            "No apps here yet.\nTap Add apps to fill this box.", color = Eon.DMuted, fontSize = 14.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        )
                    }
                } else if (arranging) {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(4),
                        contentPadding = PaddingValues(top = 10.dp, bottom = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        items(apps, key = { it.key }) { app ->
                            val i = apps.indexOf(app)
                            Box(Modifier.fillMaxWidth().animateItem(), contentAlignment = Alignment.Center) {
                                AppIconBody(app, 52.dp, true, 12f, false)
                                Box(Modifier.align(Alignment.TopStart).padding(start = 2.dp)) {
                                    LibEditDot(Icons.Outlined.Remove) { state.setCategory(app.packageName, "none") }
                                }
                                Row(Modifier.align(Alignment.BottomCenter), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    if (i > 0) LibEditDot(Icons.Outlined.ChevronLeft) {
                                        LibraryConfig.moveApp(tile.id, apps.map { it.key }, app.key, -1)
                                    }
                                    if (i < apps.size - 1) LibEditDot(Icons.Outlined.ChevronRight) {
                                        LibraryConfig.moveApp(tile.id, apps.map { it.key }, app.key, 1)
                                    }
                                }
                            }
                        }
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(4),
                        contentPadding = PaddingValues(top = 10.dp, bottom = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        items(apps, key = { it.key }) { app ->
                            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                                DragAppIcon(
                                    app, 56.dp, drag, { onLaunch(app) }, { onMenu(app) }, onDrop,
                                    showLabel = true, labelSp = 12f, labelColor = Eon.DText,
                                )
                            }
                        }
                    }
                }
            }
            if (tile.manage) {
                Row(
                    Modifier.fillMaxWidth().padding(top = 8.dp).navigationBarsPadding().padding(bottom = 20.dp).height(50.dp)
                        .clip(RoundedCornerShape(25.dp)).background(Color(0x1AFFFFFF))
                        .border(1.dp, Color(0x29FFFFFF), RoundedCornerShape(25.dp))
                        .clickable { adding = true },
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Outlined.Add, null, tint = Eon.DSoft, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Add apps", color = Eon.DText, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                }
            } else {
                Spacer(Modifier.navigationBarsPadding().height(20.dp))
            }
        }
        if (adding) {
            AddAppsScreen(
                tile.name, allApps, tile.apps.map { it.key }.toSet(),
                onConfirm = { list -> list.forEach { state.setCategory(it.packageName, tile.id) } },
                onClose = { adding = false },
            )
        }
    }
}

/** A small round button used while arranging apps in a box. */
@Composable
internal fun LibEditDot(icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Box(
        Modifier.size(30.dp).clip(CircleShape).background(Color(0xDD1C1C1F))
            .border(1.dp, Color(0x4DFFFFFF), CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, null, tint = Eon.DText, modifier = Modifier.size(16.dp)) }
}

/** Pick any apps to put in a box or folder called [name]. Apps already in it ([inBox]) are ticked and stay. */
@Composable
internal fun AddAppsScreen(
    name: String, allApps: List<AppEntry>, inBox: Set<String>,
    onConfirm: (List<AppEntry>) -> Unit, onClose: () -> Unit,
) {
    BackHandler { onClose() }
    var query by remember { mutableStateOf("") }
    val picked = remember { androidx.compose.runtime.mutableStateListOf<String>() }
    val list = remember(allApps, query) {
        allApps.filter { query.isBlank() || it.label.contains(query.trim(), ignoreCase = true) }.sortedBy { it.label.lowercase() }
    }
    Column(
        Modifier.fillMaxSize().background(Color(0xFA000000)).systemBarsPadding()
            .pointerInput(Unit) { detectTapGestures { } }.padding(horizontal = 16.dp),
    ) {
        Gap(12)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Add apps to", color = Eon.DFaint, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text(name, color = Eon.DText, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            }
            Box(
                Modifier.clip(androidx.compose.foundation.shape.CircleShape).background(Eon.Button)
                    .clickable {
                        onConfirm(allApps.filter { it.key in picked })
                        onClose()
                    }.padding(horizontal = 20.dp, vertical = 10.dp),
            ) {
                Text(if (picked.isEmpty()) "Close" else "Add ${picked.size}", color = Eon.OnAccent, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
        Gap(12)
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0xFF151517)).padding(horizontal = 14.dp, vertical = 12.dp)) {
            if (query.isEmpty()) Text("Search apps", color = Eon.DFaint, fontSize = 15.sp)
            BasicTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                textStyle = TextStyle(color = Eon.DText, fontSize = 15.sp), cursorBrush = SolidColor(Eon.DAccent),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp)) {
            items(list, key = { it.key }) { app ->
                val already = app.key in inBox
                val on = already || app.key in picked
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                        .clickable(enabled = !already) { if (app.key in picked) picked.remove(app.key) else picked.add(app.key) }
                        .padding(horizontal = 8.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Image(bitmap = app.icon, contentDescription = null, modifier = Modifier.size(40.dp))
                    Text(
                        app.label, color = if (already) Eon.DFaint else Eon.DText, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f).padding(start = 14.dp),
                    )
                    Box(
                        Modifier.size(24.dp).clip(androidx.compose.foundation.shape.CircleShape)
                            .accentFill(on && !already, if (already) Color(0xFF2A2A2E) else Color(0xFF1C1C1F)),
                        contentAlignment = Alignment.Center,
                    ) { if (on) Icon(Icons.Outlined.Check, null, tint = if (already) Eon.DFaint else Eon.OnAccent, modifier = Modifier.size(16.dp)) }
                }
            }
        }
    }
}

