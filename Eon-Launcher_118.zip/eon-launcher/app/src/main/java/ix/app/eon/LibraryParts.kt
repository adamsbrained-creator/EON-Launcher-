package ix.app.eon

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Process
import android.provider.Settings
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import android.graphics.Bitmap
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntSize
import kotlin.math.max
import kotlin.math.roundToInt
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Calendar
import kotlin.math.abs

/** The cyan to blue fill of the selected tab and other small buttons in the App Library. */
internal fun libGrad2(): Brush = Eon.dynamic?.let { Brush.linearGradient(listOf(it.primary, it.tertiary)) }
    ?: Brush.linearGradient(listOf(Color(0xFF35D6F0), Color(0xFF5C9DFF)))

/** The cyan, blue and violet fill of the selected sort chip and of Done. */
internal fun libGrad3(): Brush = Eon.dynamic?.let { Brush.horizontalGradient(listOf(it.primary, it.secondary, it.tertiary)) }
    ?: Brush.horizontalGradient(listOf(Color(0xFF35D6F0), Color(0xFF5C9DFF), Color(0xFF9B7BFF)))

internal val LibPink = Color(0xFFF25CCB)

/** A coloured fill with the colour of the glyph that sits on it. */
internal class LibTint(val a: Color, val b: Color, val ink: Color)

private val TintCyan = LibTint(Color(0xFF6BEAFC), Color(0xFF1F9DC4), Color(0xFF0A0A0B))
private val TintBlue = LibTint(Color(0xFF7BAEFF), Color(0xFF3566E0), Color(0xFFFFFFFF))
private val TintViolet = LibTint(Color(0xFFB195FF), Color(0xFF6A47E0), Color(0xFFFFFFFF))
private val TintPink = LibTint(Color(0xFFFF86DA), Color(0xFFC93A9E), Color(0xFF0A0A0B))
private val TintOrange = LibTint(Color(0xFFFFC066), Color(0xFFE8801A), Color(0xFF0A0A0B))
private val TintDark = LibTint(Color(0xFF41444C), Color(0xFF16171A), Color(0xFFF5F5F6))
private val TintAll = listOf(TintCyan, TintBlue, TintViolet, TintPink, TintOrange)

/** The colour of a box's round badge in its sheet. The usual boxes always get the same one. */
internal fun libTintFor(id: String): LibTint = when (id) {
    "social", "contacts" -> TintViolet
    "media", "music", "entertainment" -> TintPink
    "productivity", "reading", "~recent" -> TintOrange
    "games" -> TintBlue
    "tools", "internet", "~suggest" -> TintCyan
    "~other", "other" -> TintDark
    else -> TintAll[abs(id.hashCode()) % TintAll.size]
}

/**
 * How long each app has been on screen today, for the "1h 12m today" pill and the box sheets. Android only shares this
 * with an app the user has switched on in Settings > Usage access, so until then [granted] is false and the Library
 * shows a pill that opens that page. Kept in memory only and never sent anywhere.
 */
object ScreenTime {
    var granted by mutableStateOf(false)
        private set

    /** Milliseconds on screen today per package. */
    val today = mutableStateMapOf<String, Long>()

    /** Everything today except Eon itself. */
    var total by mutableLongStateOf(0L)
        private set

    fun hasAccess(ctx: Context): Boolean = try {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        } else {
            @Suppress("DEPRECATION")
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        }
        mode == AppOpsManager.MODE_ALLOWED
    } catch (_: Exception) {
        false
    }

    /** Looks again: whether access is on, and if so how long each app has been open since midnight. */
    suspend fun refresh(ctx: Context) {
        if (!hasAccess(ctx)) {
            granted = false
            today.clear()
            total = 0L
            return
        }
        val sums = withContext(Dispatchers.Default) { read(ctx) }
        granted = true
        today.clear()
        today.putAll(sums)
        total = sums.entries.filter { it.key != ctx.packageName }.sumOf { it.value }
    }

    private fun read(ctx: Context): Map<String, Long> {
        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager ?: return emptyMap()
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val now = System.currentTimeMillis()
        val sums = HashMap<String, Long>()
        try {
            val events = usm.queryEvents(cal.timeInMillis, now)
            val e = UsageEvents.Event()
            val open = HashMap<String, Long>()
            while (events.hasNextEvent()) {
                events.getNextEvent(e)
                val pkg = e.packageName ?: continue
                when (e.eventType) {
                    // 1 is "activity resumed" (an app comes to the front), 2 is "activity paused" (it leaves).
                    1 -> open[pkg] = e.timeStamp
                    2 -> open.remove(pkg)?.let { sums[pkg] = (sums[pkg] ?: 0L) + (e.timeStamp - it).coerceAtLeast(0L) }
                }
            }
            // Whatever is open right now has been open since it came to the front.
            open.forEach { (p, t) -> sums[p] = (sums[p] ?: 0L) + (now - t).coerceAtLeast(0L) }
        } catch (_: Exception) {
        }
        return sums
    }

    /** "1h 12m", or "12m" under an hour. */
    fun format(ms: Long): String {
        val m = ms / 60_000L
        val h = m / 60L
        return if (h > 0) "${h}h ${m % 60L}m" else "${m}m"
    }

    /** Opens Android's Usage access page, where Eon can be switched on. */
    fun openSettings(ctx: Context) {
        try {
            ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
        }
    }
}

private val LibSaturate = ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(1.35f) })

/**
 * The blurred wallpaper that shows through the boxes, like iOS. When Eon draws the wallpaper itself (the picture from
 * Settings > Wallpaper), a small blurred copy of that picture is made once and each box draws the part of it that is
 * behind it. With the plain system wallpaper Eon cannot read the picture, so there is no copy and the boxes are only
 * tinted glass over the window blur.
 */
internal object LibBackdrop {
    var image by mutableStateOf<ImageBitmap?>(null)
        private set
    private var key = ""

    suspend fun refresh(ctx: Context) {
        if (!WallpaperConfig.active) {
            image = null
            key = ""
            return
        }
        val name = WallpaperConfig.current
        val dm = ctx.resources.displayMetrics
        val k = "$name|${dm.widthPixels}x${dm.heightPixels}"
        if (k == key && image != null) return
        val made = withContext(Dispatchers.Default) { make(ctx, name, dm.widthPixels, dm.heightPixels) }
        if (made != null) {
            image = made
            key = k
        }
    }

    /** The picture cropped to the screen, shrunk to an eighth and blurred, so it costs almost nothing to keep. */
    private fun make(ctx: Context, name: String, sw: Int, sh: Int): ImageBitmap? {
        val tw = (sw / 8).coerceAtLeast(16)
        val th = (sh / 8).coerceAtLeast(16)
        val full = WallpaperStore.load(ctx, name, sw / 4, sh / 4, WallpaperConfig.QUALITY_STANDARD, software = true) ?: return null
        val out = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888)
        val scale = max(tw.toFloat() / full.width, th.toFloat() / full.height)
        val srcW = tw / scale
        val srcH = th / scale
        val l = ((full.width - srcW) / 2f).coerceAtLeast(0f)
        val t = ((full.height - srcH) / 2f).coerceAtLeast(0f)
        val src = android.graphics.Rect(
            l.roundToInt(), t.roundToInt(),
            (l + srcW).roundToInt().coerceAtMost(full.width), (t + srcH).roundToInt().coerceAtMost(full.height),
        )
        android.graphics.Canvas(out).drawBitmap(full, src, android.graphics.Rect(0, 0, tw, th), android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG))
        full.recycle()
        val px = IntArray(tw * th)
        out.getPixels(px, 0, tw, 0, 0, tw, th)
        val tmp = IntArray(px.size)
        repeat(3) {
            for (y in 0 until th) blurLine(px, tmp, y * tw, 1, tw, 4)
            for (x in 0 until tw) blurLine(tmp, px, x, tw, th, 4)
        }
        out.setPixels(px, 0, tw, 0, 0, tw, th)
        return out.asImageBitmap()
    }

    /** One pass of a box blur along a row or a column; the edges repeat their last pixel. */
    private fun blurLine(src: IntArray, dst: IntArray, start: Int, stride: Int, count: Int, r: Int) {
        val div = 2 * r + 1
        var rr = 0
        var g = 0
        var b = 0
        for (i in -r..r) {
            val c = src[start + i.coerceIn(0, count - 1) * stride]
            rr += (c shr 16) and 255
            g += (c shr 8) and 255
            b += c and 255
        }
        for (i in 0 until count) {
            dst[start + i * stride] = (0xFF shl 24) or ((rr / div) shl 16) or ((g / div) shl 8) or (b / div)
            val add = src[start + (i + r + 1).coerceAtMost(count - 1) * stride]
            val rem = src[start + (i - r).coerceAtLeast(0) * stride]
            rr += ((add shr 16) and 255) - ((rem shr 16) and 255)
            g += ((add shr 8) and 255) - ((rem shr 8) and 255)
            b += (add and 255) - (rem and 255)
        }
    }
}

/**
 * A frosted-glass card for a box. Behind the fill, when the blurred wallpaper copy exists ([LibBackdrop]), the part of
 * it that lies behind the box is drawn (a little more colourful, under the same dim layer as the rest of the drawer).
 * The fill is lighter at the top and fades down, and the hairline edge catches the light along the top. [selected]
 * turns the edge accent-coloured.
 */
@Composable
internal fun Modifier.libTileGlass(shape: Shape, selected: Boolean = false): Modifier {
    var origin by remember { mutableStateOf(Offset.Zero) }
    val backdrop = LibBackdrop.image
    val dm = LocalContext.current.resources.displayMetrics
    val base = DrawerConfig.tileColor
    val o = DrawerConfig.tileOpacity
    val top = base.copy(alpha = ((if (LibraryConfig.frosted) o * 2.2f else o * 1.6f) + if (selected) 0.05f else 0f).coerceAtMost(1f))
    val bottom = base.copy(alpha = (if (LibraryConfig.frosted) o * 1.2f else o * 0.8f).coerceAtMost(1f))
    val edge = if (selected) {
        Brush.verticalGradient(listOf(Eon.DAccent.copy(alpha = 0.85f), Eon.DAccent.copy(alpha = 0.35f)))
    } else {
        Brush.verticalGradient(listOf(Color.White.copy(alpha = if (DrawerConfig.tileBorder) 0.42f else 0.24f), Color.White.copy(alpha = 0.06f)))
    }
    var m = this.clip(shape)
    if (backdrop != null) {
        m = m.onGloballyPositioned { origin = it.positionInWindow() }.drawBehind {
            // The wallpaper does not move with the box, so draw it shifted back by where the box is on the screen.
            translate(-origin.x, -origin.y) {
                drawImage(backdrop, dstSize = IntSize(dm.widthPixels, dm.heightPixels), filterQuality = FilterQuality.Medium, colorFilter = LibSaturate)
                drawRect(DrawerConfig.scrim(), size = Size(dm.widthPixels.toFloat(), dm.heightPixels.toFloat()))
            }
        }
    }
    return m.background(Brush.verticalGradient(listOf(top, bottom))).border(if (selected) 1.5.dp else 1.dp, edge, shape)
}

/** The fourth slot of a box with more than four apps: a small glass tile holding the next apps, like iOS. */
@Composable
internal fun LibMiniCluster(rest: List<AppEntry>, size: Dp, modifier: Modifier = Modifier, onClick: (() -> Unit)? = null) {
    val chip = RoundedCornerShape(size * 0.28f)
    val inner = size * 0.1f
    val gap = size * 0.06f
    val mini = (size - inner * 2 - gap) / 2
    Box(
        modifier.size(size).clip(chip).background(Color(0x26FFFFFF)).border(1.dp, Color(0x33FFFFFF), chip)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(inner),
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(gap)) {
            rest.take(4).chunked(2).forEach { pair ->
                Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                    pair.forEach { a -> Image(bitmap = a.icon, contentDescription = null, modifier = Modifier.size(mini).scaledIcon(a.iconScale)) }
                }
            }
        }
    }
}

/** One easing for every Library movement (sheet, Arrange, popups), so nothing feels like its own canned animation: fast start, long soft landing, no bounce. */
internal val LibEase = androidx.compose.animation.core.CubicBezierEasing(0.2f, 0f, 0f, 1f)
