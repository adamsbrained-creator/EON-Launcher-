package ix.app.eon

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Category
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Settings as SettingsIcon
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material.icons.outlined.Wallpaper
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog

@Composable
private fun MenuRow(icon: ImageVector, text: String, color: Color = Eon.Text, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Icon(icon, null, tint = if (color == Eon.Text) Eon.Periwinkle else color, modifier = Modifier.size(20.dp))
        Text(text, color = color, fontSize = 15.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun MenuDivider() {
    Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp).height(1.dp).background(Color(0x24FFFFFF)))
}

/** Long-press menu for an app icon. */
@Composable
fun AppMenu(
    app: AppEntry, state: EonState, inDock: Boolean, canAddToDock: Boolean,
    onToggleDock: () -> Unit, onDismiss: () -> Unit,
) {
    val ctx = LocalContext.current
    var picking by remember { mutableStateOf(false) }
    val category = state.overrides[app.packageName] ?: app.autoCategory
    val pinned = app.key in state.pinned

    Dialog(onDismissRequest = onDismiss) {
        Column(Modifier.width(300.dp).glass(RoundedCornerShape(26.dp)).padding(vertical = 8.dp)) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Image(app.icon, null, Modifier.size(40.dp))
                Column {
                    Text(app.label, color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    Text(category, color = Eon.Muted, fontSize = 12.sp)
                }
            }
            MenuDivider()
            if (!picking) {
                MenuRow(Icons.Outlined.Home, if (pinned) "Remove from home" else "Pin to home") {
                    state.togglePin(app.key); onDismiss()
                }
                if (inDock || canAddToDock) {
                    MenuRow(Icons.Outlined.Home, if (inDock) "Remove from dock" else "Add to dock") {
                        onToggleDock(); onDismiss()
                    }
                }
                MenuRow(Icons.Outlined.Category, "Change category") { picking = true }
                MenuRow(Icons.Outlined.VisibilityOff, "Hide from drawer") {
                    state.hide(app.packageName); onDismiss()
                }
                MenuRow(Icons.Outlined.Info, "App info") {
                    ctx.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.packageName}"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    )
                    onDismiss()
                }
                MenuRow(Icons.Outlined.Delete, "Uninstall", Eon.Danger) {
                    ctx.startActivity(
                        Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.packageName}"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    )
                    onDismiss()
                }
            } else {
                CATEGORIES.forEach { c ->
                    Text(
                        c, color = if (c == category) Eon.Periwinkle else Eon.Text, fontSize = 15.sp,
                        fontWeight = if (c == category) FontWeight.Bold else FontWeight.Medium,
                        modifier = Modifier.fillMaxWidth()
                            .clickable { state.setCategory(app.packageName, c); onDismiss() }
                            .padding(horizontal = 20.dp, vertical = 12.dp),
                    )
                }
            }
        }
    }
}

/** Long-press menu for the empty home screen. */
@Composable
fun HomeMenu(onDismiss: () -> Unit, onSettings: () -> Unit) {
    val ctx = LocalContext.current
    Dialog(onDismissRequest = onDismiss) {
        Column(Modifier.width(280.dp).glass(RoundedCornerShape(26.dp)).padding(vertical = 8.dp)) {
            MenuRow(Icons.Outlined.Wallpaper, "Wallpaper") {
                ctx.startActivity(
                    Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper")
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                )
                onDismiss()
            }
            MenuRow(Icons.Outlined.SettingsIcon, "Eon settings", onClick = onSettings)
        }
    }
}
