package ix.app.eon

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.net.Uri
import android.os.UserHandle
import android.provider.MediaStore
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

val CATEGORIES = listOf("Social", "Media", "Games", "Work", "Reading", "Maps", "Tools", "Other")

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("eon", Context.MODE_PRIVATE)

    var onboarded: Boolean
        get() = sp.getBoolean("onboarded", false)
        set(v) { sp.edit().putBoolean("onboarded", v).apply() }

    /** "glassy" or "flat" */
    var look: String
        get() = sp.getString("look", "glassy") ?: "glassy"
        set(v) { sp.edit().putString("look", v).apply() }

    /** "dark", "light" or "auto" (stored, not applied yet) */
    var theme: String
        get() = sp.getString("theme", "dark") ?: "dark"
        set(v) { sp.edit().putString("theme", v).apply() }

    /** Component names of apps pinned to the home screen, in order. */
    var pinned: List<String>
        get() = (sp.getString("pinned", "") ?: "").split("\n").filter { it.isNotBlank() }
        set(v) { sp.edit().putString("pinned", v.joinToString("\n")).apply() }

    /** Component names in the dock, in order (only used once the dock has been customised). */
    var dock: List<String>
        get() = (sp.getString("dock", "") ?: "").split("\n").filter { it.isNotBlank() }
        set(v) { sp.edit().putString("dock", v.joinToString("\n")).apply() }

    var dockCustom: Boolean
        get() = sp.getBoolean("dockCustom", false)
        set(v) { sp.edit().putBoolean("dockCustom", v).apply() }

    /** Package names hidden from the drawer. */
    var hidden: Set<String>
        get() = sp.getStringSet("hidden", emptySet()) ?: emptySet()
        set(v) { sp.edit().putStringSet("hidden", HashSet(v)).apply() }

    /** Manual category per package. */
    var overrides: Map<String, String>
        get() = (sp.getStringSet("cats", emptySet()) ?: emptySet()).mapNotNull {
            val i = it.indexOf('|')
            if (i > 0) it.substring(0, i) to it.substring(i + 1) else null
        }.toMap()
        set(v) { sp.edit().putStringSet("cats", v.map { "${it.key}|${it.value}" }.toHashSet()).apply() }
}

data class AppEntry(
    val label: String,
    val packageName: String,
    val component: ComponentName,
    val user: UserHandle,
    val icon: ImageBitmap,
    val autoCategory: String,
) {
    val key: String = component.flattenToString()
}

class AppRepo(private val context: Context) {
    private val launcherApps =
        context.getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps

    private fun categoryOf(pkg: String): String {
        val info = try {
            context.packageManager.getApplicationInfo(pkg, 0)
        } catch (_: Exception) {
            return "Other"
        }
        return when (info.category) {
            ApplicationInfo.CATEGORY_SOCIAL -> "Social"
            ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_VIDEO, ApplicationInfo.CATEGORY_IMAGE -> "Media"
            ApplicationInfo.CATEGORY_GAME -> "Games"
            ApplicationInfo.CATEGORY_PRODUCTIVITY -> "Work"
            ApplicationInfo.CATEGORY_NEWS -> "Reading"
            ApplicationInfo.CATEGORY_MAPS -> "Maps"
            else -> if (info.flags and ApplicationInfo.FLAG_SYSTEM != 0) "Tools" else "Other"
        }
    }

    suspend fun load(): List<AppEntry> = withContext(Dispatchers.Default) {
        val px = (context.resources.displayMetrics.density * 56f).toInt().coerceAtLeast(96)
        launcherApps.profiles
            .flatMap { user ->
                launcherApps.getActivityList(null, user).map { info ->
                    val pkg = info.componentName.packageName
                    AppEntry(
                        label = info.label.toString(),
                        packageName = pkg,
                        component = info.componentName,
                        user = user,
                        icon = info.getBadgedIcon(0).toBitmap(px, px).asImageBitmap(),
                        autoCategory = categoryOf(pkg),
                    )
                }
            }
            .filter { it.packageName != context.packageName }
            .sortedBy { it.label.lowercase() }
    }

    fun launch(app: AppEntry) {
        try {
            launcherApps.startMainActivity(app.component, app.user, null, null)
        } catch (_: Exception) {
        }
    }

    /** Phone, messages, browser and camera if they can be found; otherwise the first apps. */
    fun defaultDock(apps: List<AppEntry>): List<AppEntry> {
        val pm = context.packageManager
        val probes = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")),
            Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA),
        )
        val packages = probes.mapNotNull {
            pm.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
        }
        val picked = packages
            .mapNotNull { p -> apps.firstOrNull { it.packageName == p } }
            .distinctBy { it.packageName }
            .toMutableList()
        for (a in apps) {
            if (picked.size >= 4) break
            if (picked.none { it.packageName == a.packageName }) picked.add(a)
        }
        return picked.take(4)
    }

    /** Calls [onChange] when apps are installed, removed or updated. Returns an unregister function. */
    fun watch(onChange: () -> Unit): () -> Unit {
        val callback = object : LauncherApps.Callback() {
            override fun onPackageRemoved(packageName: String, user: UserHandle) = onChange()
            override fun onPackageAdded(packageName: String, user: UserHandle) = onChange()
            override fun onPackageChanged(packageName: String, user: UserHandle) = onChange()
            override fun onPackagesAvailable(
                packageNames: Array<out String>, user: UserHandle, replacing: Boolean,
            ) = onChange()
            override fun onPackagesUnavailable(
                packageNames: Array<out String>, user: UserHandle, replacing: Boolean,
            ) = onChange()
        }
        launcherApps.registerCallback(callback)
        return { launcherApps.unregisterCallback(callback) }
    }
}
