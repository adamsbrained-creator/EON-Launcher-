package ix.app.eon

import android.content.Intent
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver

@Composable
fun SettingsScreen(state: EonState, onClose: () -> Unit, onResetGreeting: () -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    DisposableEffect(Unit) {
        val owner = (ctx as ComponentActivity).lifecycle
        val observer = LifecycleEventObserver { _, event -> if (event == Lifecycle.Event.ON_RESUME) tick++ }
        owner.addObserver(observer)
        onDispose { owner.removeObserver(observer) }
    }
    val notifications = remember(tick) {
        NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    }
    val version = remember {
        runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: ""
    }
    BackHandler { onClose() }

    Column(
        Modifier.fillMaxSize().background(Color(0xF5070B24)).systemBarsPadding().padding(horizontal = 20.dp),
    ) {
        Gap(12)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(Color(0x24FFFFFF)).clickable(onClick = onClose),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Outlined.ArrowBack, "Back", tint = Eon.Text, modifier = Modifier.size(22.dp)) }
            Text("Eon settings", color = Eon.Text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
        Gap(14)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Crumb("Eon", false)
            Text("›", color = Eon.Faint, fontSize = 16.sp)
            Crumb("Settings", true)
        }
        Gap(24)
        Label("LOOK")
        Row(
            Modifier.fillMaxWidth().glass(RoundedCornerShape(24.dp)).padding(14.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Pick("Glassy", state.look == "glassy") { state.changeLook("glassy") }
            Pick("Flat", state.look == "flat") { state.changeLook("flat") }
        }
        Gap(22)
        Label("NOTIFICATIONS")
        Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(24.dp)).padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Dots and counts on icons", color = Eon.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                    Text(if (notifications) "Access granted" else "Access off", color = Eon.Muted, fontSize = 12.sp)
                }
                Box(
                    Modifier.height(34.dp).clip(CircleShape).background(Eon.Button)
                        .clickable { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
                        .padding(horizontal = 16.dp),
                    contentAlignment = Alignment.Center,
                ) { Text(if (notifications) "Manage" else "Open", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold) }
            }
            Gap(8)
            Text(
                "If the switch is greyed out: App info → ⋮ menu → Allow restricted settings.",
                color = Eon.Faint, fontSize = 12.sp, lineHeight = 17.sp,
            )
        }
        Gap(22)
        Label("APPS")
        Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(24.dp)).padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Hidden apps", color = Eon.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                    Text("${state.hidden.size} hidden", color = Eon.Muted, fontSize = 12.sp)
                }
                if (state.hidden.isNotEmpty()) {
                    Box(
                        Modifier.height(34.dp).clip(CircleShape).background(Color(0x24FFFFFF))
                            .clickable { state.showAllApps() }.padding(horizontal = 16.dp),
                        contentAlignment = Alignment.Center,
                    ) { Text("Show all", color = Eon.Text, fontSize = 14.sp, fontWeight = FontWeight.Bold) }
                }
            }
        }
        Gap(22)
        Box(
            Modifier.fillMaxWidth().clip(CircleShape).background(Color(0x1FFFFFFF)).clickable(onClick = onResetGreeting)
                .padding(vertical = 14.dp),
            contentAlignment = Alignment.Center,
        ) { Text("Show the greeting again", color = Eon.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium) }
        Spacer(Modifier.weight(1f))
        Text(
            "Eon $version", color = Eon.Faint, fontSize = 12.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 12.dp),
        )
    }
}

@Composable
private fun Label(text: String) {
    Text(
        text, color = Eon.Faint, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp,
        modifier = Modifier.padding(start = 4.dp, bottom = 8.dp),
    )
}

@Composable
private fun Crumb(text: String, active: Boolean) {
    val bg = if (active) Modifier.background(Eon.Button) else Modifier.background(Color(0x1FFFFFFF))
    Box(Modifier.height(30.dp).clip(CircleShape).then(bg).padding(horizontal = 12.dp), contentAlignment = Alignment.Center) {
        Text(text, color = if (active) Color.White else Color(0xFFC9D1F5), fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun RowScope.Pick(label: String, on: Boolean, onClick: () -> Unit) {
    val look = if (on) Modifier.background(Eon.Button)
    else Modifier.background(Color(0x1FFFFFFF)).border(1.dp, Color(0x4DBECDFF), CircleShape)
    Box(
        Modifier.weight(1f).height(40.dp).clip(CircleShape).then(look).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label, color = if (on) Color.White else Color(0xFFC9D1F5), fontSize = 15.sp,
            fontWeight = if (on) FontWeight.Bold else FontWeight.Medium,
        )
    }
}
