package ix.app.eon

import android.app.Notification
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.compose.runtime.mutableStateMapOf

/** Number of visible notifications per package, read by the icons. */
object Badges {
    val counts = mutableStateMapOf<String, Int>()
}

class EonNotificationListener : NotificationListenerService() {
    override fun onListenerConnected() = refresh()
    override fun onListenerDisconnected() = publish(emptyMap())
    override fun onNotificationPosted(sbn: StatusBarNotification?) = refresh()
    override fun onNotificationRemoved(sbn: StatusBarNotification?) = refresh()

    private fun refresh() {
        val active = try {
            activeNotifications
        } catch (_: Exception) {
            null
        } ?: return
        val next = HashMap<String, Int>()
        for (n in active) {
            if (n.isOngoing) continue
            if ((n.notification.flags and Notification.FLAG_GROUP_SUMMARY) != 0) continue
            next[n.packageName] = (next[n.packageName] ?: 0) + 1
        }
        publish(next)
    }

    private fun publish(next: Map<String, Int>) {
        Handler(Looper.getMainLooper()).post {
            Badges.counts.clear()
            Badges.counts.putAll(next)
        }
    }
}
