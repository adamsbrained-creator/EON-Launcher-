package ix.app.eon

import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

val LocalLook = compositionLocalOf { "glassy" }

/** Everything the user can change, kept in memory and saved to [Prefs]. */
class EonState(private val prefs: Prefs) {
    var look by mutableStateOf(prefs.look)
        private set
    val pinned = mutableStateListOf<String>().also { it.addAll(prefs.pinned) }
    val dock = mutableStateListOf<String>().also { it.addAll(prefs.dock) }
    var dockCustom by mutableStateOf(prefs.dockCustom)
        private set
    val hidden = mutableStateListOf<String>().also { it.addAll(prefs.hidden) }
    val overrides = mutableStateMapOf<String, String>().also { it.putAll(prefs.overrides) }

    fun changeLook(value: String) {
        look = value
        prefs.look = value
    }

    fun togglePin(key: String) {
        if (!pinned.remove(key)) pinned.add(key)
        prefs.pinned = pinned.toList()
    }

    fun moveHome(from: Int, to: Int) {
        if (from == to || from !in pinned.indices || to !in pinned.indices) return
        pinned.add(to, pinned.removeAt(from))
        prefs.pinned = pinned.toList()
    }

    fun setDock(keys: List<String>) {
        dock.clear()
        dock.addAll(keys)
        dockCustom = true
        prefs.dock = keys
        prefs.dockCustom = true
    }

    fun hide(pkg: String) {
        if (pkg !in hidden) hidden.add(pkg)
        prefs.hidden = hidden.toSet()
    }

    fun showAllApps() {
        hidden.clear()
        prefs.hidden = emptySet()
    }

    fun setCategory(pkg: String, category: String) {
        overrides[pkg] = category
        prefs.overrides = overrides.toMap()
    }
}
