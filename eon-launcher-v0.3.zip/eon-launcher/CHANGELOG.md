# Eon: what's new

## v0.3.0
- New: drag to rearrange. Long-press a pinned app on the home screen, then drag it to a new spot
- New: the dock can be rearranged the same way, and you can add or remove dock apps from the long-press menu
- Changed: long-press and release without moving still opens the app menu
- Changed: long-press on empty space opens the home menu only on empty space (not on icons)
- Not yet: dragging between the drawer, home and dock; folders; widgets

## v0.2.0
- Fixed: the drawer now lists every app (Eon asks Android for full app visibility)
- Fixed: Eon now appears in Android's notification access list
- New: notification counts on app icons (needs notification access)
- New: drawer categories (Social, Media, Games, Work, Reading, Maps, Tools, Other) as chips; typing searches all apps
- New: long-press an app: pin to home, change category, hide, app info, uninstall
- New: pinned apps on the home screen (4 columns, up to 16)
- New: long-press the home screen: wallpaper, Eon settings
- New: Eon settings: Glassy or Flat look, notification access, hidden apps, show greeting again
- Changed: the drawer background is more solid so the home clock no longer shows through
- Not yet: widgets, dock editing, drag to rearrange, light theme

## v0.1.0
- First build: greeting flow, home with clock and dock, app drawer with search
