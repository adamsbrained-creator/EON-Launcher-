package ix.app.eon

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material.icons.outlined.ViewModule
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private class GridChip(val id: String, val name: String, val count: Int, val manage: Boolean)

/**
 * The normal icon-grid drawers. Shelves: one row of icons per shelf (Suggestions, Recently added, your boxes, Other apps)
 * that scrolls sideways, with See all, a search pill and an A-Z button at the bottom. Chips: a search pill, a row of chips
 * (All, Suggested, Recent and your boxes) and one grid of icons under them. Both use the columns, icon size, labels, sort
 * and background from Settings > Drawer, and the chips, search pill and shelves follow the Library look (Glass or Flat).
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun GridDrawer(
    shelves: Boolean,
    apps: List<AppEntry>, state: EonState, focusSearch: Boolean,
    onLaunch: (AppEntry) -> Unit, onMenu: (AppEntry) -> Unit, onClose: () -> Unit,
    drag: DragState, onDrop: (AppEntry, Offset) -> Unit,
    onSettings: () -> Unit = {},
) {
    val focus = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    var searching by remember { mutableStateOf(focusSearch || DrawerConfig.autoKeyboard) }
    var query by remember { mutableStateOf("") }
    var azView by remember { mutableStateOf(false) }
    var openId by remember { mutableStateOf<String?>(null) }
    var sel by remember { mutableStateOf(state.drawerCategory) }
    var adding by remember { mutableStateOf(false) }
    var menuFor by remember { mutableStateOf<String?>(null) }
    var renaming by remember { mutableStateOf<String?>(null) }
    var picking by remember { mutableStateOf<String?>(null) }
    var openFolderKey by remember { mutableStateOf<String?>(null) }
    var moreMenu by remember { mutableStateOf(false) }
    var moreAnchor by remember { mutableStateOf<Rect?>(null) }
    val bounds = remember { HashMap<String, Rect>() }
    val edges = remember { ListEdges() }
    val edgePull = remember { EdgePull() }
    val listState = rememberLazyListState()
    val tiles by remember(apps) { derivedStateOf { buildTiles(apps, state) } }
    val q = query.trim()

    // The Library leaves its sheet position behind when it closes; the home screen's depth and blur read it, so start from open.
    LaunchedEffect(Unit) { LibPull.p = 0f }
    // The blurred wallpaper the cards show through (only when the wallpaper is Eon's own picture), as in the Library.
    val ctx = androidx.compose.ui.platform.LocalContext.current
    LaunchedEffect(WallpaperConfig.enabled, WallpaperConfig.current) { LibBackdrop.refresh(ctx) }

    LaunchedEffect(searching) {
        if (searching) {
            try {
                focus.requestFocus()
            } catch (_: Exception) {
            }
        }
    }
    BackHandler(enabled = openFolderKey != null) { openFolderKey = null }
    BackHandler(enabled = searching) {
        searching = false
        query = ""
        focusManager.clearFocus()
    }
    BackHandler(enabled = azView && !searching) { azView = false }

    val other = if (shelves) "Chips" else "Shelves"
    val switchActions = listOf(
        PopupAction(Icons.Outlined.GridView, "Switch to Library") { state.chooseDrawerStyle("library") },
        PopupAction(Icons.Outlined.ViewModule, "Switch to $other") { state.chooseDrawerStyle(if (shelves) "chips" else "shelves") },
        PopupAction(Icons.Outlined.Tune, "Drawer settings") { onSettings() },
    )

    Box(
        Modifier.fillMaxSize()
            .pullToClose(edgePull, { !searching && drag.app == null && openId == null }, { edges.atTop }, { edges.atBottom }, onClose)
            .graphicsLayer {
                translationY = edgePull.offset
                alpha = 1f - 0.5f * (Math.abs(edgePull.offset) / size.height.coerceAtLeast(1f)).coerceIn(0f, 1f)
            },
    ) {
        Column(
            Modifier.fillMaxSize()
                .background(DrawerConfig.scrim())
                // Keeps touches from reaching the home screen underneath.
                .pointerInput(Unit) { detectTapGestures(onTap = { }) }
                .systemBarsPadding().imePadding(),
        ) {
            if (searching) {
                Spacer(Modifier.height(8.dp))
                SearchField(
                    query = query, onQuery = { query = it }, focus = focus,
                    onDone = {
                        val list = if (q.isEmpty()) apps else apps.filter { it.label.contains(q, ignoreCase = true) }
                        list.firstOrNull()?.let(onLaunch)
                    },
                    onClose = {
                        searching = false
                        query = ""
                        focusManager.clearFocus()
                    },
                )
                val shown = remember(apps, q) { if (q.isEmpty()) apps else apps.filter { SearchIndex.matches(it, q) } }
                val smart = remember(q) { SmartSearch.answer(q) }
                if (smart != null) SmartAnswerCard(smart, Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
                if (q.isEmpty()) RecentChips({ query = it }, Modifier.padding(horizontal = 16.dp))
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    AppGrid(shown, "No apps match", onLaunch, onMenu, drag, onDrop, fitToApps = DrawerConfig.autoFit)
                }
                if (q.length >= 2) {
                    Column(
                        Modifier.fillMaxWidth().heightIn(max = 260.dp).verticalScroll(rememberScrollState())
                            .padding(horizontal = 16.dp),
                    ) {
                        if (shown.isEmpty()) NoAppsHint(state)
                        ExtraResults(q, state, shown, onLaunch)
                    }
                }
            } else if (shelves) {
                // ---- Shelves
                Row(
                    Modifier.fillMaxWidth().padding(start = 20.dp, end = 16.dp, top = 14.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Library", color = DrawerConfig.textColor, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                        Text(
                            if (azView) "A to Z · ${apps.size} apps" else "${apps.size} apps in ${tiles.size} shelves",
                            color = Eon.DSoft, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                        )
                    }
                    Box(
                        Modifier.size(44.dp).onGloballyPositioned { moreAnchor = it.boundsInWindow() }
                            .clip(CircleShape).background(Color(0x12FFFFFF)).border(1.dp, Color(0x24FFFFFF), CircleShape)
                            .clickable { moreMenu = true },
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Outlined.MoreVert, "Library options", tint = DrawerConfig.textColor, modifier = Modifier.size(20.dp)) }
                }
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    if (azView) {
                        val az = remember(apps) { apps.sortedBy { it.label.lowercase() } }
                        AppGrid(az, "No apps", onLaunch, onMenu, drag, onDrop, fitToApps = DrawerConfig.autoFit, edges = edges)
                    } else {
                        val top = !listState.canScrollBackward
                        val bottom = !listState.canScrollForward
                        SideEffect {
                            edges.atTop = top
                            edges.atBottom = bottom
                        }
                        // Each shelf is a card made like a Library box: same colour, opacity, corners and outline (Settings > Drawer),
                        // Glass or Flat, with a wash of its own colour.
                        val shelfShape = RoundedCornerShape(LibStyle.tile(DrawerConfig.tileRadius))
                        LazyColumn(
                            Modifier.fillMaxSize(), state = listState,
                            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 16.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp),
                        ) {
                            items(tiles, key = { it.id }) { t ->
                                Column(Modifier.fillMaxWidth().libTileGlass(shelfShape, false, libTintFor(t.id).a)) {
                                    Row(
                                        Modifier.fillMaxWidth()
                                            .onGloballyPositioned { bounds[t.id] = it.boundsInWindow() }
                                            .combinedClickable(onClick = { openId = t.id }, onLongClick = { if (t.manage) menuFor = t.id })
                                            .padding(start = 18.dp, end = 10.dp, top = 12.dp, bottom = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    ) {
                                        Box(Modifier.size(8.dp).clip(CircleShape).background(libTintFor(t.id).a))
                                        Text(
                                            t.name, color = DrawerConfig.textColor, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold,
                                            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false),
                                        )
                                        Text("${t.apps.size}", color = Eon.DSoft, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        Spacer(Modifier.weight(1f))
                                        Text(
                                            "See all", color = Eon.DAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                                            modifier = Modifier.clip(CircleShape).padding(horizontal = 8.dp, vertical = 4.dp),
                                        )
                                    }
                                    if (t.apps.isEmpty()) {
                                        Text("Nothing here yet", color = Eon.DMuted, fontSize = 12.sp, modifier = Modifier.padding(start = 18.dp, bottom = 14.dp))
                                    } else {
                                        LazyRow(
                                            Modifier.fillMaxWidth(),
                                            contentPadding = PaddingValues(start = 18.dp, end = 18.dp, bottom = 12.dp),
                                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                                        ) {
                                            items(t.apps, key = { it.key }) { app ->
                                                DragAppIcon(
                                                    app, 60.dp, drag, { onLaunch(app) }, { onMenu(app) }, onDrop,
                                                    showLabel = DrawerConfig.showLabels, labelSp = 11f, labelColor = DrawerConfig.textColor,
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                // Search pill with the A-Z button.
                Box(Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 16.dp)) {
                    Row(
                        Modifier.fillMaxWidth().height(54.dp).libGlass(if (LibraryConfig.isFlat) LibStyle.field() else RoundedCornerShape(27.dp))
                            .clickable { searching = true }.padding(start = 18.dp, end = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Icon(Icons.Outlined.Search, null, tint = LibStyle.soft, modifier = Modifier.size(20.dp))
                        Text("Search or jump to a letter", color = LibStyle.soft, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f), maxLines = 1)
                        Box(
                            Modifier.size(40.dp).clip(CircleShape).background(Eon.DAccent).clickable { azView = !azView },
                            contentAlignment = Alignment.Center,
                        ) { Text("A–Z", color = Color(0xFF0A0A0B), fontSize = 13.sp, fontWeight = FontWeight.ExtraBold) }
                    }
                }
            } else {
                // ---- Chips
                Row(
                    Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 12.dp).height(50.dp)
                        .libGlass(LibStyle.field()).clickable { searching = true }.padding(start = 18.dp, end = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Icon(Icons.Outlined.Search, null, tint = LibStyle.soft, modifier = Modifier.size(19.dp))
                    Text("Search apps", color = LibStyle.soft, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    Box(
                        Modifier.size(38.dp).onGloballyPositioned { moreAnchor = it.boundsInWindow() }.clip(CircleShape)
                            .clickable { moreMenu = true },
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Outlined.MoreVert, "Drawer options", tint = LibStyle.soft, modifier = Modifier.size(20.dp)) }
                }
                val chips = remember(tiles, apps) {
                    listOf(GridChip(CAT_ALL, "All", apps.size, false)) + tiles.map { GridChip(it.id, it.name, it.apps.size, it.manage) }
                }
                val current = chips.firstOrNull { it.id == sel } ?: chips.first()
                val chipShape = if (LibraryConfig.isFlat) LibStyle.chip() else RoundedCornerShape(19.dp)
                LazyRow(
                    Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 6.dp).libFadeEnd(),
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(chips, key = { it.id }) { c ->
                        val on = c.id == current.id
                        val ink = if (on) Color(0xFF0A0A0B) else LibStyle.ink
                        Row(
                            Modifier.height(38.dp).onGloballyPositioned { bounds[c.id] = it.boundsInWindow() }
                                .then(if (on) Modifier.clip(chipShape).background(Eon.DAccent).border(1.dp, Eon.DAccent, chipShape) else Modifier.libGlass(chipShape))
                                .combinedClickable(onClick = { sel = c.id }, onLongClick = { if (c.manage) menuFor = c.id })
                                .padding(horizontal = 16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(7.dp),
                        ) {
                            Text(c.name, color = ink, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            Text("${c.count}", color = ink.copy(alpha = 0.7f), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    item(key = "~add") {
                        Box(
                            Modifier.size(38.dp).libGlass(chipShape).clickable { adding = true },
                            contentAlignment = Alignment.Center,
                        ) { Icon(Icons.Outlined.Add, "New box", tint = LibStyle.ink, modifier = Modifier.size(20.dp)) }
                    }
                }
                val isAll = current.id == CAT_ALL
                val list = if (isAll) apps else tiles.firstOrNull { it.id == current.id }?.apps ?: apps
                Row(
                    Modifier.fillMaxWidth().padding(start = 24.dp, end = 24.dp, top = 12.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.Bottom,
                ) {
                    Text(
                        if (isAll) "All apps" else current.name, color = DrawerConfig.textColor, fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f),
                    )
                    Text(DRAWER_SORTS.getOrElse(DrawerConfig.sort) { "" }, color = Eon.DSoft, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    AppGrid(
                        list, "No apps", onLaunch, onMenu, drag, onDrop, fitToApps = DrawerConfig.autoFit,
                        folders = if (isAll) state.drawerFolders else emptyList(), allApps = apps,
                        onOpenFolder = { openFolderKey = it.key }, edges = edges,
                    )
                }
            }
        }

        state.drawerFolders.firstOrNull { it.key == openFolderKey }?.let { f ->
            PopAnim {
                DrawerFolderPopup(
                    state, f, apps,
                    onLaunch = { app -> openFolderKey = null; onLaunch(app) },
                    onMenu = onMenu,
                    onClose = { openFolderKey = null },
                )
            }
        }
        openId?.let { id ->
            tiles.firstOrNull { it.id == id }?.let { t ->
                LibBoxSheet(t, state, apps, onLaunch, onMenu, drag, onDrop, origin = null) { openId = null }
            }
        }
        if (adding) {
            AddCategoryScreen(
                existing = state.categories.map { it.id }.toSet(),
                onPick = { def ->
                    val id = state.addCategory(def)
                    state.selectCategory(id)
                    sel = id
                    adding = false
                },
                onCustom = {
                    val id = state.addCustomCategory()
                    state.selectCategory(id)
                    sel = id
                    adding = false
                    renaming = id
                },
                onBack = { adding = false },
            )
        }
    }

    if (moreMenu) {
        LibMenu(
            anchor = moreAnchor,
            items = (listOf(PopupAction(Icons.Outlined.Add, "New box") { adding = true }) + switchActions)
                .map { a -> PopupAction(a.icon, a.label) { moreMenu = false; a.onClick() } },
            onDismiss = { moreMenu = false },
        )
    }
    menuFor?.let { id ->
        val cat = state.categories.firstOrNull { it.id == id }
        if (cat != null) {
            CategoryPopup(
                title = cat.name, anchor = bounds[id], canRemove = id != CAT_ALL,
                onAdd = { menuFor = null; adding = true },
                onEditIcon = { menuFor = null; picking = id },
                onRename = { menuFor = null; renaming = id },
                onRemove = { menuFor = null; if (sel == id) sel = CAT_ALL; state.removeCategory(id) },
                onDismiss = { menuFor = null },
                extras = switchActions.map { a -> PopupAction(a.icon, a.label) { menuFor = null; a.onClick() } },
            )
        }
    }
    renaming?.let { id ->
        val cat = state.categories.firstOrNull { it.id == id }
        if (cat != null) {
            NameDialog(
                title = "Rename category", initial = cat.name,
                onDone = { state.renameCategory(id, it); renaming = null },
                onDismiss = { renaming = null },
            )
        }
    }
    picking?.let { id ->
        val cat = state.categories.firstOrNull { it.id == id }
        if (cat != null) {
            IconPickerDialog(
                current = cat.icon,
                onPick = { state.setCategoryIcon(id, it); picking = null },
                onDismiss = { picking = null },
            )
        }
    }
}
