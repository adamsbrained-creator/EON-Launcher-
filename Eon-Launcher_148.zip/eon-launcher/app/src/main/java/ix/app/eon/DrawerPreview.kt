package ix.app.eon

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/*
 * The picture at the top of Settings > Drawer. It is not a drawing of the drawer: it is the drawer's own pieces (your real
 * icons, your real folders and shelves, the same glass cards, colours, corners, spacing and labels) laid out on a phone-sized
 * screen and shrunk to fit, so every setting below shows in it the way it will really look. Nothing in it can be touched
 * except the whole card, which makes the picture bigger or smaller.
 */

/** The size of the screen the drawer is laid out on (dp). It is shrunk so its width fills the card, and the card scrolls over it. */
private const val SCREEN_W = 412f
private const val SCREEN_H = 860f

private val PREVIEW_SIZES = listOf("S" to 240.dp, "M" to 380.dp, "L" to 540.dp)

@Composable
internal fun DrawerLivePreview(state: EonState) {
    var size by rememberSaveable { mutableStateOf(0) }
    val cardH by animateDpAsState(PREVIEW_SIZES[size].second, tween(240), label = "previewH")
    val shape = RoundedCornerShape(22.dp)
    val scroll = rememberScrollState()
    BoxWithConstraints(Modifier.fillMaxWidth().height(cardH).clip(shape).background(Color.Black).border(1.dp, Eon.P2, shape)) {
        // The screen is laid out at full size, scaled from its top-left corner until its width fills the card, and scrolls.
        val scale = maxWidth.value / SCREEN_W
        Box(Modifier.fillMaxSize().verticalScroll(scroll)) {
            Box(Modifier.size(maxWidth, (SCREEN_H * scale).dp)) {
                Box(
                    Modifier.wrapContentSize(Alignment.TopStart, unbounded = true).size(SCREEN_W.dp, SCREEN_H.dp)
                        .graphicsLayer { scaleX = scale; scaleY = scale; transformOrigin = TransformOrigin(0f, 0f) },
                ) { PreviewScreen(state) }
            }
        }
        // Small, medium or large. Only this control takes a tap; everything else scrolls the picture.
        Row(
            Modifier.align(Alignment.BottomEnd).padding(end = 10.dp, bottom = 10.dp).clip(CircleShape)
                .background(Color(0xCC111114)).border(1.dp, Color(0x33FFFFFF), CircleShape).padding(3.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            PREVIEW_SIZES.forEachIndexed { i, (label, _) ->
                val on = i == size
                Box(
                    Modifier.size(width = 34.dp, height = 28.dp).clip(CircleShape).background(if (on) Eon.DAccent else Color.Transparent)
                        .clickable { size = i },
                    contentAlignment = Alignment.Center,
                ) { Text(label, color = if (on) Color(0xFF0A0A0B) else Color(0xFFD0D3DA), fontSize = 12.sp, fontWeight = FontWeight.ExtraBold) }
            }
        }
    }
}

@Composable
private fun PreviewScreen(state: EonState) {
    val cfg = DrawerConfig
    val ctx = LocalContext.current
    val style = state.drawerStyle
    // The blurred wallpaper the Library cards show through, when Eon has a copy of the wallpaper.
    LaunchedEffect(WallpaperConfig.enabled, WallpaperConfig.current) { LibBackdrop.refresh(ctx) }
    val apps = remember(state.appsForLabels, state.hidden.size, cfg.hidePlayStore, cfg.hideIconPacks, cfg.sort) {
        sortApps(state.appsForLabels.filter { it.packageName !in state.hidden && !cfg.hiddenByRules(it) }, cfg.sort)
    }
    val tiles = buildTiles(apps, state)

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        PreviewWallpaper()
        Box(Modifier.fillMaxSize().background(cfg.scrim()))
        // The Library lays a little extra dim over the whole screen, so home widgets do not show through as ghosts.
        if (style == "library") Box(Modifier.fillMaxSize().background(Color(0x59000000)))
        when (style) {
            "library" -> PrevLibrary(tiles)
            "shelves" -> PrevShelves(tiles, apps.size)
            "chips" -> PrevChips(tiles, apps)
            else -> PrevBar(state, apps)
        }
    }
}

/** Your wallpaper when Eon has a copy of it, otherwise a colourful stand-in, blurred as much as the Blur slider says. */
@Composable
private fun PreviewWallpaper() {
    val image = LibBackdrop.image
    val radius = (BlurConfig.amount / 100f * 28f).dp
    val blurred = if (BlurConfig.amount > 0) Modifier.blur(radius, BlurredEdgeTreatment.Unbounded) else Modifier
    Box(Modifier.fillMaxSize().then(blurred)) {
        if (image != null) {
            Image(bitmap = image, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        } else {
            Box(
                Modifier.fillMaxSize().background(
                    Brush.linearGradient(listOf(Color(0xFF2B5CFF), Color(0xFFF25CCB), Color(0xFFFFA63D))),
                ),
            )
            Box(
                Modifier.fillMaxSize().background(
                    Brush.radialGradient(listOf(Color(0x6635D6F0), Color.Transparent), center = androidx.compose.ui.geometry.Offset(90f, 520f), radius = 360f),
                ),
            )
        }
    }
}

/** Keeps what is inside from being squeezed into the screen: it is laid out at its natural height and cut off at the edge, like a list that scrolls. */
private fun Modifier.naturalHeight(): Modifier = this.wrapContentHeight(Alignment.Top, unbounded = true)

// ---- Library

@Composable
private fun PrevLibrary(tiles: List<LibTile>) {
    val cols = DrawerConfig.libColumns
    Column(Modifier.fillMaxSize().padding(top = 36.dp)) {
        // The search pill ("Apps"), as at the top of the real Library.
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp).height(48.dp).libGlass(LibStyle.field()).padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Outlined.Search, null, tint = LibStyle.soft, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(10.dp))
            Text("Apps", color = LibStyle.soft, fontSize = 16.sp)
        }
        Box(Modifier.weight(1f).fillMaxWidth().clipToBounds()) {
            Column(
                Modifier.fillMaxWidth().naturalHeight().padding(start = 20.dp, end = 20.dp, top = 12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                tiles.chunked(cols).take(6).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.Top) {
                        row.forEach { t -> Box(Modifier.weight(1f)) { PrevTile(t, cols) } }
                        repeat(cols - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
        }
    }
}

/** One Library box: the same card, the same four slots and the same "+N" cluster as the real one. */
@Composable
private fun PrevTile(tile: LibTile, cols: Int) {
    val shape = RoundedCornerShape(LibStyle.tile(DrawerConfig.tileRadius))
    val small = cols >= 3
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        BoxWithConstraints(Modifier.fillMaxWidth().aspectRatio(1f).libTileGlass(shape, false, libTintFor(tile.id).a)) {
            val w = maxWidth
            val pad = w * 0.10f
            val gap = w * 0.07f
            val icon = w * 0.365f
            val apps = tile.apps
            if (apps.isNotEmpty()) {
                val overflow = apps.size > 4
                val shown = if (overflow) apps.take(3) else apps
                val near = pad
                val far = pad + icon + gap
                val mid = (w - icon) / 2
                val slots: List<Pair<Dp, Dp>> = when {
                    overflow || apps.size == 4 -> listOf(near to near, far to near, near to far, far to far)
                    apps.size == 3 -> listOf(near to near, far to near, mid to far)
                    apps.size == 2 -> listOf(near to mid, far to mid)
                    else -> listOf(mid to mid)
                }
                shown.forEachIndexed { i, app ->
                    Image(
                        bitmap = app.icon, contentDescription = null,
                        modifier = Modifier.offset(slots[i].first, slots[i].second).size(icon).scaledIcon(app.iconScale),
                    )
                }
                if (overflow) LibMiniCluster(apps.drop(3), icon, Modifier.offset(slots[3].first, slots[3].second))
            }
        }
        val nameSize = if (small) 12.sp else 13.sp
        if (LibraryConfig.style == 1) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(tile.name, color = DrawerConfig.textColor, fontSize = nameSize, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                Text("${tile.apps.size}", color = DrawerConfig.textColor.copy(alpha = 0.62f), fontSize = 12.sp)
            }
        } else {
            Text(
                tile.name, color = DrawerConfig.textColor, fontSize = nameSize, fontWeight = FontWeight.Medium,
                maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(horizontal = 2.dp),
            )
        }
    }
}

// ---- Shelves

@Composable
private fun PrevShelves(tiles: List<LibTile>, appCount: Int) {
    val cfg = DrawerConfig
    val shape = RoundedCornerShape(LibStyle.tile(cfg.tileRadius))
    Column(Modifier.fillMaxSize().padding(top = 32.dp)) {
        Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 16.dp, top = 14.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Library", color = cfg.textColor, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                Text("$appCount apps in ${tiles.size} shelves", color = Eon.DSoft, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(Color(0x12FFFFFF)).border(1.dp, Color(0x24FFFFFF), CircleShape),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Outlined.MoreVert, null, tint = cfg.textColor, modifier = Modifier.size(20.dp)) }
        }
        Box(Modifier.weight(1f).fillMaxWidth().clipToBounds()) {
            Column(
                Modifier.fillMaxWidth().naturalHeight().padding(start = 16.dp, end = 16.dp, top = 6.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                tiles.take(7).forEach { t ->
                    Column(Modifier.fillMaxWidth().libTileGlass(shape, false, libTintFor(t.id).a)) {
                        Row(
                            Modifier.fillMaxWidth().padding(start = 18.dp, end = 10.dp, top = 12.dp, bottom = 8.dp),
                            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Box(Modifier.size(8.dp).clip(CircleShape).background(libTintFor(t.id).a))
                            Text(t.name, color = cfg.textColor, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                            Text("${t.apps.size}", color = Eon.DSoft, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.weight(1f))
                            Text("See all", color = Eon.DAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                        }
                        Box(Modifier.fillMaxWidth().clipToBounds()) {
                            Row(
                                Modifier.wrapContentWidth(Alignment.Start, unbounded = true).padding(start = 18.dp, end = 18.dp, bottom = 12.dp),
                                horizontalArrangement = Arrangement.spacedBy(16.dp),
                            ) {
                                t.apps.take(7).forEach { app ->
                                    AppIconBody(app, 60.dp, cfg.showLabels, 11f, false, cfg.textColor, previewCount = 0)
                                }
                            }
                        }
                    }
                }
            }
        }
        PrevPill("Search or jump to a letter", if (LibraryConfig.isFlat) LibStyle.field() else RoundedCornerShape(27.dp), 54.dp, azButton = true)
    }
}

/** The search pill at the bottom of Shelves (with the A-Z button) or at the top of Chips. */
@Composable
private fun PrevPill(text: String, shape: androidx.compose.ui.graphics.Shape, height: Dp, azButton: Boolean = false) {
    Box(Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = if (azButton) 10.dp else 12.dp, bottom = if (azButton) 22.dp else 0.dp)) {
        Row(
            Modifier.fillMaxWidth().height(height).libGlass(shape).padding(start = 18.dp, end = 7.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Icon(Icons.Outlined.Search, null, tint = LibStyle.soft, modifier = Modifier.size(20.dp))
            Text(text, color = LibStyle.soft, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f), maxLines = 1)
            if (azButton) {
                Box(Modifier.size(40.dp).clip(CircleShape).background(Eon.DAccent), contentAlignment = Alignment.Center) {
                    Text("A–Z", color = Color(0xFF0A0A0B), fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                }
            } else {
                Icon(Icons.Outlined.MoreVert, null, tint = LibStyle.soft, modifier = Modifier.size(20.dp))
            }
        }
    }
}

// ---- Chips

@Composable
private fun PrevChips(tiles: List<LibTile>, apps: List<AppEntry>) {
    val cfg = DrawerConfig
    val chipShape = if (LibraryConfig.isFlat) LibStyle.chip() else RoundedCornerShape(19.dp)
    val chips = listOf("All" to apps.size) + tiles.map { it.name to it.apps.size }
    Column(Modifier.fillMaxSize().padding(top = 32.dp)) {
        PrevPill("Search apps", LibStyle.field(), 50.dp)
        Box(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 6.dp).clipToBounds().libFadeEnd()) {
            Row(
                Modifier.wrapContentWidth(Alignment.Start, unbounded = true).padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                chips.forEachIndexed { i, (name, count) ->
                    val on = i == 0
                    val ink = if (on) Color(0xFF0A0A0B) else LibStyle.ink
                    Row(
                        Modifier.height(38.dp)
                            .then(if (on) Modifier.clip(chipShape).background(Eon.DAccent).border(1.dp, Eon.DAccent, chipShape) else Modifier.libGlass(chipShape))
                            .padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp),
                    ) {
                        Text(name, color = ink, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                        Text("$count", color = ink.copy(alpha = 0.7f), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(start = 24.dp, end = 24.dp, top = 12.dp, bottom = 4.dp), verticalAlignment = Alignment.Bottom) {
            Text("All apps", color = cfg.textColor, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, modifier = Modifier.weight(1f))
            Text(DRAWER_SORTS.getOrElse(cfg.sort) { "" }, color = Eon.DSoft, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Box(Modifier.weight(1f).fillMaxWidth()) { PrevGrid(apps) }
    }
}

// ---- Bar

@Composable
private fun PrevBar(state: EonState, apps: List<AppEntry>) {
    val cfg = DrawerConfig
    val cats = state.categories.toList()
    val current = cats.firstOrNull { it.id == state.drawerCategory } ?: cats.firstOrNull()
    Column(Modifier.fillMaxSize().padding(top = 30.dp, bottom = 22.dp)) {
        // The open wallpaper above the apps, then the panel (its height is the "Height of the apps" setting), then the bar.
        Spacer(Modifier.weight(1f))
        Column(Modifier.fillMaxWidth().fillMaxHeight(cfg.panelPct / 100f)) {
            Row(Modifier.fillMaxWidth().padding(start = 24.dp, end = 8.dp, top = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                if (cfg.showTitle && cfg.titleCenter) Spacer(Modifier.width(72.dp))
                if (cfg.showTitle) {
                    Text(
                        current?.name ?: "", color = cfg.textColor, fontSize = cfg.titleSp.sp, fontWeight = FontWeight.Medium, maxLines = 1,
                        overflow = TextOverflow.Ellipsis, textAlign = if (cfg.titleCenter) TextAlign.Center else TextAlign.Start,
                        modifier = Modifier.weight(1f),
                    )
                } else {
                    Spacer(Modifier.weight(1f).height(48.dp))
                }
                Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) { Icon(Icons.Outlined.Search, null, tint = cfg.textColor) }
                Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) { Icon(Icons.Outlined.MoreVert, null, tint = cfg.textColor) }
            }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                val list = if (current == null || current.id == CAT_ALL) apps else apps.filter { state.inCategory(it, current.id) }
                PrevGrid(list)
            }
        }
        if (cfg.showBar) {
            val tint = cfg.textColor
            val height = (cfg.barIconDp + 34).dp
            val barModifier = if (cfg.barPill) {
                Modifier.padding(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 10.dp).fillMaxWidth().height(height).clip(CircleShape)
                    .background(tint.copy(alpha = 0.14f)).border(1.dp, tint.copy(alpha = 0.16f), CircleShape)
            } else {
                Modifier.padding(top = 4.dp, bottom = 8.dp).fillMaxWidth().height(height)
            }
            Row(barModifier.padding(horizontal = 6.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                cats.take(6).forEach { cat ->
                    val on = cat.id == current?.id
                    val t = if (on) 1f else 0f
                    Box(Modifier.width(52.dp).fillMaxHeight(), contentAlignment = Alignment.Center) {
                        Icon(
                            catIcon(cat.icon), null,
                            tint = lerp(tint.copy(alpha = 0.7f), cfg.accentColor, t),
                            modifier = Modifier.offset(y = (-3).dp).size(cfg.barIconDp.dp).graphicsLayer { scaleX = 1f + 0.12f * t; scaleY = 1f + 0.12f * t },
                        )
                        if (cfg.barIndicator) {
                            Box(
                                Modifier.align(Alignment.BottomCenter).padding(bottom = 6.dp).size(width = 26.dp * t, height = 3.dp)
                                    .clip(CircleShape).background(cfg.accentColor.copy(alpha = t)),
                            )
                        }
                    }
                }
            }
        }
    }
}

// ---- the grid of icons, shared by Bar and Chips

/** The grid of icons, with the same columns, icon size, spacing, padding and labels as the real drawer (including "Fit the grid to the apps"). */
@Composable
private fun PrevGrid(list: List<AppEntry>) {
    val cfg = DrawerConfig
    BoxWithConstraints(Modifier.fillMaxSize().clipToBounds()) {
        val padS = if (cfg.customPadding) cfg.padSide else 14
        val padT = if (cfg.customPadding) cfg.padTop else 12
        val padB = if (cfg.customPadding) cfg.padBottom else 20
        val gap = cfg.rowGap.dp
        var cols = cfg.columns
        var icon = cfg.iconDp.dp
        if (cfg.autoFit) {
            val availW = maxWidth - (padS * 2).dp
            val availH = maxHeight - (padT + padB).dp
            val labelH = if (cfg.showLabels) (cfg.labelSp * 1.35f * (if (cfg.twoLine) 2 else 1) + 10f).dp else 0.dp
            for (c in 2..6) {
                val ic = minOf(availW / c * 0.78f, 104.dp)
                if (ic < 44.dp) break
                val rows = (list.size + c - 1) / c
                val rowH = ic + labelH + 8.dp
                if (rowH * rows + gap * (rows - 1) <= availH) {
                    cols = c
                    icon = ic
                    break
                }
            }
        }
        Column(
            Modifier.fillMaxWidth().naturalHeight().padding(start = padS.dp, end = padS.dp, top = padT.dp),
            verticalArrangement = Arrangement.spacedBy(gap),
        ) {
            list.chunked(cols).take(10).forEach { row ->
                Row(Modifier.fillMaxWidth()) {
                    row.forEach { app ->
                        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                            AppIconBody(app, icon, cfg.showLabels, cfg.labelSp, cfg.twoLine, cfg.textColor, previewCount = 0)
                        }
                    }
                    repeat(cols - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
    }
}
