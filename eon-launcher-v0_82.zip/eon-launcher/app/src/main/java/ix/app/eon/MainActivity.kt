package ix.app.eon

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.isSystemInDarkTheme
import kotlinx.coroutines.delay
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue

class MainActivity : ComponentActivity() {
    private var homeTick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        val prefs = Prefs(this)
        AppLock.activity = java.lang.ref.WeakReference(this)
        AppLock.load(prefs)
        RecentSearches.load(prefs)
        IconCustom.init(this, prefs)
        AnimConfig.load(prefs)
        BlurConfig.load(prefs)
        val repo = AppRepo(this)
        IconStyle.load(applicationContext, prefs)
        BadgeStyle.load(prefs)
        IconAuto.load(prefs)
        Haptics.load(prefs)
        FolderStyle.load(prefs)
        val state = EonState(prefs)
        val widgets = WidgetHolder(this)
        GoogleFeed.load(prefs)
        setContent {
            val base = androidx.compose.ui.platform.LocalHapticFeedback.current
            CompositionLocalProvider(
                androidx.compose.ui.platform.LocalHapticFeedback provides remember(base) { GatedHaptic(base) },
            ) { EonApp(prefs, state, widgets, repo, homeTick) }
        }
        Haptics.attach(window.decorView)
        GoogleFeed.create(this)
    }

    // The Google feed (if switched on) follows the activity's life.
    override fun onAttachedToWindow() { super.onAttachedToWindow(); GoogleFeed.onAttached() }
    override fun onDetachedFromWindow() { super.onDetachedFromWindow(); GoogleFeed.onDetached() }
    override fun onStart() { super.onStart(); GoogleFeed.onStart() }
    override fun onResume() { super.onResume(); GoogleFeed.onResume() }
    override fun onPause() { GoogleFeed.onPause(); super.onPause() }
    override fun onStop() { GoogleFeed.onStop(); super.onStop() }
    override fun onDestroy() { GoogleFeed.destroy(); super.onDestroy() }

    // Pressing Home while Eon is already open comes back here: close the drawer.
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN && intent.hasCategory(Intent.CATEGORY_HOME)) {
            homeTick++
            if (GoogleFeed.progress > 0f) GoogleFeed.close()
        }
    }
}

@Composable
fun EonApp(prefs: Prefs, state: EonState, widgets: WidgetHolder, repo: AppRepo, homeTick: Int) {
    var onboarded by remember { mutableStateOf(prefs.onboarded) }
    var apps by remember { mutableStateOf(AppRepo.last) }
    var reload by remember { mutableIntStateOf(0) }

    LaunchedEffect(reload, state.iconReload) { apps = repo.load() }
    DisposableEffect(Unit) {
        val stop = repo.watch { reload++ }
        onDispose { stop() }
    }

    // Immersive mode: hide the system bars. They come back whenever Eon is shown again, so apply it on every resume.
    val view = androidx.compose.ui.platform.LocalView.current
    DisposableEffect(state.immersive) {
        val apply = {
            val window = (view.context as? android.app.Activity)?.window
            if (window != null) {
                val controller = androidx.core.view.WindowCompat.getInsetsController(window, view)
                controller.systemBarsBehavior =
                    androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                if (state.immersive) {
                    controller.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
                } else {
                    controller.show(androidx.core.view.WindowInsetsCompat.Type.systemBars())
                }
            }
        }
        apply()
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) apply()
        }
        val lifecycle = (view.context as ComponentActivity).lifecycle
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer) }
    }
    // Light or dark: from the chosen theme, the phone's dark mode, or the hour of day for the schedule.
    val systemDark = isSystemInDarkTheme()
    var hour by remember { mutableIntStateOf(java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)) }
    LaunchedEffect(state.theme) {
        while (state.theme == "schedule") {
            hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
            delay(30_000)
        }
    }
    // Focus modes with a schedule switch on and off by themselves when their time comes.
    LaunchedEffect(Unit) {
        var last: String? = null
        while (true) {
            val wanted = Focus.scheduled(java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY), Focus.dayBitNow())
            if (wanted != last) {
                if (last != null || wanted.isNotEmpty()) state.switchFocus(wanted)
                last = wanted
            }
            delay(30_000)
        }
    }
    val wantsLight = state.wantsLight(systemDark, hour)
    if (Eon.light != wantsLight) Eon.light = wantsLight
    val appCtx = LocalContext.current
    val dyn = remember(state.materialYou, wantsLight) {
        if (!state.materialYou) null else if (wantsLight) dynamicLightColorScheme(appCtx) else dynamicDarkColorScheme(appCtx)
    }
    if (Eon.dynamic !== dyn) Eon.dynamic = dyn
    CompositionLocalProvider(LocalLook provides state.look) {
        MaterialTheme(colorScheme = dyn ?: (if (Eon.light) lightColorScheme() else darkColorScheme())) {
            if (onboarded) {
                Home(repo, state, widgets, apps, homeTick) {
                    prefs.onboarded = false
                    onboarded = false
                }
            } else {
                Onboarding(prefs) {
                    state.chooseLook(prefs.look)
                    state.chooseTheme(prefs.theme)
                    onboarded = true
                }
            }
        }
    }
}
