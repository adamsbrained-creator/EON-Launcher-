package ix.app.eon

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog

/** The ways an open folder can look, in the order of [FolderStyle.mode]. */
val FOLDER_STYLES = listOf("Card", "Full page", "Bottom sheet")

/** Which look an open home screen folder has. Card is the original; Full page is the default. */
object FolderStyle {
    var mode by mutableIntStateOf(1)

    fun load(p: Prefs) {
        mode = p.getInt("folderStyle", 1).coerceIn(0, FOLDER_STYLES.size - 1)
    }

    fun save(p: Prefs) {
        p.putInt("folderStyle", mode)
    }
}

/** Plays the opening animation that goes with the folder style. */
@Composable
fun FolderEnter(content: @Composable () -> Unit) {
    if (FolderStyle.mode == 2) {
        val shown = remember { MutableTransitionState(false).apply { targetState = true } }
        AnimatedVisibility(
            visibleState = shown,
            enter = slideInVertically(tween(340, easing = Motion.Decel)) { it / 2 } + fadeIn(tween(220)),
        ) { content() }
    } else {
        PopAnim(content)
    }
}

/** An open folder, drawn in the style chosen in Settings > Drawer > Folders. */
@Composable
fun FolderPopup(
    state: EonState, folder: Item, apps: List<AppEntry>,
    onLaunch: (AppEntry) -> Unit, onMenu: (AppEntry) -> Unit, onClose: () -> Unit,
) {
    when (FolderStyle.mode) {
        1 -> FolderPage(state, folder, apps, onLaunch, onMenu, onClose, sheet = false)
        2 -> FolderPage(state, folder, apps, onLaunch, onMenu, onClose, sheet = true)
        else -> FolderCard(state, folder, apps, onLaunch, onMenu, onClose)
    }
}

/**
 * The calm folder: no card. As a full page the home screen sinks into darkness and the apps sit in the lower half,
 * near your thumb. As a bottom sheet the home screen stays visible above and the handle drags it away.
 * Gestures, Change icon and Remove folder are in the ··· menu; + adds apps.
 */
@Composable
private fun FolderPage(
    state: EonState, folder: Item, apps: List<AppEntry>,
    onLaunch: (AppEntry) -> Unit, onMenu: (AppEntry) -> Unit, onClose: () -> Unit, sheet: Boolean,
) {
    var rev by remember(folder.key) { mutableIntStateOf(0) }
    val members = rev.let { folder.members.mapNotNull { k -> apps.firstOrNull { it.key == k } } }
    var pickingIcon by remember(folder.key) { mutableStateOf(false) }
    var adding by remember(folder.key) { mutableStateOf(false) }
    var menu by remember(folder.key) { mutableStateOf(false) }
    var dragY by remember { mutableFloatStateOf(0f) }
    // Save the name however the folder closes.
    DisposableEffect(folder.key) { onDispose { state.commitLayout() } }

    val header: @Composable (Modifier) -> Unit = { mod ->
        Row(mod.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                FolderNameField(folder, if (sheet) 24.sp else 30.sp, TextAlign.Start)
                if (sheet) Text("${members.size} apps", color = Eon.DMuted, fontSize = 13.sp)
            }
            RoundButton("+", "Add apps") { adding = true }
            Spacer(Modifier.width(10.dp))
            Box {
                RoundButton("···", "Folder options") { menu = true }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Gestures") }, onClick = {
                        menu = false
                        state.gestureEditor = GestureTarget("f", folder.key, folder.name.ifBlank { "Folder" })
                        onClose()
                    })
                    DropdownMenuItem(text = { Text("Change icon") }, onClick = { menu = false; pickingIcon = true })
                    if (folder.members.size == 2) {
                        DropdownMenuItem(
                            text = { Text(if (folder.pair) "Turn off app pair" else "Open both apps side by side") },
                            onClick = { menu = false; folder.pair = !folder.pair; state.commitLayout() },
                        )
                    }
                    DropdownMenuItem(text = { Text("Remove folder") }, onClick = { menu = false; state.disbandFolder(folder.key) })
                }
            }
        }
    }

    val grid: @Composable () -> Unit = {
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            modifier = Modifier.heightIn(max = if (sheet) 420.dp else 480.dp),
            verticalArrangement = Arrangement.spacedBy(22.dp),
        ) {
            items(members, key = { it.key }) { app ->
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    AppIcon(app, 58.dp, true, { onLaunch(app) }, { onMenu(app) })
                }
            }
        }
    }

    Box(
        Modifier.fillMaxSize().background(if (sheet) Color(0x88000000) else Color(0xE6050508))
            .pointerInput(Unit) { detectTapGestures(onTap = { onClose() }) },
    ) {
        if (sheet) {
            Column(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                    .graphicsLayer { translationY = dragY.coerceAtLeast(0f) }
                    .clip(RoundedCornerShape(topStart = 34.dp, topEnd = 34.dp))
                    .background(Color(0xFF14151B))
                    .pointerInput(Unit) { detectTapGestures(onTap = { }) }
                    .navigationBarsPadding().padding(start = 18.dp, end = 18.dp, bottom = 28.dp),
            ) {
                Box(
                    Modifier.fillMaxWidth().pointerInput(Unit) {
                        detectVerticalDragGestures(
                            onDragEnd = { if (dragY > 140f) onClose() else dragY = 0f },
                            onDragCancel = { dragY = 0f },
                        ) { _, d -> dragY = (dragY + d).coerceAtLeast(0f) }
                    }.padding(top = 12.dp, bottom = 14.dp),
                    contentAlignment = Alignment.Center,
                ) { Box(Modifier.width(40.dp).size(width = 40.dp, height = 5.dp).clip(CircleShape).background(Color(0xFF3A3D49))) }
                header(Modifier.padding(horizontal = 6.dp))
                Spacer(Modifier.size(22.dp))
                grid()
            }
        } else {
            Column(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                    .pointerInput(Unit) { detectTapGestures(onTap = { }) }
                    .navigationBarsPadding().padding(start = 20.dp, end = 20.dp, bottom = 96.dp),
            ) {
                header(Modifier.padding(horizontal = 4.dp))
                Spacer(Modifier.size(28.dp))
                grid()
            }
        }
        if (pickingIcon) FolderIconDialog(state, folder, apps) { pickingIcon = false }
        if (adding) AddAppsDialog(state, folder, apps) { adding = false; rev++ }
    }
}

@Composable
private fun RoundButton(label: String, description: String, onClick: () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(CircleShape).background(Color(0x1FFFFFFF))
            .border(1.dp, Color(0x22FFFFFF), CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = Color(0xFFF0F2F8), fontSize = if (label == "+") 22.sp else 18.sp, fontWeight = FontWeight.Medium)
    }
}

/** The folder's name, editable in place. */
@Composable
private fun FolderNameField(folder: Item, size: TextUnit, align: TextAlign) {
    var name by remember(folder.key) { mutableStateOf(folder.name) }
    BasicTextField(
        value = name,
        onValueChange = { name = it.take(24); folder.name = name },
        singleLine = true,
        textStyle = TextStyle(color = Color.White, fontSize = size, fontWeight = FontWeight.Bold, textAlign = align),
        cursorBrush = SolidColor(Eon.Accent),
        modifier = Modifier.fillMaxWidth(),
        decorationBox = { inner ->
            Box(Modifier.fillMaxWidth()) {
                if (name.isEmpty()) Text("Folder", color = Eon.DFaint, fontSize = size, fontWeight = FontWeight.Bold)
                inner()
            }
        },
    )
}

/** Pick apps from the whole list to put in the folder. They are taken from wherever they are on the home screen. */
@Composable
private fun AddAppsDialog(state: EonState, folder: Item, apps: List<AppEntry>, onDone: () -> Unit) {
    var picked by remember { mutableStateOf(setOf<String>()) }
    val candidates = remember { apps.filter { it.key !in folder.members }.sortedBy { it.label.lowercase() } }
    Dialog(onDismissRequest = onDone) {
        Column(Modifier.width(320.dp).heightIn(max = 560.dp).glass(RoundedCornerShape(26.dp)).padding(top = 18.dp, bottom = 10.dp)) {
            Text("Add apps", color = Eon.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp))
            Spacer(Modifier.size(8.dp))
            LazyColumn(Modifier.weight(1f, fill = false)) {
                items(candidates, key = { it.key }) { app ->
                    val on = app.key in picked
                    Row(
                        Modifier.fillMaxWidth().clickable { picked = if (on) picked - app.key else picked + app.key }
                            .padding(horizontal = 20.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        Image(app.icon, null, Modifier.size(38.dp))
                        Text(app.label, color = Eon.Text, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        Box(
                            Modifier.size(22.dp).clip(CircleShape)
                                .then(if (on) Modifier.background(Eon.Button) else Modifier.border(2.dp, Eon.Muted, CircleShape)),
                        )
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.End) {
                Box(Modifier.clip(CircleShape).clickable(onClick = onDone).padding(horizontal = 16.dp, vertical = 10.dp)) {
                    Text("Cancel", color = Eon.Muted, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                }
                Box(
                    Modifier.clip(CircleShape).clickable(enabled = picked.isNotEmpty()) {
                        state.addAppsToFolder(folder.key, picked.toList())
                        onDone()
                    }.padding(horizontal = 16.dp, vertical = 10.dp),
                ) {
                    Text(
                        if (picked.isEmpty()) "Add" else "Add ${picked.size}",
                        color = if (picked.isEmpty()) Eon.Faint else Eon.Accent, fontSize = 15.sp, fontWeight = FontWeight.Bold,
                    )
                }
            }
        }
    }
}
