package ix.app.eon

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog

/*
 * Small building blocks added to the App Library in 0.80.0: soft edges for the scrolling boxes, the box name with its
 * count chip, the "New box" tile that fills an empty spot, the slim Suggestions / Recently added rows, the bottom bar,
 * and the colour picker for a box.
 */

/**
 * Fades the top and the bottom edge of a scrolling list to nothing, so boxes slide under the search pill and off the
 * screen softly instead of being cut by a straight line. An edge only fades while there is more to scroll that way.
 */
internal fun Modifier.libFadeEdges(canUp: () -> Boolean, canDown: () -> Boolean, top: Dp = 26.dp, bottom: Dp = 34.dp): Modifier =
    this.graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen).drawWithContent {
        drawContent()
        val t = top.toPx()
        val b = bottom.toPx()
        if (canUp()) {
            drawRect(
                Brush.verticalGradient(listOf(Color.Transparent, Color.Black), startY = 0f, endY = t),
                topLeft = Offset(0f, 0f), size = Size(size.width, t), blendMode = BlendMode.DstIn,
            )
        }
        if (canDown()) {
            drawRect(
                Brush.verticalGradient(listOf(Color.Black, Color.Transparent), startY = size.height - b, endY = size.height),
                topLeft = Offset(0f, size.height - b), size = Size(size.width, b), blendMode = BlendMode.DstIn,
            )
        }
    }

/** The name under a box. Glass: centred. Flat: to the left. The count is a small chip next to it (or at the far end when chips are off in Flat). */
@Composable
internal fun LibTileName(tile: LibTile, small: Boolean) {
    // Quiet, like iOS: 12 sp, regular weight, no drop shadow (the blurred, dimmed wallpaper already gives the contrast).
    val shadow = TextStyle(shadow = if (LibraryConfig.classicDim) Shadow(Color(0x73000000), Offset(0f, 2f), 8f) else null)
    val size = 12.sp
    val flat = LibraryConfig.isFlat
    val chip = LibraryConfig.countChip
    val spread = flat && !chip
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 4.dp),
        horizontalArrangement = if (spread) Arrangement.SpaceBetween else Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            tile.name, color = (LibFrost.labelInk() ?: DrawerConfig.textColor).copy(alpha = if (LibraryConfig.classicDim) 1f else 0.88f), fontSize = size,
            fontWeight = if (LibraryConfig.classicDim) { if (flat) FontWeight.SemiBold else FontWeight.Medium } else FontWeight.Normal,
            maxLines = 1, overflow = TextOverflow.Ellipsis, style = shadow,
            modifier = if (spread) Modifier.weight(1f) else Modifier.weight(1f, fill = false),
        )
        if (chip) {
            Spacer(Modifier.width(6.dp))
            Box(Modifier.clip(CircleShape).background(Color(0x26FFFFFF)).padding(horizontal = 7.dp, vertical = 1.dp)) {
                Text("${tile.apps.size}", color = DrawerConfig.textColor.copy(alpha = 0.82f), fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
            }
        } else if (flat) {
            Text("${tile.apps.size}", color = DrawerConfig.textColor.copy(alpha = 0.62f), fontSize = 12.sp, style = shadow)
        }
    }
}

/** A ghost box in the empty spot at the end of an odd row. Tap to make a new box. */
@Composable
internal fun LibNewBoxTile(small: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(LibStyle.tile(DrawerConfig.tileRadius))
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Box(
            Modifier.fillMaxWidth().aspectRatio(1f).clip(shape).background(Color(0x0DFFFFFF))
                .border(1.dp, Color(0x2EFFFFFF), shape).clickable(onClick = onClick),
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Outlined.Add, null, tint = Color(0x99FFFFFF), modifier = Modifier.size(34.dp)) }
        Text("New box", color = DrawerConfig.textColor.copy(alpha = 0.6f), fontSize = if (small) 12.sp else 13.sp, fontWeight = FontWeight.Medium)
    }
}

/** Suggestions or Recently added as one slim glass strip of icons, so more of your own boxes fit on the screen. */
@Composable
internal fun LibQuickRow(
    title: String, apps: List<AppEntry>, drag: DragState,
    onLaunch: (AppEntry) -> Unit, onMenu: (AppEntry) -> Unit, onDrop: (AppEntry, Offset) -> Unit,
) {
    if (apps.isEmpty()) return
    Column(Modifier.fillMaxWidth()) {
        Text(
            title, color = DrawerConfig.textColor.copy(alpha = 0.82f), fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(start = 6.dp, bottom = 8.dp),
        )
        Row(
            Modifier.fillMaxWidth().libGlass(RoundedCornerShape(LibStyle.tile(DrawerConfig.tileRadius)))
                .horizontalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            apps.forEach { a ->
                DragAppIcon(
                    a, 52.dp, drag, { onLaunch(a) }, { onMenu(a) }, onDrop,
                    showLabel = true, labelSp = 10f, labelColor = DrawerConfig.textColor,
                )
            }
        }
    }
}

/** The small bar at the bottom of the Library: Library, A-Z and Arrange. */
@Composable
internal fun LibBottomBar(azOn: Boolean, onLibrary: () -> Unit, onAz: () -> Unit, onArrange: () -> Unit, modifier: Modifier) {
    Row(
        modifier.libGlass(RoundedCornerShape(26.dp)).padding(5.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        LibBarItem("Library", !azOn, onLibrary)
        LibBarItem("A\u2013Z", azOn, onAz)
        LibBarItem("Arrange", false, onArrange)
    }
}

@Composable
private fun LibBarItem(label: String, on: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(21.dp)
    Box(
        Modifier.height(40.dp).clip(shape)
            .background(if (on) Eon.DAccent.copy(alpha = 0.26f) else Color.Transparent)
            .clickable(onClick = onClick).padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = if (on) Eon.DAccent else LibStyle.ink, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

private val LibSwatches = listOf(
    0xFF35D6F0, 0xFF5C9DFF, 0xFF9B7BFF, 0xFFF25CCB, 0xFFFF9F43,
    0xFF4CD98A, 0xFFFF5C6C, 0xFFF2C94C, 0xFF8E939E, 0xFF2B5CFF,
)

/** Pick a colour for one box, or go back to its automatic colour. */
@Composable
internal fun LibColorDialog(current: Int?, onPick: (Color?) -> Unit, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().glassDark(RoundedCornerShape(28.dp)).padding(18.dp)) {
            Text("Box colour", color = Eon.DText, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text("The soft tint of the box, and its round badge.", color = Eon.DSoft, fontSize = 12.sp)
            Spacer(Modifier.height(14.dp))
            LibSwatches.chunked(5).forEach { row ->
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    row.forEach { argb ->
                        val on = current != null && (current.toLong() and 0xFFFFFFFFL) == argb
                        Box(
                            Modifier.size(46.dp).clip(CircleShape).background(Color(argb))
                                .border(if (on) 3.dp else 1.dp, if (on) Color.White else Color(0x33FFFFFF), CircleShape)
                                .clickable { onPick(Color(argb)) },
                        )
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Automatic", color = Eon.DAccent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clip(CircleShape).clickable { onPick(null) }.padding(horizontal = 14.dp, vertical = 10.dp),
                )
                Text(
                    "Close", color = Eon.DSoft, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clip(CircleShape).clickable(onClick = onDismiss).padding(horizontal = 14.dp, vertical = 10.dp),
                )
            }
        }
    }
}

/** A small heading that groups the switches in Customize Library. */
@Composable
internal fun LibSectionTitle(title: String) {
    Text(
        title.uppercase(), color = Eon.DAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp,
        modifier = Modifier.padding(top = 18.dp, bottom = 2.dp),
    )
}

/** A titled slider with its value on the right, for Customize Library. [onDone] runs when the finger lifts (store the value there). */
@Composable
internal fun LibSlider(
    title: String, valueText: String, value: Float, range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit, onDone: () -> Unit,
) {
    Column(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = Eon.DText, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            Text(valueText, color = Eon.DSoft, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
        androidx.compose.material3.Slider(
            value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange, valueRange = range,
            onValueChangeFinished = onDone,
            colors = androidx.compose.material3.SliderDefaults.colors(
                thumbColor = Color.White, activeTrackColor = Eon.DAccent, inactiveTrackColor = Color(0x33FFFFFF),
            ),
        )
    }
}
