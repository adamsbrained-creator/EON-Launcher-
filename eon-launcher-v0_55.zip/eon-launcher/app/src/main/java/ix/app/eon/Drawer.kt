package ix.app.eon

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import kotlinx.coroutines.launch
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Size of an app icon in the drawer. */
val DRAWER_ICON = 68.dp

private val BAR_ITEM = 52.dp

/**
 * The app drawer: a title and a grid of apps in the lower half of the screen, and a bar of category
 * icons at the bottom. Tap an icon (or swipe sideways) to change category; long-press an icon, or
 * use the ⋮ button, for Add category, Edit icon, Rename and Remove. Search looks through every app.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Drawer(
    apps: List<AppEntry>, state: EonState, focusSearch: Boolean,
    onLaunch: (AppEntry) -> Unit, onMenu: (AppEntry) -> Unit, onClose: () -> Unit,
    drag: DragState, onDrop: (AppEntry, Offset) -> Unit,
    onSettings: () -> Unit = {},
) {
    val focus = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    var searching by remember { mutableStateOf(focusSearch || DrawerConfig.autoKeyboard) }
    var query by remember { mutableStateOf("") }
    var adding by remember { mutableStateOf(false) }
    var menuFor by remember { mutableStateOf<String?>(null) }
    var renaming by remember { mutableStateOf<String?>(null) }
    var picking by remember { mutableStateOf<String?>(null) }
    var openFolderKey by remember { mutableStateOf<String?>(null) }
    // Where each bar icon is on screen, so the menu can point at it. Plain map: it is only read when a menu opens.
    val bounds = remember { HashMap<String, Rect>() }

    val cats = state.categories
    val pager = rememberPagerState(
        initialPage = cats.indexOfFirst { it.id == state.drawerCategory }.coerceAtLeast(0),
    ) { cats.size }

    // Follow the chosen category (bar taps, adding, removing) ...
    LaunchedEffect(state.drawerCategory, cats.size) {
        val i = cats.indexOfFirst { it.id == state.drawerCategory }
        if (i >= 0 && i != pager.currentPage) pager.animateScrollToPage(i)
    }
    // ... and remember the one you land on after a swipe.
    LaunchedEffect(pager) {
        snapshotFlow { pager.settledPage }.collect { i ->
            cats.getOrNull(i)?.let { state.selectCategory(it.id) }
        }
    }
    LaunchedEffect(searching) {
        if (searching) {
            try {
                focus.requestFocus()
            } catch (_: Exception) {
            }
        }
    }
    BackHandler(enabled = openFolderKey != null) { openFolderKey = null }
    BackHandler(enabled = searching) {
        searching = false
        query = ""
        focusManager.clearFocus()
    }

    val q = query.trim()
    val upClose = rememberSwipeUpToClose({ !searching }, onClose)
    val edges = remember { ListEdges() }

    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize()
                .background(DrawerConfig.scrim())
                // Keeps touches from reaching the home screen underneath.
                .pointerInput(Unit) { detectTapGestures(onTap = { }) }
                // Swipe up goes home (Settings > Drawer): on the title and the bar, and on a list with nothing left to scroll.
                .swipeUpToClose({ !searching }, onClose)
                .pullToClose({ !searching && drag.app == null }, { edges.atTop }, { edges.atBottom }, onClose)
                .nestedScroll(upClose)
                .systemBarsPadding().imePadding(),
        ) {
            if (!searching) {
                // The open wallpaper above the apps: tap it, or pull it down, to close the drawer.
                Box(
                    Modifier.weight(1f).fillMaxWidth()
                        .pointerInput(Unit) { detectTapGestures(onTap = { onClose() }) }
                        .pointerInput(Unit) {
                            var total = 0f
                            detectVerticalDragGestures(
                                onDragStart = { total = 0f },
                                onDragEnd = { if (total > 100f || (DrawerConfig.swipeUpHome && total < -100f)) onClose() },
                                onDragCancel = { total = 0f },
                                onVerticalDrag = { _, dy -> total += dy },
                            )
                        },
                )
            }

            Column(
                if (searching) Modifier.weight(1f).fillMaxWidth()
                else Modifier.fillMaxWidth().fillMaxHeight(DrawerConfig.panelPct / 100f),
            ) {
                if (searching) {
                    Gap(8)
                    SearchField(
                        query = query, onQuery = { query = it }, focus = focus,
                        onDone = {
                            val list = if (q.isEmpty()) apps else apps.filter { it.label.contains(q, ignoreCase = true) }
                            list.firstOrNull()?.let(onLaunch)
                        },
                        onClose = {
                            searching = false
                            query = ""
                            focusManager.clearFocus()
                        },
                    )
                } else {
                    Row(
                        Modifier.fillMaxWidth().padding(start = 24.dp, end = 8.dp, top = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        // With a centred title, this spacer is as wide as the two buttons, so the title sits in the middle.
                        if (DrawerConfig.showTitle && DrawerConfig.titleCenter) Spacer(Modifier.width(72.dp))
                        if (DrawerConfig.showTitle) {
                            Text(
                                cats.getOrNull(pager.currentPage)?.name ?: "",
                                color = DrawerConfig.textColor, fontSize = DrawerConfig.titleSp.sp, fontWeight = FontWeight.Medium,
                                maxLines = 1, overflow = TextOverflow.Ellipsis,
                                textAlign = if (DrawerConfig.titleCenter) TextAlign.Center else TextAlign.Start,
                                modifier = Modifier.weight(1f),
                            )
                        } else {
                            Spacer(Modifier.weight(1f).height(48.dp))
                        }
                        IconButton(onClick = { searching = true }) {
                            Icon(Icons.Outlined.Search, "Search apps", tint = DrawerConfig.textColor)
                        }
                        IconButton(onClick = { menuFor = cats.getOrNull(pager.currentPage)?.id }) {
                            Icon(Icons.Outlined.MoreVert, "Category menu", tint = DrawerConfig.textColor)
                        }
                    }
                }

                Box(Modifier.weight(1f).fillMaxWidth()) {
                    if (searching) {
                        val shown = remember(apps, q) {
                            if (q.isEmpty()) apps else apps.filter { it.label.contains(q, ignoreCase = true) }
                        }
                        AppGrid(shown, "No apps match", onLaunch, onMenu, drag, onDrop, fitToApps = DrawerConfig.autoFit)
                    } else {
                        HorizontalPager(
                            pager, Modifier.fillMaxSize(),
                            userScrollEnabled = DrawerConfig.swipeCategories,
                            key = { index -> cats.getOrNull(index)?.id ?: index },
                        ) { index ->
                            val cat = cats.getOrNull(index)
                            if (cat != null) {
                                val list by remember(apps, cat.id) {
                                    derivedStateOf {
                                        if (cat.id == CAT_ALL) apps else apps.filter { state.inCategory(it, cat.id) }
                                    }
                                }
                                Box(
                                    Modifier.fillMaxSize().graphicsLayer {
                                        // How this page moves while you change category (Settings > Drawer).
                                        val off = (pager.currentPage - index) + pager.currentPageOffsetFraction
                                        val a = Math.abs(off).coerceIn(0f, 1f)
                                        when (DrawerConfig.transition) {
                                            1 -> {
                                                translationX = size.width * off
                                                alpha = 1f - a
                                            }
                                            2 -> {
                                                val sc = 1f - 0.15f * a
                                                scaleX = sc
                                                scaleY = sc
                                                alpha = 1f - 0.6f * a
                                            }
                                            3 -> {
                                                cameraDistance = 12f * density
                                                rotationY = -off * 35f
                                                alpha = 1f - 0.5f * a
                                            }
                                            else -> {}
                                        }
                                    },
                                ) {
                                    AppGrid(
                                        list, emptyText(cat), onLaunch, onMenu, drag, onDrop, fitToApps = DrawerConfig.autoFit,
                                        folders = state.drawerFolders, allApps = apps, onOpenFolder = { openFolderKey = it.key },
                                        edges = if (index == pager.currentPage) edges else null,
                                    )
                                }
                            }
                        }
                    }
                }
            }

            if (!searching && DrawerConfig.showBar) {
                CategoryBar(
                    cats = cats, selectedId = state.drawerCategory,
                    onSelect = { state.selectCategory(it) },
                    onLongPress = { menuFor = it },
                    onBounds = { id, r -> bounds[id] = r },
                )
            }
        }

        state.drawerFolders.firstOrNull { it.key == openFolderKey }?.let { f ->
            PopAnim {
                DrawerFolderPopup(
                    state, f, apps,
                    onLaunch = { app -> openFolderKey = null; onLaunch(app) },
                    onMenu = onMenu,
                    onClose = { openFolderKey = null },
                )
            }
        }
        if (adding) {
            AddCategoryScreen(
                existing = cats.map { it.id }.toSet(),
                onPick = { def ->
                    state.selectCategory(state.addCategory(def))
                    adding = false
                },
                onCustom = {
                    val id = state.addCustomCategory()
                    state.selectCategory(id)
                    adding = false
                    renaming = id
                },
                onBack = { adding = false },
            )
        }
    }

    menuFor?.let { id ->
        val cat = cats.firstOrNull { it.id == id }
        if (cat != null) {
            CategoryPopup(
                title = cat.name, anchor = bounds[id], canRemove = id != CAT_ALL,
                onAdd = { menuFor = null; adding = true },
                onEditIcon = { menuFor = null; picking = id },
                onRename = { menuFor = null; renaming = id },
                onRemove = { menuFor = null; state.removeCategory(id) },
                onDismiss = { menuFor = null },
                extras = listOf(
                    PopupAction(Icons.Outlined.GridView, "Switch to Library") {
                        menuFor = null
                        state.chooseDrawerStyle("library")
                    },
                    PopupAction(Icons.Outlined.Tune, "Drawer settings") {
                        menuFor = null
                        onSettings()
                    },
                ),
            )
        }
    }
    renaming?.let { id ->
        val cat = cats.firstOrNull { it.id == id }
        if (cat != null) {
            NameDialog(
                title = "Rename category", initial = cat.name,
                onDone = { state.renameCategory(id, it); renaming = null },
                onDismiss = { renaming = null },
            )
        }
    }
    picking?.let { id ->
        val cat = cats.firstOrNull { it.id == id }
        if (cat != null) {
            IconPickerDialog(
                current = cat.icon,
                onPick = { state.setCategoryIcon(id, it); picking = null },
                onDismiss = { picking = null },
            )
        }
    }
}

private fun emptyText(cat: DrawerCat): String =
    if (cat.id == CAT_ALL) "No apps"
    else if (cat.id.startsWith("c") && cat.id.drop(1).all { it.isDigit() } || cat.id == "favorites")
        "Nothing here yet.\nLong-press an app and choose Change category."
    else "No apps in this category yet."

@Composable
internal fun AppGrid(
    list: List<AppEntry>, empty: String,
    onLaunch: (AppEntry) -> Unit, onMenu: (AppEntry) -> Unit,
    drag: DragState, onDrop: (AppEntry, Offset) -> Unit,
    labelColor: Color = DrawerConfig.textColor,
    fitToApps: Boolean = false,
    folders: List<Item> = emptyList(),
    allApps: List<AppEntry> = list,
    onOpenFolder: (Item) -> Unit = {},
    edges: ListEdges? = null,
) {
    if (list.isEmpty()) {
        if (edges != null) {
            androidx.compose.runtime.SideEffect {
                edges.atTop = true
                edges.atBottom = true
            }
        }
        Box(Modifier.fillMaxSize().padding(horizontal = 40.dp), contentAlignment = Alignment.Center) {
            Text(empty, color = Eon.Muted, fontSize = 14.sp, textAlign = TextAlign.Center)
        }
        return
    }
    val cfg = DrawerConfig
    val entries = buildGridEntries(list, folders)
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val padS = if (cfg.customPadding) cfg.padSide else 14
        val padT = if (cfg.customPadding) cfg.padTop else 12
        val padB = if (cfg.customPadding) cfg.padBottom else 20
        val gap = cfg.rowGap.dp
        var cols = cfg.columns
        var icon = cfg.iconDp.dp
        if (fitToApps) {
            // Few apps: fewer, bigger icons. Many apps: more columns, smaller icons, until they all fit without scrolling.
            val availW = maxWidth - (padS * 2).dp
            val availH = maxHeight - (padT + padB).dp
            val labelH = if (cfg.showLabels) (cfg.labelSp * 1.35f * (if (cfg.twoLine) 2 else 1) + 10f).dp else 0.dp
            for (c in 2..6) {
                val ic = minOf(availW / c * 0.78f, 104.dp)
                if (ic < 44.dp) break
                val rows = (entries.size + c - 1) / c
                val rowH = ic + labelH + 8.dp
                if (rowH * rows + gap * (rows - 1) <= availH) {
                    cols = c
                    icon = ic
                    break
                }
            }
        }
        val gridState = rememberLazyGridState()
        if (edges != null) {
            // Tells the drawer when this page's list is at its top or its end, for the pull that closes it.
            val top = !gridState.canScrollBackward
            val bottom = !gridState.canScrollForward
            androidx.compose.runtime.SideEffect {
                edges.atTop = top
                edges.atBottom = bottom
            }
        }
        val scope = rememberCoroutineScope()
        LazyVerticalGrid(
            columns = GridCells.Fixed(cols),
            state = gridState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = padS.dp, end = padS.dp, top = padT.dp, bottom = padB.dp),
            verticalArrangement = if (cfg.moveDown && !cfg.stackBottom) Arrangement.spacedBy(gap, Alignment.Bottom)
            else Arrangement.spacedBy(gap),
            reverseLayout = cfg.stackBottom,
        ) {
            items(entries, key = { it.key }) { entry ->
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    when (entry) {
                        is GridApp -> DragAppIcon(
                            entry.app, icon, drag, { onLaunch(entry.app) }, { onMenu(entry.app) }, onDrop,
                            showLabel = cfg.showLabels, labelSp = cfg.labelSp,
                            twoLine = cfg.twoLine, labelColor = labelColor,
                        )
                        is GridFolder -> Box(
                            Modifier.clip(RoundedCornerShape(16.dp)).clickable { onOpenFolder(entry.folder) },
                        ) {
                            FolderIconBody(
                                entry.folder, allApps, icon, cfg.showLabels, cfg.labelSp, cfg.twoLine, labelColor,
                            )
                        }
                    }
                }
            }
        }
        if (cfg.searchIndex && cfg.sort == 0 && entries.size > 10) {
            val letters = remember(entries.map { it.key }) { entries.map { indexLetter(it.label) }.distinct().sorted() }
            IndexRail(letters, Modifier.align(Alignment.CenterEnd)) { letter ->
                val i = entries.indexOfFirst { indexLetter(it.label) == letter }
                if (i >= 0) scope.launch { gridState.scrollToItem(i) }
            }
        }
    }
}

private fun indexLetter(label: String): Char {
    val c = label.firstOrNull()?.uppercaseChar()
    return if (c != null && c.isLetter()) c else '#'
}

/** A thin A to Z strip at the edge of the apps. Touch it or slide along it to jump to a letter. */
@Composable
private fun IndexRail(letters: List<Char>, modifier: Modifier = Modifier, onPick: (Char) -> Unit) {
    var active by remember { mutableStateOf<Char?>(null) }
    val haptic = LocalHapticFeedback.current
    Column(
        modifier.width(22.dp).fillMaxHeight().padding(vertical = 8.dp)
            .pointerInput(letters) {
                awaitEachGesture {
                    val down = awaitFirstDown()
                    fun pick(y: Float) {
                        val i = (y / size.height * letters.size).toInt().coerceIn(0, letters.size - 1)
                        val l = letters[i]
                        if (l != active) {
                            active = l
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onPick(l)
                        }
                    }
                    pick(down.position.y)
                    down.consume()
                    drag(down.id) { change ->
                        pick(change.position.y)
                        change.consume()
                    }
                    active = null
                }
            },
        verticalArrangement = Arrangement.SpaceEvenly,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        letters.forEach { l ->
            Text(
                l.toString(), fontSize = 10.sp, fontWeight = FontWeight.Bold,
                color = if (l == active) DrawerConfig.accentColor else DrawerConfig.textColor.copy(alpha = 0.6f),
            )
        }
    }
}

@Composable
private fun SearchField(
    query: String, onQuery: (String) -> Unit, focus: FocusRequester,
    onDone: () -> Unit, onClose: () -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
            .glass(CircleShape).padding(start = 20.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.weight(1f).padding(vertical = 14.dp)) {
            if (query.isEmpty()) Text("Search apps", color = Eon.Faint, fontSize = 16.sp)
            BasicTextField(
                value = query,
                onValueChange = onQuery,
                singleLine = true,
                textStyle = TextStyle(color = Eon.Text, fontSize = 16.sp),
                cursorBrush = SolidColor(Eon.Accent),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { onDone() }),
                modifier = Modifier.fillMaxWidth().focusRequester(focus),
            )
        }
        IconButton(onClick = onClose) {
            Icon(Icons.Outlined.Close, "Close search", tint = Eon.Soft)
        }
    }
}

/**
 * The category icons at the bottom: icons spread across a rounded glass pill (or loose, when Pill background
 * is off). It scrolls sideways when there are more than fit. The icon you are on grows and takes the selected
 * colour, and a small marker slides in under it.
 */
@Composable
private fun CategoryBar(
    cats: List<DrawerCat>, selectedId: String,
    onSelect: (String) -> Unit, onLongPress: (String) -> Unit, onBounds: (String, Rect) -> Unit,
) {
    val listState = rememberLazyListState()
    val density = LocalDensity.current
    LaunchedEffect(selectedId, cats.size) {
        val i = cats.indexOfFirst { it.id == selectedId }
        if (i >= 0) {
            val info = listState.layoutInfo
            val viewport = info.viewportEndOffset - info.viewportStartOffset
            val item = with(density) { BAR_ITEM.roundToPx() }
            listState.animateScrollToItem(i, -(viewport / 2 - item / 2))
        }
    }
    val tint = DrawerConfig.textColor
    val height = (DrawerConfig.barIconDp + 34).dp
    val barModifier = if (DrawerConfig.barPill) {
        Modifier.padding(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 10.dp).fillMaxWidth().height(height)
            .clip(CircleShape)
            .background(tint.copy(alpha = 0.14f))
            .border(1.dp, tint.copy(alpha = 0.16f), CircleShape)
    } else {
        Modifier.padding(top = 4.dp, bottom = 8.dp).fillMaxWidth().height(height)
    }
    LazyRow(
        state = listState,
        modifier = barModifier,
        contentPadding = PaddingValues(horizontal = 6.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        items(cats, key = { it.id }) { cat ->
            BarItem(cat, cat.id == selectedId, onSelect, onLongPress, onBounds)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun BarItem(
    cat: DrawerCat, on: Boolean,
    onSelect: (String) -> Unit, onLongPress: (String) -> Unit, onBounds: (String, Rect) -> Unit,
) {
    val haptic = LocalHapticFeedback.current
    val t by animateFloatAsState(
        if (on) 1f else 0f, spring(dampingRatio = 0.7f, stiffness = Spring.StiffnessMediumLow), label = "barItem",
    )
    Box(
        Modifier.width(BAR_ITEM).fillMaxHeight()
            .clip(CircleShape)
            .combinedClickable(
                onClick = {
                    if (!on) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onSelect(cat.id)
                },
                onLongClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    onLongPress(cat.id)
                },
            )
            .onGloballyPositioned { onBounds(cat.id, it.boundsInWindow()) },
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            catIcon(cat.icon), cat.name,
            tint = lerp(DrawerConfig.textColor.copy(alpha = 0.7f), DrawerConfig.accentColor, t),
            modifier = Modifier.offset(y = (-3).dp).size(DrawerConfig.barIconDp.dp)
                .graphicsLayer {
                    scaleX = 1f + 0.12f * t
                    scaleY = 1f + 0.12f * t
                },
        )
        // The little marker under the icon of the category you are in.
        if (DrawerConfig.barIndicator) {
            Box(
                Modifier.align(Alignment.BottomCenter).padding(bottom = 6.dp)
                    .size(width = 26.dp * t, height = 3.dp).clip(CircleShape)
                    .background(DrawerConfig.accentColor.copy(alpha = t)),
            )
        }
    }
}
