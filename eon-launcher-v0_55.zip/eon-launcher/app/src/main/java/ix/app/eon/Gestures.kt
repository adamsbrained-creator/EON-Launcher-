package ix.app.eon

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp

/** What the double tap and the swipes on empty space on the home screen do. Swipe up opens the drawer unless you change it. */
object GestureConfig {
    var doubleTap by mutableStateOf(Act.NONE)
    var swipeDown by mutableStateOf(Act.NOTIF)
    var swipeUp by mutableStateOf(Act.DRAWER)
    var twoUp by mutableStateOf(Act.NONE)
    var twoDown by mutableStateOf(Act.NONE)

    private fun read(p: Prefs, key: String, legacyKey: String, legacyDef: Int): String {
        val s = p.getString(key)
        return if (s.isNotEmpty()) s else Act.fromLegacy(p.getInt(legacyKey, legacyDef))
    }

    fun load(p: Prefs) {
        doubleTap = read(p, "gestureDoubleS", "gestureDouble", 0)
        swipeDown = read(p, "gestureDownS", "gestureDown", 4)
        swipeUp = p.getString("gestureUpS").ifEmpty { Act.DRAWER }
        twoUp = p.getString("gestureTwoUpS").ifEmpty { Act.NONE }
        twoDown = p.getString("gestureTwoDownS").ifEmpty { Act.NONE }
    }

    fun save(p: Prefs) {
        p.putString("gestureDoubleS", doubleTap)
        p.putString("gestureDownS", swipeDown)
        p.putString("gestureUpS", swipeUp)
        p.putString("gestureTwoUpS", twoUp)
        p.putString("gestureTwoDownS", twoDown)
    }
}

/**
 * Swipe up goes home (Settings > Drawer), for the parts of a drawer that do not scroll: the title, the bar and the
 * empty space. A short swipe up (about 45 dp) closes the drawer. [enabled] lets a drawer switch it off while it is busy
 * (searching, arranging).
 */
fun Modifier.swipeUpToClose(enabled: () -> Boolean, onClose: () -> Unit): Modifier = this.pointerInput(Unit) {
    var total = 0f
    val need = 45.dp.toPx()
    detectVerticalDragGestures(
        onDragStart = { total = 0f },
        onDragEnd = { if (DrawerConfig.swipeUpHome && enabled() && total < -need) onClose() },
        onDragCancel = { total = 0f },
        onVerticalDrag = { _, dy -> total += dy },
    )
}

/** What a drawer's list says about itself, so a pull at its edge can close the drawer. */
class ListEdges {
    /** The list cannot scroll up any further (it is at its top, or too short to scroll). */
    var atTop = true

    /** The list cannot scroll down any further (it is at its end, or too short to scroll). */
    var atBottom = true
}

/**
 * Pull past the edge of a drawer's list and the drawer closes, like going from one page to the next but up and down:
 *  - Pull down once the list is at its top (Settings > Drawer > Pull down at the top goes home);
 *  - Pull up once the list is at its end (Settings > Drawer > Swipe up goes home).
 * It watches the finger directly, before the list sees it, so the list's own stretch effect and scrolling cannot hide
 * the pull. Only movement made while the list is at that edge counts, so scrolling up to the top and then carrying on
 * in the same swipe closes the drawer, and reversing the finger takes it back. About 32 dp is enough.
 */
fun Modifier.pullToClose(
    enabled: () -> Boolean, atTop: () -> Boolean, atBottom: () -> Boolean, onClose: () -> Unit,
): Modifier = this.pointerInput(Unit) {
    val need = 32.dp.toPx()
    awaitEachGesture {
        awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
        var down = 0f
        var up = 0f
        var fired = false
        while (true) {
            val event = awaitPointerEvent(PointerEventPass.Initial)
            if (event.changes.all { !it.pressed }) break
            if (fired || event.changes.size != 1) continue
            val d = event.changes[0].positionChange()
            if (kotlin.math.abs(d.y) > kotlin.math.abs(d.x)) {
                val on = enabled()
                val canDown = on && DrawerConfig.pullDownHome && atTop()
                val canUp = on && DrawerConfig.swipeUpHome && atBottom()
                down = if (canDown) kotlin.math.max(0f, down + d.y) else 0f
                up = if (canUp) kotlin.math.max(0f, up - d.y) else 0f
                if (down > need || up > need) {
                    fired = true
                    onClose()
                }
            }
        }
    }
}

/**
 * Closing a drawer by pulling on a list that has nothing more to scroll, so a short pull does it (about 30 dp):
 *  - Swipe up goes home: keep pulling up at the end of the list, or when the list is too short to scroll;
 *  - Pull down at the top: keep pulling down when the list is already at its top.
 * A quick flick closes it at once. Only your finger counts: a fling that runs into the end of a list never closes it,
 * and neither does scrolling, so going through a long list is safe. Each way has its own switch in Settings > Drawer.
 */
@Composable
fun rememberSwipeUpToClose(enabled: () -> Boolean, onClose: () -> Unit): NestedScrollConnection {
    val close by rememberUpdatedState(onClose)
    val active by rememberUpdatedState(enabled)
    val density = LocalDensity.current.density
    return remember(density) {
        object : NestedScrollConnection {
            private var pulledUp = 0f
            private var pulledDown = 0f

            private fun reset() {
                pulledUp = 0f
                pulledDown = 0f
            }

            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                val up = DrawerConfig.swipeUpHome
                val down = DrawerConfig.pullDownHome
                if ((!up && !down) || !active()) {
                    reset()
                    return Offset.Zero
                }
                if (consumed.y != 0f) {
                    // The list is still moving: this is scrolling, not a swipe home.
                    reset()
                } else if (source == NestedScrollSource.UserInput && kotlin.math.abs(available.y) > kotlin.math.abs(available.x)) {
                    if (available.y < 0f && up) {
                        pulledDown = 0f
                        pulledUp -= available.y
                        if (pulledUp > 30f * density) {
                            reset()
                            close()
                        }
                    } else if (available.y > 0f && down) {
                        pulledUp = 0f
                        pulledDown += available.y
                        if (pulledDown > 30f * density) {
                            reset()
                            close()
                        }
                    }
                }
                return Offset.Zero
            }

            override suspend fun onPreFling(available: Velocity): Velocity {
                val on = active()
                val flickUp = on && DrawerConfig.swipeUpHome && pulledUp > 6f * density && available.y < -1200f
                val flickDown = on && DrawerConfig.pullDownHome && pulledDown > 6f * density && available.y > 1200f
                reset()
                if (flickUp || flickDown) close()
                return Velocity.Zero
            }
        }
    }
}

/** Needed so Eon can lock the screen. Android asks the user to turn it on the first time. */
class EonAdminReceiver : DeviceAdminReceiver()

/** Locks the screen. The first time, opens Android's screen to make Eon a device administrator. */
fun lockScreen(ctx: Context) {
    try {
        val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val admin = ComponentName(ctx, EonAdminReceiver::class.java)
        if (dpm.isAdminActive(admin)) {
            dpm.lockNow()
        } else {
            ctx.startActivity(
                Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
                    .putExtra(
                        DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                        "Eon only uses this to lock the screen when you use the lock gesture.",
                    )
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
        }
    } catch (_: Exception) {
    }
}
