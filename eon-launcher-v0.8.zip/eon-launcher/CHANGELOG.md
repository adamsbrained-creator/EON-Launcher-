# Eon: what's new

## v0.8.0
- Fixed: long-pressing empty space on the home screen did nothing since pages arrived in v0.5, because the page swiper was catching the touch; it now opens the home menu (widgets, pages, settings) again, and long-pressing an app no longer risks opening it twice.
- New: tapping the page marker at the bottom also opens the home menu, as a second way in.

## v0.7.1
- Fixed: the build failed because two functions in the settings state had the same internal name (a naming clash on the look setting). Nothing else changed, so v0.7.1 has everything from v0.5 to v0.7, including home pages, the Eon widgets and weather.

## v0.7.0
- Weather and quote: a new Eon widget with the local weather on the left (angular icon, temperature, feels like) and a daily quote on the right; tap the weather to refresh or to allow location, tap the quote for another one. Weather comes from Open-Meteo using your last known coarse location, so Eon now asks for internet access.
- Not yet: your own quotes, folders, dragging apps between pages.

## v0.6.0
- Eon widgets: two built-in widgets under "EON" in the widget picker. Now playing shows the track and artist as plain text with a round cover and a green dot while playing (tap to open the player; needs notification access), and Week shows seven days around today with the month and the time.
- Gesture: swipe down on the home screen to pull the notification shade.
- Not yet: weather, folders, dragging apps between pages.

## v0.5.0
- Home pages: swipe sideways between pages, each with its own pinned apps and widgets; the marker at the bottom shows where you are, with the Eon glyph always standing for page one.
- Page controls: long-press empty space to add a page to the left or right, or to remove an empty one; pressing Home takes you back to page one.
- Changed: pinning an app or adding a widget now goes to the page you are on, and the widget manager shows that page's widgets.
- Not yet: dragging apps between pages, resizing widgets, folders.

## v0.4.0
- Widgets: long-press empty space and choose Widgets to add any widget from any app, then move or remove them in the "On this page" tab; they sit above your pinned apps.

## v0.3.0
- Drag to rearrange: long-press a pinned app or a dock app and drag it to a new spot; long-press and release still opens the app menu, which can now add or remove dock apps.

## v0.2.0
- Every app now shows in the drawer, Eon appears in the notification access list, and icons get notification counts.
- The drawer has category chips with search across all apps; long-press an app to pin, recategorize, hide, open app info or uninstall.
- Eon settings (Glassy or Flat look, notification access, hidden apps) and a more solid drawer background.

## v0.1.0
- First build: greeting flow, home with clock and dock, app drawer with search.
