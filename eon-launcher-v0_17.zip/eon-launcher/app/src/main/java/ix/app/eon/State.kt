package ix.app.eon

import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import kotlin.math.abs
import kotlin.math.roundToInt

val LocalLook = compositionLocalOf { "glassy" }

const val GRID_COLS = 4

/**
 * Something placed on a home page: an app ("a") or a widget ("w"). Position and size are in grid cells.
 * Apps always sit on whole cells; widgets can sit anywhere (steps of 0.05 cell) and overlap, in which
 * case the higher [z] is drawn on top.
 */
class Item(val kind: String, val key: String, col: Float, row: Float, w: Float, h: Float, z: Int = 0) {
    var col by mutableStateOf(col)
    var row by mutableStateOf(row)
    var w by mutableStateOf(w)
    var h by mutableStateOf(h)
    var z by mutableStateOf(z)
}

/** Smallest a widget can be made, in cells. */
const val MIN_SIZE = 0.5f

/** Rounds to a whole cell when snapping, otherwise to steps of 0.05 cell. */
fun snapValue(v: Float, snap: Boolean): Float =
    if (snap) v.roundToInt().toFloat() else (v * 20f).roundToInt() / 20f

/** 2 -> "2", 1.5 -> "1.50" */
fun cellText(v: Float): String =
    if (v == v.toInt().toFloat()) v.toInt().toString() else String.format(java.util.Locale.US, "%.2f", v)

/** One home page. The legacy lists only hold data from versions before v0.9 until it is migrated. */
class PageData(
    var legacyPinned: List<String> = emptyList(),
    var legacyWidgets: List<Int> = emptyList(),
) {
    val items = mutableStateListOf<Item>()
}

private fun JSONArray.strings(): List<String> = (0 until length()).map { getString(it) }
private fun JSONArray.ints(): List<Int> = (0 until length()).map { getInt(it) }

/** Everything the user can change, kept in memory and saved to [Prefs]. */
class EonState(private val prefs: Prefs) {
    var look by mutableStateOf(prefs.look)
        private set
    val pages = mutableStateListOf<PageData>().also { it.addAll(loadPages()) }
    var currentPage by mutableIntStateOf(0)
    var gridRows by mutableIntStateOf(6)
    val hidden = mutableStateListOf<String>().also { it.addAll(prefs.hidden) }
    val overrides = mutableStateMapOf<String, String>().also { it.putAll(prefs.overrides) }

    // ---- saving and loading
    private fun loadPages(): List<PageData> {
        val raw = prefs.pagesJson
        if (raw.isBlank()) return listOf(PageData(prefs.pinned, prefs.widgets))
        return try {
            val root = JSONTokener(raw).nextValue()
            if (root is JSONObject) {
                val arr = root.getJSONArray("pages")
                (0 until arr.length()).map { i ->
                    val page = PageData()
                    val items = arr.getJSONObject(i).getJSONArray("items")
                    for (j in 0 until items.length()) {
                        val o = items.getJSONObject(j)
                        page.items.add(
                            Item(
                                o.getString("t"), o.getString("k"),
                                o.getDouble("c").toFloat(), o.getDouble("r").toFloat(),
                                o.getDouble("w").toFloat(), o.getDouble("h").toFloat(),
                                o.optInt("z", 0),
                            ),
                        )
                    }
                    page
                }.ifEmpty { listOf(PageData()) }
            } else {
                // v0.5 to v0.8 format: plain lists per page
                val arr = root as JSONArray
                (0 until arr.length()).map { i ->
                    val o = arr.getJSONObject(i)
                    PageData(o.getJSONArray("pinned").strings(), o.getJSONArray("widgets").ints())
                }.ifEmpty { listOf(PageData()) }
            }
        } catch (_: Exception) {
            listOf(PageData(prefs.pinned, prefs.widgets))
        }
    }

    private fun savePages() {
        val pagesArr = JSONArray()
        pages.forEach { p ->
            val items = JSONArray()
            p.items.forEach { i ->
                items.put(
                    JSONObject().put("t", i.kind).put("k", i.key)
                        .put("c", i.col.toDouble()).put("r", i.row.toDouble()).put("w", i.w.toDouble()).put("h", i.h.toDouble())
                        .put("z", i.z),
                )
            }
            pagesArr.put(JSONObject().put("items", items))
        }
        prefs.pagesJson = JSONObject().put("v", 2).put("pages", pagesArr).toString()
    }

    /** Moves data from older versions onto the grid: widgets first, then apps, in the order they had. */
    fun migrate(sizeOf: (Int) -> Pair<Int, Int>) {
        var changed = false
        pages.forEach { p ->
            if (p.legacyWidgets.isNotEmpty() || p.legacyPinned.isNotEmpty()) {
                changed = true
                p.legacyWidgets.forEach { id ->
                    val (w, h) = sizeOf(id)
                    place(p, "w", id.toString(), w, h, 20)
                }
                p.legacyPinned.forEach { k -> place(p, "a", k, 1, 1, 20) }
                p.legacyWidgets = emptyList()
                p.legacyPinned = emptyList()
            }
        }
        if (changed) savePages()
    }

    fun chooseLook(value: String) {
        look = value
        prefs.look = value
    }

    /** Whether snapping to whole cells is on while editing widgets. */
    var snapToGrid by mutableStateOf(prefs.snapToGrid)
        private set

    fun chooseSnap(on: Boolean) {
        snapToGrid = on
        prefs.snapToGrid = on
    }

    /** True when app icons can be placed anywhere; false when they sit on grid cells. */
    var freeIcons by mutableStateOf(prefs.freeIcons)
        private set

    fun chooseFreeIcons(on: Boolean) {
        freeIcons = on
        prefs.freeIcons = on
        if (!on) snapAppsToGrid()
    }

    /** Key of the widget currently being edited on the home screen, or null. */
    var editing by mutableStateOf<String?>(null)

    // ---- grid helpers
    private fun fits(p: PageData, c: Float, r: Float, w: Float, h: Float, rows: Int, ignore: Item? = null): Boolean {
        val e = 0.001f
        if (c < -e || r < -e || w < MIN_SIZE - e || h < MIN_SIZE - e || c + w > GRID_COLS + e || r + h > rows + e) return false
        return p.items.none {
            it !== ignore && c < it.col + it.w - e && c + w > it.col + e && r < it.row + it.h - e && r + h > it.row + e
        }
    }

    private fun firstFree(p: PageData, w: Int, h: Int, rows: Int): Pair<Int, Int>? {
        for (r in 0..(rows - h)) {
            for (c in 0..(GRID_COLS - w)) {
                if (fits(p, c.toFloat(), r.toFloat(), w.toFloat(), h.toFloat(), rows)) return c to r
            }
        }
        return null
    }

    private fun place(p: PageData, kind: String, key: String, w: Int, h: Int, rows: Int = gridRows): Boolean {
        val spot = firstFree(p, w, h, rows) ?: return false
        p.items.add(Item(kind, key, spot.first.toFloat(), spot.second.toFloat(), w.toFloat(), h.toFloat()))
        return true
    }

    // ---- apps on pages
    fun isPinned(key: String): Boolean = pages.any { p -> p.items.any { it.kind == "a" && it.key == key } }

    /** Pins or unpins an app. Returns false when there is no free cell on the current page. */
    fun togglePin(key: String): Boolean {
        val holder = pages.firstOrNull { p -> p.items.any { it.kind == "a" && it.key == key } }
        if (holder != null) {
            holder.items.removeAll { it.kind == "a" && it.key == key }
            savePages()
            return true
        }
        val page = pages.getOrNull(currentPage) ?: return false
        val ok = place(page, "a", key, 1, 1)
        if (ok) savePages()
        return ok
    }

    /** Drops an app on a cell: moves it if the cell is free, swaps with another app, ignores widgets. */
    fun moveApp(pageIndex: Int, key: String, col: Int, row: Int) {
        val page = pages.getOrNull(pageIndex) ?: return
        val me = page.items.firstOrNull { it.kind == "a" && it.key == key } ?: return
        val cx = col + 0.5f
        val cy = row + 0.5f
        val other = page.items.firstOrNull {
            it !== me && cx >= it.col && cx < it.col + it.w && cy >= it.row && cy < it.row + it.h
        }
        when {
            other == null -> {
                me.col = col.toFloat()
                me.row = row.toFloat()
            }
            other.kind == "a" -> {
                other.col = me.col
                other.row = me.row
                me.col = col.toFloat()
                me.row = row.toFloat()
            }
            else -> return
        }
        savePages()
    }

    /** Free placement: drops an app at an exact spot. Ignored if it would land on top of another app. */
    fun dropApp(pageIndex: Int, key: String, col: Float, row: Float) {
        val page = pages.getOrNull(pageIndex) ?: return
        val me = page.items.firstOrNull { it.kind == "a" && it.key == key } ?: return
        val c = snapValue(col.coerceIn(0f, GRID_COLS - 1f), false)
        val r = snapValue(row.coerceIn(0f, maxOf(gridRows, 1) - 1f), false)
        val crowded = page.items.any { it !== me && it.kind == "a" && abs(it.col - c) < 0.6f && abs(it.row - r) < 0.6f }
        if (crowded) return
        me.col = c
        me.row = r
        savePages()
    }

    /** Back to grid placement: every app goes to the nearest free cell. */
    private fun snapAppsToGrid() {
        val rows = maxOf(gridRows, 1)
        pages.forEach { p ->
            p.items.filter { it.kind == "a" }.forEach { me ->
                val tc = me.col.roundToInt().coerceIn(0, GRID_COLS - 1)
                val tr = me.row.roundToInt().coerceIn(0, rows - 1)
                if (fits(p, tc.toFloat(), tr.toFloat(), 1f, 1f, rows, me)) {
                    me.col = tc.toFloat()
                    me.row = tr.toFloat()
                } else {
                    var best: Pair<Int, Int>? = null
                    var bestD = Int.MAX_VALUE
                    for (r in 0 until rows) {
                        for (c in 0 until GRID_COLS) {
                            if (fits(p, c.toFloat(), r.toFloat(), 1f, 1f, rows, me)) {
                                val d = (c - tc) * (c - tc) + (r - tr) * (r - tr)
                                if (d < bestD) {
                                    bestD = d
                                    best = c to r
                                }
                            }
                        }
                    }
                    best?.let {
                        me.col = it.first.toFloat()
                        me.row = it.second.toFloat()
                    }
                }
            }
        }
        savePages()
    }

    // ---- widgets
    fun widgetItems(): List<Item> = pages.getOrNull(currentPage)?.items?.filter { it.kind == "w" } ?: emptyList()

    fun allWidgets(): List<Int> =
        pages.flatMap { p -> p.items.filter { it.kind == "w" }.mapNotNull { it.key.toIntOrNull() } }

    /** Returns false when the current page has no room for a widget of this size. */
    fun addWidget(id: Int, w: Int, h: Int): Boolean {
        val page = pages.getOrNull(currentPage) ?: return false
        if (page.items.any { it.kind == "w" && it.key == id.toString() }) return true
        val ok = place(page, "w", id.toString(), w, h)
        if (ok) savePages()
        return ok
    }

    fun removeWidget(id: Int) {
        pages.forEach { p -> p.items.removeAll { it.kind == "w" && it.key == id.toString() } }
        savePages()
    }

    fun nudgeWidget(key: String, dc: Int, dr: Int) {
        val p = pages.getOrNull(currentPage) ?: return
        val it = p.items.firstOrNull { x -> x.kind == "w" && x.key == key } ?: return
        if (fits(p, it.col + dc, it.row + dr, it.w, it.h, gridRows, it)) {
            it.col += dc
            it.row += dr
            savePages()
        }
    }

    fun resizeWidget(key: String, dw: Int, dh: Int) {
        val p = pages.getOrNull(currentPage) ?: return
        val it = p.items.firstOrNull { x -> x.kind == "w" && x.key == key } ?: return
        val w = (it.w + dw).coerceIn(1f, GRID_COLS.toFloat())
        val h = (it.h + dh).coerceIn(1f, 4f)
        if (fits(p, it.col, it.row, w, h, gridRows, it)) {
            it.w = w
            it.h = h
            savePages()
        }
    }

    /** Sets a widget's position and size in cells, keeping it inside the page. */
    fun setRect(item: Item, col: Float, row: Float, w: Float, h: Float) {
        val ww = w.coerceIn(MIN_SIZE, GRID_COLS.toFloat())
        val hh = h.coerceIn(MIN_SIZE, maxOf(gridRows, 1).toFloat())
        item.w = ww
        item.h = hh
        item.col = col.coerceIn(0f, GRID_COLS - ww)
        item.row = row.coerceIn(0f, maxOf(gridRows, 1) - hh)
    }

    /** Draw order of overlapping items: higher is on top. */
    fun raise(item: Item, by: Int) {
        item.z = (item.z + by).coerceIn(-99, 99)
        savePages()
    }

    /** Saves after a drag or a button press while editing. */
    fun commitLayout() = savePages()

    // ---- pages
    fun addPage(index: Int) {
        pages.add(index.coerceIn(0, pages.size), PageData())
        savePages()
    }

    fun removePage(index: Int) {
        if (pages.size > 1 && index in pages.indices && pages[index].items.isEmpty()) {
            pages.removeAt(index)
            savePages()
        }
    }

    // ---- hidden apps and categories
    fun hide(pkg: String) {
        if (pkg !in hidden) hidden.add(pkg)
        prefs.hidden = hidden.toSet()
    }

    fun showAllApps() {
        hidden.clear()
        prefs.hidden = emptySet()
    }

    fun setCategory(pkg: String, category: String) {
        overrides[pkg] = category
        prefs.overrides = overrides.toMap()
    }
}
