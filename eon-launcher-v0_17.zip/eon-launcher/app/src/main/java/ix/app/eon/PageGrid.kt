package ix.app.eon

import androidx.compose.animation.core.animateIntOffsetAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitLongPressOrCancellation
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import kotlin.math.roundToInt

val CELL_HEIGHT: Dp = 92.dp

/**
 * One home page as a grid of 4 columns. Apps and widgets sit on cells.
 * Long-press an app and drag it to any free cell (or onto another app to swap).
 * Long-press and release without moving opens the app menu; long-press on empty space opens the home menu.
 */
@Composable
fun PageGrid(
    page: PageData,
    pageIndex: Int,
    state: EonState,
    apps: List<AppEntry>,
    widgets: WidgetHolder,
    onTap: (AppEntry) -> Unit,
    onMenu: (AppEntry) -> Unit,
    onEmptyLongPress: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val density = LocalDensity.current
    val haptic = LocalHapticFeedback.current
    var dragKey by remember { mutableStateOf<String?>(null) }
    var dragPos by remember { mutableStateOf(Offset.Zero) }
    var targetCol by remember { mutableIntStateOf(0) }
    var targetRow by remember { mutableIntStateOf(0) }
    var settled by remember { mutableStateOf<String?>(null) }
    val latestApps by rememberUpdatedState(apps)
    val latestTap by rememberUpdatedState(onTap)
    val latestMenu by rememberUpdatedState(onMenu)
    val latestEmpty by rememberUpdatedState(onEmptyLongPress)

    BoxWithConstraints(
        modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures(onLongPress = { latestEmpty() }) },
    ) {
        val cellW = constraints.maxWidth.toFloat() / GRID_COLS
        val cellH = with(density) { CELL_HEIGHT.toPx() }
        val cellWDp = with(density) { cellW.toDp() }
        val rows = state.gridRows
        val editItem = page.items.firstOrNull { it.kind == "w" && it.key == state.editing }

        if (dragKey != null || editItem != null) GridOverlay(cellW, cellH, rows)

        if (dragKey != null && !state.freeIcons) {
            val shape = RoundedCornerShape(20.dp)
            Box(
                Modifier
                    .offset { IntOffset((targetCol * cellW).roundToInt(), (targetRow * cellH).roundToInt()) }
                    .size(DpSize(cellWDp, CELL_HEIGHT))
                    .padding(4.dp)
                    .clip(shape)
                    .background(Color(0x22FFFFFF))
                    .border(1.dp, Color(0x66FFFFFF), shape),
            )
        }

        page.items.toList().forEach { item ->
            key(item.kind + item.key) {
                if (item.kind == "w") {
                    val id = item.key.toIntOrNull()
                    if (id != null) {
                        Box(
                            Modifier
                                .offset { IntOffset((item.col * cellW).roundToInt(), (item.row * cellH).roundToInt()) }
                                .size(DpSize(cellWDp * item.w, CELL_HEIGHT * item.h))
                                .zIndex(item.z.toFloat())
                                .padding(4.dp)
                                .pointerInput(item.key) {
                                    // Long-press a widget to edit it. Watching before the widget sees the touch
                                    // (Initial pass) means this works even over widgets that handle touches.
                                    awaitEachGesture {
                                        val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                                        if (state.editing == item.key) return@awaitEachGesture
                                        var cancelled = false
                                        withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
                                            while (!cancelled) {
                                                val ev = awaitPointerEvent(PointerEventPass.Initial)
                                                val c = ev.changes.firstOrNull { it.id == down.id }
                                                if (c == null || !c.pressed ||
                                                    (c.position - down.position).getDistance() > viewConfiguration.touchSlop
                                                ) {
                                                    cancelled = true
                                                }
                                            }
                                        }
                                        if (!cancelled) {
                                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                            state.editing = item.key
                                            // Take over the rest of the touch so the widget does not also react to it.
                                            while (true) {
                                                val ev = awaitPointerEvent(PointerEventPass.Initial)
                                                ev.changes.forEach { it.consume() }
                                                if (ev.changes.none { it.pressed }) break
                                            }
                                        }
                                    }
                                },
                        ) {
                            WidgetView(
                                widgets, id,
                                (cellWDp * item.w).value.toInt() - 8,
                                (CELL_HEIGHT * item.h).value.toInt() - 8,
                            )
                        }
                    }
                } else {
                    val app = apps.firstOrNull { it.key == item.key }
                    if (app != null) {
                        val isDragged = dragKey == item.key
                        val slot = IntOffset((item.col * cellW).roundToInt(), (item.row * cellH).roundToInt())
                        val animated by animateIntOffsetAsState(slot, label = "slot")
                        val pos = when {
                            isDragged -> IntOffset(dragPos.x.roundToInt(), dragPos.y.roundToInt())
                            settled == item.key && state.freeIcons -> slot
                            else -> animated
                        }
                        Box(
                            Modifier
                                .offset { pos }
                                .size(DpSize(cellWDp, CELL_HEIGHT))
                                .zIndex(if (isDragged) 1000f else item.z.toFloat())
                                .graphicsLayer {
                                    val s = if (isDragged) 1.12f else 1f
                                    scaleX = s
                                    scaleY = s
                                    alpha = if (isDragged) 0.92f else 1f
                                }
                                .pointerInput(item.key) {
                                    awaitEachGesture {
                                        val down = awaitFirstDown(requireUnconsumed = false)
                                        down.consume()
                                        val press = awaitLongPressOrCancellation(down.id)
                                        if (press == null) {
                                            val ev = currentEvent.changes.firstOrNull { it.id == down.id }
                                            if (ev != null && !ev.pressed &&
                                                (ev.position - down.position).getDistance() < viewConfiguration.touchSlop * 2
                                            ) {
                                                latestApps.firstOrNull { it.key == item.key }?.let { latestTap(it) }
                                            }
                                            return@awaitEachGesture
                                        }
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        dragKey = item.key
                                        settled = null
                                        dragPos = Offset(item.col * cellW, item.row * cellH)
                                        targetCol = item.col.roundToInt()
                                        targetRow = item.row.roundToInt()
                                        var travelled = 0f
                                        drag(down.id) { change ->
                                            val d = change.positionChange()
                                            travelled += d.getDistance()
                                            dragPos += d
                                            change.consume()
                                            val cx = dragPos.x + cellW / 2f
                                            val cy = dragPos.y + cellH / 2f
                                            targetCol = (cx / cellW).toInt().coerceIn(0, GRID_COLS - 1)
                                            targetRow = (cy / cellH).toInt().coerceIn(0, state.gridRows - 1)
                                        }
                                        val tc = targetCol
                                        val tr = targetRow
                                        dragKey = null
                                        if (travelled > viewConfiguration.touchSlop * 2) {
                                            if (state.freeIcons) {
                                                settled = item.key
                                                state.dropApp(pageIndex, item.key, dragPos.x / cellW, dragPos.y / cellH)
                                            } else if (tc.toFloat() != item.col || tr.toFloat() != item.row) {
                                                state.moveApp(pageIndex, item.key, tc, tr)
                                            }
                                        } else {
                                            latestApps.firstOrNull { it.key == item.key }?.let { latestMenu(it) }
                                        }
                                    }
                                },
                            contentAlignment = Alignment.Center,
                        ) { AppIconBody(app, ICON_SIZE, true) }
                    }
                }
            }
        }

        if (editItem != null) WidgetEditLayer(state, widgets, editItem, cellW, cellH, rows)
    }
}
