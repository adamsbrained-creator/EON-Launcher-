plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "ix.app.eon"
    compileSdk = 35

    defaultConfig {
        applicationId = "ix.app.eon"
        minSdk = 31
        targetSdk = 35
        versionCode = 98
        versionName = "0.58.1"
    }

    // A fixed key committed to the repo so every GitHub build is signed the same way
    // and installs over the previous one. Personal use only, not for the Play Store.
    signingConfigs {
        create("eon") {
            storeFile = file("eon.jks")
            storePassword = "eonlauncher"
            keyAlias = "eon"
            keyPassword = "eonlauncher"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            signingConfig = signingConfigs.getByName("eon")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        debug {
            signingConfig = signingConfigs.getByName("eon")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures {
        compose = true
        aidl = true
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.core:core-ktx:1.15.0")
}
