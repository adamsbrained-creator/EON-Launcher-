package ix.app.eon

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.graphics.drawable.toBitmap

/** The AI pill. Tap it to open the AI it shows; tap the arrow to pick another one or to customise the pill. */
const val W_AI = -8

/**
 * One assistant the pill can open.
 *
 * [activity] is the exact activity to start (the one you find in Activity Launcher). It is tried first;
 * if the phone has no such activity, the app's normal launch intent is used instead.
 */
private class AiApp(val id: String, val label: String, val pkg: String, val activity: String? = null)

private val AI_APPS = listOf(
    AiApp("gemini", "Gemini", "com.google.android.apps.bard", "com.google.android.apps.bard.shellapp.BardEntryPointActivity"),
    AiApp("claude", "Claude", "com.anthropic.claude"),
    AiApp("chatgpt", "ChatGPT", "com.openai.chatgpt"),
    AiApp("grok", "Grok", "ai.x.grok"),
)

private const val GEMINI_ASSISTANT = "assistant"
private const val GEMINI_VOICE = "voice"
private const val GEMINI_APP = "app"

/** Everything you can change about the pill, saved as you go. */
private class AiSettings(private val sp: SharedPreferences) {
    var opacity by mutableFloatStateOf(sp.getFloat("ai_opacity", 0.6f))
    var size by mutableFloatStateOf(sp.getFloat("ai_size", 16f))
    var track by mutableFloatStateOf(sp.getFloat("ai_track", 0f))
    var showIcon by mutableStateOf(sp.getBoolean("ai_icon", true))
    var showText by mutableStateOf(sp.getBoolean("ai_text", true))
    var geminiMode by mutableStateOf(sp.getString("ai_gemini_mode", GEMINI_ASSISTANT) ?: GEMINI_ASSISTANT)
    val labels = mutableStateMapOf<String, String>().also { m ->
        AI_APPS.forEach { m[it.id] = sp.getString("ai_label_" + it.id, "") ?: "" }
    }

    fun save() {
        val e = sp.edit()
        e.putFloat("ai_opacity", opacity)
        e.putFloat("ai_size", size)
        e.putFloat("ai_track", track)
        e.putBoolean("ai_icon", showIcon)
        e.putBoolean("ai_text", showText)
        e.putString("ai_gemini_mode", geminiMode)
        labels.forEach { (k, v) -> e.putString("ai_label_$k", v) }
        e.apply()
    }

    /** The text on the pill for this AI: your own words, or its name when left empty. */
    fun labelFor(a: AiApp): String = (labels[a.id] ?: "").ifBlank { a.label }
}

private fun aiPrefs(ctx: Context) = ctx.getSharedPreferences("eon", Context.MODE_PRIVATE)

private fun installed(ctx: Context, a: AiApp): Boolean =
    runCatching { ctx.packageManager.getApplicationInfo(a.pkg, 0); true }.getOrDefault(false)

private fun tryStart(ctx: Context, i: Intent): Boolean = try {
    ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    true
} catch (e: Exception) {
    false
}

private fun launchIntent(ctx: Context, a: AiApp): Intent? {
    if (a.activity != null) {
        val i = Intent(Intent.ACTION_MAIN).setComponent(ComponentName(a.pkg, a.activity))
        if (i.resolveActivity(ctx.packageManager) != null) return i
    }
    return ctx.packageManager.getLaunchIntentForPackage(a.pkg)
}

private fun openAi(ctx: Context, a: AiApp, geminiMode: String) {
    // Gemini can open the same overlay as the power button: Android's own "assistant" action.
    if (a.id == "gemini") {
        if (geminiMode == GEMINI_ASSISTANT && tryStart(ctx, Intent(Intent.ACTION_ASSIST))) return
        if (geminiMode == GEMINI_VOICE && tryStart(ctx, Intent(Intent.ACTION_VOICE_COMMAND))) return
    }
    val i = launchIntent(ctx, a)
    if (i == null) {
        Toast.makeText(ctx, a.label + " is not installed", Toast.LENGTH_SHORT).show()
        return
    }
    if (!tryStart(ctx, i)) Toast.makeText(ctx, "Could not open " + a.label, Toast.LENGTH_SHORT).show()
}

private fun iconOf(ctx: Context, a: AiApp): ImageBitmap? = try {
    ctx.packageManager.getApplicationIcon(a.pkg).toBitmap(96, 96).asImageBitmap()
} catch (e: Exception) {
    null
}

private val PillBase = Color(0xFF202124)

@Composable
fun AiWidget() {
    val ctx = LocalContext.current
    val s = remember { AiSettings(aiPrefs(ctx)) }
    val available = remember { AI_APPS.filter { installed(ctx, it) } }
    val shown = available.ifEmpty { AI_APPS }
    var selectedId by remember { mutableStateOf(aiPrefs(ctx).getString("ai_widget_pick", "gemini") ?: "gemini") }
    var menu by remember { mutableStateOf(false) }
    var dialog by remember { mutableStateOf(false) }
    val current = shown.firstOrNull { it.id == selectedId } ?: shown.first()
    val icon = remember(current.id) { iconOf(ctx, current) }
    val pillShape = CircleShape
    // The pill and its menu share one look, so they always match.
    val fill = PillBase.copy(alpha = s.opacity.coerceIn(0f, 1f))
    val line = Color(0x33FFFFFF)

    BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        val boxW = maxWidth
        val narrow = boxW < 120.dp
        val arrowW = if (narrow) 32.dp else 44.dp
        // When the pill is small the icon makes way for the text.
        val iconNow = s.showIcon && icon != null && boxW >= 120.dp
        val iconSize = (s.size * 1.4f).coerceIn(16f, 40f).dp
        val label = s.labelFor(current)

        Row(
            Modifier.fillMaxSize().clip(pillShape).background(fill).border(1.dp, line, pillShape),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            // Left part: open the AI.
            Row(
                Modifier.weight(1f).fillMaxHeight()
                    .clickable { openAi(ctx, current, s.geminiMode) }
                    .padding(start = if (narrow) 8.dp else 18.dp, end = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
            ) {
                if (iconNow) {
                    Image(icon!!, null, Modifier.size(iconSize).clip(CircleShape))
                    if (s.showText) Spacer(Modifier.width(10.dp))
                }
                if (s.showText) {
                    // The text shrinks a step at a time until it fits, instead of disappearing.
                    var scale by remember(label, s.size, s.track, boxW, iconNow) { mutableFloatStateOf(1f) }
                    Text(
                        label, color = Color.White, fontSize = (s.size * scale).sp,
                        letterSpacing = s.track.sp, fontWeight = FontWeight.Medium,
                        maxLines = 1, softWrap = false, overflow = TextOverflow.Clip,
                        modifier = Modifier.weight(1f, fill = false),
                        onTextLayout = { if (it.hasVisualOverflow && scale > 0.4f) scale *= 0.9f },
                    )
                }
            }
            // Right part: choose another AI.
            Box(Modifier.fillMaxHeight().width(arrowW).clickable { menu = true }, contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.KeyboardArrowDown, "Choose AI", tint = Color(0xFFC8CAD0), modifier = Modifier.size(22.dp))
                DropdownMenu(
                    expanded = menu, onDismissRequest = { menu = false },
                    containerColor = fill,
                    shape = RoundedCornerShape(22.dp),
                    tonalElevation = 0.dp,
                    shadowElevation = 0.dp,
                    border = androidx.compose.foundation.BorderStroke(1.dp, line),
                ) {
                    shown.forEach { a ->
                        val ic = remember(a.id) { iconOf(ctx, a) }
                        DropdownMenuItem(
                            text = {
                                Text(
                                    s.labelFor(a) + if (installed(ctx, a)) "" else "  (not installed)",
                                    color = if (a.id == current.id) Color.White else Color(0xFFC8CAD0),
                                    fontWeight = if (a.id == current.id) FontWeight.Bold else FontWeight.Normal,
                                )
                            },
                            leadingIcon = {
                                if (ic != null) Image(ic, null, Modifier.size(24.dp).clip(CircleShape))
                                else Box(Modifier.size(24.dp).clip(CircleShape).background(Color(0xFF34363B)))
                            },
                            onClick = {
                                menu = false
                                selectedId = a.id
                                aiPrefs(ctx).edit().putString("ai_widget_pick", a.id).apply()
                                openAi(ctx, a, s.geminiMode)
                            },
                        )
                    }
                    DropdownMenuItem(
                        text = { Text("Customize", color = Color(0xFFC8CAD0)) },
                        leadingIcon = { Icon(Icons.Outlined.Tune, null, tint = Color(0xFFC8CAD0), modifier = Modifier.size(22.dp)) },
                        onClick = {
                            menu = false
                            dialog = true
                        },
                    )
                }
            }
        }
    }

    if (dialog) AiSettingsDialog(s, current) { dialog = false }
}

@Composable
private fun AiSettingsDialog(s: AiSettings, current: AiApp, onClose: () -> Unit) {
    val shape = RoundedCornerShape(28.dp)
    Dialog(onDismissRequest = { s.save(); onClose() }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.fillMaxWidth(0.92f).heightIn(max = 640.dp).clip(shape)
                .background(Eon.P0).border(1.dp, Eon.P2, shape)
                .verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("AI pill", color = Eon.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text(
                    "DONE", color = Eon.Good, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { s.save(); onClose() }.padding(8.dp),
                )
            }

            AiSlider("Opacity", (s.opacity * 100).toInt().toString() + "%", s.opacity, 0f..1f, { s.opacity = it }, { s.save() })
            AiSlider("Text size", String.format("%.0f", s.size), s.size, 8f..32f, { s.size = it }, { s.save() })
            AiSlider("Tracking", String.format("%.1f", s.track), s.track, -1f..8f, { s.track = it }, { s.save() })

            AiSwitch("Show icon", s.showIcon) { s.showIcon = it; s.save() }
            AiSwitch("Show text", s.showText) { s.showText = it; s.save() }
            Text(
                "A small pill hides its icon by itself so the text keeps its room.",
                color = Eon.Muted, fontSize = 12.sp,
            )

            Text("TEXT FOR EACH AI", color = Eon.Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
            AI_APPS.forEach { a ->
                AiField(a.label, s.labels[a.id] ?: "") { s.labels[a.id] = it; s.save() }
            }
            Text("Leave a field empty to use the AI's name.", color = Eon.Muted, fontSize = 12.sp)

            Text("GEMINI OPENS AS", color = Eon.Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(GEMINI_ASSISTANT to "Overlay", GEMINI_VOICE to "Voice", GEMINI_APP to "App").forEach { (k, name) ->
                    val on = s.geminiMode == k
                    Box(
                        Modifier.weight(1f).clip(RoundedCornerShape(14.dp))
                            .background(if (on) Eon.P2 else Eon.P1)
                            .border(1.dp, if (on) Eon.Accent else Eon.P2, RoundedCornerShape(14.dp))
                            .clickable { s.geminiMode = k; s.save() }
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(name, color = Eon.Text, fontSize = 14.sp, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal)
                    }
                }
            }
            Text(
                "Overlay is the same window as the power button. If it opens something else, try Voice or App.",
                color = Eon.Muted, fontSize = 12.sp,
            )
        }
    }
}

@Composable
private fun AiSlider(
    title: String, value: String, v: Float, range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit, onDone: () -> Unit,
) {
    Column {
        Row {
            Text(title, color = Eon.Text, fontSize = 15.sp, modifier = Modifier.weight(1f))
            Text(value, color = Eon.Muted, fontSize = 15.sp)
        }
        Slider(
            value = v, onValueChange = onChange, valueRange = range, onValueChangeFinished = onDone,
            colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Eon.Accent, inactiveTrackColor = Eon.P2),
        )
    }
}

@Composable
private fun AiSwitch(title: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Eon.Text, fontSize = 15.sp, modifier = Modifier.weight(1f))
        EonSwitch(on, onChange)
    }
}

@Composable
private fun AiField(name: String, value: String, onChange: (String) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(name, color = Eon.Muted, fontSize = 14.sp, modifier = Modifier.width(78.dp))
        BasicTextField(
            value = value, onValueChange = { onChange(it.take(40)) }, singleLine = true,
            textStyle = TextStyle(color = Eon.Text, fontSize = 15.sp),
            cursorBrush = SolidColor(Eon.Accent),
            modifier = Modifier.weight(1f),
            decorationBox = { inner ->
                Box(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Eon.P1)
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                ) {
                    if (value.isEmpty()) Text(name, color = Eon.Muted, fontSize = 15.sp)
                    inner()
                }
            },
        )
    }
}
