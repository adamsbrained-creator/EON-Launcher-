package ix.app.eon

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowDownward
import androidx.compose.material.icons.outlined.ArrowUpward
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.roundToInt

private const val DAY = 24L * 60L * 60L * 1000L

/**
 * What you open, kept on the phone and never sent anywhere: a list of "this app, at this time" (the last 1000).
 * The suggestions, the stats and the "most used" sorting all come from it.
 */
object Usage {
    private class Entry(val key: String, val at: Long)

    private val log = ArrayList<Entry>()
    private var prefs: Prefs? = null

    /** Goes up on every launch, so anything showing numbers from here updates. */
    var tick by mutableIntStateOf(0)
        private set

    /** When Eon started keeping the list. */
    var since = 0L
        private set

    fun init(p: Prefs) {
        prefs = p
        log.clear()
        try {
            val arr = JSONArray(p.getString("usageLog").ifEmpty { "[]" })
            for (i in 0 until arr.length()) {
                val o = arr.getJSONArray(i)
                log.add(Entry(o.getString(0), o.getLong(1)))
            }
        } catch (_: Exception) {
        }
        since = p.getString("usageSince").toLongOrNull() ?: 0L
        if (since == 0L) {
            since = System.currentTimeMillis()
            p.putString("usageSince", since.toString())
        }
    }

    fun record(key: String) {
        log.add(Entry(key, System.currentTimeMillis()))
        while (log.size > 1000) log.removeAt(0)
        save()
        tick++
    }

    /** The keys of the [limit] apps most likely wanted now, leaving out [exclude]. See [PredictedRow]. */
    fun predict(limit: Int, exclude: Set<String>): List<String> {
        val now = System.currentTimeMillis()
        val cal = java.util.Calendar.getInstance()
        val hourNow = cal.get(java.util.Calendar.HOUR_OF_DAY) + cal.get(java.util.Calendar.MINUTE) / 60f
        val scores = HashMap<String, Float>()
        for (e in log) {
            val ageDays = (now - e.at) / 86_400_000f
            if (ageDays > 30f) continue
            cal.timeInMillis = e.at
            val h = cal.get(java.util.Calendar.HOUR_OF_DAY) + cal.get(java.util.Calendar.MINUTE) / 60f
            var gap = kotlin.math.abs(h - hourNow)
            if (gap > 12f) gap = 24f - gap
            // Launches within three hours of now count most; every launch counts a little; older ones count less.
            val near = if (gap <= 3f) 1f - gap / 3f else 0f
            val weight = (0.3f + 0.7f * near) * (1f - ageDays / 40f)
            scores[e.key] = (scores[e.key] ?: 0f) + weight
        }
        return scores.entries.filter { it.key !in exclude && it.value > 0f }
            .sortedByDescending { it.value }.take(limit).map { it.key }
    }

    fun clear() {
        log.clear()
        since = System.currentTimeMillis()
        prefs?.putString("usageSince", since.toString())
        save()
        tick++
    }

    private fun save() {
        val arr = JSONArray()
        log.forEach { arr.put(JSONArray().put(it.key).put(it.at)) }
        prefs?.putString("usageLog", arr.toString())
    }

    /** How many days Eon has been keeping the list. */
    fun spanDays(): Int {
        tick
        return ((System.currentTimeMillis() - since) / DAY).toInt()
    }

    fun count(key: String, days: Int = 30): Int {
        tick
        val from = System.currentTimeMillis() - days * DAY
        return log.count { it.key == key && it.at >= from }
    }

    fun last(key: String): Long {
        tick
        return log.lastOrNull { it.key == key }?.at ?: 0L
    }

    fun total(days: Int): Int {
        tick
        val from = System.currentTimeMillis() - days * DAY
        return log.count { it.at >= from }
    }

    /** Opens per day for the last [days] days, oldest first, with the first day's start for the labels. */
    fun perDay(days: Int): IntArray {
        tick
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val firstDay = cal.timeInMillis - (days - 1) * DAY
        val out = IntArray(days)
        log.forEach {
            if (it.at >= firstDay) out[((it.at - firstDay) / DAY).toInt().coerceIn(0, days - 1)]++
        }
        return out
    }

    /** The app opened most in the last [days] days, with how many times. */
    fun top(days: Int, apps: List<AppEntry>): Pair<AppEntry, Int>? {
        tick
        val from = System.currentTimeMillis() - days * DAY
        val counts = HashMap<String, Int>()
        log.forEach { if (it.at >= from) counts[it.key] = (counts[it.key] ?: 0) + 1 }
        return apps.mapNotNull { a -> counts[a.key]?.let { a to it } }.maxByOrNull { it.second }
    }

    /**
     * Apps you tend to open around now. Each launch in the last 30 days counts, more when it was at about this time
     * of day and more when it was recent.
     */
    fun suggestions(apps: List<AppEntry>, n: Int): List<AppEntry> {
        tick
        val now = System.currentTimeMillis()
        val cal = Calendar.getInstance()
        val nowBucket = cal.get(Calendar.HOUR_OF_DAY) / 3
        val scores = HashMap<String, Double>()
        val c = Calendar.getInstance()
        log.forEach { e ->
            val ageDays = (now - e.at) / DAY.toDouble()
            if (ageDays <= 30.0) {
                c.timeInMillis = e.at
                val b = c.get(Calendar.HOUR_OF_DAY) / 3
                val dist = minOf((b - nowBucket + 8) % 8, (nowBucket - b + 8) % 8)
                val w = when (dist) {
                    0 -> 1.0
                    1 -> 0.5
                    else -> 0.1
                }
                scores[e.key] = (scores[e.key] ?: 0.0) + w * exp(-ageDays / 14.0)
            }
        }
        return apps.filter { (scores[it.key] ?: 0.0) > 0.3 }.sortedByDescending { scores[it.key] ?: 0.0 }.take(n)
    }

    /** Apps installed a while ago that were not opened through Eon for [days] days. */
    fun unused(apps: List<AppEntry>, days: Int, n: Int): List<AppEntry> {
        tick
        val now = System.currentTimeMillis()
        return apps.filter { a ->
            a.firstInstall in 1 until (now - 14 * DAY) && now - last(a.key).coerceAtLeast(since) > days * DAY
        }.sortedBy { a -> last(a.key) }.take(n)
    }
}

/** The insight cards you can have above the boxes. */
val INSIGHT_CARDS = listOf(
    "suggested" to "Suggested for you",
    "pills" to "Quick facts",
    "stats" to "Your stats",
    "recent" to "Recently added",
    "unused" to "Not opened lately",
    "notifs" to "Waiting for you",
)

/** How to sort the apps inside a box. */
val BOX_SORTS = listOf(
    "auto" to "Default", "az" to "A to Z", "used" to "Most used", "recent" to "Recently used",
    "new" to "Newest", "custom" to "My order",
)

/** What you chose for the App Library: insight cards, how each box sorts, the order you gave the apps. */
object LibraryConfig {
    var showInsights by mutableStateOf(false)
    var smartBoxes by mutableStateOf(false)

    /** Apps you open around now, as the first box of the Library (instead of the Suggested card). */
    var suggestBox by mutableStateOf(true)

    /** Blur the home screen behind the Library, and draw the boxes as light frosted glass (off: darker, plainer boxes). */
    var homeBlur by mutableStateOf(true)

    /** How the Library looks: 0 Glass (blurred and see-through, with a soft tint per box), 1 Flat (a solid colour you choose, no blur). */
    var style by mutableStateOf(0)
    val styleNames = listOf("Glass", "Flat")
    val styleName: String get() = styleNames[style]
    val isFlat: Boolean get() = style == 1

    /** The Flat look, all yours to change: fill colour and opacity, border colour, opacity and width, corner roundness. */
    var flatColor by mutableStateOf(Color(0xFF1A1C20))
    var flatOpacity by mutableStateOf(0.96f)
    var flatBorderColor by mutableStateOf(Color(0xFF2A2D33))
    var flatBorderOpacity by mutableStateOf(1f)
    var flatBorderWidth by mutableStateOf(1f)
    var flatRadius by mutableStateOf(14)


    /** When on, icons inside the boxes are just pictures: any tap on a box opens it, and nothing is launched or dragged from it. */
    var openOnly by mutableStateOf(false)

    /** Soft fade where the boxes scroll under the search pill and off the bottom of the screen. */
    var edgeFade by mutableStateOf(true)

    /** The "+N" tile looks like one more icon tile (same corners, no outline). */
    var tidyCluster by mutableStateOf(true)

    /** An app shows in one of your boxes only (the first that holds it). Suggestions and Recently added still repeat apps. */
    var uniqueApps by mutableStateOf(false)

    /** A small dot on the icon that has notifications, instead of one number on the whole box. */
    var badgeDots by mutableStateOf(true)

    /** Flat boxes get the soft wash of their own colour too, and a light edge along the top. */
    var flatTint by mutableStateOf(true)

    /** The number of apps as a small chip next to the box name. */
    var countChip by mutableStateOf(true)

    /** A "New box" tile in the empty spot at the end of an odd row. */
    var fillGap by mutableStateOf(true)

    /** Suggestions and Recently added as slim strips of icons above the boxes instead of boxes. */
    var quickRows by mutableStateOf(false)

    /** Each box gets a soft wash of its own colour. Off: every card is the same neutral frosted glass (colours you pick for a box still show). */
    var tintCards by mutableStateOf(false)

    /** The extra black layer the Library used to put over the wallpaper (on only in the Classic preset). */
    var classicDim by mutableStateOf(false)

    /** Light or dark frost for the cards: 0 Auto (from the wallpaper), 1 Light, 2 Dark. See [LibFrost]. */
    var frost by mutableStateOf(0)
    val frostNames = listOf("Auto", "Light", "Dark")

    /** Clear glass: the frosted card with less fill, so more of the wallpaper shows through. */
    var clearGlass by mutableStateOf(false)

    /** The layers of the glass (all optional): a bright edge along the top, a darker band along the bottom, a soft shadow, a little grain. */
    var glassTop by mutableStateOf(true)
    var glassShade by mutableStateOf(true)
    var glassShadow by mutableStateOf(true)
    var grain by mutableStateOf(false)

    /** The tile under the four small icons of a "+N" cluster: 0 none (the icons sit on the card), 1 subtle. */
    var clusterPlate by mutableStateOf(0)

    /** The search pill is made of the same material as the cards, says "App Library" and lines up with the card margins. */
    var iosPill by mutableStateOf(true)

    /** The four materials of Customize Library: Frosted, Clear, Tinted (a wash of each box's colour) and Flat. */
    val materialNames = listOf("Frosted", "Clear", "Tinted", "Flat")
    val material: Int get() = when { isFlat -> 3; tintCards -> 2; clearGlass -> 1; else -> 0 }

    fun chooseMaterial(i: Int) {
        style = if (i == 3) 1 else 0
        tintCards = i == 2
        clearGlass = i == 1
        save()
    }

    fun chooseFrost(i: Int) { frost = i.coerceIn(0, 2); save() }

    /** The dim over the wallpaper, 0 to 70%. It is the drawer's own opacity (Settings > Drawer > Background); [saveDim] stores it once the finger lifts. */
    fun chooseDim(v: Float) { DrawerConfig.bgOpacity = (Math.round(v * 100f) / 100f).coerceIn(0f, 0.7f) }
    fun saveDim() { prefs?.let { DrawerConfig.save(it) } }

    /** The wash colour for a box's card, or null for the neutral card. */
    fun tintFor(id: String): Color? = if (tintCards || boxColors[id] != null) libTintFor(id).a else null

    /** The small bar at the bottom: Library, A-Z, Arrange. */
    var bottomBar by mutableStateOf(true)

    /** The boxes ease in one after another when the Library opens. */
    var stagger by mutableStateOf(true)

    /** How the boxes arrive: 0 Calm (a gentle rise), 1 Lively (a quicker, springy rise), 2 Instant (no animation). */
    var motion by mutableIntStateOf(0)
    val motionNames = listOf("Calm", "Lively", "Instant")

    /** Layout, all in dp (sp for the label): the margin at the sides, the gap between boxes (across and down), the gap between a box and its name. */
    var sideMargin by mutableIntStateOf(26)
    var colGap by mutableIntStateOf(14)
    var rowGap by mutableIntStateOf(18)
    var nameGap by mutableIntStateOf(6)
    var labelSize by mutableIntStateOf(12)
    var labelBold by mutableStateOf(false)

    fun chooseColumns(n: Int) {
        DrawerConfig.libColumns = n.coerceIn(2, 3)
        prefs?.let { DrawerConfig.save(it) }
    }

    fun resetLayout() {
        sideMargin = 26; colGap = 14; rowGap = 18; nameGap = 6; labelSize = 12; labelBold = false
        chooseColumns(2)
        save()
    }

    fun resetMotion() { motion = 0; stagger = true; save() }

    /** Boxes kept at the top, boxes tucked away, and a colour chosen for a box. Hidden boxes show again while [showHiddenBoxes] is on. */
    val pinned = mutableStateListOf<String>()
    val hiddenBoxes = mutableStateListOf<String>()
    var showHiddenBoxes by mutableStateOf(false)
    val boxColors = mutableStateMapOf<String, Int>()

    val presetNames = listOf("iOS", "Glass", "Flat", "Minimal", "Rich", "Classic")

    /** True for the preset that also sets the icon shape (Squircle), so the dialog can ask the launcher to change it. */
    fun presetSetsShape(i: Int): Boolean = presetNames.getOrNull(i) == "iOS"

    /** One tap sets the look and the extras together. Your boxes, their order and their colours stay as they are. */
    fun applyPreset(i: Int) {
        val name = presetNames.getOrNull(i) ?: return
        // A ready-made look brings its own spacing, names and motion (columns stay as you set them). Classic leaves them as they are.
        if (name != "Classic") {
            sideMargin = 26; colGap = 14; rowGap = 18; nameGap = 6; labelSize = 12; labelBold = false; motion = 0
            save()
        }
        if (name == "Classic") {
            prefs?.let { LibLook.restoreClassic(it) }
            return
        }
        if (name == "iOS") {
            prefs?.let { LibLook.applyIos(it) }
            return
        }
        // The other presets go with the calmer look: light dim, blurred wallpaper, neutral cards.
        prefs?.let { if (classicDim || tintCards) LibLook.restoreNew(it) }
        when (name) {
            "Glass" -> { style = 0; edgeFade = true; tidyCluster = true; countChip = false; flatTint = true; badgeDots = true; quickRows = false; bottomBar = true; fillGap = true; stagger = true }
            "Flat" -> { style = 1; edgeFade = true; tidyCluster = true; countChip = true; flatTint = true; badgeDots = true; quickRows = false; bottomBar = true; fillGap = true; stagger = true }
            "Minimal" -> { style = 0; edgeFade = true; tidyCluster = true; countChip = false; flatTint = false; badgeDots = true; quickRows = true; bottomBar = false; fillGap = false; stagger = false }
            else -> { style = 0; edgeFade = true; tidyCluster = true; countChip = true; flatTint = true; badgeDots = true; quickRows = false; bottomBar = true; fillGap = true; stagger = true }
        }
        save()
    }

    // ---- Your own looks: saved in the app, and shared as a short text code.

    /** Name and look (as JSON text) of each look you saved. */
    val saved = mutableStateListOf<Pair<String, String>>()

    /** The settings that make up a look. Your boxes, their order, colours and cards are not part of it. */
    private val lookKeys = listOf(
        "look", "flatColor", "flatOpacity", "flatBorderColor", "flatBorderOpacity", "flatBorderWidth", "flatRadius",
        "edgeFade", "tidyCluster", "badgeDots", "flatTint", "countChip", "fillGap", "quickRows", "bottomBar", "stagger",
        "tintCards", "classicDim", "frost", "clearGlass", "glassTop", "glassShade", "glassShadow", "grain", "clusterPlate",
        "iosPill", "homeBlur", "motion", "sideMargin", "colGap", "rowGap", "nameGap", "labelSize", "labelBold",
    )

    /** The current look as JSON text: the Library's own settings plus the drawer's opacity, blur, fill, corners and columns. */
    fun snapshot(): String {
        save()
        val all = try { JSONObject(prefs?.getString("libCfg").orEmpty().ifEmpty { "{}" }) } catch (_: Exception) { JSONObject() }
        val o = JSONObject()
        lookKeys.forEach { k -> if (all.has(k)) o.put(k, all.get(k)) }
        o.put("dBg", DrawerConfig.bgOpacity.toDouble()).put("dBlur", BlurConfig.amount).put("dTile", DrawerConfig.tileOpacity.toDouble())
        o.put("dRad", DrawerConfig.tileRadius).put("dCols", DrawerConfig.libColumns)
        return o.toString()
    }

    /** Switches to a look made by [snapshot]. Returns false when the text is not a look. */
    fun applySnapshot(json: String): Boolean {
        val p = prefs ?: return false
        val o = try { JSONObject(json) } catch (_: Exception) { return false }
        if (lookKeys.none { o.has(it) }) return false
        save()
        val all = try { JSONObject(p.getString("libCfg").ifEmpty { "{}" }) } catch (_: Exception) { JSONObject() }
        lookKeys.forEach { k -> if (o.has(k)) all.put(k, o.get(k)) }
        p.putString("libCfg", all.toString())
        if (o.has("dBg")) DrawerConfig.bgOpacity = o.optDouble("dBg", 0.2).toFloat().coerceIn(0f, 0.7f)
        if (o.has("dTile")) DrawerConfig.tileOpacity = o.optDouble("dTile", 0.1).toFloat().coerceIn(0f, 1f)
        if (o.has("dRad")) DrawerConfig.tileRadius = o.optInt("dRad", 28).coerceIn(0, 60)
        if (o.has("dCols")) DrawerConfig.libColumns = o.optInt("dCols", 2).coerceIn(2, 3)
        DrawerConfig.save(p)
        if (o.has("dBlur")) BlurConfig.set(o.optInt("dBlur", 0))
        load(p)
        return true
    }

    private fun saveSaved() {
        val a = JSONArray()
        saved.forEach { (n, d) -> a.put(JSONObject().put("n", n).put("d", d)) }
        prefs?.putString("libSaved", a.toString())
    }

    /** Keeps the current look under [name] (the same name replaces the old one). */
    fun saveLook(name: String) {
        val n = name.trim().take(24).ifEmpty { "My look ${saved.size + 1}" }
        val d = snapshot()
        val at = saved.indexOfFirst { it.first.equals(n, ignoreCase = true) }
        if (at >= 0) saved[at] = n to d else saved.add(n to d)
        saveSaved()
    }

    fun useLook(i: Int): Boolean = saved.getOrNull(i)?.let { applySnapshot(it.second) } ?: false

    fun deleteLook(i: Int) {
        if (i in saved.indices) { saved.removeAt(i); saveSaved() }
    }

    private const val CODE_TAG = "EONLIB1:"

    /** A look as a line of text to send to someone (or keep in a note). */
    fun lookCode(json: String): String = CODE_TAG + android.util.Base64.encodeToString(json.toByteArray(Charsets.UTF_8), android.util.Base64.NO_WRAP or android.util.Base64.URL_SAFE)

    /** The look inside a code made by [lookCode], or null when the text is not one. */
    fun readCode(text: String): String? {
        val t = text.trim()
        val at = t.indexOf(CODE_TAG)
        if (at < 0) return null
        val body = t.substring(at + CODE_TAG.length).takeWhile { !it.isWhitespace() }
        return try {
            val json = String(android.util.Base64.decode(body, android.util.Base64.NO_WRAP or android.util.Base64.URL_SAFE), Charsets.UTF_8)
            JSONObject(json)
            json
        } catch (_: Exception) { null }
    }

    /** Changes a setting and saves. */
    fun update(change: () -> Unit) { change(); save() }

    fun togglePin(id: String) { if (id in pinned) pinned.remove(id) else pinned.add(id); save() }
    fun toggleHideBox(id: String) { if (id in hiddenBoxes) hiddenBoxes.remove(id) else hiddenBoxes.add(id); save() }
    fun setBoxColor(id: String, c: Color?) { if (c == null) boxColors.remove(id) else boxColors[id] = c.toArgb(); save() }

    /** How an opened box looks: 0 a sheet rising from the bottom, 1 a full page like the folders on the home screen. */
    var boxPage by mutableStateOf(0)

    /** How easily a swipe up on home opens the Library: 0 relaxed, 1 normal, 2 eager. */
    var swipeFeel by mutableStateOf(1)

    /** Pull (dp) before the Library starts to follow the finger. */
    fun liveSlopDp(): Float = when (swipeFeel) { 0 -> 36f; 2 -> 16f; else -> 24f }

    /** Speed (dp/s) at which a quick swipe opens it however short, and the least pull (dp) for that. */
    fun flickSpeedDp(): Float = when (swipeFeel) { 0 -> 650f; 2 -> 320f; else -> 450f }
    fun flickPullDp(): Float = when (swipeFeel) { 0 -> 44f; 2 -> 20f; else -> 28f }

    /** A slow release opens it once pulled this far up (fraction of the screen). */
    fun settleFraction(): Float = when (swipeFeel) { 0 -> 0.45f; 2 -> 0.25f; else -> 0.35f }

    /** The cards in order, and whether each shows. */
    val cards = mutableStateListOf<Pair<String, Boolean>>()
    val sorts = mutableStateMapOf<String, String>()
    val orders = mutableStateMapOf<String, List<String>>()
    private var prefs: Prefs? = null

    fun load(p: Prefs) {
        prefs = p
        cards.clear()
        sorts.clear()
        orders.clear()
        pinned.clear()
        hiddenBoxes.clear()
        boxColors.clear()
        saved.clear()
        try {
            val sv = JSONArray(p.getString("libSaved").ifEmpty { "[]" })
            for (i in 0 until sv.length()) { val e = sv.getJSONObject(i); saved.add(e.getString("n") to e.getString("d")) }
        } catch (_: Exception) {
        }
        try {
            val o = JSONObject(p.getString("libCfg").ifEmpty { "{}" })
            showInsights = o.optBoolean("insights", false)
            smartBoxes = o.optBoolean("smart", false)
            homeBlur = o.optBoolean("homeBlur", true)
            // "look" replaced "style" when Frost was dropped: Glass stays 0, Flat was 2 and is now 1, Frost becomes Glass.
            style = if (o.has("look")) o.optInt("look", 0).coerceIn(0, 1) else if (o.optInt("style", 0) == 2) 1 else 0
            flatColor = Color(o.optInt("flatColor", Color(0xFF1A1C20).toArgb()))
            flatOpacity = o.optDouble("flatOpacity", 0.96).toFloat().coerceIn(0f, 1f)
            flatBorderColor = Color(o.optInt("flatBorderColor", Color(0xFF2A2D33).toArgb()))
            flatBorderOpacity = o.optDouble("flatBorderOpacity", 1.0).toFloat().coerceIn(0f, 1f)
            flatBorderWidth = o.optDouble("flatBorderWidth", 1.0).toFloat().coerceIn(0f, 4f)
            flatRadius = o.optInt("flatRadius", 14).coerceIn(0, 40)
            swipeFeel = o.optInt("swipeFeel", 1).coerceIn(0, 2)
            openOnly = o.optBoolean("openOnly", false)
            boxPage = o.optInt("boxPage", 0).coerceIn(0, 2)
            edgeFade = o.optBoolean("edgeFade", true)
            tidyCluster = o.optBoolean("tidyCluster", true)
            uniqueApps = o.optBoolean("uniqueApps", false)
            badgeDots = o.optBoolean("badgeDots", true)
            flatTint = o.optBoolean("flatTint", true)
            countChip = o.optBoolean("countChip", true)
            fillGap = o.optBoolean("fillGap", true)
            quickRows = o.optBoolean("quickRows", false)
            bottomBar = o.optBoolean("bottomBar", true)
            stagger = o.optBoolean("stagger", true)
            tintCards = o.optBoolean("tintCards", false)
            classicDim = o.optBoolean("classicDim", false)
            // Saved before 0.80.2: the new glass layers come on for the calmer look, and stay off for the Classic preset.
            frost = o.optInt("frost", if (classicDim) 1 else 0).coerceIn(0, 2)
            clearGlass = o.optBoolean("clearGlass", false)
            glassTop = o.optBoolean("glassTop", !classicDim)
            glassShade = o.optBoolean("glassShade", !classicDim)
            glassShadow = o.optBoolean("glassShadow", !classicDim)
            grain = o.optBoolean("grain", false)
            clusterPlate = o.optInt("clusterPlate", if (classicDim) 1 else 0).coerceIn(0, 1)
            iosPill = o.optBoolean("iosPill", !classicDim)
            motion = o.optInt("motion", 0).coerceIn(0, 2)
            sideMargin = o.optInt("sideMargin", 26).coerceIn(8, 40)
            colGap = o.optInt("colGap", 14).coerceIn(4, 32)
            rowGap = o.optInt("rowGap", 18).coerceIn(4, 40)
            nameGap = o.optInt("nameGap", 6).coerceIn(0, 16)
            labelSize = o.optInt("labelSize", 12).coerceIn(9, 16)
            labelBold = o.optBoolean("labelBold", false)
            o.optJSONArray("pinned")?.let { a -> for (i in 0 until a.length()) pinned.add(a.getString(i)) }
            o.optJSONArray("hiddenBoxes")?.let { a -> for (i in 0 until a.length()) hiddenBoxes.add(a.getString(i)) }
            o.optJSONObject("boxColors")?.let { c -> c.keys().forEach { k -> boxColors[k] = c.getInt(k) } }
            // Saved before the Suggestions box existed: the box takes over from the cards, which stay in Customize Library.
            suggestBox = if (o.has("suggestBox")) o.optBoolean("suggestBox", true) else true
            if (!o.has("suggestBox")) showInsights = false
            o.optJSONArray("cards")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val c = arr.getJSONObject(i)
                    if (INSIGHT_CARDS.any { it.first == c.getString("id") }) cards.add(c.getString("id") to c.optBoolean("on", true))
                }
            }
            o.optJSONObject("sorts")?.let { s -> s.keys().forEach { k -> sorts[k] = s.getString(k) } }
            o.optJSONObject("orders")?.let { s ->
                s.keys().forEach { k ->
                    val a = s.getJSONArray(k)
                    orders[k] = (0 until a.length()).map { a.getString(it) }
                }
            }
        } catch (_: Exception) {
        }
        // A card Eon has not saved yet goes where it belongs in the list. Of the cards, only Suggested and Quick facts
        // start switched on (the rest are in Customize Library).
        INSIGHT_CARDS.forEachIndexed { at, (id, _) ->
            if (cards.none { it.first == id }) cards.add(at.coerceAtMost(cards.size), id to (id == "suggested" || id == "pills"))
        }
    }

    fun save() {
        val o = JSONObject().put("insights", showInsights).put("smart", smartBoxes).put("suggestBox", suggestBox).put("homeBlur", homeBlur).put("look", style).put("flatColor", flatColor.toArgb()).put("flatOpacity", flatOpacity.toDouble()).put("flatBorderColor", flatBorderColor.toArgb()).put("flatBorderOpacity", flatBorderOpacity.toDouble()).put("flatBorderWidth", flatBorderWidth.toDouble()).put("flatRadius", flatRadius).put("swipeFeel", swipeFeel).put("openOnly", openOnly).put("boxPage", boxPage)
        val arr = JSONArray()
        cards.forEach { arr.put(JSONObject().put("id", it.first).put("on", it.second)) }
        o.put("cards", arr)
        o.put("edgeFade", edgeFade).put("tidyCluster", tidyCluster).put("uniqueApps", uniqueApps).put("badgeDots", badgeDots)
        o.put("flatTint", flatTint).put("countChip", countChip).put("fillGap", fillGap).put("quickRows", quickRows)
        o.put("bottomBar", bottomBar).put("stagger", stagger).put("tintCards", tintCards).put("classicDim", classicDim)
        o.put("frost", frost).put("clearGlass", clearGlass).put("glassTop", glassTop).put("glassShade", glassShade).put("glassShadow", glassShadow)
        o.put("grain", grain).put("clusterPlate", clusterPlate).put("iosPill", iosPill)
        o.put("motion", motion).put("sideMargin", sideMargin).put("colGap", colGap).put("rowGap", rowGap).put("nameGap", nameGap)
        o.put("labelSize", labelSize).put("labelBold", labelBold)
        o.put("pinned", JSONArray(pinned.toList())).put("hiddenBoxes", JSONArray(hiddenBoxes.toList()))
        val bc = JSONObject()
        boxColors.forEach { (k, v) -> bc.put(k, v) }
        o.put("boxColors", bc)
        val s = JSONObject()
        sorts.forEach { (k, v) -> s.put(k, v) }
        o.put("sorts", s)
        val ord = JSONObject()
        orders.forEach { (k, v) -> ord.put(k, JSONArray(v)) }
        o.put("orders", ord)
        prefs?.putString("libCfg", o.toString())
    }

    fun chooseInsights(on: Boolean) { showInsights = on; save() }
    fun chooseSmartBoxes(on: Boolean) { smartBoxes = on; save() }
    fun chooseSuggestBox(on: Boolean) { suggestBox = on; save() }
    fun chooseHomeBlur(on: Boolean) { homeBlur = on; save() }
    fun chooseStyle(i: Int) { style = i.coerceIn(0, 1); save() }
    fun cycleStyle() = chooseStyle((style + 1) % 2)
    fun chooseSwipeFeel(i: Int) { swipeFeel = i.coerceIn(0, 2); save() }
    fun chooseOpenOnly(on: Boolean) { openOnly = on; save() }
    fun chooseBoxPage(i: Int) { boxPage = i.coerceIn(0, 2); save() }

    fun cardOn(id: String): Boolean = cards.firstOrNull { it.first == id }?.second ?: false

    fun setCard(id: String, on: Boolean) {
        val i = cards.indexOfFirst { it.first == id }
        if (i >= 0) cards[i] = id to on
        save()
    }

    fun moveCard(id: String, delta: Int) {
        val i = cards.indexOfFirst { it.first == id }
        val j = i + delta
        if (i < 0 || j !in cards.indices) return
        val c = cards.removeAt(i)
        cards.add(j, c)
        save()
    }

    fun sortOf(box: String): String = sorts[box] ?: "auto"

    fun setSort(box: String, mode: String) {
        sorts[box] = mode
        save()
    }

    /** Applies the box's sort to [apps], which come in the drawer's own order. */
    fun sorted(box: String, apps: List<AppEntry>): List<AppEntry> = when (sortOf(box)) {
        "az" -> apps.sortedBy { it.label.lowercase() }
        "used" -> apps.sortedWith(compareByDescending<AppEntry> { Usage.count(it.key, 30) }.thenBy { it.label.lowercase() })
        "recent" -> apps.sortedByDescending { Usage.last(it.key) }
        "new" -> apps.sortedByDescending { it.firstInstall }
        "custom" -> {
            val order = orders[box] ?: emptyList()
            apps.withIndex().sortedBy { (i, a) ->
                val at = order.indexOf(a.key)
                if (at >= 0) at else order.size + i
            }.map { it.value }
        }
        else -> apps
    }

    /** Moves one app one step earlier or later in a box and switches the box to "My order". */
    fun moveApp(box: String, shownKeys: List<String>, key: String, delta: Int) {
        val i = shownKeys.indexOf(key)
        val j = i + delta
        if (i < 0 || j !in shownKeys.indices) return
        val list = shownKeys.toMutableList()
        list.removeAt(i)
        list.add(j, key)
        orders[box] = list
        sorts[box] = "custom"
        save()
    }

    fun forgetBox(box: String) {
        sorts.remove(box)
        orders.remove(box)
        pinned.remove(box)
        hiddenBoxes.remove(box)
        boxColors.remove(box)
        save()
    }
}

/** The cards above the boxes. Hidden ones and the whole panel can be turned off in [LibraryCustomizeDialog]. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun InsightsPanel(
    apps: List<AppEntry>, onLaunch: (AppEntry) -> Unit, onMenu: (AppEntry) -> Unit, onHideApp: (AppEntry) -> Unit,
) {
    if (!LibraryConfig.showInsights) return
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        LibraryConfig.cards.toList().forEach { (id, on) ->
            if (!on) return@forEach
            when (id) {
                "suggested" -> {
                    // With the Suggestions box on, the first box does this job.
                    if (!LibraryConfig.suggestBox) SuggestedCard(Usage.suggestions(apps, 5), onLaunch, onMenu)
                }
                "pills" -> QuickPills(apps)
                "stats" -> InsightCard("Your stats", "Kept on this phone only", id) { StatsBody(apps) }
                "recent" -> {
                    val list = apps.filter { it.firstInstall > 0 }.sortedByDescending { it.firstInstall }.take(5)
                    if (list.isNotEmpty()) InsightCard("Recently added", null, id) { AppsRow(list, onLaunch, onMenu) }
                }
                "unused" -> {
                    val list = Usage.unused(apps, 30, 4)
                    if (list.isNotEmpty() && Usage.spanDays() >= 7) {
                        InsightCard("Not opened lately", "Not opened here in a month. Hide to tidy up.", id) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                list.forEach { app ->
                                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                        Image(bitmap = app.icon, contentDescription = null, modifier = Modifier.size(44.dp).scaledIcon(app.iconScale))
                                        Text(
                                            app.label, color = Eon.DSoft, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.padding(top = 4.dp),
                                        )
                                        Text(
                                            "Hide", color = Eon.DAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                                            modifier = Modifier.clip(CircleShape).clickable { onHideApp(app) }
                                                .padding(horizontal = 10.dp, vertical = 4.dp),
                                        )
                                    }
                                }
                                repeat(4 - list.size) { Spacer(Modifier.weight(1f)) }
                            }
                        }
                    }
                }
                "notifs" -> {
                    val list = apps.filter { (Badges.counts[it.packageName] ?: 0) > 0 }
                        .sortedByDescending { Badges.counts[it.packageName] ?: 0 }.take(5)
                    if (list.isNotEmpty()) {
                        InsightCard("Waiting for you", "Apps with something new", id) { AppsRow(list, onLaunch, onMenu) }
                    }
                }
            }
        }
    }
}

@Composable
private fun InsightCard(title: String, subtitle: String?, id: String, content: @Composable () -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    Column(
        Modifier.fillMaxWidth().clip(shape).background(Color(0x1AFFFFFF)).border(1.dp, Color(0x2EFFFFFF), shape)
            .padding(start = 14.dp, end = 14.dp, top = 12.dp, bottom = 12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    title.uppercase(), color = Eon.DText.copy(alpha = 0.85f), fontSize = 11.sp, fontWeight = FontWeight.SemiBold,
                    letterSpacing = 0.8.sp,
                )
                if (subtitle != null) Text(subtitle, color = Eon.DMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
            }
            Text(
                "Hide", color = Eon.DText.copy(alpha = 0.7f), fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clip(CircleShape).clickable { LibraryConfig.setCard(id, false) }
                    .padding(horizontal = 6.dp, vertical = 2.dp),
            )
        }
        Spacer(Modifier.height(10.dp))
        content()
    }
}

/** "Around this time you open": the apps Eon thinks you want now, on a card washed with cyan, violet and pink. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun SuggestedCard(list: List<AppEntry>, onLaunch: (AppEntry) -> Unit, onMenu: (AppEntry) -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    Column(
        Modifier.fillMaxWidth().clip(shape)
            .background(
                Brush.linearGradient(
                    0f to Color(0x3335D6F0), 0.55f to Color(0x2E9B7BFF), 1f to Color(0x2EF25CCB),
                ),
            )
            .border(1.dp, Color(0x33FFFFFF), shape)
            .padding(start = 14.dp, end = 14.dp, top = 12.dp, bottom = 10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(
                Modifier.size(8.dp).clip(CircleShape)
                    .background(Brush.horizontalGradient(listOf(Color(0xFF35D6F0), Color(0xFFF25CCB)))),
            )
            Text(
                "AROUND THIS TIME YOU OPEN", color = Eon.DText.copy(alpha = 0.85f), fontSize = 11.sp, fontWeight = FontWeight.SemiBold,
                letterSpacing = 0.8.sp, modifier = Modifier.weight(1f),
            )
            Text(
                "Hide", color = Eon.DText.copy(alpha = 0.7f), fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clip(CircleShape).clickable { LibraryConfig.setCard("suggested", false) }
                    .padding(horizontal = 6.dp, vertical = 2.dp),
            )
        }
        if (list.isEmpty()) {
            Text(
                "Open a few apps and Eon will start suggesting the ones you use at this time of day.",
                color = Eon.DMuted, fontSize = 13.sp, lineHeight = 18.sp, modifier = Modifier.padding(bottom = 4.dp),
            )
        } else {
            AppsRow(list, onLaunch, onMenu)
        }
    }
}

/** The small facts under the suggestions: how many apps are waiting, time on screen today, apps new this week. */
@Composable
private fun QuickPills(apps: List<AppEntry>) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val waiting = apps.count { (Badges.counts[it.packageName] ?: 0) > 0 }
    val fresh = apps.count { it.firstInstall > System.currentTimeMillis() - 7 * DAY }
    Row(Modifier.fillMaxWidth().libFadeEnd().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        if (waiting > 0) FactPill("$waiting waiting", Color(0xFFF25CCB), null)
        if (ScreenTime.granted) {
            FactPill("${ScreenTime.format(ScreenTime.total)} today", Color(0xFF35D6F0), null)
        } else {
            FactPill("Show screen time", Color(0xFF35D6F0)) { ScreenTime.openSettings(ctx) }
        }
        if (fresh > 0) FactPill("$fresh new this week", Color(0xFFFFA63D), null)
    }
}

@Composable
private fun FactPill(text: String, dot: Color, onClick: (() -> Unit)?) {
    val shape = LibStyle.chip()
    Row(
        Modifier.height(34.dp).libGlass(shape)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(start = 10.dp, end = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(dot))
        Text(text, color = LibStyle.ink, fontSize = 13.sp, maxLines = 1)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppsRow(list: List<AppEntry>, onLaunch: (AppEntry) -> Unit, onMenu: (AppEntry) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        list.forEach { app ->
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(14.dp))
                    .combinedClickable(onClick = { onLaunch(app) }, onLongClick = { onMenu(app) })
                    .padding(vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Image(bitmap = app.icon, contentDescription = app.label, modifier = Modifier.size(46.dp).scaledIcon(app.iconScale))
                Text(
                    app.label, color = Eon.DText.copy(alpha = 0.9f), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center, modifier = Modifier.padding(top = 4.dp),
                )
            }
        }
        repeat(5 - list.size) { Spacer(Modifier.weight(1f)) }
    }
}

@Composable
private fun StatsBody(apps: List<AppEntry>) {
    val week = Usage.total(7)
    val top = Usage.top(30, apps)
    val days = Usage.perDay(7)
    val biggest = max(1, days.maxOrNull() ?: 1)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        StatBlock("${apps.size}", "apps", Modifier.weight(1f))
        StatBlock("$week", "opens this week", Modifier.weight(1f))
        StatBlock(top?.first?.label ?: "none yet", "most opened", Modifier.weight(1f))
    }
    Spacer(Modifier.height(14.dp))
    val cal = Calendar.getInstance()
    val letters = "SMTWTFS"
    Row(Modifier.fillMaxWidth().height(70.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.Bottom) {
        days.forEachIndexed { i, n ->
            cal.timeInMillis = System.currentTimeMillis() - (6 - i) * DAY
            val letter = letters[cal.get(Calendar.DAY_OF_WEEK) - 1]
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.BottomCenter) {
                    Box(
                        Modifier.fillMaxWidth(0.55f).height((6 + 40 * n / biggest.toFloat()).dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (n > 0) Eon.Button else androidx.compose.ui.graphics.SolidColor(Color(0x22FFFFFF))),
                    )
                }
                Text(letter.toString(), color = Eon.DFaint, fontSize = 10.sp, modifier = Modifier.padding(top = 4.dp))
            }
        }
    }
}

@Composable
private fun StatBlock(value: String, label: String, modifier: Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(16.dp)).background(Color(0x1AFFFFFF)).padding(vertical = 10.dp, horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(value, color = Eon.DText, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(label, color = Eon.DMuted, fontSize = 11.sp, maxLines = 1, textAlign = TextAlign.Center)
    }
}

/** Settings for the App Library, in five tabs: Presets, Look, Layout, Content and Motion. */
@Composable
fun LibraryCustomizeDialog(onOrganize: () -> Int, onDismiss: () -> Unit, onIosShape: () -> Unit = {}) {
    var tab by remember { mutableStateOf(0) }
    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier.fillMaxWidth().heightIn(max = 640.dp).glassDark(RoundedCornerShape(28.dp)).padding(top = 18.dp, start = 18.dp, end = 18.dp, bottom = 14.dp),
        ) {
            Text("Customize Library", color = Eon.DText, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            // The tab names, always in view while the page below scrolls.
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Presets", "Look", "Layout", "Content", "Motion").forEachIndexed { i, name ->
                    val on = tab == i
                    Box(
                        Modifier.clip(CircleShape)
                            .background(if (on) Eon.DAccent.copy(alpha = 0.26f) else Color(0x14FFFFFF))
                            .border(1.dp, if (on) Eon.DAccent else Color(0x1FFFFFFF), CircleShape)
                            .clickable { tab = i }.padding(horizontal = 14.dp, vertical = 8.dp),
                    ) { Text(name, color = if (on) Eon.DAccent else Eon.DText, fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
                }
            }
            Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()).padding(top = 4.dp)) {
                when (tab) {
                    0 -> LibTabPresets(onIosShape)
                    1 -> LibTabLook()
                    2 -> LibTabLayout()
                    3 -> LibTabContent(onOrganize)
                    else -> LibTabMotion()
                }
            }
            Spacer(Modifier.height(10.dp))
            Box(Modifier.align(Alignment.End).clip(CircleShape).background(Eon.Button).clickable(onClick = onDismiss).padding(horizontal = 24.dp, vertical = 10.dp)) {
                Text("Done", color = Eon.OnAccent, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun LibGap() { Spacer(Modifier.height(12.dp)) }

@Composable
private fun LibHeading(title: String, sub: String) {
    Text(title, color = Eon.DText, fontSize = 15.sp, fontWeight = FontWeight.Medium)
    Text(sub, color = Eon.DSoft, fontSize = 12.sp)
}

@Composable
private fun LibTabPresets(onIosShape: () -> Unit) {
    var note by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    val clip = androidx.compose.ui.platform.LocalClipboardManager.current
    LibSectionTitle("Presets")
    LibHeading("Ready-made looks", "One tap sets the look and the extras together. Your boxes, their order and colours stay as they are")
    val pickPreset: (Int) -> Unit = { i ->
        LibraryConfig.applyPreset(i)
        if (LibraryConfig.presetSetsShape(i)) onIosShape()
        note = "${LibraryConfig.presetNames[i]} applied."
    }
    ChoiceChips(LibraryConfig.presetNames.take(3), -1) { pickPreset(it) }
    ChoiceChips(LibraryConfig.presetNames.drop(3), -1) { pickPreset(it + 3) }
    Text("iOS also sets the icon shape to Squircle (Settings > Drawer > Icons changes it back).", color = Eon.DMuted, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))

    LibSectionTitle("My looks")
    LibHeading("Keep what you made", "Saves the glass, spacing, labels and motion as they are now. Boxes and their order are not part of a look")
    Spacer(Modifier.height(8.dp))
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        androidx.compose.foundation.text.BasicTextField(
            value = name, onValueChange = { name = it.take(24) }, singleLine = true,
            textStyle = androidx.compose.ui.text.TextStyle(color = Eon.DText, fontSize = 14.sp),
            cursorBrush = androidx.compose.ui.graphics.SolidColor(Eon.DAccent),
            modifier = Modifier.weight(1f),
            decorationBox = { inner ->
                Box(
                    Modifier.fillMaxWidth().height(42.dp).clip(RoundedCornerShape(14.dp)).background(Color(0x1AFFFFFF)).padding(horizontal = 14.dp),
                    contentAlignment = Alignment.CenterStart,
                ) {
                    if (name.isEmpty()) Text("Name, for example Night", color = Eon.DFaint, fontSize = 14.sp)
                    inner()
                }
            },
        )
        DialogChip("Save", Modifier.width(84.dp)) {
            LibraryConfig.saveLook(name)
            note = "Saved \"" + (name.trim().take(24).ifEmpty { "My look ${LibraryConfig.saved.size}" }) + "\"."
            name = ""
        }
    }
    LibraryConfig.saved.toList().forEachIndexed { i, (n, d) ->
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(n, color = Eon.DText, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f).padding(start = 4.dp))
            DialogChip("Use", Modifier.width(60.dp)) { note = if (LibraryConfig.useLook(i)) "\"$n\" applied." else "That look could not be read." }
            DialogChip("Share", Modifier.width(68.dp)) {
                clip.setText(androidx.compose.ui.text.AnnotatedString(LibraryConfig.lookCode(d)))
                note = "Code of \"$n\" copied. Paste it in a message."
            }
            DialogChip("Delete", Modifier.width(70.dp)) { LibraryConfig.deleteLook(i); note = "Deleted \"$n\"." }
        }
    }
    LibGap()
    LibHeading("Use a look from a code", "Copy a code someone sent you, then tap below")
    Spacer(Modifier.height(8.dp))
    DialogChip("Paste code and use it", Modifier.fillMaxWidth()) {
        val code = clip.getText()?.text.orEmpty()
        val look = LibraryConfig.readCode(code)
        note = when {
            look == null -> "No Eon look code found in the clipboard."
            LibraryConfig.applySnapshot(look) -> "Look applied. Save it above to keep it."
            else -> "That code could not be read."
        }
    }
    if (note.isNotEmpty()) Text(note, color = Eon.DAccent, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp, start = 4.dp))
}

@Composable
private fun LibTabLook() {
    LibSectionTitle("Glass")
    Spacer(Modifier.height(8.dp))
    LibHeading("Material", "Frosted: one neutral glass. Clear: more wallpaper shows through. Tinted: a wash of each box's colour. Flat: a solid colour")
    ChoiceChips(LibraryConfig.materialNames, LibraryConfig.material) { LibraryConfig.chooseMaterial(it) }
    Spacer(Modifier.height(8.dp))
    LibSlider("Blur", if (BlurConfig.amount == 0) "Off" else "${BlurConfig.amount}%", BlurConfig.amount.toFloat(), 0f..100f, { BlurConfig.set(it.roundToInt()) }, {})
    LibBlurNote(Modifier.padding(bottom = 4.dp))
    LibSlider("Dim", "${(DrawerConfig.bgOpacity * 100).roundToInt()}%", DrawerConfig.bgOpacity, 0f..0.7f, { LibraryConfig.chooseDim(it) }, { LibraryConfig.saveDim() })
    Spacer(Modifier.height(4.dp))
    LibHeading(
        "Frost",
        if (LibraryConfig.frost == 0 && LibFrost.lum < 0f) "Auto picks light or dark cards from your wallpaper. Eon cannot read the system wallpaper, so Auto uses Light until you choose a picture in Settings > Wallpaper"
        else "Auto picks light or dark cards and names from how bright your wallpaper is",
    )
    ChoiceChips(LibraryConfig.frostNames, LibraryConfig.frost) { LibraryConfig.chooseFrost(it) }
    LibGap()
    SwitchLine("Bright top edge", "A light line along the top of each card that fades away down the sides", LibraryConfig.glassTop) { v -> LibraryConfig.update { LibraryConfig.glassTop = v } }
    LibGap()
    SwitchLine("Darker bottom band", "A faint shade along the bottom of each card", LibraryConfig.glassShade) { v -> LibraryConfig.update { LibraryConfig.glassShade = v } }
    LibGap()
    SwitchLine("Soft shadow", "Lifts the cards off the wallpaper. Left out in Battery Saver", LibraryConfig.glassShadow) { v -> LibraryConfig.update { LibraryConfig.glassShadow = v } }
    LibGap()
    SwitchLine("Grain", "A touch of noise so the gradients do not show bands", LibraryConfig.grain) { v -> LibraryConfig.update { LibraryConfig.grain = v } }
    LibGap()
    SwitchLine("Soft edges", "Boxes fade out under the search pill and at the bottom", LibraryConfig.edgeFade) { v -> LibraryConfig.update { LibraryConfig.edgeFade = v } }
    LibGap()
    SwitchLine("Blur the home screen", "Behind the Library (Android 12 and newer)", LibraryConfig.homeBlur) { LibraryConfig.chooseHomeBlur(it) }
    LibSectionTitle("Details")
    Spacer(Modifier.height(8.dp))
    SwitchLine("Capsule search pill", "Same glass as the cards, \"App Library\", lined up with the cards", LibraryConfig.iosPill) { v -> LibraryConfig.update { LibraryConfig.iosPill = v } }
    LibGap()
    SwitchLine("Colour every box", "Each box gets a wash of its own colour. Off: all boxes are the same frosted glass", LibraryConfig.tintCards) { v -> LibraryConfig.update { LibraryConfig.tintCards = v } }
    LibGap()
    SwitchLine("Tint Flat boxes", "A soft wash of each box's colour in the Flat look", LibraryConfig.flatTint) { v -> LibraryConfig.update { LibraryConfig.flatTint = v } }
    LibGap()
    LibHeading("Under the +N icons", "The four small icons sit straight on the card, or on a small glass tile")
    ChoiceChips(listOf("Nothing", "Subtle tile"), LibraryConfig.clusterPlate) { v -> LibraryConfig.update { LibraryConfig.clusterPlate = v } }
    LibGap()
    LibHeading("Style", "Glass: blurred and see-through. Flat: a solid colour you choose (Settings > Drawer)")
    ChoiceChips(LibraryConfig.styleNames, LibraryConfig.style) { LibraryConfig.chooseStyle(it) }
}

@Composable
private fun LibTabLayout() {
    LibSectionTitle("Boxes")
    Spacer(Modifier.height(8.dp))
    LibHeading("Boxes per row", "Two big boxes or three small ones")
    ChoiceChips(listOf("2", "3"), DrawerConfig.libColumns - 2) { LibraryConfig.chooseColumns(it + 2) }
    Spacer(Modifier.height(8.dp))
    LibSlider("Side margin", "${LibraryConfig.sideMargin} dp", LibraryConfig.sideMargin.toFloat(), 8f..40f, { LibraryConfig.sideMargin = it.roundToInt() }, { LibraryConfig.save() })
    LibSlider("Gap between boxes", "${LibraryConfig.colGap} dp", LibraryConfig.colGap.toFloat(), 4f..32f, { LibraryConfig.colGap = it.roundToInt() }, { LibraryConfig.save() })
    LibSlider("Gap between rows", "${LibraryConfig.rowGap} dp", LibraryConfig.rowGap.toFloat(), 4f..40f, { LibraryConfig.rowGap = it.roundToInt() }, { LibraryConfig.save() })
    LibSectionTitle("Names")
    Spacer(Modifier.height(8.dp))
    LibSlider("Name size", "${LibraryConfig.labelSize} sp", LibraryConfig.labelSize.toFloat(), 9f..16f, { LibraryConfig.labelSize = it.roundToInt() }, { LibraryConfig.save() })
    LibSlider("Space above the name", "${LibraryConfig.nameGap} dp", LibraryConfig.nameGap.toFloat(), 0f..16f, { LibraryConfig.nameGap = it.roundToInt() }, { LibraryConfig.save() })
    SwitchLine("Bold names", "A little heavier than the iOS look", LibraryConfig.labelBold) { v -> LibraryConfig.update { LibraryConfig.labelBold = v } }
    LibGap()
    SwitchLine("App count chip", "The number of apps as a small chip by the name", LibraryConfig.countChip) { v -> LibraryConfig.update { LibraryConfig.countChip = v } }
    LibSectionTitle("Extras")
    Spacer(Modifier.height(8.dp))
    SwitchLine("Dot on the icon", "Notifications show as a dot on the app, not a number on the box", LibraryConfig.badgeDots) { v -> LibraryConfig.update { LibraryConfig.badgeDots = v } }
    LibGap()
    SwitchLine("Tidy +N tile", "The tile with the rest of the apps looks like one more icon", LibraryConfig.tidyCluster) { v -> LibraryConfig.update { LibraryConfig.tidyCluster = v } }
    LibGap()
    SwitchLine("New box tile", "Fills the empty spot at the end of an odd row", LibraryConfig.fillGap) { v -> LibraryConfig.update { LibraryConfig.fillGap = v } }
    LibGap()
    SwitchLine("Bottom bar", "Library, A–Z and Arrange in one small bar", LibraryConfig.bottomBar) { v -> LibraryConfig.update { LibraryConfig.bottomBar = v } }
    Spacer(Modifier.height(14.dp))
    DialogChip("Reset layout", Modifier.fillMaxWidth()) { LibraryConfig.resetLayout() }
}

@Composable
private fun LibTabContent(onOrganize: () -> Int) {
    var note by remember { mutableStateOf("") }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    LibSectionTitle("Boxes")
    Spacer(Modifier.height(8.dp))
    SwitchLine("Suggestions box", "Apps you open around now, as the first box", LibraryConfig.suggestBox) { LibraryConfig.chooseSuggestBox(it) }
    LibGap()
    SwitchLine("Slim rows", "Suggestions and Recently added as strips of icons, not boxes", LibraryConfig.quickRows) { v -> LibraryConfig.update { LibraryConfig.quickRows = v } }
    LibGap()
    SwitchLine("Each app once", "An app shows in the first of your boxes that holds it", LibraryConfig.uniqueApps) { v -> LibraryConfig.update { LibraryConfig.uniqueApps = v } }
    LibGap()
    SwitchLine("Smart box order", "Boxes you open most come first", LibraryConfig.smartBoxes) { LibraryConfig.chooseSmartBoxes(it) }
    LibGap()
    SwitchLine("Show hidden boxes", "Boxes you hid from their menu, until you switch this off", LibraryConfig.showHiddenBoxes) { v -> LibraryConfig.showHiddenBoxes = v }
    LibSectionTitle("Insights")
    Spacer(Modifier.height(8.dp))
    SwitchLine("Insights", "Cards above your boxes", LibraryConfig.showInsights) { LibraryConfig.chooseInsights(it) }
    if (LibraryConfig.showInsights) {
        LibraryConfig.cards.toList().forEachIndexed { i, (id, on) ->
            val name = INSIGHT_CARDS.firstOrNull { it.first == id }?.second ?: id
            Row(
                Modifier.fillMaxWidth().padding(start = 8.dp, top = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(name, color = if (on) Eon.DText else Eon.DFaint, fontSize = 14.sp, modifier = Modifier.weight(1f))
                MiniArrow(Icons.Outlined.ArrowUpward, i > 0) { LibraryConfig.moveCard(id, -1) }
                MiniArrow(Icons.Outlined.ArrowDownward, i < LibraryConfig.cards.size - 1) { LibraryConfig.moveCard(id, 1) }
                Spacer(Modifier.width(8.dp))
                EonSwitch(on) { LibraryConfig.setCard(id, it) }
            }
        }
    }
    Spacer(Modifier.height(14.dp))
    if (!ScreenTime.granted) {
        // Time on screen shows in each box once Eon is switched on in Android's Usage access.
        DialogChip("Show screen time in boxes", Modifier.fillMaxWidth()) { ScreenTime.openSettings(ctx) }
        Spacer(Modifier.height(8.dp))
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        DialogChip("Organize boxes", Modifier.weight(1f)) {
            val n = onOrganize()
            note = if (n == 0) "Everything fits your boxes already." else "Added $n new box" + (if (n == 1) "." else "es.")
        }
        DialogChip("Clear my usage", Modifier.weight(1f)) {
            Usage.clear()
            note = "Usage cleared."
        }
    }
    if (note.isNotEmpty()) Text(note, color = Eon.DAccent, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp, start = 4.dp))
}

@Composable
private fun LibTabMotion() {
    LibSectionTitle("Motion")
    Spacer(Modifier.height(8.dp))
    LibHeading("How boxes arrive", "Calm: a gentle rise. Lively: quicker, with a little spring. Instant: no animation")
    ChoiceChips(LibraryConfig.motionNames, LibraryConfig.motion) { v -> LibraryConfig.update { LibraryConfig.motion = v } }
    LibGap()
    SwitchLine("Ease boxes in", "Boxes slide in one after another when it opens", LibraryConfig.stagger) { v -> LibraryConfig.update { LibraryConfig.stagger = v } }
    LibSectionTitle("Behaviour")
    Spacer(Modifier.height(8.dp))
    SwitchLine("Tap opens the box", "Icons on the boxes stop launching: every tap opens the box", LibraryConfig.openOnly) { LibraryConfig.chooseOpenOnly(it) }
    LibGap()
    LibHeading("Opened box", "A sheet from the bottom, a dimmed full page, or exactly like a folder on the home screen")
    ChoiceChips(listOf("Sheet", "Full page", "Like home"), LibraryConfig.boxPage) { LibraryConfig.chooseBoxPage(it) }
    LibGap()
    LibHeading("Swipe up to open", "How easily a swipe up on the home screen opens the Library")
    ChoiceChips(listOf("Relaxed", "Normal", "Eager"), LibraryConfig.swipeFeel) { LibraryConfig.chooseSwipeFeel(it) }
    Spacer(Modifier.height(14.dp))
    DialogChip("Reset motion", Modifier.fillMaxWidth()) { LibraryConfig.resetMotion() }
}

@Composable
private fun SwitchLine(title: String, sub: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Eon.DText, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text(sub, color = Eon.DMuted, fontSize = 12.sp)
        }
        EonSwitch(on, onChange)
    }
}

@Composable
private fun MiniArrow(icon: androidx.compose.ui.graphics.vector.ImageVector, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(32.dp).clip(CircleShape).then(if (enabled) Modifier.clickable(onClick = onClick) else Modifier),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, null, tint = if (enabled) Eon.DSoft else Color(0xFF3A3A3E), modifier = Modifier.size(18.dp)) }
}

@Composable
private fun DialogChip(label: String, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.clip(RoundedCornerShape(14.dp)).background(Color(0x22FFFFFF)).clickable(onClick = onClick).padding(vertical = 12.dp),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = Eon.DSoft, fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
}


/** A row of equal pill choices; the picked one is outlined in the accent colour. */
@Composable
internal fun ChoiceChips(labels: List<String>, selected: Int, onPick: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        labels.forEachIndexed { i, label ->
            val on = selected == i
            val chip = RoundedCornerShape(19.dp)
            Box(
                Modifier.weight(1f).height(38.dp).clip(chip)
                    .background(if (on) Eon.DAccent.copy(alpha = 0.26f) else Color(0x1AFFFFFF))
                    .border(1.dp, if (on) Eon.DAccent else Color(0x29FFFFFF), chip)
                    .clickable { onPick(i) },
                contentAlignment = Alignment.Center,
            ) { Text(label, color = if (on) Eon.DAccent else Eon.DText, fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
        }
    }
}
