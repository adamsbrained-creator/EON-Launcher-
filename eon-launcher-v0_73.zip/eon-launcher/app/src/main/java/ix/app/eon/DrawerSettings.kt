package ix.app.eon

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Replay
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asComposePath
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

/**
 * Settings > Drawer. A live preview stays at the top while you change things below it.
 * The bar style and the App Library each get their own section, shown for the style you use.
 */
@Composable
fun DrawerSettingsScreen(state: EonState, onBack: () -> Unit) {
    BackHandler { onBack() }
    val cfg = DrawerConfig
    val library = state.drawerStyle == "library"
    fun changed() = state.saveDrawer()

    Column(
        Modifier.fillMaxSize().background(Eon.Page).systemBarsPadding().padding(horizontal = 20.dp),
    ) {
        Gap(12)
        PageHeader("Drawer", onBack)
        Gap(14)
        DrawerPreview(library)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            Gap(16)
            SettingsSectionLabel("STYLE")
            DsChips(listOf("Bar", "Library"), if (library) 1 else 0) {
                state.chooseDrawerStyle(if (it == 1) "library" else "bar")
            }
            Gap(12)
            Text("Presets", color = Eon.Muted, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
            DsChips(DRAWER_PRESETS.map { it.name }, -1) {
                cfg.applyPreset(DRAWER_PRESETS[it])
                changed()
            }

            Gap(20)
            SettingsSectionLabel("BACKGROUND")
            DsColor("Colour", cfg.bgColor, Color.Black) { cfg.bgColor = it; changed() }
            DsSlider("Opacity", "${(cfg.bgOpacity * 100).roundToInt()}%", cfg.bgOpacity, 0f..1f, {
                cfg.bgOpacity = (it * 100).roundToInt() / 100f
                changed()
            }) { cfg.bgOpacity = 0.65f; changed() }
            DsToggle("Fade from top to bottom", "Lighter at the top, stronger behind the apps", cfg.bgGradient) {
                cfg.bgGradient = it
                changed()
            }

            Gap(16)
            SettingsSectionLabel("APPS AND LABELS")
            DsColor("Text colour", cfg.textColor, Color(0xFFF5F5F6)) { cfg.textColor = it; changed() }
            DsSlider("Icon size", "${cfg.iconDp} dp", cfg.iconDp.toFloat(), 44f..88f, {
                cfg.iconDp = it.roundToInt()
                changed()
            }) { cfg.iconDp = 68; changed() }
            DsToggle("Fit the grid to the apps", "Few apps get bigger icons, many apps get more columns, so they all fit", cfg.autoFit) {
                cfg.autoFit = it
                changed()
            }
            if (!cfg.autoFit) {
                DsStepper(
                    "Columns", "${cfg.columns}",
                    { cfg.columns = (cfg.columns - 1).coerceAtLeast(3); changed() },
                    { cfg.columns = (cfg.columns + 1).coerceAtMost(6); changed() },
                )
            }
            DsSlider("Row spacing", "${cfg.rowGap} dp", cfg.rowGap.toFloat(), 0f..32f, {
                cfg.rowGap = it.roundToInt()
                changed()
            }) { cfg.rowGap = 14; changed() }
            DsToggle("Show labels", "The app's name under its icon", cfg.showLabels) { cfg.showLabels = it; changed() }
            DsToggle("Custom padding", "Set the space around the apps yourself", cfg.customPadding) {
                cfg.customPadding = it
                changed()
            }
            if (cfg.customPadding) {
                DsSlider("Side padding", "${cfg.padSide} dp", cfg.padSide.toFloat(), 0f..40f, {
                    cfg.padSide = it.roundToInt(); changed()
                }) { cfg.padSide = 14; changed() }
                DsSlider("Top padding", "${cfg.padTop} dp", cfg.padTop.toFloat(), 0f..60f, {
                    cfg.padTop = it.roundToInt(); changed()
                }) { cfg.padTop = 12; changed() }
                DsSlider("Bottom padding", "${cfg.padBottom} dp", cfg.padBottom.toFloat(), 0f..60f, {
                    cfg.padBottom = it.roundToInt(); changed()
                }) { cfg.padBottom = 20; changed() }
            }
            if (cfg.showLabels) {
                DsSlider("Label size", "${cfg.labelSp.roundToInt()} pt", cfg.labelSp, 9f..16f, {
                    cfg.labelSp = it.roundToInt().toFloat()
                    changed()
                }) { cfg.labelSp = 12f; changed() }
                DsToggle("Allow two-line labels", "Let long names use two lines", cfg.twoLine) { cfg.twoLine = it; changed() }
            }

            if (!library) {
                Gap(16)
                SettingsSectionLabel("CATEGORY BAR")
                DsToggle("Show the category bar", "Turn it off for a plain list of apps", cfg.showBar) { cfg.showBar = it; changed() }
                Text("Category transition", color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp, top = 6.dp, bottom = 8.dp))
                DsChips(DRAWER_TRANSITIONS, cfg.transition) { cfg.transition = it; changed() }
                Gap(6)
                DsSlider("Height of the apps", "${cfg.panelPct}%", cfg.panelPct.toFloat(), 30f..75f, {
                    cfg.panelPct = it.roundToInt()
                    changed()
                }) { cfg.panelPct = 50; changed() }
                DsToggle("Show category title", null, cfg.showTitle) { cfg.showTitle = it; changed() }
                if (cfg.showTitle) {
                    DsSlider("Title size", "${cfg.titleSp} sp", cfg.titleSp.toFloat(), 18f..40f, {
                        cfg.titleSp = it.roundToInt()
                        changed()
                    }) { cfg.titleSp = 28; changed() }
                    DsToggle("Centre the title", null, cfg.titleCenter) { cfg.titleCenter = it; changed() }
                }
                DsSlider("Bar icon size", "${cfg.barIconDp} dp", cfg.barIconDp.toFloat(), 18f..32f, {
                    cfg.barIconDp = it.roundToInt()
                    changed()
                }) { cfg.barIconDp = 24; changed() }
                DsToggle("Pill background", "Put the category icons in a rounded glass bar", cfg.barPill) {
                    cfg.barPill = it
                    changed()
                }
                DsColor("Selected icon colour", cfg.accentColor, Color.White) { cfg.accentColor = it; changed() }
                DsToggle("Selected marker", "The small bar under the icon you are on", cfg.barIndicator) {
                    cfg.barIndicator = it
                    changed()
                }
                DsToggle("Swipe between categories", "Swipe the apps sideways to change category", cfg.swipeCategories) {
                    cfg.swipeCategories = it
                    changed()
                }
            } else {
                Gap(16)
                SettingsSectionLabel("APP LIBRARY")
                DsStepper(
                    "Folders per row", "${cfg.libColumns}",
                    { cfg.libColumns = (cfg.libColumns - 1).coerceAtLeast(2); changed() },
                    { cfg.libColumns = (cfg.libColumns + 1).coerceAtMost(3); changed() },
                )
                DsColor("Folder colour", cfg.tileColor, Color.White) { cfg.tileColor = it; changed() }
                DsSlider("Folder opacity", "${(cfg.tileOpacity * 100).roundToInt()}%", cfg.tileOpacity, 0f..0.8f, {
                    cfg.tileOpacity = (it * 100).roundToInt() / 100f
                    changed()
                }) { cfg.tileOpacity = 0.22f; changed() }
                DsSlider("Folder corners", "${cfg.tileRadius} dp", cfg.tileRadius.toFloat(), 8f..40f, {
                    cfg.tileRadius = it.roundToInt()
                    changed()
                }) { cfg.tileRadius = 28; changed() }
                DsToggle("Folder outline", "A thin line around each folder", cfg.tileBorder) { cfg.tileBorder = it; changed() }
                DsToggle("Recently added folder", "The newest apps, first in the list", cfg.showRecent) { cfg.showRecent = it; changed() }
                DsToggle("Other apps folder", "Apps that none of your categories hold", cfg.showOther) { cfg.showOther = it; changed() }
                DsToggle(
                    "Open apps from a folder", "Tap a big icon on a folder to launch the app. Off: a tap opens the folder, so a slip while scrolling never starts an app",
                    cfg.libDirectLaunch,
                ) { cfg.libDirectLaunch = it; changed() }
            }

            Gap(16)
            SettingsSectionLabel("SWIPES")
            DsToggle(
                "Swipe up goes home", "Swipe up in the drawer to close it, and swipe down on the home screen to open it. Replaces the home swipe-down gesture while on",
                cfg.swipeUpHome,
            ) { cfg.swipeUpHome = it; changed() }
            DsToggle(
                "Pull down at the top goes home", "When a list is already at its top, pull down a little more and the drawer closes",
                cfg.pullDownHome,
            ) { cfg.pullDownHome = it; changed() }

            Gap(16)
            SettingsSectionLabel("SORT AND SEARCH")
            Text("Order of apps", color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
            DsChips(DRAWER_SORTS, cfg.sort) { cfg.sort = it; changed() }
            Gap(6)
            DsToggle("Open the keyboard with the drawer", "Start typing to search straight away", cfg.autoKeyboard) {
                cfg.autoKeyboard = it
                changed()
            }

            Gap(16)
            SettingsSectionLabel("ICON SHAPE")
            ShapeGrid(state.iconShape) { state.chooseIconShape(it) }

            Gap(16)
            SettingsSectionLabel("ICON STYLE")
            DsChips(ICON_STYLES, state.iconStyle) { state.chooseIconStyle(it, state.iconTint) }
            if (state.iconStyle != 0 && state.iconStyle != 3) {
                Gap(10)
                Text("Colour", color = Eon.Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    ICON_TINTS.forEach { c ->
                        val on = state.iconTint == c
                        Box(
                            Modifier.size(28.dp).clip(CircleShape)
                                .background(if (c == 0) Eon.Button else androidx.compose.ui.graphics.SolidColor(Color(c)))
                                .border(if (on) 2.dp else 0.dp, if (on) Eon.Text else Color.Transparent, CircleShape)
                                .clickable { state.chooseIconStyle(state.iconStyle, c) },
                            contentAlignment = Alignment.Center,
                        ) { if (c == 0) Text("W", color = Eon.OnAccent, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold) }
                    }
                }
                Text(
                    "The first circle takes the colour from your wallpaper. Icons from an icon pack, or ones you chose yourself, are left as they are.",
                    color = Eon.Faint, fontSize = 12.sp, modifier = Modifier.padding(start = 4.dp, top = 8.dp),
                )
            }

            Gap(16)
            var advanced by rememberSaveable { mutableStateOf(false) }
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { advanced = !advanced }.padding(horizontal = 4.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("ADVANCED", color = Eon.Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, modifier = Modifier.weight(1f))
                Text(if (advanced) "Hide" else "Show", color = Eon.Soft, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
            if (advanced) {
                DsToggle("Search apps by index", "A to Z strip at the edge (name order only)", cfg.searchIndex) { cfg.searchIndex = it; changed() }
                DsToggle("Hide Play Store icon", null, cfg.hidePlayStore) { cfg.hidePlayStore = it; changed() }
                DsToggle("Hide icon packs", "Apps that only hold icons or themes", cfg.hideIconPacks) { cfg.hideIconPacks = it; changed() }
                DsToggle("Move icons down", "Short lists sit at the bottom, near your thumb", cfg.moveDown) { cfg.moveDown = it; changed() }
                DsToggle("Stack apps from the bottom", "The list starts at the bottom edge", cfg.stackBottom) { cfg.stackBottom = it; changed() }
                DsToggle("Close the drawer after launching", null, cfg.closeAfterLaunch) { cfg.closeAfterLaunch = it; changed() }
            }

            Gap(20)
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Eon.P1)
                    .border(1.dp, Eon.P2, RoundedCornerShape(16.dp))
                    .clickable { cfg.reset(); changed() }.padding(vertical = 14.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text("Reset drawer settings", color = Eon.Danger, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
            Gap(28)
        }
    }
}

// ---- preview

private val MOCK_COLORS = listOf(Color(0xFFFF5C7A), Color(0xFF5C9DFF), Color(0xFF35D6F0), Color(0xFFFFA63D))

/** A small copy of the drawer on a made-up wallpaper, drawn from the current settings. */
@Composable
private fun DrawerPreview(library: Boolean) {
    val cfg = DrawerConfig
    Box(
        Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(22.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF2B5CFF), Color(0xFFF25CCB), Color(0xFFFFA63D))))
            .border(1.dp, Eon.P2, RoundedCornerShape(22.dp)),
    ) {
        Box(Modifier.matchParentSize().background(cfg.scrim()))
        if (library) {
            Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.fillMaxWidth().height(20.dp).clip(RoundedCornerShape(8.dp)).background(Eon.ov(0x33)))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    repeat(cfg.libColumns) { n ->
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            val shape = RoundedCornerShape((cfg.tileRadius * 0.5f).dp)
                            Column(
                                Modifier.fillMaxWidth().height(if (cfg.libColumns == 2) 76.dp else 54.dp).clip(shape)
                                    .background(cfg.tileColor.copy(alpha = cfg.tileOpacity))
                                    .then(
                                        if (cfg.tileBorder) Modifier.border(1.dp, cfg.tileColor.copy(alpha = cfg.tileOpacity * 0.55f), shape)
                                        else Modifier,
                                    )
                                    .padding(8.dp),
                                verticalArrangement = Arrangement.spacedBy(5.dp),
                            ) {
                                for (r in 0..1) {
                                    Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                        for (c in 0..1) {
                                            Box(
                                                Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(5.dp))
                                                    .background(MOCK_COLORS[(r * 2 + c + n) % 4]),
                                            )
                                        }
                                    }
                                }
                            }
                            Text("Folder", color = cfg.textColor.copy(alpha = 0.85f), fontSize = 9.sp, modifier = Modifier.padding(top = 3.dp))
                        }
                    }
                }
            }
        } else {
            Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 10.dp)) {
                Spacer(Modifier.weight(1f))
                if (cfg.showTitle) {
                    Text(
                        "My Apps", color = cfg.textColor, fontSize = (cfg.titleSp * 0.55f).sp, fontWeight = FontWeight.Medium,
                        textAlign = if (cfg.titleCenter) TextAlign.Center else TextAlign.Start,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(Modifier.height(6.dp))
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    repeat(cfg.columns.coerceAtMost(6)) { i ->
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                Modifier.size((cfg.iconDp * 0.4f).dp).clip(RoundedCornerShape((cfg.iconDp * 0.1f).dp))
                                    .background(MOCK_COLORS[i % 4]),
                            )
                            if (cfg.showLabels) {
                                Text("App", color = cfg.textColor, fontSize = (cfg.labelSp * 0.6f).sp, modifier = Modifier.padding(top = 2.dp))
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(
                    Modifier.fillMaxWidth().then(
                        if (cfg.barPill) Modifier.clip(CircleShape).background(cfg.textColor.copy(alpha = 0.14f)).padding(vertical = 5.dp)
                        else Modifier,
                    ),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                ) {
                    repeat(5) { i ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                Modifier.size((cfg.barIconDp * 0.55f).dp).clip(CircleShape)
                                    .background(if (i == 2) cfg.accentColor else cfg.textColor.copy(alpha = 0.6f)),
                            )
                            if (cfg.barIndicator && i == 2) {
                                Box(Modifier.padding(top = 2.dp).size(width = 14.dp, height = 2.dp).clip(CircleShape).background(cfg.accentColor.copy(alpha = 0.4f)))
                            } else {
                                Spacer(Modifier.height(4.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---- icon shapes

private class IconPathShape(val index: Int) : androidx.compose.ui.graphics.Shape {
    override fun createOutline(
        size: androidx.compose.ui.geometry.Size,
        layoutDirection: androidx.compose.ui.unit.LayoutDirection,
        density: androidx.compose.ui.unit.Density,
    ): androidx.compose.ui.graphics.Outline =
        androidx.compose.ui.graphics.Outline.Generic(iconShapePath(index, size.width).asComposePath())
}

@Composable
private fun ShapeGrid(selected: Int, onPick: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ICON_SHAPES.chunked(4).forEachIndexed { r, row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEachIndexed { c, name ->
                    val i = r * 4 + c
                    val on = i == selected
                    Column(
                        Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).clickable { onPick(i) }.padding(vertical = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Box(
                            Modifier.size(52.dp).clip(IconPathShape(i))
                                .background(if (on) Eon.Button else androidx.compose.ui.graphics.SolidColor(Eon.P2)),
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(name, color = if (on) Eon.Text else Eon.Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
                repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

// ---- rows

@Composable
private fun DsToggle(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(horizontal = 4.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            if (subtitle != null) Text(subtitle, color = Eon.Muted, fontSize = 12.sp, lineHeight = 16.sp)
        }
        EonSwitch(checked, onChange)
    }
}

@Composable
private fun DsStepper(title: String, value: String, onMinus: () -> Unit, onPlus: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        DsStepButton("−", onMinus)
        Text(value, color = Eon.Text, fontSize = 16.sp, modifier = Modifier.width(56.dp), textAlign = TextAlign.Center)
        DsStepButton("+", onPlus)
    }
}

@Composable
private fun DsStepButton(label: String, onClick: () -> Unit) {
    Box(
        Modifier.size(width = 52.dp, height = 44.dp).clip(RoundedCornerShape(14.dp)).background(Eon.P1).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = Eon.Text, fontSize = 22.sp) }
}

@Composable
private fun DsSlider(
    title: String, valueText: String, value: Float, range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit, onReset: () -> Unit,
) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text(valueText, color = Eon.Muted, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(12.dp))
            Box(
                Modifier.size(36.dp).clip(RoundedCornerShape(12.dp)).background(Eon.P1).clickable(onClick = onReset),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Outlined.Replay, "Reset", tint = Eon.Soft, modifier = Modifier.size(18.dp)) }
        }
        DsSliderBar(value, range, onChange)
    }
}

@Composable
private fun DsSliderBar(value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Slider(
        value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange, valueRange = range,
        colors = SliderDefaults.colors(
            thumbColor = Color.White, activeTrackColor = Eon.Accent, inactiveTrackColor = Eon.ov(0x33),
        ),
    )
}

/** A row of pills; the chosen one is filled with the rainbow. Pass -1 when none is "chosen" (presets). */
@Composable
private fun DsChips(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        options.forEachIndexed { i, label ->
            val on = i == selected
            Box(
                Modifier.height(40.dp).clip(CircleShape).accentFill(on, Eon.P1)
                    .clickable { onSelect(i) }.padding(horizontal = 20.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(label, color = if (on) Eon.OnAccent else Eon.Text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

private val SWATCHES = listOf(
    Color.White, Color(0xFFF5F5F6), Color(0xFF8A8C93), Color.Black, Color(0xFF070B1F),
    Color(0xFF35D6F0), Color(0xFF4F8CFF), Color(0xFF9B7BFF), Color(0xFFF25CCB),
    Color(0xFFFF7A66), Color(0xFFFFA63D), Color(0xFFFFD23D), Color(0xFF4ADE80),
)

/** A colour: a row of swatches, and Custom for hue, saturation and brightness. */
@Composable
private fun DsColor(title: String, value: Color, default: Color, onChange: (Color) -> Unit) {
    var custom by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Box(Modifier.size(22.dp).clip(CircleShape).background(value).border(1.dp, Color(0x55FFFFFF), CircleShape))
            Spacer(Modifier.width(12.dp))
            Box(
                Modifier.size(36.dp).clip(RoundedCornerShape(12.dp)).background(Eon.P1).clickable { onChange(default) },
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Outlined.Replay, "Reset", tint = Eon.Soft, modifier = Modifier.size(18.dp)) }
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            SWATCHES.forEach { c ->
                val on = c == value
                Box(
                    Modifier.size(34.dp).clip(CircleShape).background(c)
                        .border(if (on) 2.dp else 1.dp, if (on) Eon.Accent else Eon.ov(0x33), CircleShape)
                        .clickable { onChange(c) },
                )
            }
            Box(
                Modifier.height(34.dp).clip(CircleShape).accentFill(custom, Eon.P1)
                    .clickable { custom = !custom }.padding(horizontal = 14.dp),
                contentAlignment = Alignment.Center,
            ) { Text("Custom", color = if (custom) Eon.OnAccent else Eon.Text, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
        }
        if (custom) {
            val start = remember { FloatArray(3).also { android.graphics.Color.colorToHSV(value.toArgb(), it) } }
            var h by remember { mutableFloatStateOf(start[0]) }
            var s by remember { mutableFloatStateOf(start[1]) }
            var v by remember { mutableFloatStateOf(start[2]) }
            fun push() = onChange(Color(android.graphics.Color.HSVToColor(floatArrayOf(h, s, v))))
            Text("Hue", color = Eon.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
            DsSliderBar(h, 0f..360f) { h = it; push() }
            Text("Saturation", color = Eon.Muted, fontSize = 12.sp)
            DsSliderBar(s, 0f..1f) { s = it; push() }
            Text("Brightness", color = Eon.Muted, fontSize = 12.sp)
            DsSliderBar(v, 0f..1f) { v = it; push() }
        }
    }
}
