package ix.app.eon

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val PanelColor: Color get() = Eon.P0
private val LineColor: Color get() = Eon.Line

private class Choice(val id: String, val title: String, val subtitle: String)

private val HOME_CHOICES = listOf(
    Choice("none", "None", "Icons are just there"),
    Choice("fade", "Fade", "Icons fade and grow in softly"),
    Choice("rise", "Rise", "Icons float up into place, one after another"),
    Choice("fall", "Free fall", "Icons drop from the top and bounce into place"),
    Choice("pop", "Pop", "Icons pop in with a little overshoot"),
)

private val PAGE_CHOICES = listOf(
    Choice("slide", "Slide", "Pages slide side to side"),
    Choice("fade", "Fade", "The page you leave fades out as the next fades in"),
    Choice("zoom", "Zoom", "Pages shrink and fade as they pass"),
    Choice("depth", "Depth", "The page you leave sinks behind the next one"),
)

private val DRAWER_CHOICES = listOf(
    Choice("slide", "Slide up", "Rises a little from the bottom"),
    Choice("zoom", "Zoom", "Grows in from the middle"),
    Choice("fade", "Fade", "Just fades in and out"),
    Choice("sheet", "Sheet", "Slides all the way up from the bottom edge"),
)

private val BLUR_CHOICES = listOf(
    Choice("off", "Off", "The wallpaper stays sharp"),
    Choice("frosted", "Frosted glass", "A soft blur, the wallpaper still shows through"),
    Choice("strong", "Strong blur", "Heavy blur, like frosted opaque glass"),
)

/** Settings hub > Animations. */
@Composable
fun AnimationsPage(onBack: () -> Unit) {
    BackHandler { onBack() }
    var replay by remember { mutableIntStateOf(0) }

    Column(
        Modifier.fillMaxSize().background(Eon.Page).systemBarsPadding().padding(horizontal = 16.dp)
            .verticalScroll(rememberScrollState()),
    ) {
        Gap(12)
        PageHeader("Animations", onBack)
        Gap(18)

        HomePreview(AnimConfig.home, replay) { replay++ }
        Text(
            "Tap the preview to play it again. The real one plays whenever you come back to the home screen.",
            color = Eon.Faint, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 8.dp),
        )

        Gap(10)
        SettingsSectionLabel("HOME ANIMATION")
        ChoiceGroup(HOME_CHOICES, AnimConfig.home) { AnimConfig.chooseHome(it); replay++ }

        Gap(22)
        SettingsSectionLabel("SWIPING BETWEEN PAGES")
        ChoiceGroup(PAGE_CHOICES, AnimConfig.page) { AnimConfig.choosePage(it) }

        Gap(22)
        SettingsSectionLabel("APP DRAWER")
        ChoiceGroup(DRAWER_CHOICES, AnimConfig.drawer) { AnimConfig.chooseDrawer(it) }

        Gap(22)
        SettingsSectionLabel("BLUR BEHIND THE DRAWER")
        ChoiceGroup(BLUR_CHOICES, BLUR_CHOICES[BlurConfig.level].id) { BlurConfig.choose(BLUR_CHOICES.indexOfFirst { c -> c.id == it }) }
        Text(
            "Frosted glass blurs your wallpaper while the drawer or settings are open. Some phones turn this off in battery saver.",
            color = Eon.Faint, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 8.dp),
        )

        Gap(14)
        SettingsSectionLabel("TOUCH")
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(PanelColor).border(1.dp, LineColor, RoundedCornerShape(24.dp))) {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f).padding(end = 12.dp)) {
                    Text("Icon press effect", color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text("Icons shrink a little under your finger", color = Eon.Muted, fontSize = 13.sp)
                }
                EonSwitch(AnimConfig.press) { AnimConfig.choosePress(it) }
            }
        }
        Gap(8)
        Text(
            "If you turn animations off in Android's developer options, these play instantly.",
            color = Eon.Faint, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
        )
        Gap(28)
    }
}

@Composable
private fun ChoiceGroup(choices: List<Choice>, selected: String, onSelect: (String) -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(PanelColor).border(1.dp, LineColor, RoundedCornerShape(24.dp))) {
        choices.forEachIndexed { i, c ->
            if (i > 0) Box(Modifier.padding(horizontal = 16.dp).fillMaxWidth().height(1.dp).background(Eon.Line))
            val on = c.id == selected
            Row(
                Modifier.fillMaxWidth().clickable { onSelect(c.id) }.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Column(Modifier.weight(1f)) {
                    Text(c.title, color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text(c.subtitle, color = Eon.Muted, fontSize = 13.sp)
                }
                Box(
                    Modifier.size(24.dp).clip(CircleShape)
                        .then(if (on) Modifier.background(Eon.Button) else Modifier.border(2.dp, Color(0xFF3A3A40), CircleShape)),
                    contentAlignment = Alignment.Center,
                ) {
                    if (on) Box(Modifier.size(8.dp).clip(CircleShape).background(Color.White))
                }
            }
        }
    }
}

/** A small home screen of eight icons that plays the chosen home animation, using the same maths as the real one. */
@Composable
private fun HomePreview(mode: String, replay: Int, onTap: () -> Unit) {
    val t = remember { Animatable(1f) }
    LaunchedEffect(mode, replay) {
        if (mode == "none") {
            t.snapTo(1f)
        } else {
            t.snapTo(0f)
            delay(180)
            t.animateTo(1f, tween(AnimConfig.introMs(mode), easing = LinearEasing))
        }
    }
    val density = LocalDensity.current
    val tileTravel = with(density) { 190.dp.toPx() }
    Box(
        Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(24.dp)).background(PanelColor)
            .border(1.dp, LineColor, RoundedCornerShape(24.dp)).clickable(onClick = onTap).padding(16.dp),
    ) {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceEvenly) {
            for (row in 0 until 2) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    for (col in 0 until 4) {
                        val order = (row + col / 4f) / 2f * 0.85f
                        val tint = TILE_COLORS[(row * 4 + col) % TILE_COLORS.size]
                        Box(
                            Modifier.size(52.dp)
                                .graphicsLayer { applyIntro(mode, t.value, order, tileTravel) }
                                .clip(RoundedCornerShape(16.dp)).background(tint),
                        )
                    }
                }
            }
        }
    }
}

private val TILE_COLORS = listOf(
    Color(0xFF4F8CFF), Color(0xFF35D6F0), Color(0xFF9B7BFF), Color(0xFFFF6B8B),
    Color(0xFFFF9F43), Color(0xFF2ED47A), Color(0xFFFFD166), Color(0xFFC77DFF),
)
