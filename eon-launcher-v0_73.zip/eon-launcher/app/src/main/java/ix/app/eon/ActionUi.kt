package ix.app.eon

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Article
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.ArrowDownward
import androidx.compose.material.icons.outlined.ArrowForward
import androidx.compose.material.icons.outlined.ArrowUpward
import androidx.compose.material.icons.outlined.Block
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.PowerSettingsNew
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material.icons.outlined.ToggleOn
import androidx.compose.material.icons.outlined.TouchApp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Asks for an action: [title] says which gesture it is for, [current] is what it does now, [onPick] gets the result. */
class ActionRequest(val title: String, val current: String, val onPick: (String) -> Unit)

private class ActionChoice(val spec: String, val label: String, val icon: ImageVector)

private val SUGGESTED = listOf(
    ActionChoice(Act.NONE, "None", Icons.Outlined.Block),
)
private val SYSTEM = listOf(
    ActionChoice(Act.SCREEN_OFF, "Turn off the screen", Icons.Outlined.PowerSettingsNew),
    ActionChoice(Act.LOCK, "Lock screen (device admin)", Icons.Outlined.Lock),
    ActionChoice(Act.NOTIF, "Show notifications panel", Icons.Outlined.Notifications),
    ActionChoice(Act.RECENTS, "Show recent apps", Icons.Outlined.History),
    ActionChoice(Act.PANEL, "Show toggle panel", Icons.Outlined.ToggleOn),
)
private val NAVIGATION = listOf(
    ActionChoice(Act.DRAWER, "App page", Icons.Outlined.GridView),
    ActionChoice(Act.SEARCH, "Search page", Icons.Outlined.Search),
    ActionChoice(Act.SETTINGS, "Preferences", Icons.Outlined.Tune),
    ActionChoice(Act.NEXT_PAGE, "Next home page", Icons.Outlined.ArrowForward),
    ActionChoice(Act.PREV_PAGE, "Previous home page", Icons.Outlined.ArrowBack),
    ActionChoice(Act.FIRST_PAGE, "First home page", Icons.Outlined.Home),
    ActionChoice(Act.FEED, "News feed (Eon)", Icons.Outlined.Article),
    ActionChoice(Act.GOOGLE_FEED, "Google feed", Icons.Outlined.Article),
)

/**
 * Full-screen list of everything a gesture can do, in tabs: Suggested (None, Open web page, System, Navigation)
 * and Apps (open any app). Tapping one picks it and closes the list.
 */
@Composable
fun ActionPickerScreen(request: ActionRequest, apps: List<AppEntry>, popups: List<Int> = emptyList(), onClose: () -> Unit) {
    val actionCtx = androidx.compose.ui.platform.LocalContext.current
    BackHandler { onClose() }
    var tab by remember { mutableIntStateOf(if (request.current.startsWith(Act.APP)) 1 else 0) }
    var askUrl by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    val pick: (String) -> Unit = { spec ->
        request.onPick(spec)
        onClose()
    }
    Column(
        Modifier.fillMaxSize().background(Eon.Page).systemBarsPadding()
            .pointerInput(Unit) { detectTapGestures { } }
            .padding(horizontal = 16.dp),
    ) {
        Gap(12)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(Eon.P1).border(1.dp, Eon.P2, CircleShape)
                    .clickable(onClick = onClose),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Outlined.ArrowBack, "Back", tint = Eon.Text, modifier = Modifier.size(22.dp)) }
            Column {
                Text("Assign action", color = Eon.Faint, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text(request.title, color = Eon.Text, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
        Gap(16)
        Row(
            Modifier.fillMaxWidth().clip(CircleShape).background(Eon.P1).padding(3.dp),
            horizontalArrangement = Arrangement.spacedBy(3.dp),
        ) {
            listOf("Suggested", "Apps").forEachIndexed { i, label ->
                Box(
                    Modifier.weight(1f).clip(CircleShape).accentFill(tab == i, Color.Transparent)
                        .clickable { tab = i }.padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        label, color = if (tab == i) Eon.OnAccent else Eon.Soft, fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
        }
        Gap(8)
        if (tab == 0) {
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                SettingsSectionLabel("SUGGESTED")
                SUGGESTED.take(1).forEach { c -> ChoiceRow(c.icon, c.label, request.current == c.spec) { pick(c.spec) } }
                ChoiceRow(
                    Icons.Outlined.Language, "Open web page", request.current.startsWith(Act.URL),
                    detail = if (request.current.startsWith(Act.URL)) Act.label(request.current, apps) else null,
                ) { askUrl = true }
                SUGGESTED.drop(1).forEach { c -> ChoiceRow(c.icon, c.label, request.current == c.spec) { pick(c.spec) } }
                Gap(10)
                SettingsSectionLabel("SYSTEM")
                SYSTEM.forEach { c -> ChoiceRow(c.icon, c.label, request.current == c.spec) { pick(c.spec) } }
                Gap(10)
                SettingsSectionLabel("NAVIGATION")
                NAVIGATION.forEach { c -> ChoiceRow(c.icon, c.label, request.current == c.spec) { pick(c.spec) } }
                Gap(10)
                if (popups.isNotEmpty()) {
                    SettingsSectionLabel("POPUP WIDGET")
                    popups.forEach { wid ->
                        ChoiceRow(Icons.Outlined.GridView, popupLabel(actionCtx, wid), request.current == Act.POPUP + wid) { pick(Act.POPUP + wid) }
                    }
                    Gap(10)
                }
                SettingsSectionLabel("FOCUS")
                ChoiceRow(Icons.Outlined.Home, "Normal home", request.current == Act.FOCUS) { pick(Act.FOCUS) }
                Focus.modes.toList().forEach { m ->
                    ChoiceRow(Icons.Outlined.Tune, "Focus: " + m.name, request.current == Act.FOCUS + m.name) { pick(Act.FOCUS + m.name) }
                }
                Gap(24)
            }
        } else {
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Eon.P1)
                    .padding(horizontal = 14.dp, vertical = 12.dp),
            ) {
                if (query.isEmpty()) Text("Search apps", color = Eon.Faint, fontSize = 15.sp)
                BasicTextField(
                    value = query, onValueChange = { query = it }, singleLine = true,
                    textStyle = TextStyle(color = Eon.Text, fontSize = 15.sp), cursorBrush = SolidColor(Eon.Accent),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            val list = remember(apps, query) {
                apps.filter { query.isBlank() || it.label.contains(query.trim(), ignoreCase = true) }.sortedBy { it.label.lowercase() }
            }
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp)) {
                items(list, key = { it.key }) { app ->
                    val spec = Act.APP + app.key
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable { pick(spec) }
                            .padding(horizontal = 8.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Image(bitmap = app.icon, contentDescription = null, modifier = Modifier.size(40.dp))
                        Text(
                            app.label, color = Eon.Text, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f).padding(start = 14.dp),
                        )
                        if (request.current == spec) Icon(Icons.Outlined.Check, null, tint = Eon.Accent, modifier = Modifier.size(20.dp))
                    }
                }
            }
        }
    }
    if (askUrl) {
        NameDialog(
            title = "Web address",
            initial = if (request.current.startsWith(Act.URL)) request.current.removePrefix(Act.URL) else "https://",
            onDone = { raw ->
                val url = if (raw.contains("://")) raw else "https://$raw"
                askUrl = false
                pick(Act.URL + url)
            },
            onDismiss = { askUrl = false },
        )
    }
}

@Composable
private fun ChoiceRow(icon: ImageVector, label: String, selected: Boolean, detail: String? = null, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(bottom = 6.dp).clip(RoundedCornerShape(18.dp))
            .background(if (selected) Eon.Accent.copy(alpha = 0.14f) else Eon.P0)
            .border(1.dp, if (selected) Eon.Accent.copy(alpha = 0.6f) else Eon.Line, RoundedCornerShape(18.dp))
            .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Icon(icon, null, tint = if (selected) Eon.Accent else Eon.Soft, modifier = Modifier.size(22.dp))
        Column(Modifier.weight(1f)) {
            Text(label, color = Eon.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            if (detail != null) Text(detail, color = Eon.Faint, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (selected) Icon(Icons.Outlined.Check, null, tint = Eon.Accent, modifier = Modifier.size(20.dp))
    }
}

/**
 * The gestures of one app, folder or widget: a row per gesture showing what it does, tap to change.
 * Changes are saved at once.
 */
@Composable
fun GestureEditorScreen(state: EonState, target: GestureTarget, apps: List<AppEntry>, onClose: () -> Unit) {
    BackHandler(enabled = state.actionPicker == null) { onClose() }
    val id = target.id
    Column(
        Modifier.fillMaxSize().background(Eon.Page).systemBarsPadding()
            .pointerInput(Unit) { detectTapGestures { } }
            .padding(horizontal = 16.dp).verticalScroll(rememberScrollState()),
    ) {
        Gap(12)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(Eon.P1).border(1.dp, Eon.P2, CircleShape)
                    .clickable(onClick = onClose),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Outlined.ArrowBack, "Back", tint = Eon.Text, modifier = Modifier.size(22.dp)) }
            Column {
                Text("Gestures", color = Eon.Faint, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text(target.title, color = Eon.Text, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        Gap(20)
        ITEM_GESTURES.forEach { (g, name) ->
            val current = ItemGestures.get(id, g) ?: Act.NONE
            val icon = when (g) {
                G_UP -> Icons.Outlined.ArrowUpward
                G_DOWN -> Icons.Outlined.ArrowDownward
                G_LEFT -> Icons.Outlined.ArrowBack
                G_RIGHT -> Icons.Outlined.ArrowForward
                else -> Icons.Outlined.TouchApp
            }
            Row(
                Modifier.fillMaxWidth().padding(bottom = 10.dp).clip(RoundedCornerShape(20.dp)).background(Eon.P0)
                    .border(1.dp, Eon.P2, RoundedCornerShape(20.dp))
                    .clickable {
                        state.actionPicker = ActionRequest("${target.title} · $name", current) { spec -> ItemGestures.set(id, g, spec) }
                    }
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Icon(icon, null, tint = if (current == Act.NONE) Eon.Faint else Eon.Accent, modifier = Modifier.size(22.dp))
                Column(Modifier.weight(1f)) {
                    Text(name, color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text(
                        Act.label(current, apps), color = if (current == Act.NONE) Eon.Faint else Eon.Accent,
                        fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                }
                Icon(Icons.Outlined.ChevronRight, null, tint = Eon.Faint, modifier = Modifier.size(20.dp))
            }
        }
        if (ItemGestures.count(id) > 0) {
            Box(
                Modifier.padding(top = 4.dp).clip(CircleShape).clickable { ItemGestures.clear(id) }
                    .padding(horizontal = 16.dp, vertical = 10.dp),
            ) { Text("Clear all", color = Eon.Danger, fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
        }
        Gap(10)
        Text(
            if (target.kind == "w") {
                "On a widget the first tap of a double tap still reaches the widget. A swipe you set here is taken from the widget, so it cannot scroll that way."
            } else {
                "Swipe on the icon to use these. Directions you leave empty keep swiping the pages."
            },
            color = Eon.Muted, fontSize = 13.sp, lineHeight = 18.sp, modifier = Modifier.padding(start = 4.dp, bottom = 24.dp),
        )
    }
}
