package ix.app.eon

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog

// Folders in the bar-style app page. They are made from an app's long-press menu (Add to folder), show in the grid
// in place of their apps, and open in a popup like the folders on the home screen.

/** One cell of the app grid: an app or a folder. */
sealed interface GridEntry {
    val key: String
    val label: String
}

class GridApp(val app: AppEntry) : GridEntry {
    override val key: String = app.key
    override val label: String = app.label
}

class GridFolder(val folder: Item) : GridEntry {
    override val key: String = "folder:" + folder.key
    override val label: String get() = folder.name
}

/**
 * Turns the apps of a page into grid cells: apps that sit in a folder are replaced by the folder, which takes the
 * place of the first of its apps that this page shows.
 */
fun buildGridEntries(list: List<AppEntry>, folders: List<Item>): List<GridEntry> {
    if (folders.isEmpty()) return list.map { GridApp(it) }
    val owner = HashMap<String, Item>()
    folders.forEach { f -> f.members.forEach { owner[it] = f } }
    val emitted = HashSet<String>()
    val out = ArrayList<GridEntry>()
    list.forEach { app ->
        val f = owner[app.key]
        if (f == null) out.add(GridApp(app)) else if (emitted.add(f.key)) out.add(GridFolder(f))
    }
    return out
}

/**
 * An open app page folder: its name (tap to rename) and its apps. Add apps, change the icon, or remove the folder
 * (its apps go back into the grid). Tap outside to close.
 */
@Composable
fun DrawerFolderPopup(
    state: EonState, folder: Item, apps: List<AppEntry>,
    onLaunch: (AppEntry) -> Unit, onMenu: (AppEntry) -> Unit, onClose: () -> Unit,
) {
    val members = folder.members.mapNotNull { k -> apps.firstOrNull { it.key == k } }
    var name by remember(folder.key) { mutableStateOf(folder.name) }
    var pickingIcon by remember(folder.key) { mutableStateOf(false) }
    var adding by remember(folder.key) { mutableStateOf(false) }
    // Save the name however the popup closes.
    DisposableEffect(folder.key) { onDispose { state.saveDrawerFolders() } }
    Box(
        Modifier.fillMaxSize().background(Color(0x99000000))
            .pointerInput(Unit) { detectTapGestures(onTap = { onClose() }) },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier.padding(horizontal = 24.dp).fillMaxWidth()
                .glassDark(RoundedCornerShape(30.dp))
                .pointerInput(Unit) { detectTapGestures(onTap = { }) }
                .padding(horizontal = 18.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            BasicTextField(
                value = name,
                onValueChange = { name = it.take(24); folder.name = name },
                singleLine = true,
                textStyle = TextStyle(color = Eon.DText, fontSize = 22.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center),
                cursorBrush = SolidColor(Eon.DAccent),
                modifier = Modifier.fillMaxWidth(),
                decorationBox = { inner ->
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        if (name.isEmpty()) Text("Folder", color = Eon.DFaint, fontSize = 22.sp)
                        inner()
                    }
                },
            )
            Gap(16)
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                modifier = Modifier.heightIn(max = 380.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(members, key = { it.key }) { app ->
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        AppIcon(app, 52.dp, true, { onLaunch(app) }, { onMenu(app) })
                    }
                }
            }
            Gap(14)
            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                Box(
                    Modifier.clip(CircleShape).clickable { adding = true }.padding(horizontal = 10.dp, vertical = 8.dp),
                ) { Text("Add apps", color = Eon.DAccent, fontSize = 14.sp, fontWeight = FontWeight.Medium) }
                Box(
                    Modifier.clip(CircleShape).clickable { pickingIcon = true }.padding(horizontal = 10.dp, vertical = 8.dp),
                ) { Text("Change icon", color = Eon.DAccent, fontSize = 14.sp, fontWeight = FontWeight.Medium) }
                Box(
                    Modifier.clip(CircleShape).clickable { state.deleteDrawerFolder(folder.key); onClose() }
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                ) { Text("Remove folder", color = Eon.DMuted, fontSize = 14.sp, fontWeight = FontWeight.Medium) }
            }
        }
        if (pickingIcon) {
            FolderIconDialog(
                state, folder, apps,
                onChange = { k, v, c -> state.setDrawerFolderIcon(folder.key, k, v, c) },
                onScale = { state.setDrawerFolderScale(folder.key, it) },
                onDismiss = { pickingIcon = false },
            )
        }
        if (adding) {
            AddAppsScreen(
                folder.name.ifBlank { "Folder" }, apps, folder.members.toSet(),
                onConfirm = { list -> list.forEach { state.addToDrawerFolder(folder.key, it.key) } },
                onClose = { adding = false },
            )
        }
    }
}

/** From an app's menu: choose a folder for it, or make a new one. */
@Composable
fun AppFolderPicker(app: AppEntry, state: EonState, onDone: () -> Unit, onBack: () -> Unit) {
    Dialog(onDismissRequest = onBack) {
        Column(Modifier.width(300.dp).glassDark(RoundedCornerShape(26.dp)).padding(vertical = 8.dp)) {
            Text(
                "Add to folder", color = Eon.DText, fontSize = 17.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
            )
            Column(Modifier.heightIn(max = 340.dp).verticalScroll(rememberScrollState())) {
                state.drawerFolders.toList().forEach { f ->
                    val here = app.key in f.members
                    Row(
                        Modifier.fillMaxWidth().clickable(enabled = !here) {
                            state.addToDrawerFolder(f.key, app.key)
                            onDone()
                        }.padding(horizontal = 20.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            f.name.ifBlank { "Folder" }, color = if (here) Eon.DFaint else Eon.DText, fontSize = 15.sp,
                            fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f),
                        )
                        Text(if (here) "Already in" else "${f.members.size} apps", color = Eon.DFaint, fontSize = 12.sp)
                    }
                }
                Text(
                    "New folder", color = Eon.DAccent, fontSize = 15.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth().clickable {
                        state.newDrawerFolder(app.key)
                        onDone()
                    }.padding(horizontal = 20.dp, vertical = 12.dp),
                )
            }
        }
    }
}
