package ix.app.eon

import android.content.Context
import android.graphics.Bitmap
import android.os.PowerManager
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageShader
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Light or dark frost (0.80.2). The Library measures how bright your wallpaper is ([LibBackdrop] does it once, on its small
 * blurred copy). With Frost on Auto, a bright wallpaper gets dark smoke cards and dark names, a dark one gets light frosted
 * cards and light names. When Eon cannot read the wallpaper (the plain system wallpaper) there is nothing to measure, so Auto
 * behaves like Light.
 */
internal object LibFrost {
    /** Average brightness of the wallpaper, 0 (black) to 1 (white), or -1 while it is unknown. */
    var lum by mutableFloatStateOf(-1f)

    /** True when the wallpaper is still bright after the Library's dim is laid over it. */
    private val bright: Boolean get() = lum >= 0f && lum * (1f - DrawerConfig.bgOpacity.coerceIn(0f, 1f)) > 0.5f

    /** True when the cards are dark smoke instead of light frost. */
    val darkCards: Boolean
        get() = when (LibraryConfig.frost) {
            1 -> false
            2 -> true
            else -> bright
        }

    /** A dark colour for the names under the cards when Auto finds the wallpaper bright, else null (the drawer's text colour). */
    fun labelInk(): Color? = if (LibraryConfig.frost == 0 && bright && !LibraryConfig.isFlat) Color(0xFF101114) else null
}

/** A small tile of grey noise that is laid over the cards at 3%, so the soft gradients do not show bands. Made once. */
internal object LibGrain {
    val brush: Brush by lazy {
        val n = 96
        val rnd = java.util.Random(7L)
        val px = IntArray(n * n) {
            val v = rnd.nextInt(256)
            (0xFF shl 24) or (v shl 16) or (v shl 8) or v
        }
        val bmp = Bitmap.createBitmap(px, n, n, Bitmap.Config.ARGB_8888)
        ShaderBrush(ImageShader(bmp.asImageBitmap(), TileMode.Repeated, TileMode.Repeated))
    }
}

/** True while Android's Battery Saver is on: the Library then leaves out the shadow and the grain. */
@Composable
internal fun libLiteFx(): Boolean {
    val ctx = LocalContext.current
    return remember {
        try {
            (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isPowerSaveMode
        } catch (_: Exception) {
            false
        }
    }
}

/**
 * The fill of a frosted card: white (or your tile colour) at about 22% at the top fading to 12%, or black smoke when the frost
 * is dark. [boost] makes it a few percent lighter (the search pill), [lift] makes the top a little stronger (a selected box).
 * Clear glass uses 60% of that.
 */
internal fun libFrostFill(boost: Float = 0f, lift: Float = 0f): Brush {
    val clear = if (LibraryConfig.clearGlass) 0.6f else 1f
    return if (LibFrost.darkCards) {
        Brush.verticalGradient(
            listOf(
                Color.Black.copy(alpha = ((0.26f - boost) * clear + lift).coerceIn(0f, 1f)),
                Color.Black.copy(alpha = ((0.15f - boost) * clear).coerceIn(0f, 1f)),
            ),
        )
    } else {
        val base = DrawerConfig.tileColor
        val o = DrawerConfig.tileOpacity
        Brush.verticalGradient(
            listOf(
                base.copy(alpha = ((o * 2.2f + boost) * clear + lift).coerceIn(0f, 1f)),
                base.copy(alpha = ((o * 1.2f + boost) * clear).coerceIn(0f, 1f)),
            ),
        )
    }
}

/** A soft outer shadow that lifts a card off the wallpaper (about 12 dp, 8% black). Placed before the clip. Off with the switch, with Flat and in Battery Saver. */
@Composable
internal fun Modifier.libSoftShadow(shape: Shape, radius: Dp = 12.dp): Modifier {
    val lite = libLiteFx()
    if (!LibraryConfig.glassShadow || lite || LibraryConfig.isFlat) return this
    return this.shadow(radius, shape, clip = false, ambientColor = Color.Black.copy(alpha = 0.08f), spotColor = Color.Black.copy(alpha = 0.08f))
}

/**
 * The search pill: the same frosted material as the cards with a few percent more white, a bright top edge and a soft shadow.
 * Flat, and the Classic preset, keep the plain Library glass.
 */
@Composable
internal fun Modifier.libPill(shape: Shape): Modifier {
    if (!LibraryConfig.iosPill || LibraryConfig.isFlat) return this.libGlass(shape)
    val dark = LibFrost.darkCards
    val edge = Brush.verticalGradient(listOf(Color.White.copy(alpha = if (dark) 0.30f else 0.55f), Color.White.copy(alpha = 0.06f)))
    return this.libSoftShadow(shape, 8.dp).clip(shape).background(libFrostFill(boost = 0.04f)).border(1.dp, edge, shape)
}

/** False while Android is not blurring behind windows (Battery Saver, "Disable window blurs" in Developer options, some phone makers). Read right now. */
internal fun libBlurEnabledNow(ctx: Context): Boolean = try {
    ctx.getSystemService(android.view.WindowManager::class.java).isCrossWindowBlurEnabled
} catch (_: Exception) {
    true
}

/** [libBlurEnabledNow], read when the screen opens. */
@Composable
internal fun libBlurWorks(): Boolean {
    val ctx = LocalContext.current
    return remember { libBlurEnabledNow(ctx) }
}

/** A one-line warning under a Blur slider when the phone is not blurring, so a sharp wallpaper is not mistaken for a bug. Shows nothing otherwise. */
@Composable
internal fun LibBlurNote(modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val works = libBlurWorks()
    // Not rememberLiveWallpaperActive(): inside a dialog the context is not the activity.
    val live = remember { isEonLiveWallpaper(ctx) }
    // Eon blurs the picture itself when it is the wallpaper in the app, or when Android will not blur and Eon can blur its own copy of the live wallpaper.
    val own = WallpaperConfig.active && (!live || !works)
    val amount = BlurConfig.amount
    val route = when {
        amount <= 0 -> "Blur is off."
        android.os.Build.VERSION.SDK_INT < 31 -> "Blurring the wallpaper needs Android 12 or newer."
        own && live -> "Android is not blurring behind apps, so Eon blurs its own copy of its live wallpaper."
        own -> "Wallpaper: Eon's own picture, blurred by Eon itself."
        else -> "Wallpaper: the system or live wallpaper, blurred by Android."
    }
    Column(modifier) {
        Text(route, color = Eon.DMuted, fontSize = 11.sp, lineHeight = 15.sp)
        if (!works && !own && amount > 0) {
            Text(
                "Android is not blurring behind apps right now (Battery Saver, \"Disable window blurs\" in Developer options, or a phone setting), so this wallpaper stays sharp whatever the slider says. Choose a picture in Settings > Wallpaper and Eon blurs it itself.",
                color = Color(0xFFFFB454), fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.padding(top = 2.dp),
            )
        }
    }
}
