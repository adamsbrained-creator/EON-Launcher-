package ix.app.eon

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint

/** The automatic sizing modes, in the order of [IconAuto.mode]. */
val AUTO_MODES = listOf("Off", "Match size", "Optical")

/** How much of its frame each icon fills, in the order of [IconAuto.fill]. */
val AUTO_FILLS = listOf("Compact", "Standard", "Full")
private val FILL_VALUES = floatArrayOf(0.86f, 0.93f, 1f)

/**
 * Makes every icon the same size, whatever the app or the icon pack drew.
 * - Match size: finds the visible part of the icon and scales it so its longest side is the same for all icons.
 * - Optical: also looks at how much of that box is filled, so a round icon and a square one look equally big.
 * In both modes the visible part is moved to the middle of the frame. It is done once per icon and kept in the icon cache.
 * While it is on, sizes you set by hand for single icons are not used.
 */
object IconAuto {
    @Volatile var mode: Int = 0
    @Volatile var fill: Int = 1

    fun load(p: Prefs) {
        mode = p.getInt("autoSize", 0).coerceIn(0, AUTO_MODES.size - 1)
        fill = p.getInt("autoFill", 1).coerceIn(0, AUTO_FILLS.size - 1)
    }

    fun save(p: Prefs) {
        p.putInt("autoSize", mode)
        p.putInt("autoFill", fill)
    }

    /** Goes into the icon cache key, so icons are rebuilt when this changes. */
    fun signature(): String = if (mode == 0) "a0" else "a$mode:$fill"

    fun apply(src: Bitmap, px: Int): Bitmap {
        if (mode == 0) return src
        return try {
            fit(src)
        } catch (_: Exception) {
            src
        } catch (_: OutOfMemoryError) {
            src
        }
    }

    private fun fit(src: Bitmap): Bitmap {
        val w = src.width
        val h = src.height
        if (w < 8 || h < 8 || src.config == Bitmap.Config.HARDWARE) return src
        val pix = IntArray(w * h)
        src.getPixels(pix, 0, w, 0, 0, w, h)
        var minX = w
        var minY = h
        var maxX = -1
        var maxY = -1
        var area = 0f
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                val a = pix[row + x] ushr 24
                // Only solid pixels count, so a soft shadow or glow around an icon does not make it look bigger.
                if (a >= 128) {
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                    area += 1f
                }
            }
        }
        if (maxX < 0) return src
        val bw = maxX - minX + 1
        val bh = maxY - minY + 1
        val side = maxOf(bw, bh).toFloat()
        val target = FILL_VALUES[fill.coerceIn(0, FILL_VALUES.size - 1)] * w
        var s = target / side
        if (mode == 2 && area > 0f) {
            // A rounded square covers about 94% of its box; icons with less to show are scaled up a little.
            val byArea = Math.sqrt((target * target * 0.94f / area).toDouble()).toFloat()
            s = Math.sqrt((s * byArea).toDouble()).toFloat()
        }
        // Never grow an icon past its frame, and keep the change sensible.
        s = s.coerceIn(0.6f, minOf(1.7f, w / side))
        val cx = (minX + maxX + 1) / 2f
        val cy = (minY + maxY + 1) / 2f
        val moved = Math.abs(cx - w / 2f) + Math.abs(cy - h / 2f)
        if (Math.abs(s - 1f) < 0.02f && moved < w * 0.01f) return src
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.translate(w / 2f, h / 2f)
        c.scale(s, s)
        c.translate(-cx, -cy)
        c.drawBitmap(src, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
        return out
    }
}
