package ix.app.eon

import android.content.Intent
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.activity.compose.BackHandler
import androidx.activity.compose.PredictiveBackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Article
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Bolt
import androidx.compose.material.icons.outlined.Restore
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Save
import androidx.compose.material.icons.outlined.TouchApp
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.ViewDay
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material.icons.outlined.Wallpaper
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver

// The rainbow from the Eon icon. Each category tile has one of these colours.
private val Blue = Color(0xFF4F8CFF)
private val Cyan = Color(0xFF35D6F0)
private val Violet = Color(0xFF9B7BFF)
private val Magenta = Color(0xFFF25CCB)
private val Coral = Color(0xFFFF7A66)
private val Orange = Color(0xFFFFA63D)
private val Rainbow = Brush.horizontalGradient(listOf(Cyan, Blue, Violet, Magenta, Coral, Orange))

private val PanelBg: Color get() = Eon.P0

/** One category tile on the settings hub. */
private class HubTile(
    val title: String,
    val status: String,
    val icon: ImageVector,
    val from: Color,
    val to: Color,
    val ink: Color,
    val keywords: String,
    val onClick: () -> Unit,
)

@Composable
fun SettingsScreen(state: EonState, onClose: () -> Unit, onResetGreeting: () -> Unit, startSub: String = "") {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    DisposableEffect(Unit) {
        val owner = (ctx as ComponentActivity).lifecycle
        val observer = LifecycleEventObserver { _, event -> if (event == Lifecycle.Event.ON_RESUME) tick++ }
        owner.addObserver(observer)
        onDispose { owner.removeObserver(observer) }
    }
    val notifications = remember(tick) {
        NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    }
    val version = remember {
        runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: ""
    }
    // "" is the hub. The others are its pages: grid, dock, wallpaper, wpsettings, hidden, about.
    var sub by remember { mutableStateOf(startSub) }
    val goBack: () -> Unit = {
        when (sub) {
            "wpsettings" -> {
                sub = "wallpaper"
            }
            "wallpaper" -> {
                if (startSub == "wallpaper") onClose() else sub = ""
            }
            "drawer" -> {
                if (startSub == "drawer") onClose() else sub = ""
            }
            "feed" -> {
                if (startSub == "feed") onClose() else sub = ""
            }
            "grid", "dock", "hidden", "about", "gestures", "icons", "anim", "import", "backup", "focus", "automations", "pages", "markers" -> {
                sub = ""
            }
            else -> {
                onClose()
            }
        }
    }
    // The page shrinks as the back gesture is dragged (Android 14 and up), then closes when it is let go.
    PredictiveBackHandler { events ->
        try {
            events.collect { PredictiveBack.settings = if (sub == "") it.progress else 0f }
            if (sub != "") PredictiveBack.settings = 0f
            goBack()
        } catch (e: kotlinx.coroutines.CancellationException) {
            PredictiveBack.settings = 0f
        }
    }
    AnimatedContent(
        targetState = sub,
        modifier = Modifier.fillMaxSize(),
        transitionSpec = {
            // Going into a page slides it in from the right; coming back reverses it.
            val deeper = (targetState.isNotEmpty() && initialState.isEmpty()) ||
                (initialState == "wallpaper" && targetState == "wpsettings")
            if (deeper) {
                (fadeIn(tween(260, easing = Motion.Decel)) + slideInHorizontally(tween(340, easing = Motion.Decel)) { it / 5 }) togetherWith
                    (fadeOut(tween(200)) + slideOutHorizontally(tween(340, easing = Motion.Decel)) { -it / 8 })
            } else {
                (fadeIn(tween(260, easing = Motion.Decel)) + slideInHorizontally(tween(340, easing = Motion.Decel)) { -it / 8 }) togetherWith
                    (fadeOut(tween(200)) + slideOutHorizontally(tween(340, easing = Motion.Decel)) { it / 5 })
            }
        },
        label = "settingsPage",
    ) { page ->
    when (page) {
        "wallpaper" -> {
            WallpaperScreen(
                state,
                onBack = { if (startSub == "wallpaper") onClose() else sub = "" },
                onSettings = { sub = "wpsettings" },
            )
            return@AnimatedContent
        }
        "wpsettings" -> {
            WallpaperSettingsScreen(state, onBack = { sub = "wallpaper" })
            return@AnimatedContent
        }
        "dock" -> {
            DockSettingsScreen(state, onBack = { sub = "" })
            return@AnimatedContent
        }
        "drawer" -> {
            DrawerSettingsScreen(state, onBack = { if (startSub == "drawer") onClose() else sub = "" })
            return@AnimatedContent
        }
        "grid" -> {
            GridSettingsScreen(state, onBack = { sub = "" })
            return@AnimatedContent
        }
        "hidden" -> {
            HiddenAppsPage(state, onBack = { sub = "" })
            return@AnimatedContent
        }
        "gestures" -> {
            GesturesPage(state, onBack = { sub = "" })
            return@AnimatedContent
        }
        "icons" -> {
            IconsPage(state, onBack = { sub = "" })
            return@AnimatedContent
        }
        "anim" -> {
            AnimationsPage(onBack = { sub = "" })
            return@AnimatedContent
        }
        "import" -> {
            SmartLauncherImportPage(state, onBack = { sub = "" })
            return@AnimatedContent
        }
        "automations" -> {
            AutomationsPage(state, onBack = { sub = "" })
            return@AnimatedContent
        }
        "focus" -> {
            FocusPage(state, onBack = { sub = "" })
            return@AnimatedContent
        }
        "markers" -> {
            MarkersPage(state, onBack = { sub = "" })
            return@AnimatedContent
        }
        "pages" -> {
            PageManagerScreen(state, state.appsForLabels, onBack = { sub = "" })
            return@AnimatedContent
        }
        "feed" -> {
            FeedPage(state, onBack = { if (startSub == "feed") onClose() else sub = "" }, onPages = { sub = "pages" })
            return@AnimatedContent
        }
        "backup" -> {
            BackupPage(onBack = { sub = "" })
            return@AnimatedContent
        }
        "about" -> {
            AboutPage(version, onResetGreeting, onBack = { sub = "" })
            return@AnimatedContent
        }
    }

    var query by remember { mutableStateOf("") }
    val q = query.trim().lowercase()

    val tiles = listOf(
        HubTile(
            "Grid and icons", "${HomeConfig.cols} × " + (if (HomeConfig.rowsSetting > 0) "${HomeConfig.rowsSetting}" else "auto") +
                " · ${HomeConfig.iconDp} dp",
            Icons.Outlined.GridView, Blue, Cyan, Color(0xFF04140B),
            "grid columns rows icon size labels padding home screen",
        ) { sub = "grid" },
        HubTile(
            "Dock", if (HomeConfig.dockOn) "${HomeConfig.dockCols} × ${HomeConfig.dockRows}" else "Off",
            Icons.Outlined.ViewDay, Cyan, Color(0xFF5C9DFF), Color(0xFF031418),
            "dock bar bottom",
        ) { sub = "dock" },
        HubTile(
            "Drawer", (if (state.drawerStyle == "library") "Library" else "Bar") + " · " +
                "${(DrawerConfig.bgOpacity * 100).toInt()}% dim",
            Icons.Outlined.Apps, Orange, Coral, Color(0xFF2A1000),
            "drawer app library bar categories opacity transparency colour color background icons labels sort search folders tiles",
        ) { sub = "drawer" },
        HubTile(
            "Wallpaper", if (WallpaperConfig.active) "Gyro on" else "System wallpaper",
            Icons.Outlined.Wallpaper, Violet, Color(0xFFC77DFF), Color(0xFF0C0620),
            "wallpaper gyro rain snow ripple lock screen live effects",
        ) { sub = "wallpaper" },
        HubTile(
            "Page manager", "Google feed, Eon feed, app page, search",
            Icons.Outlined.Article, Blue, Cyan, Color(0xFF031418),
            "page manager pages feed google swipe left right up down search app page",
        ) { sub = "pages" },
        HubTile(
            "Feed", if (FeedConfig.enabled) "${FeedConfig.selected.size} sources · swipe right" else "Off",
            Icons.Outlined.Article, Blue, Cyan, Color(0xFF031418),
            "feed news rss google discover articles headlines sources swipe left page",
        ) { sub = "feed" },
        HubTile(
            "Backup", "Daily · keeps 7 days",
            Icons.Outlined.Save, Cyan, Blue, Color(0xFF031418),
            "backup restore daily save copy export import settings layout",
        ) { sub = "backup" },
        HubTile(
            "Import layout", "From Smart Launcher",
            Icons.Outlined.Restore, Orange, Color(0xFFFFD23D), Color(0xFF2A1700),
            "import backup smart launcher restore migrate layout slbk move switch",
        ) { sub = "import" },
        HubTile(
            "Animations", "Home · " + (HOME_NAMES[AnimConfig.home] ?: "Free fall"),
            Icons.Outlined.Bolt, Blue, Violet, Color(0xFF0A0A24),
            "animations motion home animation free fall page swipe transition drawer zoom fade press effect",
        ) { sub = "anim" },
        HubTile(
            "Icon packs", (state.iconPack.takeIf { it.isNotBlank() }?.let { pk ->
                runCatching { ctx.packageManager.getApplicationInfo(pk, 0).loadLabel(ctx.packageManager).toString() }.getOrNull()
            } ?: "Eon icons"),
            Icons.Outlined.Palette, Magenta, Coral, Color(0xFF240315),
            "icon packs custom icons rename names labels theme change icon",
        ) { sub = "icons" },
        HubTile(
            "Automations", if (Automations.list.none { it.enabled }) "None yet" else "${Automations.list.count { it.enabled }} on",
            Icons.Outlined.Bolt, Blue, Violet, Color(0xFF0A0A24),
            "automations if then when headphones charger time schedule tasker shortcuts",
        ) { sub = "automations" },
        HubTile(
            "Focus", if (Focus.active.isEmpty()) "Off" else Focus.active,
            Icons.Outlined.Bolt, Violet, Magenta, Color(0xFF1A0A24),
            "focus mode work sleep schedule pages hide apps do not disturb",
        ) { sub = "focus" },
        HubTile(
            "Gestures", "Double tap · ${Act.label(GestureConfig.doubleTap, state.appsForLabels)}",
            Icons.Outlined.TouchApp, Color(0xFF5C9DFF), Violet, Color(0xFF05102A),
            "gestures double tap swipe down up left right two fingers lock screen notifications search recents",
        ) { sub = "gestures" },
        HubTile(
            "Notifications", (if (notifications) "Access granted" else "Access off") + " · " + BADGE_STYLES[BadgeStyle.mode],
            Icons.Outlined.Notifications, Magenta, Color(0xFFFF7A9E), Color(0xFF240315),
            "notifications dots counts badges access marker glow peek",
        ) { sub = "markers" },
        HubTile(
            "Hidden apps", "${state.hidden.size} hidden",
            Icons.Outlined.VisibilityOff, Coral, Color(0xFFFF9A5C), Color(0xFF2A0B05),
            "hidden apps hide show",
        ) { sub = "hidden" },
        HubTile(
            "About Eon", "$version · greeting",
            Icons.Outlined.AutoAwesome, Orange, Color(0xFFFFD23D), Color(0xFF2A1700),
            "about version greeting welcome",
        ) { sub = "about" },
    )
    val shown = tiles.filter { q.isEmpty() || it.title.lowercase().contains(q) || it.keywords.contains(q) }
    val quickWords = "theme light dark auto schedule night day look glassy flat black amoled panel icon placement grid free page indicator dots quick immersive fullscreen status bar"
    val showQuick = q.isEmpty() || quickWords.contains(q)

    Column(
        Modifier.fillMaxSize().background(Eon.Page).systemBarsPadding().padding(horizontal = 16.dp)
            .verticalScroll(rememberScrollState()),
    ) {
        Gap(12)
        HubHeader("Settings", onClose)
        Gap(18)

        // Search
        Row(
            Modifier.fillMaxWidth().height(48.dp).clip(CircleShape).background(Eon.P0)
                .border(1.dp, Eon.P2, CircleShape).padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Icon(Icons.Outlined.Search, null, tint = Eon.Muted, modifier = Modifier.size(20.dp))
            BasicTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                textStyle = TextStyle(color = Eon.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold),
                cursorBrush = SolidColor(Cyan),
                modifier = Modifier.weight(1f),
                decorationBox = { inner ->
                    Box(contentAlignment = Alignment.CenterStart) {
                        if (query.isEmpty()) Text("Search settings", color = Eon.Muted, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                        inner()
                    }
                },
            )
        }
        Gap(22)

        // Category tiles, two per row
        shown.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEachIndexed { col, t -> Box(Modifier.weight(1f)) { HubTileView(t, shown.indexOf(t) .coerceAtLeast(col)) } }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        if (shown.isEmpty() && !showQuick) {
            Text("Nothing matches \"$query\".", color = Eon.Muted, fontSize = 14.sp, modifier = Modifier.padding(4.dp))
        }

        if (showQuick) {
            Gap(10)
            Text(
                "QUICK SETTINGS", color = Eon.Muted, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.6.sp,
                modifier = Modifier.padding(start = 4.dp, bottom = 10.dp),
            )
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(PanelBg).border(1.dp, Eon.Line, RoundedCornerShape(24.dp))) {
                QuickRow("Look") {
                    Segmented(listOf("Glassy", "Flat", "Black"), when (state.look) { "flat" -> 1; "black" -> 2; else -> 0 }) {
                        state.chooseLook(when (it) { 1 -> "flat"; 2 -> "black"; else -> "glassy" })
                    }
                }
                QuickDivider()
                QuickRow("Theme") {
                    Segmented(listOf("Dark", "Light", "Auto"), when (state.theme) { "light" -> 1; "auto", "schedule" -> 2; else -> 0 }) {
                        state.chooseTheme(when (it) { 1 -> "light"; 2 -> if (state.theme == "schedule") "schedule" else "auto"; else -> "dark" })
                    }
                }
                if (state.theme == "auto" || state.theme == "schedule") {
                    QuickDivider()
                    QuickRow("Auto follows") {
                        Segmented(listOf("Phone", "Schedule"), if (state.theme == "schedule") 1 else 0) {
                            state.chooseTheme(if (it == 1) "schedule" else "auto")
                        }
                    }
                }
                if (state.theme == "schedule") {
                    QuickDivider()
                    QuickRow("Light from") {
                        HourStepper(state.themeFrom) { state.chooseThemeHours(it, state.themeTo) }
                    }
                    QuickDivider()
                    QuickRow("Dark from") {
                        HourStepper(state.themeTo) { state.chooseThemeHours(state.themeFrom, it) }
                    }
                }
                QuickDivider()
                QuickRow("Colours") {
                    Segmented(listOf("Eon", "Wallpaper"), if (state.materialYou) 1 else 0) { state.chooseMaterialYou(it == 1) }
                }
                QuickDivider()
                QuickRow("Predicted apps") {
                    Segmented(listOf("Off", "On"), if (state.predicted) 1 else 0) { state.choosePredicted(it == 1) }
                }
                QuickDivider()
                QuickRow("Desk mode") {
                    Segmented(listOf("Off", "Charging", "Landscape"), when (DeskConfig.mode) { "charging" -> 1; "landscape" -> 2; else -> 0 }) {
                        DeskConfig.chooseMode(when (it) { 1 -> "charging"; 2 -> "landscape"; else -> "" })
                    }
                }
                if (DeskConfig.mode.isNotEmpty()) DeskPhotosRow()
                QuickDivider()
                QuickRow("Icon placement") {
                    Segmented(listOf("Grid", "Free"), if (state.freeIcons) 1 else 0) { state.chooseFreeIcons(it == 1) }
                }
                QuickDivider()
                QuickRow("Drawer style") {
                    Segmented(listOf("Bar", "Library"), if (state.drawerStyle == "library") 1 else 0) { state.chooseDrawerStyle(if (it == 1) "library" else "bar") }
                }
                QuickDivider()
                QuickRow("Immersive mode") {
                    GradientSwitch(state.immersive) { state.chooseImmersive(it) }
                }
                QuickDivider()
                QuickRow("Page indicator") {
                    GradientSwitch(HomeConfig.indicator) {
                        HomeConfig.indicator = it
                        state.saveHome()
                    }
                }
            }
        }

        Gap(22)
        Row(
            Modifier.align(Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Box(Modifier.size(width = 36.dp, height = 3.dp).clip(CircleShape).background(Rainbow))
            Text("Eon $version", color = Eon.Muted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
        Gap(28)
    }
    }
}

@Composable
private fun HubHeader(title: String, onBack: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        Box(
            Modifier.size(44.dp).clip(CircleShape).background(Eon.P1).border(1.dp, Eon.P2, CircleShape)
                .clickable(onClick = onBack),
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Outlined.ArrowBack, "Back", tint = Eon.Text, modifier = Modifier.size(22.dp)) }
        Text(title, color = Eon.Text, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
private fun HubTileView(t: HubTile, index: Int = 0) {
    val shape = RoundedCornerShape(24.dp)
    Column(
        Modifier.staggerIn(index / 2).pressScale().fillMaxWidth().height(132.dp).clip(shape).background(PanelBg)
            .border(1.dp, t.from.copy(alpha = 0.4f), shape)
            .clickable(onClick = t.onClick).padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
            Box(
                Modifier.size(42.dp).clip(RoundedCornerShape(14.dp))
                    .background(Brush.linearGradient(listOf(t.from, t.to))),
                contentAlignment = Alignment.Center,
            ) { Icon(t.icon, null, tint = t.ink, modifier = Modifier.size(22.dp)) }
            Text("›", color = t.from, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Column {
            Text(t.title, color = Eon.Text, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
            Text(t.status, color = Eon.Muted, fontSize = 13.sp, maxLines = 1, modifier = Modifier.padding(top = 2.dp))
        }
    }
}

@Composable
private fun QuickRow(title: String, control: @Composable () -> Unit) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 66.dp).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(title, color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        control()
    }
}

/** Minus, the hour as 07:00, plus. Wraps around midnight. */
@Composable
private fun HourStepper(hour: Int, onChange: (Int) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(36.dp).clip(CircleShape).background(Eon.P1).clickable { onChange((hour + 23) % 24) },
            contentAlignment = Alignment.Center,
        ) { Text("\u2212", color = Eon.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        Text(
            hour.toString().padStart(2, '0') + ":00", color = Eon.Text, fontSize = 15.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.width(62.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
        Box(
            Modifier.size(36.dp).clip(CircleShape).background(Eon.P1).clickable { onChange((hour + 1) % 24) },
            contentAlignment = Alignment.Center,
        ) { Text("+", color = Eon.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun QuickDivider() {
    Box(Modifier.padding(horizontal = 16.dp).fillMaxWidth().height(1.dp).background(Eon.Line))
}

/** A small switch between two or three options; the chosen one is filled with the rainbow gradient. */
@Composable
private fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier.clip(RoundedCornerShape(15.dp)).background(Eon.P1).padding(3.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        options.forEachIndexed { i, label ->
            val on = i == selected
            Box(
                Modifier.height(40.dp).clip(RoundedCornerShape(12.dp))
                    .then(if (on) Modifier.background(Eon.Button) else Modifier)
                    .clickable { onSelect(i) }.padding(horizontal = 17.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    label, color = if (on) Color(0xFF0A0A0C) else Eon.Soft, fontSize = 13.sp,
                    fontWeight = if (on) FontWeight.ExtraBold else FontWeight.Bold,
                )
            }
        }
    }
}

@Composable
private fun GradientSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    Box(
        Modifier.size(width = 52.dp, height = 32.dp).clip(CircleShape)
            .background(if (checked) Eon.Button else SolidColor(Eon.P2))
            .clickable { onChange(!checked) }.padding(4.dp),
        contentAlignment = if (checked) Alignment.CenterEnd else Alignment.CenterStart,
    ) {
        Box(Modifier.size(24.dp).clip(CircleShape).background(if (checked) Color.White else Eon.Muted))
    }
}

/** Hub > Gestures. */
@Composable
private fun GesturesPage(state: EonState, onBack: () -> Unit) {
    val ctx = LocalContext.current
    BackHandler { onBack() }
    // The helper can be turned on in Android's settings, so look again when coming back.
    var tick by remember { mutableIntStateOf(0) }
    DisposableEffect(Unit) {
        val owner = (ctx as ComponentActivity).lifecycle
        val observer = LifecycleEventObserver { _, event -> if (event == Lifecycle.Event.ON_RESUME) tick++ }
        owner.addObserver(observer)
        onDispose { owner.removeObserver(observer) }
    }
    val helperOn = remember(tick) { EonAccessibilityService.enabled }
    Column(
        Modifier.fillMaxSize().background(Eon.Page).systemBarsPadding().padding(horizontal = 16.dp)
            .verticalScroll(rememberScrollState()),
    ) {
        Gap(12)
        HubHeader("Gestures", onBack)
        Gap(22)
        SettingsSectionLabel("HOME SCREEN")
        GestureRow("Swipe up", "On empty space.", GestureConfig.swipeUp, state) { GestureConfig.swipeUp = it; state.saveGestures() }
        GestureRow("Swipe down", "On empty space.", GestureConfig.swipeDown, state) { GestureConfig.swipeDown = it; state.saveGestures() }
        GestureRow("Double tap", "On empty space.", GestureConfig.doubleTap, state) { GestureConfig.doubleTap = it; state.saveGestures() }
        GestureRow("Two fingers up", "Anywhere on the home screen.", GestureConfig.twoUp, state) { GestureConfig.twoUp = it; state.saveGestures() }
        GestureRow("Two fingers down", "Anywhere on the home screen.", GestureConfig.twoDown, state) { GestureConfig.twoDown = it; state.saveGestures() }
        GestureRow("Shake the phone", "Shake it three times while Eon is on screen.", GestureConfig.shake, state) { GestureConfig.shake = it; state.saveGestures() }
        GestureRow("Double knock", "Knock twice on the phone. Experimental: it may need a firm tap.", GestureConfig.knock, state) { GestureConfig.knock = it; state.saveGestures() }
        Row(
            Modifier.fillMaxWidth().padding(top = 6.dp).clip(RoundedCornerShape(20.dp)).background(Eon.P0)
                .border(1.dp, Eon.Line, RoundedCornerShape(20.dp))
                .clickable { state.ensureStack(POPUP_STACK); state.stackConfig = POPUP_STACK }.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f).padding(end = 12.dp)) {
                Text("Popup widgets", color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Pick widgets here, then give an icon, folder or widget the action Popup widget.",
                    color = Eon.Muted, fontSize = 13.sp,
                )
            }
            Text("Manage", color = Eon.Accent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        }
        Gap(14)
        SettingsSectionLabel("APPS, FOLDERS AND WIDGETS")
        Text(
            "Every app, folder and widget can have its own swipe up, down, left and right and a double tap. " +
                "Long-press an app and choose Gestures. For a folder, open it and choose Gestures. For a widget, " +
                "long-press it and open the Gestures tab. A swipe on an icon wins over swiping the pages, " +
                "so only the directions you set are taken.",
            color = Eon.Muted, fontSize = 13.sp, lineHeight = 18.sp, modifier = Modifier.padding(start = 4.dp, bottom = 14.dp),
        )
        Gap(6)
        SettingsSectionLabel("GESTURE HELPER")
        Text(
            "Turning off the screen, showing recent apps and opening the toggle panel need Eon's gesture helper, " +
                "an Android accessibility service. It cannot read anything on your screen. " +
                if (helperOn) "It is on." else "It is off: turn it on under Installed apps > Eon gesture helper.",
            color = Eon.Muted, fontSize = 13.sp, lineHeight = 18.sp, modifier = Modifier.padding(start = 4.dp, bottom = 12.dp),
        )
        if (!helperOn) {
            Box(
                Modifier.padding(start = 4.dp).clip(CircleShape).background(Eon.Button)
                    .clickable { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                    .padding(horizontal = 20.dp, vertical = 11.dp),
            ) { Text("Open accessibility settings", color = Eon.OnAccent, fontSize = 14.sp, fontWeight = FontWeight.Bold) }
        }
        Gap(8)
        Text(
            "Lock screen (device admin) is the older way to turn the screen off. Android asks the first time. " +
                "To undo it, turn Eon off under Settings > Security > Device admin apps.",
            color = Eon.Muted, fontSize = 13.sp, lineHeight = 18.sp,
            modifier = Modifier.padding(start = 4.dp, top = 10.dp, bottom = 14.dp),
        )
        Gap(20)
    }
}

/** One home screen gesture: its name, what it does now, and a tap to choose something else. */
@Composable
private fun GestureRow(title: String, subtitle: String, current: String, state: EonState, onPick: (String) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(bottom = 10.dp).clip(RoundedCornerShape(20.dp)).background(Eon.P0)
            .border(1.dp, Eon.P2, RoundedCornerShape(20.dp))
            .clickable { state.actionPicker = ActionRequest(title, current, onPick) }
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Eon.Faint, fontSize = 12.sp)
        }
        Text(
            Act.label(current, state.appsForLabels), color = if (current == Act.NONE) Eon.Faint else Eon.Accent,
            fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
            modifier = Modifier.widthIn(max = 160.dp),
        )
    }
}

/** Hub > Hidden apps. */
@Composable
private fun HiddenAppsPage(state: EonState, onBack: () -> Unit) {
    BackHandler { onBack() }
    Column(Modifier.fillMaxSize().background(Eon.Page).systemBarsPadding().padding(horizontal = 16.dp)) {
        Gap(12)
        HubHeader("Hidden apps", onBack)
        Gap(22)
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(PanelBg)
                .border(1.dp, Coral.copy(alpha = 0.4f), RoundedCornerShape(24.dp)).padding(16.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Hidden apps", color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text("${state.hidden.size} hidden", color = Eon.Muted, fontSize = 13.sp)
                }
                if (state.hidden.isNotEmpty()) {
                    Box(
                        Modifier.height(40.dp).clip(CircleShape).background(Brush.horizontalGradient(listOf(Coral, Orange)))
                            .clickable { state.showAllApps() }.padding(horizontal = 18.dp),
                        contentAlignment = Alignment.Center,
                    ) { Text("Show all", color = Color(0xFF2A0B05), fontSize = 14.sp, fontWeight = FontWeight.ExtraBold) }
                }
            }
            Gap(10)
            Text(
                "Hide an app by long-pressing it in the drawer. Hidden apps stay installed; they just do not show in Eon.",
                color = Eon.Faint, fontSize = 12.sp, lineHeight = 17.sp,
            )
        }
    }
}

/** Hub > About Eon. */
@Composable
private fun AboutPage(version: String, onResetGreeting: () -> Unit, onBack: () -> Unit) {
    BackHandler { onBack() }
    Column(Modifier.fillMaxSize().background(Eon.Page).systemBarsPadding().padding(horizontal = 16.dp)) {
        Gap(12)
        HubHeader("About Eon", onBack)
        Gap(22)
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(PanelBg)
                .border(1.dp, Orange.copy(alpha = 0.4f), RoundedCornerShape(24.dp)),
        ) {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Version", color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text(version, color = Eon.Muted, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
            QuickDivider()
            Row(
                Modifier.fillMaxWidth().clickable(onClick = onResetGreeting).padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Show the greeting again", color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text("Replay the welcome", color = Eon.Muted, fontSize = 13.sp)
                }
                Text("›", color = Orange, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
        }
        Gap(18)
        Box(Modifier.align(Alignment.CenterHorizontally).size(width = 96.dp, height = 3.dp).clip(CircleShape).background(Rainbow))
    }
}

private val HOME_NAMES = mapOf("none" to "None", "fade" to "Fade", "rise" to "Rise", "fall" to "Free fall", "pop" to "Pop")
