package ix.app.eon

import android.content.Intent
import android.graphics.Bitmap
import android.provider.Settings
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.activity.compose.BackHandler
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat

/** The marker styles, in the order of [BadgeStyle.mode]. */
val BADGE_STYLES = listOf("Rainbow dot", "Glow", "Label dot", "Count in label", "Off")

/** How an app with unread notifications is marked on the home screen, in the dock and in the drawer. */
object BadgeStyle {
    var mode by mutableIntStateOf(0)
    /** Show the latest notification at the top of an app's long-press menu. */
    var peek by mutableStateOf(true)

    fun load(p: Prefs) {
        mode = p.getInt("badgeStyle", 0).coerceIn(0, BADGE_STYLES.size - 1)
        peek = p.getBool("badgePeek", true)
    }

    fun save(p: Prefs) {
        p.putInt("badgeStyle", mode)
        p.putBool("badgePeek", peek)
    }

    /** Styles that need a visible label fall back to the rainbow dot when labels are hidden. */
    fun effective(showLabel: Boolean): Int = if ((mode == 2 || mode == 3) && !showLabel) 0 else mode
}

/** A bright, saturated colour taken from an icon, used for the glow and the label dot. */
fun iconAccent(img: ImageBitmap, fallback: Color): Color = try {
    val raw = img.asAndroidBitmap()
    val soft = if (raw.config == Bitmap.Config.HARDWARE) raw.copy(Bitmap.Config.ARGB_8888, false) else raw
    val s = Bitmap.createScaledBitmap(soft, 12, 12, true)
    val hsv = FloatArray(3)
    var best = 0f
    var pick = floatArrayOf(0f, 0f, 0f)
    for (y in 0 until 12) for (x in 0 until 12) {
        val p = s.getPixel(x, y)
        if (android.graphics.Color.alpha(p) < 200) continue
        android.graphics.Color.colorToHSV(p, hsv)
        val score = hsv[1] * hsv[2]
        if (score > best) { best = score; pick = hsv.copyOf() }
    }
    if (best < 0.15f) fallback else {
        pick[1] = pick[1].coerceAtLeast(0.45f)
        pick[2] = pick[2].coerceAtLeast(0.9f)
        Color(android.graphics.Color.HSVToColor(pick))
    }
} catch (_: Exception) {
    fallback
}

/** A soft halo behind an icon that slowly breathes. */
@Composable
fun Modifier.noticeGlow(color: Color): Modifier {
    val t = rememberInfiniteTransition(label = "noticeGlow")
    val a by t.animateFloat(
        0.55f, 1f,
        infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "a",
    )
    return drawBehind {
        val r = size.minDimension / 2f
        val reach = r * 1.6f
        drawCircle(
            brush = Brush.radialGradient(
                0f to color.copy(alpha = 0.75f * a),
                (r / reach) to color.copy(alpha = 0.6f * a),
                1f to Color.Transparent,
                center = center, radius = reach,
            ),
            radius = reach, center = center,
        )
    }
}

/** The numbered dot: a rainbow ring around a red centre, tucked into the icon's top corner. */
@Composable
fun RainbowDot(count: Int, modifier: Modifier = Modifier) {
    // One digit is a perfect circle; two or more grow sideways into a pill of the same height.
    Box(
        modifier.then(if (count < 10) Modifier.size(21.dp) else Modifier.height(21.dp).widthIn(min = 21.dp))
            .clip(CircleShape)
            .background(
                Brush.sweepGradient(
                    listOf(
                        Color(0xFFFF5A5F), Color(0xFFFFB84D), Color(0xFF5FE08A),
                        Color(0xFF4DC3FF), Color(0xFFB27CFF), Color(0xFFFF5A5F),
                    ),
                ),
            )
            .padding(2.dp),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            (if (count < 10) Modifier.size(17.dp) else Modifier.height(17.dp).widthIn(min = 17.dp))
                .clip(CircleShape).background(Color(0xFFD6264A)),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                if (count > 99) "99+" else "$count", color = Color.White,
                fontSize = 10.sp, fontWeight = FontWeight.Bold,
                // A line exactly as tall as the text, so the number sits in the middle and never stretches the dot.
                style = androidx.compose.ui.text.TextStyle(
                    lineHeight = 10.sp,
                    lineHeightStyle = androidx.compose.ui.text.style.LineHeightStyle(
                        androidx.compose.ui.text.style.LineHeightStyle.Alignment.Center,
                        androidx.compose.ui.text.style.LineHeightStyle.Trim.Both,
                    ),
                ),
                modifier = Modifier.padding(horizontal = 3.dp),
            )
        }
    }
}

/** A line of the long-press menu: the newest notification from the app. */
@Composable
fun NotificationPeek(app: AppEntry) {
    val peek = Badges.latest[app.packageName] ?: return
    val count = Badges.counts[app.packageName] ?: 0
    val ago = android.text.format.DateUtils.getRelativeTimeSpanString(
        peek.time, System.currentTimeMillis(), android.text.format.DateUtils.MINUTE_IN_MILLIS,
    ).toString()
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(16.dp)).background(Eon.ov(0x1A)).padding(horizontal = 14.dp, vertical = 10.dp),
    ) {
        if (peek.title.isNotBlank()) {
            Text(peek.title, color = Eon.Text, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (peek.text.isNotBlank()) {
            Text(peek.text, color = Eon.Soft, fontSize = 13.sp, lineHeight = 17.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
        }
        Text(
            (if (count > 1) "$count notifications · " else "") + ago,
            color = Eon.Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp),
        )
    }
}

/** Settings > Notifications: how apps with unread notifications are marked. */
@Composable
fun MarkersPage(state: EonState, onBack: () -> Unit) {
    BackHandler { onBack() }
    val ctx = LocalContext.current
    val granted = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    val sample = state.appsForLabels.take(4)
    val counts = listOf(3, 1, 0, 12)

    Column(Modifier.fillMaxSize().background(Eon.Page).systemBarsPadding().padding(horizontal = 20.dp)) {
        Gap(12)
        PageHeader("Notifications", onBack)
        Gap(14)
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()),
        ) {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Eon.P1).padding(vertical = 22.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
            ) {
                if (sample.isEmpty()) {
                    Text("Your apps show here", color = Eon.Muted, fontSize = 13.sp)
                } else {
                    sample.forEachIndexed { i, app ->
                        AppIconBody(app, 52.dp, true, previewCount = counts.getOrElse(i) { 0 })
                    }
                }
            }
            Gap(18)
            SettingsSectionLabel("MARKER")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BADGE_STYLES.forEachIndexed { i, label ->
                    val on = i == BadgeStyle.mode
                    Box(
                        Modifier.height(40.dp).clip(CircleShape).accentFill(on, Eon.P1)
                            .clickable { BadgeStyle.mode = i; state.saveBadges() }.padding(horizontal = 20.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(label, color = if (on) Eon.OnAccent else Eon.Text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Text(
                when (BadgeStyle.mode) {
                    0 -> "A numbered dot with a rainbow ring on the icon's corner."
                    1 -> "The icon glows softly in its own colour. Nothing sits on top of it."
                    2 -> "A dot before the name, and the name takes the icon's colour."
                    3 -> "The number sits in the name, like “Chat · 2”."
                    else -> "No marker. Notifications still arrive normally."
                } + if (BadgeStyle.mode in 2..3) " Needs icon labels turned on." else "",
                color = Eon.Faint, fontSize = 12.sp, modifier = Modifier.padding(start = 4.dp, top = 8.dp),
            )
            Gap(18)
            SettingsSectionLabel("LONG PRESS")
            Row(
                Modifier.fillMaxWidth().clickable { BadgeStyle.peek = !BadgeStyle.peek; state.saveBadges() }
                    .padding(horizontal = 4.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f).padding(end = 12.dp)) {
                    Text("Peek at the latest notification", color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text("Hold an icon to read its newest notification in the menu", color = Eon.Muted, fontSize = 12.sp, lineHeight = 16.sp)
                }
                EonSwitch(BadgeStyle.peek) { BadgeStyle.peek = it; state.saveBadges() }
            }
            Gap(18)
            SettingsSectionLabel("ACCESS")
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Eon.P1)
                    .clickable { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Notification access", color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text(
                        if (granted) "Granted. Eon can count and show notifications." else "Off. Eon cannot see notifications yet.",
                        color = Eon.Muted, fontSize = 12.sp,
                    )
                }
                Text("Open", color = Eon.Soft, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
            Gap(24)
        }
    }
}
