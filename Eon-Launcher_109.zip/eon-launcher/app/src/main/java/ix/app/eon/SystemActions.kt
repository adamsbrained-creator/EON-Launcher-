package ix.app.eon

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Bluetooth
import androidx.compose.material.icons.outlined.BrightnessAuto
import androidx.compose.material.icons.outlined.BrightnessHigh
import androidx.compose.material.icons.outlined.BrightnessLow
import androidx.compose.material.icons.outlined.DoNotDisturbOff
import androidx.compose.material.icons.outlined.DoNotDisturbOn
import androidx.compose.material.icons.outlined.FlashlightOn
import androidx.compose.material.icons.outlined.Nfc
import androidx.compose.material.icons.outlined.ScreenRotation
import androidx.compose.material.icons.outlined.Vibration
import androidx.compose.material.icons.outlined.VolumeOff
import androidx.compose.material.icons.outlined.VolumeUp
import androidx.compose.material.icons.outlined.Wifi
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * Things Eon can switch on the phone itself, usable from any gesture or automation. Android lets a normal app do only
 * some of this: the flashlight, Do Not Disturb, the ringer, auto-rotate and brightness are done directly (the last
 * three need you to allow it once, and Eon opens the right Android page when it is missing). Wi-Fi, Bluetooth, NFC and
 * volume cannot be switched by an app since Android 10, so those open Android's own small panel for one more tap.
 */
object SysAct {
    class Choice(val spec: String, val label: String, val icon: ImageVector)

    val CHOICES: List<Choice> = listOf(
        Choice("sys:torch", "Flashlight on or off", Icons.Outlined.FlashlightOn),
        Choice("sys:dnd:toggle", "Do Not Disturb: switch", Icons.Outlined.DoNotDisturbOn),
        Choice("sys:dnd:on", "Do Not Disturb: on", Icons.Outlined.DoNotDisturbOn),
        Choice("sys:dnd:off", "Do Not Disturb: off", Icons.Outlined.DoNotDisturbOff),
        Choice("sys:ringer:normal", "Ringer: sound", Icons.Outlined.VolumeUp),
        Choice("sys:ringer:vibrate", "Ringer: vibrate", Icons.Outlined.Vibration),
        Choice("sys:ringer:silent", "Ringer: silent", Icons.Outlined.VolumeOff),
        Choice("sys:rotate", "Auto-rotate on or off", Icons.Outlined.ScreenRotation),
        Choice("sys:bright:15", "Brightness: low", Icons.Outlined.BrightnessLow),
        Choice("sys:bright:50", "Brightness: medium", Icons.Outlined.BrightnessHigh),
        Choice("sys:bright:100", "Brightness: full", Icons.Outlined.BrightnessHigh),
        Choice("sys:bright:auto", "Brightness: automatic", Icons.Outlined.BrightnessAuto),
        Choice("sys:wifi", "Wi-Fi and internet panel", Icons.Outlined.Wifi),
        Choice("sys:bluetooth", "Bluetooth settings", Icons.Outlined.Bluetooth),
        Choice("sys:nfc", "NFC panel", Icons.Outlined.Nfc),
        Choice("sys:volume", "Volume panel", Icons.Outlined.VolumeUp),
    )

    fun label(spec: String): String = CHOICES.firstOrNull { it.spec == spec }?.label ?: "System action"

    private var torchOn = false
    private var torchWatching = false

    fun run(ctx: Context, spec: String) {
        try {
            when {
                spec == "sys:torch" -> toggleTorch(ctx)
                spec.startsWith("sys:dnd:") -> dnd(ctx, spec.removePrefix("sys:dnd:"))
                spec.startsWith("sys:ringer:") -> ringer(ctx, spec.removePrefix("sys:ringer:"))
                spec == "sys:rotate" -> rotate(ctx)
                spec.startsWith("sys:bright:") -> brightness(ctx, spec.removePrefix("sys:bright:"))
                spec == "sys:wifi" -> start(ctx, Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
                spec == "sys:bluetooth" -> start(ctx, Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                spec == "sys:nfc" -> start(ctx, Intent(Settings.Panel.ACTION_NFC))
                spec == "sys:volume" -> start(ctx, Intent(Settings.Panel.ACTION_VOLUME))
            }
        } catch (e: Exception) {
            toast(ctx, "That did not work on this phone")
        }
    }

    private fun toast(ctx: Context, text: String) = Toast.makeText(ctx, text, Toast.LENGTH_LONG).show()

    private fun start(ctx: Context, intent: Intent) {
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun toggleTorch(ctx: Context) {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            val c = cm.getCameraCharacteristics(it)
            c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        } ?: return
        if (!torchWatching) {
            torchWatching = true
            cm.registerTorchCallback(
                object : CameraManager.TorchCallback() {
                    override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                        if (cameraId == id) torchOn = enabled
                    }
                },
                null,
            )
        }
        torchOn = !torchOn
        cm.setTorchMode(id, torchOn)
    }

    private fun askPolicyAccess(ctx: Context) {
        toast(ctx, "Allow Eon under Do Not Disturb access, then try again")
        start(ctx, Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
    }

    private fun dnd(ctx: Context, mode: String) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) {
            askPolicyAccess(ctx)
            return
        }
        val turnOn = when (mode) {
            "on" -> true
            "off" -> false
            else -> nm.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_ALL
        }
        nm.setInterruptionFilter(
            if (turnOn) NotificationManager.INTERRUPTION_FILTER_PRIORITY else NotificationManager.INTERRUPTION_FILTER_ALL,
        )
    }

    private fun ringer(ctx: Context, mode: String) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        try {
            am.ringerMode = when (mode) {
                "vibrate" -> AudioManager.RINGER_MODE_VIBRATE
                "silent" -> AudioManager.RINGER_MODE_SILENT
                else -> AudioManager.RINGER_MODE_NORMAL
            }
        } catch (e: SecurityException) {
            // Silent needs Do Not Disturb access.
            askPolicyAccess(ctx)
        }
    }

    private fun askWriteSettings(ctx: Context) {
        toast(ctx, "Allow Eon to change system settings, then try again")
        start(ctx, Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + ctx.packageName)))
    }

    private fun rotate(ctx: Context) {
        if (!Settings.System.canWrite(ctx)) {
            askWriteSettings(ctx)
            return
        }
        val now = Settings.System.getInt(ctx.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0)
        Settings.System.putInt(ctx.contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (now == 1) 0 else 1)
    }

    private fun brightness(ctx: Context, value: String) {
        if (!Settings.System.canWrite(ctx)) {
            askWriteSettings(ctx)
            return
        }
        val cr = ctx.contentResolver
        if (value == "auto") {
            Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC)
        } else {
            val pct = (value.toIntOrNull() ?: 50).coerceIn(1, 100)
            Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, pct * 255 / 100)
        }
    }
}
