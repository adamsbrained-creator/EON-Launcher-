package ix.app.eon

import android.appwidget.AppWidgetProviderInfo
import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.launch

/** One widget you can add: one of Eon's own, or one an app provides. */
private class PW(
    val info: AppWidgetProviderInfo?,
    val builtin: Int,
    val label: String,
    val pkg: String,
    val app: String,
    val kind: String,
    val cols: Int,
    val rows: Int,
) {
    val key: String = info?.provider?.flattenToString() ?: "eon:$builtin"
    val size: String get() = if (cols == 0) "Responsive" else "$cols×$rows"
}

/** All the widgets of one app. */
private class AppGroup(val pkg: String, val name: String, val widgets: List<PW>)

private val KINDS = listOf("Clock", "Weather", "Music", "Calendar", "Battery", "Notes", "Photos", "Search", "News", "Tools", "Other")

/** Guesses what a widget is from its name and its app's name. Not perfect, which is why everything also stays listed by app. */
internal fun kindOf(label: String, app: String, pkg: String): String {
    val t = "$label $app $pkg".lowercase()
    fun has(vararg k: String) = k.any { t.contains(it) }
    return when {
        has("weather", "forecast", "accu", "rain", "temperature", "radar") -> "Weather"
        has("clock", "alarm", "timer", "stopwatch", "time") -> "Clock"
        has("music", "player", "song", "spotify", "podcast", "audio", "radio", "now playing", "playlist") -> "Music"
        has("calendar", "agenda", "schedule", "event", "week", "month") -> "Calendar"
        has("battery") -> "Battery"
        has("note", "memo", "todo", "to-do", "task", "keep", "journal") -> "Notes"
        has("photo", "gallery", "picture", "image", "album") -> "Photos"
        has("search", "assistant") -> "Search"
        has("news", "feed", "rss", "headline", "reader") -> "News"
        has("flashlight", "torch", "calculator", "wifi", "bluetooth", "toggle", "settings", "shortcut", "counter", "tool", "storage") -> "Tools"
        else -> "Other"
    }
}

private fun buildWidgets(ctx: Context, holder: WidgetHolder, allowStack: Boolean): List<PW> {
    val list = mutableListOf<PW>()
    // A stack holds other widgets, so it cannot go inside one.
    if (allowStack) list.add(PW(null, W_STACK_TILE, "Widget Stack", ctx.packageName, "Eon", "Tools", 0, 0))
    listOf(W_NOW_PLAYING, W_WEATHER, W_WEEK, W_AGENDA, W_BATTERY, W_ALARM, W_STORAGE, W_AI).forEach { id ->
        val (c, r) = builtinSize(id) ?: return@forEach
        val label = builtinLabel(id) ?: "Widget"
        list.add(PW(null, id, label, ctx.packageName, "Eon", kindOf(label, "", ""), c, r))
    }
    holder.providers(ctx).forEach { info ->
        val label = info.loadLabel(ctx.packageManager).toString()
        val app = holder.appLabel(ctx, info)
        val (c, r) = suggestSize(ctx, info)
        list.add(PW(info, 0, label, info.provider.packageName, app, kindOf(label, app, info.provider.packageName), c, r))
    }
    return list
}

private fun letterOf(name: String): Char {
    val c = name.trim().firstOrNull()?.uppercaseChar() ?: '#'
    return if (c in 'A'..'Z') c else '#'
}

/**
 * The widget picker: search, filter by what a widget is, and browse by app with an A–Z strip.
 * Tapping an app (or a widget) opens a sheet with its widgets; Add starts the usual add flow.
 */
@Composable
fun WidgetPicker(
    state: EonState,
    holder: WidgetHolder,
    allowStack: Boolean,
    onBack: () -> Unit,
    onManage: () -> Unit,
    onAddBuiltin: (Int) -> Unit,
    onAddProvider: (AppWidgetProviderInfo) -> Unit,
) {
    val ctx = LocalContext.current
    val all = remember(allowStack) { buildWidgets(ctx, holder, allowStack) }
    val groups = remember(all) {
        all.groupBy { it.pkg }.map { (pkg, l) -> AppGroup(pkg, l.first().app, l) }.sortedBy { it.name.lowercase() }
    }
    val groupByPkg = remember(groups) { groups.associateBy { it.pkg } }
    val byApp = remember(groups) { groups.filter { it.pkg != ctx.packageName } }
    val eon = remember(all) { all.filter { it.info == null } }
    var query by rememberSaveable { mutableStateOf("") }
    var kind by rememberSaveable { mutableStateOf("All") }
    var sheet by remember { mutableStateOf<Pair<AppGroup, String?>?>(null) }
    val q = query.trim().lowercase()
    val kindsPresent = remember(all) { KINDS.filter { k -> all.any { it.kind == k } } }

    BackHandler {
        when {
            sheet != null -> sheet = null
            query.isNotEmpty() -> query = ""
            kind != "All" -> kind = "All"
            else -> onBack()
        }
    }

    fun openWidget(w: PW) {
        groupByPkg[w.pkg]?.let { sheet = it to w.key }
    }

    Box(Modifier.fillMaxSize().background(Eon.Ink)) {
        Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 20.dp)) {
            Gap(12)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Box(
                    Modifier.size(44.dp).clip(CircleShape).background(Eon.P1).clickable(onClick = onBack),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Outlined.ArrowBack, "Back", tint = Eon.Text, modifier = Modifier.size(22.dp)) }
                Text("Widgets", color = Eon.Text, fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text(
                    "On this page · ${state.widgetItems().size}", color = Eon.Muted, fontSize = 13.sp, fontWeight = FontWeight.Medium,
                    modifier = Modifier.clip(CircleShape).background(Eon.P1).clickable(onClick = onManage)
                        .padding(horizontal = 14.dp, vertical = 9.dp),
                )
            }
            Gap(16)
            Row(
                Modifier.fillMaxWidth().height(48.dp).clip(CircleShape).background(Eon.P1).padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Icon(Icons.Outlined.Search, null, tint = Eon.Muted, modifier = Modifier.size(20.dp))
                BasicTextField(
                    value = query, onValueChange = { query = it }, singleLine = true,
                    textStyle = TextStyle(color = Eon.Text, fontSize = 16.sp), cursorBrush = SolidColor(Eon.Accent),
                    modifier = Modifier.weight(1f),
                    decorationBox = { inner ->
                        Box(contentAlignment = Alignment.CenterStart) {
                            if (query.isEmpty()) Text("Search widgets or apps", color = Eon.Muted, fontSize = 15.sp)
                            inner()
                        }
                    },
                )
                if (query.isNotEmpty()) {
                    Icon(
                        Icons.Outlined.Close, "Clear", tint = Eon.Muted,
                        modifier = Modifier.size(22.dp).clip(CircleShape).clickable { query = "" },
                    )
                }
            }
            if (q.isEmpty()) {
                Gap(14)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(listOf("All") + kindsPresent, key = { it }) { k -> PChip(k, kind == k) { kind = k } }
                }
            }
            Gap(14)
            when {
                q.isNotEmpty() -> {
                    val hits = all.filter {
                        it.label.lowercase().contains(q) || it.app.lowercase().contains(q) || it.kind.lowercase().contains(q)
                    }
                    val apps = groups.filter { g -> g.name.lowercase().contains(q) }
                    if (hits.isEmpty() && apps.isEmpty()) {
                        Text("Nothing found for “${query.trim()}”.", color = Eon.Muted, fontSize = 14.sp)
                    }
                    ResultsGrid(hits, apps, "WIDGETS · ${hits.size}", ::openWidget) { sheet = it to null }
                }
                kind != "All" -> {
                    val hits = all.filter { it.kind == kind }
                    ResultsGrid(hits, emptyList(), "${kind.uppercase()} · ${hits.size}", ::openWidget) { sheet = it to null }
                }
                else -> Browse(eon, byApp, ::openWidget, { w -> onAddBuiltin(w.builtin) }) { sheet = it to null }
            }
        }

        val s = sheet
        if (s != null) {
            AppSheet(
                group = s.first, initial = s.second, onClose = { sheet = null },
                onAdd = { w -> if (w.info != null) onAddProvider(w.info) else onAddBuiltin(w.builtin) },
            )
        }
    }
}

@Composable
private fun Browse(
    eon: List<PW>,
    byApp: List<AppGroup>,
    onWidget: (PW) -> Unit,
    onAddEon: (PW) -> Unit,
    onApp: (AppGroup) -> Unit,
) {
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val headerIndex = remember(byApp) {
        val m = LinkedHashMap<Char, Int>()
        var idx = 2
        var last = ' '
        byApp.forEach { g ->
            val c = letterOf(g.name)
            if (c != last) {
                m[c] = idx
                idx++
                last = c
            }
            idx++
        }
        m
    }
    val letters = remember(headerIndex) { headerIndex.keys.toList() }
    var active by remember { mutableStateOf<Char?>(null) }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(state = listState, modifier = Modifier.fillMaxSize().padding(end = 22.dp), contentPadding = PaddingValues(bottom = 40.dp)) {
            item(key = "eon") {
                // Eon's own widgets: one panel with a rainbow edge. Tap a row to see it, or the round button to add it right away.
                val panel = RoundedCornerShape(26.dp)
                Column(
                    Modifier.fillMaxWidth().clip(panel).background(Eon.P0).border(1.5.dp, Eon.Button, panel).padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Row(Modifier.padding(horizontal = 4.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Made by Eon", color = Eon.Text, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                        Text("${eon.size} widgets", color = Eon.Muted, fontSize = 12.sp)
                    }
                    eon.forEach { w ->
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Eon.P1)
                                .clickable { onWidget(w) }.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                        ) {
                            Preview(w, Modifier.size(width = 112.dp, height = 84.dp))
                            Column(Modifier.weight(1f)) {
                                Text(w.label, color = Eon.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text(w.size, color = Eon.Muted, fontSize = 12.sp)
                            }
                            Box(
                                Modifier.size(42.dp).clip(CircleShape).background(Eon.Button).clickable { onAddEon(w) },
                                contentAlignment = Alignment.Center,
                            ) { Icon(Icons.Outlined.Add, "Add ${w.label}", tint = Eon.OnAccent, modifier = Modifier.size(24.dp)) }
                        }
                    }
                }
                Gap(26)
            }
            item(key = "byapp") {
                Column {
                    SectionLabel("BY APP")
                    Gap(4)
                }
            }
            var last = ' '
            byApp.forEach { g ->
                val c = letterOf(g.name)
                if (c != last) {
                    last = c
                    item(key = "h$c") {
                        Text(
                            c.toString(), color = Eon.Accent, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(top = 14.dp, bottom = 2.dp),
                        )
                    }
                }
                item(key = "a${g.pkg}") { AppRow(g) { onApp(g) } }
            }
        }
        // The A–Z strip: touch and slide along it to jump.
        Column(
            Modifier.align(Alignment.CenterEnd).width(22.dp).fillMaxHeight(0.8f)
                .pointerInput(letters) {
                    awaitEachGesture {
                        val down = awaitFirstDown()
                        fun pick(y: Float) {
                            if (letters.isEmpty()) return
                            val i = (y / size.height * letters.size).toInt().coerceIn(0, letters.size - 1)
                            if (active != letters[i]) {
                                active = letters[i]
                                scope.launch { listState.scrollToItem(headerIndex[letters[i]] ?: 0) }
                            }
                        }
                        pick(down.position.y)
                        down.consume()
                        drag(down.id) { change ->
                            pick(change.position.y)
                            change.consume()
                        }
                        active = null
                    }
                },
            verticalArrangement = Arrangement.SpaceEvenly,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            letters.forEach { c ->
                Text(
                    c.toString(), fontSize = 10.sp, fontWeight = if (c == active) FontWeight.Bold else FontWeight.Normal,
                    color = if (c == active) Eon.Accent else Eon.Muted,
                )
            }
        }
        val a = active
        if (a != null) {
            Box(
                Modifier.align(Alignment.Center).size(72.dp).clip(CircleShape).background(Eon.Button),
                contentAlignment = Alignment.Center,
            ) { Text(a.toString(), color = Eon.OnAccent, fontSize = 32.sp, fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
private fun ResultsGrid(
    hits: List<PW>,
    apps: List<AppGroup>,
    title: String,
    onWidget: (PW) -> Unit,
    onApp: (AppGroup) -> Unit,
) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 40.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        if (hits.isNotEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) { SectionLabel(title) }
            gridItems(hits, key = { it.key }) { w -> WidgetCard(w, true, false) { onWidget(w) } }
        }
        if (apps.isNotEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) { SectionLabel("APPS · ${apps.size}") }
            gridItems(apps, key = { "g${it.pkg}" }, span = { GridItemSpan(maxLineSpan) }) { g -> AppRow(g) { onApp(g) } }
        }
    }
}

/** The sheet with one app's widgets. Pick one, then Add. */
@Composable
private fun AppSheet(group: AppGroup, initial: String?, onClose: () -> Unit, onAdd: (PW) -> Unit) {
    val slide = remember { Animatable(1f) }
    LaunchedEffect(Unit) { slide.animateTo(0f, tween(240)) }
    var sel by remember { mutableStateOf(initial ?: group.widgets.first().key) }
    var sizeFilter by remember { mutableStateOf("All") }
    val sizes = remember(group) { group.widgets.map { it.size }.distinct().sorted() }
    val shown = group.widgets.filter { sizeFilter == "All" || it.size == sizeFilter }
    val chosen = group.widgets.firstOrNull { it.key == sel } ?: group.widgets.first()

    Box(Modifier.fillMaxSize().background(Color(0x99000000)).pointerInput(Unit) { detectTapGestures { onClose() } }) {
        Box(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().fillMaxHeight(0.86f)
                .graphicsLayer { translationY = slide.value * size.height }
                .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                .background(Eon.P0)
                .pointerInput(Unit) { detectTapGestures { } },
        ) {
            Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
                Box(Modifier.padding(top = 10.dp).align(Alignment.CenterHorizontally).size(width = 40.dp, height = 4.dp).clip(CircleShape).background(Color(0xFF3A3B40)))
                Row(Modifier.padding(top = 18.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    PkgIcon(group.pkg, 48.dp)
                    Column(Modifier.weight(1f)) {
                        Text(group.name, color = Eon.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${group.widgets.size} widget" + (if (group.widgets.size == 1) "" else "s"), color = Eon.Muted, fontSize = 12.sp)
                    }
                    Box(
                        Modifier.size(40.dp).clip(CircleShape).background(Eon.P1).clickable(onClick = onClose),
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Outlined.Close, "Close", tint = Eon.Text, modifier = Modifier.size(20.dp)) }
                }
                if (sizes.size > 1) {
                    Gap(16)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(listOf("All") + sizes, key = { it }) { s -> PChip(s, sizeFilter == s) { sizeFilter = s } }
                    }
                }
                Gap(18)
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp),
                    contentPadding = PaddingValues(bottom = 120.dp),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    gridItems(shown, key = { it.key }) { w -> WidgetCard(w, false, w.key == sel) { sel = w.key } }
                }
            }
            Box(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 20.dp, vertical = 24.dp)
                    .navigationBarsPadding().height(54.dp).clip(CircleShape).background(Eon.Button)
                    .clickable { onAdd(chosen) },
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    "Add ${chosen.label} · ${chosen.size}", color = Eon.OnAccent, fontSize = 16.sp, fontWeight = FontWeight.Bold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(horizontal = 20.dp),
                )
            }
        }
    }
}

@Composable
private fun WidgetCard(w: PW, showApp: Boolean, selected: Boolean, onClick: () -> Unit) {
    Column(Modifier.clickable(onClick = onClick)) {
        Preview(
            w,
            Modifier.fillMaxWidth().height(104.dp).then(
                if (selected) Modifier.border(2.dp, Eon.Button, RoundedCornerShape(20.dp)) else Modifier,
            ),
        )
        Text(w.label, color = Eon.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 8.dp))
        Text(if (showApp) "${w.app} · ${w.size}" else w.size, color = Eon.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun AppRow(g: AppGroup, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(62.dp).clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        PkgIcon(g.pkg, 42.dp)
        Text(g.name, color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        Text(
            "${g.widgets.size}", color = Color(0xFFC9CBD1), fontSize = 13.sp,
            modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(Eon.P1).padding(horizontal = 11.dp, vertical = 4.dp),
        )
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(text, color = Eon.Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
}

@Composable
private fun PChip(label: String, on: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.height(36.dp).clip(CircleShape).accentFill(on, Eon.P1).clickable(onClick = onClick)
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = if (on) Eon.OnAccent else Color(0xFFC9CBD1), fontSize = 14.sp, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal)
    }
}

/** An app's icon, in Eon's icon shape. */
@Composable
private fun PkgIcon(pkg: String, size: Dp) {
    val ctx = LocalContext.current
    val bmp: ImageBitmap? = remember(pkg) {
        runCatching { IconShaper.shape(ctx.packageManager.getApplicationIcon(pkg), 96).asImageBitmap() }.getOrNull()
    }
    if (bmp != null) {
        Image(bmp, null, Modifier.size(size))
    } else {
        Box(Modifier.size(size).clip(RoundedCornerShape(11.dp)).background(Eon.P2))
    }
}

/** What a widget looks like: the app's own preview picture, or a small drawing for Eon's widgets. */
@Composable
private fun Preview(w: PW, modifier: Modifier) {
    val ctx = LocalContext.current
    val info = w.info
    if (info == null) {
        EonPreview(w.builtin, modifier)
        return
    }
    val bmp: ImageBitmap? = remember(w.key) {
        runCatching {
            val d = info.loadPreviewImage(ctx, 0)
            if (d == null) {
                null
            } else {
                val iw = d.intrinsicWidth.coerceAtLeast(1)
                val ih = d.intrinsicHeight.coerceAtLeast(1)
                d.toBitmap(360, (360f * ih / iw).toInt().coerceIn(60, 360)).asImageBitmap()
            }
        }.getOrNull()
    }
    Box(modifier.clip(RoundedCornerShape(20.dp)).background(Eon.P1), contentAlignment = Alignment.Center) {
        if (bmp != null) {
            Image(bmp, null, Modifier.fillMaxSize().padding(8.dp), contentScale = ContentScale.Fit)
        } else {
            PkgIcon(w.pkg, 40.dp)
        }
    }
}

@Composable
private fun EonPreview(id: Int, modifier: Modifier) {
    val shape = RoundedCornerShape(20.dp)
    when (id) {
        W_WEATHER -> Box(
            modifier.clip(shape).background(Brush.linearGradient(listOf(Color(0xFF5B9BF5), Color(0xFF2F6FD6)))).padding(14.dp),
            contentAlignment = Alignment.BottomStart,
        ) {
            Column {
                Text("23°", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                Text("Cloudy", color = Color.White, fontSize = 12.sp)
            }
        }
        W_STACK_TILE -> Box(modifier.clip(shape).background(Eon.P1)) {
            Row(Modifier.fillMaxSize().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Spacer(Modifier.width(8.dp))
                Box(Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(16.dp)).background(Color(0xFF2B2D31)))
                Spacer(Modifier.width(8.dp))
                Box(Modifier.width(40.dp).fillMaxHeight().clip(RoundedCornerShape(topStart = 16.dp, bottomStart = 16.dp)).background(Color(0xFF34363B)))
            }
            Row(Modifier.align(Alignment.BottomCenter).padding(bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                repeat(3) { i -> Box(Modifier.size(5.dp).clip(CircleShape).background(if (i == 0) Color.White else Color(0xFF6A6C72))) }
            }
        }
        W_NOW_PLAYING -> Box(
            modifier.clip(shape).background(Brush.linearGradient(listOf(Color(0xFFD9482F), Color(0xFFA6231A)))).padding(14.dp),
            contentAlignment = Alignment.BottomStart,
        ) {
            Column {
                Text("Take it", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Box(Modifier.padding(top = 10.dp).fillMaxWidth().height(3.dp).clip(CircleShape).background(Color(0x59FFFFFF))) {
                    Box(Modifier.fillMaxWidth(0.6f).height(3.dp).background(Color.White))
                }
            }
        }
        W_AI -> Box(
            modifier.clip(CircleShape).background(Color(0x99202124)).border(1.dp, Color(0x33FFFFFF), CircleShape).padding(horizontal = 14.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text("Gemini  \u2304", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        }
        W_AGENDA, W_BATTERY, W_ALARM, W_STORAGE -> Box(
            modifier.clip(shape).background(Brush.verticalGradient(listOf(Color(0xFF1E1F22), Color(0xFF0E0F10))))
                .border(1.dp, Color(0x40FFFFFF), shape).padding(14.dp),
            contentAlignment = Alignment.BottomStart,
        ) {
            Column {
                Text(
                    when (id) { W_AGENDA -> "09:30  Stand-up"; W_BATTERY -> "82%"; W_ALARM -> "07:00"; else -> "64 GB free" },
                    color = Color.White, fontSize = if (id == W_AGENDA) 14.sp else 24.sp, fontWeight = FontWeight.Bold,
                )
                Text(
                    when (id) { W_AGENDA -> "12:00  Lunch"; W_BATTERY -> "Battery"; W_ALARM -> "Next alarm"; else -> "of 128 GB" },
                    color = Color(0xFFB5B8BF), fontSize = 12.sp,
                )
            }
        }
        else -> Box(
            modifier.clip(shape).background(Eon.P0).border(1.dp, Eon.P2, shape).padding(14.dp),
            contentAlignment = Alignment.BottomStart,
        ) {
            Column {
                Text("12:46", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                Text("Fri, 12", color = Eon.Muted, fontSize = 12.sp)
            }
        }
    }
}
