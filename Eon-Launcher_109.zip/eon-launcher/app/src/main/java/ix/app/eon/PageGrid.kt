package ix.app.eon

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateOffsetAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.VectorConverter
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateIntOffsetAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitLongPressOrCancellation
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import kotlin.math.roundToInt

val CELL_HEIGHT: Dp = 92.dp

/**
 * One home page as a grid of 4 columns. Apps and widgets sit on cells.
 * Long-press an app and drag it to any free cell (or onto another app to swap).
 * Long-press and release without moving opens the app menu; long-press on empty space opens the home menu.
 */
@Composable
fun PageGrid(
    page: PageData,
    pageIndex: Int,
    state: EonState,
    apps: List<AppEntry>,
    widgets: WidgetHolder,
    drag: DragState,
    onTap: (AppEntry) -> Unit,
    onMenu: (AppEntry) -> Unit,
    onEmptyLongPress: () -> Unit,
    modifier: Modifier = Modifier,
    onDoubleTap: () -> Unit = {},
    onAction: (String) -> Unit = {},
) {
    val density = LocalDensity.current
    val haptic = LocalHapticFeedback.current
    // Where this page is on screen, so a lifted icon can be handed to Home in screen coordinates.
    var pageRoot by remember { mutableStateOf(Offset.Zero) }
    val latestApps by rememberUpdatedState(apps)
    val latestTap by rememberUpdatedState(onTap)
    val latestMenu by rememberUpdatedState(onMenu)
    val latestEmpty by rememberUpdatedState(onEmptyLongPress)
    val latestDouble by rememberUpdatedState(onDoubleTap)
    val latestAction by rememberUpdatedState(onAction)

    BoxWithConstraints(
        modifier.fillMaxSize().onGloballyPositioned { pageRoot = it.positionInRoot() }.pointerInput(Unit) { detectTapGestures(
            onLongPress = { if (state.editing == null && !state.widgetTouch) latestEmpty() },
            onDoubleTap = { latestDouble() },
        ) },
    ) {
        val cellW = constraints.maxWidth.toFloat() / GRID_COLS
        val cellH = state.cellHeightPx
        val cellWDp = with(density) { cellW.toDp() }
        val cellHDp = with(density) { cellH.toDp() }
        val rows = state.gridRows
        val editItem = page.items.firstOrNull { it.kind == "w" && it.key == state.editing }
        // Where each thing comes in the home animation: top-left first, bottom-right last (the dock comes after).
        val introRows = maxOf(rows, 1).toFloat()

        val gridAlpha by animateFloatAsState(
            if (drag.fromHome || editItem != null) 1f else 0f, tween(160), label = "grid",
        )
        if (gridAlpha > 0.01f) GridOverlay(cellW, cellH, rows, gridAlpha)

        page.items.toList().forEach { item ->
            key(item.kind + item.key) {
                if (item.kind == "w") {
                    val id = item.key.toIntOrNull()
                    if (id != null) {
                        Box(
                            Modifier
                                .offset { IntOffset((item.col * cellW).roundToInt(), (item.row * cellH).roundToInt()) }
                                .size(DpSize(cellWDp * item.w, cellHDp * item.h))
                                .zIndex(item.z.toFloat())
                                .homeIntro(
                                    ((item.row + item.col / GRID_COLS.toFloat()) / introRows).coerceIn(0f, 1f) * 0.85f,
                                    (item.row + item.h) * cellH,
                                )
                                .padding(4.dp)
                                .pointerInput(item.key) {
                                    // Long-press a widget to edit it. Watching before the widget sees the touch
                                    // (Initial pass) means this works even over widgets that handle touches.
                                    // The same watching gives widgets their swipes and double tap.
                                    var lastTapAt = 0L
                                    val wTarget = "w:${item.key}"
                                    awaitEachGesture {
                                        val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                                        // Tells the page this touch belongs to a widget, so it does not open the home menu too.
                                        state.widgetTouch = true
                                        try {
                                        if (state.editing == item.key) return@awaitEachGesture
                                        val dbl = ItemGestures.get(wTarget, G_DOUBLE)
                                        if (dbl != null && lastTapAt != 0L &&
                                            down.uptimeMillis - lastTapAt < viewConfiguration.doubleTapTimeoutMillis
                                        ) {
                                            // The second tap: the widget does not get it.
                                            lastTapAt = 0L
                                            down.consume()
                                            while (true) {
                                                val ev = awaitPointerEvent(PointerEventPass.Initial)
                                                ev.changes.forEach { it.consume() }
                                                if (ev.changes.none { it.pressed }) break
                                            }
                                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                            latestAction(dbl)
                                            return@awaitEachGesture
                                        }
                                        var cancelled = false
                                        withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
                                            while (!cancelled) {
                                                val ev = awaitPointerEvent(PointerEventPass.Initial)
                                                val c = ev.changes.firstOrNull { it.id == down.id }
                                                if (c == null || !c.pressed ||
                                                    (c.position - down.position).getDistance() > viewConfiguration.touchSlop
                                                ) {
                                                    cancelled = true
                                                }
                                            }
                                        }
                                        if (!cancelled) {
                                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                            state.editing = item.key
                                            // Take over the rest of the touch so the widget does not also react to it.
                                            while (true) {
                                                val ev = awaitPointerEvent(PointerEventPass.Initial)
                                                ev.changes.forEach { it.consume() }
                                                if (ev.changes.none { it.pressed }) break
                                            }
                                        } else {
                                            val now = currentEvent.changes.firstOrNull { it.id == down.id }
                                            if (now != null && !now.pressed) {
                                                // Lifted without moving: remember the tap in case a second one follows.
                                                if ((now.position - down.position).getDistance() <= viewConfiguration.touchSlop) {
                                                    lastTapAt = now.uptimeMillis
                                                }
                                            } else {
                                                trackSwipe(down, wTarget, PointerEventPass.Initial, {}) { act ->
                                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                                    latestAction(act)
                                                }
                                            }
                                        }
                                        } finally {
                                            state.widgetTouch = false
                                        }
                                    }
                                },
                        ) {
                            val wDp = (cellWDp * item.w).value.toInt() - 8
                            val hDp = (cellHDp * item.h).value.toInt() - 8
                            if (isStackId(id)) StackView(widgets, state, id, wDp, hDp) else WidgetView(widgets, id, wDp, hDp)
                        }
                    }
                } else {
                    val app = if (item.kind == "a") apps.firstOrNull { it.key == item.key } else null
                    if (app != null || item.kind == "f") {
                        val slot = Offset(item.col * cellW, item.row * cellH)
                        // The icon glides to its slot when it is moved.
                        val glide = remember { Animatable(slot, Offset.VectorConverter) }
                        LaunchedEffect(slot) {
                            glide.animateTo(slot, spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMedium))
                        }
                        // While lifted, the icon is drawn by the drag layer over the whole screen, so this one hides.
                        val lifted = drag.fromHome && (drag.app?.key == item.key || drag.folder?.key == item.key)
                        // The icon follows a swipe a little, then springs back.
                        var nudge by remember { mutableStateOf(Offset.Zero) }
                        val nudged by animateOffsetAsState(nudge, spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMedium), label = "nudge")
                        Box(
                            Modifier
                                .offset { IntOffset(glide.value.x.roundToInt(), glide.value.y.roundToInt()) }
                                .size(DpSize(cellWDp, cellHDp))
                                .zIndex(item.z.toFloat())
                                .homeIntro(
                                    ((item.row + item.col / GRID_COLS.toFloat()) / introRows).coerceIn(0f, 1f) * 0.85f,
                                    (item.row + 1f) * cellH,
                                )
                                .graphicsLayer { alpha = if (lifted) 0f else 1f; translationX = nudged.x; translationY = nudged.y }
                                .pointerInput(item.key) {
                                    val target = (if (item.kind == "f") "f:" else "a:") + item.key
                                    awaitEachGesture {
                                        val down = awaitFirstDown(requireUnconsumed = false)
                                        down.consume()
                                        val press = awaitLongPressOrCancellation(down.id)
                                        if (press == null) {
                                            val ev = currentEvent.changes.firstOrNull { it.id == down.id }
                                            if (ev != null && !ev.pressed &&
                                                (ev.position - down.position).getDistance() < viewConfiguration.touchSlop * 2
                                            ) {
                                                val dbl = ItemGestures.get(target, G_DOUBLE)
                                                if (dbl != null && secondTap()) {
                                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                                    latestAction(dbl)
                                                } else if (item.kind == "f" && item.pair && item.members.size == 2) {
                                                    latestAction(Act.PAIR + item.members[0] + "|" + item.members[1])
                                                } else if (item.kind == "f") {
                                                    state.openFolder = item.key
                                                } else {
                                                    latestApps.firstOrNull { it.key == item.key }?.let { latestTap(it) }
                                                }
                                            } else if (ev != null && ev.pressed) {
                                                trackSwipe(down, target, PointerEventPass.Main, { nudge = it }) { act ->
                                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                                    latestAction(act)
                                                }
                                            }
                                            return@awaitEachGesture
                                        }
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        // Hand the finger to Home, which follows it across pages and drops the icon.
                                        // Letting go without moving still opens the menu (or the folder).
                                        val here = currentEvent.changes.firstOrNull { it.id == down.id }?.position ?: down.position
                                        val root = pageRoot + Offset(item.col * cellW, item.row * cellH) + here
                                        drag.pendingApp = if (item.kind == "f") null else latestApps.firstOrNull { it.key == item.key }
                                        drag.pendingFolder = if (item.kind == "f") item else null
                                        drag.onClick = {
                                            if (item.kind == "f") state.openFolder = item.key
                                            else latestApps.firstOrNull { it.key == item.key }?.let { latestMenu(it) }
                                        }
                                        drag.started = false
                                        drag.travelled = 0f
                                        drag.pos = root
                                        drag.last = root
                                        drag.pointer = down.id
                                    }
                                },
                            contentAlignment = Alignment.Center,
                        ) {
                            if (app != null) {
                                AppIconBody(
                                    app, HomeConfig.iconDp.dp, HomeConfig.showLabels,
                                    HomeConfig.labelSp, HomeConfig.twoLine,
                                )
                            } else {
                                FolderIconBody(
                                    item, apps, HomeConfig.iconDp.dp, HomeConfig.showLabels,
                                    HomeConfig.labelSp, HomeConfig.twoLine,
                                )
                            }
                        }
                    }
                }
            }
        }

    }
}
