package ix.app.eon

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Process
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Calendar
import kotlin.math.abs

/** The cyan to blue fill of the selected tab and other small buttons in the App Library. */
internal fun libGrad2(): Brush = Eon.dynamic?.let { Brush.linearGradient(listOf(it.primary, it.tertiary)) }
    ?: Brush.linearGradient(listOf(Color(0xFF35D6F0), Color(0xFF5C9DFF)))

/** The cyan, blue and violet fill of the selected sort chip and of Done. */
internal fun libGrad3(): Brush = Eon.dynamic?.let { Brush.horizontalGradient(listOf(it.primary, it.secondary, it.tertiary)) }
    ?: Brush.horizontalGradient(listOf(Color(0xFF35D6F0), Color(0xFF5C9DFF), Color(0xFF9B7BFF)))

internal val LibPink = Color(0xFFF25CCB)

/** A coloured fill with the colour of the glyph that sits on it. */
internal class LibTint(val a: Color, val b: Color, val ink: Color)

private val TintCyan = LibTint(Color(0xFF6BEAFC), Color(0xFF1F9DC4), Color(0xFF0A0A0B))
private val TintBlue = LibTint(Color(0xFF7BAEFF), Color(0xFF3566E0), Color(0xFFFFFFFF))
private val TintViolet = LibTint(Color(0xFFB195FF), Color(0xFF6A47E0), Color(0xFFFFFFFF))
private val TintPink = LibTint(Color(0xFFFF86DA), Color(0xFFC93A9E), Color(0xFF0A0A0B))
private val TintOrange = LibTint(Color(0xFFFFC066), Color(0xFFE8801A), Color(0xFF0A0A0B))
private val TintDark = LibTint(Color(0xFF41444C), Color(0xFF16171A), Color(0xFFF5F5F6))
private val TintAll = listOf(TintCyan, TintBlue, TintViolet, TintPink, TintOrange)

/** The colour of a box's round badge in its sheet. The usual boxes always get the same one. */
internal fun libTintFor(id: String): LibTint = when (id) {
    "social", "contacts" -> TintViolet
    "media", "music", "entertainment" -> TintPink
    "productivity", "reading", "~recent" -> TintOrange
    "games" -> TintBlue
    "tools", "internet" -> TintCyan
    "~other", "other" -> TintDark
    else -> TintAll[abs(id.hashCode()) % TintAll.size]
}

/**
 * How long each app has been on screen today, for the "1h 12m today" pill and the box sheets. Android only shares this
 * with an app the user has switched on in Settings > Usage access, so until then [granted] is false and the Library
 * shows a pill that opens that page. Kept in memory only and never sent anywhere.
 */
object ScreenTime {
    var granted by mutableStateOf(false)
        private set

    /** Milliseconds on screen today per package. */
    val today = mutableStateMapOf<String, Long>()

    /** Everything today except Eon itself. */
    var total by mutableLongStateOf(0L)
        private set

    fun hasAccess(ctx: Context): Boolean = try {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        } else {
            @Suppress("DEPRECATION")
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        }
        mode == AppOpsManager.MODE_ALLOWED
    } catch (_: Exception) {
        false
    }

    /** Looks again: whether access is on, and if so how long each app has been open since midnight. */
    suspend fun refresh(ctx: Context) {
        if (!hasAccess(ctx)) {
            granted = false
            today.clear()
            total = 0L
            return
        }
        val sums = withContext(Dispatchers.Default) { read(ctx) }
        granted = true
        today.clear()
        today.putAll(sums)
        total = sums.entries.filter { it.key != ctx.packageName }.sumOf { it.value }
    }

    private fun read(ctx: Context): Map<String, Long> {
        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager ?: return emptyMap()
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val now = System.currentTimeMillis()
        val sums = HashMap<String, Long>()
        try {
            val events = usm.queryEvents(cal.timeInMillis, now)
            val e = UsageEvents.Event()
            val open = HashMap<String, Long>()
            while (events.hasNextEvent()) {
                events.getNextEvent(e)
                val pkg = e.packageName ?: continue
                when (e.eventType) {
                    // 1 is "activity resumed" (an app comes to the front), 2 is "activity paused" (it leaves).
                    1 -> open[pkg] = e.timeStamp
                    2 -> open.remove(pkg)?.let { sums[pkg] = (sums[pkg] ?: 0L) + (e.timeStamp - it).coerceAtLeast(0L) }
                }
            }
            // Whatever is open right now has been open since it came to the front.
            open.forEach { (p, t) -> sums[p] = (sums[p] ?: 0L) + (now - t).coerceAtLeast(0L) }
        } catch (_: Exception) {
        }
        return sums
    }

    /** "1h 12m", or "12m" under an hour. */
    fun format(ms: Long): String {
        val m = ms / 60_000L
        val h = m / 60L
        return if (h > 0) "${h}h ${m % 60L}m" else "${m}m"
    }

    /** Opens Android's Usage access page, where Eon can be switched on. */
    fun openSettings(ctx: Context) {
        try {
            ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
        }
    }
}
