package ix.app.eon

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

/**
 * Four apps above the dock that you are likely to want now. They come from the launch log Eon already keeps: launches
 * around this time of day over the last month count most, and everything else counts a little. Apps already in the dock
 * are left out. Nothing leaves the phone.
 */
@Composable
fun PredictedRow(
    state: EonState,
    apps: List<AppEntry>,
    onTap: (AppEntry) -> Unit,
    onMenu: (AppEntry) -> Unit,
    modifier: Modifier = Modifier,
) {
    var slot by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(300_000L)
            slot++
        }
    }
    val inDock = state.dock.flatMap { p -> p.items.filter { it.kind == "a" }.map { it.key } }.toSet()
    val tick = Usage.tick
    val picks = remember(slot, tick, apps, inDock) {
        val byKey = apps.associateBy { it.key }
        Usage.predict(4, inDock).mapNotNull { byKey[it] }
    }
    if (picks.isEmpty()) return
    Row(
        modifier.fillMaxWidth().padding(horizontal = 28.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(26.dp)).background(Color(0x38FFFFFF)).padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        picks.forEach { app ->
            Image(
                bitmap = app.icon, contentDescription = app.label,
                modifier = Modifier.size(46.dp).pointerInput(app.key) {
                    detectTapGestures(onTap = { onTap(app) }, onLongPress = { onMenu(app) })
                },
            )
        }
    }
}

/** A small window with one widget over the home screen, opened by the "Popup widget" action. Tap outside or go back to close it. */
@Composable
fun PopupWidgetLayer(state: EonState, holder: WidgetHolder) {
    val id = state.popupWidget ?: return
    BackHandler { state.popupWidget = null }
    Box(
        Modifier.fillMaxSize().background(Color(0x66000000)).pointerInput(Unit) { detectTapGestures { state.popupWidget = null } },
        contentAlignment = Alignment.Center,
    ) {
        BoxWithConstraints(
            Modifier.fillMaxWidth(0.88f).height(200.dp).clip(RoundedCornerShape(28.dp)).background(Color(0xE6101012))
                .pointerInput(Unit) { detectTapGestures { } },
        ) {
            WidgetView(holder, id, maxWidth.value.toInt(), 200)
        }
    }
}

/** The name of a widget in the popup list. */
fun popupLabel(ctx: android.content.Context, id: Int): String = when {
    id == W_WEATHER -> "Weather"
    builtinLabel(id) != null -> builtinLabel(id) ?: "Widget"
    id > 0 -> runCatching {
        android.appwidget.AppWidgetManager.getInstance(ctx).getAppWidgetInfo(id)?.loadLabel(ctx.packageManager)?.toString()
    }.getOrNull() ?: "Widget"
    else -> "Widget"
}

/** How far the back gesture has been dragged (0 to 1) while it is shrinking the settings or the app drawer. */
object PredictiveBack {
    var settings by mutableFloatStateOf(0f)
    var drawer by mutableFloatStateOf(0f)
}

/** Shrinks, rounds and fades a screen as the back gesture is dragged, like Android's predictive back. */
fun Modifier.backShrink(progress: Float): Modifier = this.graphicsLayer {
    val s = 1f - 0.1f * progress
    scaleX = s
    scaleY = s
    alpha = 1f - 0.3f * progress
    if (progress > 0f) {
        shape = RoundedCornerShape((28f * progress).dp)
        clip = true
    }
}
