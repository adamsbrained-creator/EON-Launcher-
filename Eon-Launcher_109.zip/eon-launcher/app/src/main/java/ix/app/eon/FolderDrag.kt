package ix.app.eon

import androidx.compose.animation.core.animateIntOffsetAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.*
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.math.roundToInt


/**
 * What an open home folder needs to let an app be pulled out of it onto the home screen. Home provides this (see
 * [LocalFolderOut]); folders that do not get one (the drawer's) only reorder.
 * [onDrop] is called with the finger in root coordinates when it is let go, [onCancel] if the touch is interrupted.
 */
class FolderOut(val drag: DragState, val onDrop: (Offset) -> Unit, val onCancel: () -> Unit) {
    /** The app leaves the folder: Home draws it under the finger, and the folder hides. */
    fun begin(app: AppEntry, pos: Offset) {
        drag.pendingApp = null
        drag.pendingFolder = null
        drag.onClick = null
        drag.folder = null
        drag.app = app
        drag.pos = pos
        drag.last = pos
        drag.started = true
        drag.fromHome = true
        drag.folderOut = true
    }
}

val LocalFolderOut = compositionLocalOf<FolderOut?> { null }

/** Where a folder grid is on screen, kept up to date by the grid itself (plain fields: no need to redraw on change). */
class FolderGridSpot {
    /** The scrolling window the apps are seen through, in root coordinates. */
    var view = Rect.Zero
    /** The top-left of the full grid inside it (it moves when the grid is scrolled), in root coordinates. */
    var origin = Offset.Zero
}

fun Modifier.trackFolderView(spot: FolderGridSpot): Modifier =
    onGloballyPositioned { spot.view = Rect(it.positionInRoot(), Size(it.size.width.toFloat(), it.size.height.toFloat())) }

fun Modifier.trackFolderGrid(spot: FolderGridSpot): Modifier =
    onGloballyPositioned { spot.origin = it.positionInRoot() }

/** True once the finger has gone well past the edge of the folder's grid: that is the moment the app leaves the folder. */
fun pulledOutOfFolder(root: Offset, spot: FolderGridSpot, marginPx: Float): Boolean =
    spot.view.width > 0f && !spot.view.inflate(marginPx).contains(root)

/**
 * The apps of a folder in a grid you can rearrange: tap opens an app, hold one and it lifts (you feel a buzz), then
 * drag it and the others make room. Lift and let go without moving and you get its menu, as before.
 * [members] is the folder's own list of app keys, so the new order is the folder's order; [onCommit] saves it.
 */
@Composable
fun FolderDragGrid(
    members: SnapshotStateList<String>,
    apps: List<AppEntry>,
    maxHeight: Dp,
    onLaunch: (AppEntry) -> Unit,
    onMenu: (AppEntry) -> Unit,
    onCommit: () -> Unit,
    cols: Int = 4,
    iconDp: Dp = 52.dp,
    rowGap: Dp = 12.dp,
) {
    val density = LocalDensity.current
    val haptic = LocalHapticFeedback.current
    val ordered = members.mapNotNull { k -> apps.firstOrNull { it.key == k } }
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val cellW = maxWidth / cols
        val cellH = iconDp + 24.dp + rowGap
        val rows = ((ordered.size + cols - 1) / cols).coerceAtLeast(1)
        val wPx = with(density) { cellW.toPx() }
        val hPx = with(density) { cellH.toPx() }
        var dragKey by remember { mutableStateOf<String?>(null) }
        var dragPos by remember { mutableStateOf(Offset.Zero) }
        val folderOut = LocalFolderOut.current
        val curOut by rememberUpdatedState(folderOut)
        val spot = remember { FolderGridSpot() }
        val outMargin = with(density) { 56.dp.toPx() }
        val curApps by rememberUpdatedState(apps)
        val curLaunch by rememberUpdatedState(onLaunch)
        val curMenu by rememberUpdatedState(onMenu)
        val curCommit by rememberUpdatedState(onCommit)
        Box(Modifier.heightIn(max = maxHeight).trackFolderView(spot).verticalScroll(rememberScrollState())) {
            // One gesture detector for the whole grid. It never moves, so finger positions stay in a steady
            // coordinate space. (When each icon listened for itself, the listener moved along with the icon being
            // dragged, so the measured finger movement dropped to zero and the icon stuck in place.)
            Box(
                Modifier.fillMaxWidth().height(cellH * rows).trackFolderGrid(spot)
                    .pointerInput(cols, wPx, hPx) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            val hit = (down.position.y / hPx).toInt().coerceAtLeast(0) * cols +
                                (down.position.x / wPx).toInt().coerceIn(0, cols - 1)
                            val key = members.getOrNull(hit) ?: return@awaitEachGesture
                            val app = curApps.firstOrNull { it.key == key } ?: return@awaitEachGesture
                            val slop = viewConfiguration.touchSlop
                            // A quick lift is a tap, a swipe is a scroll, and holding still is a long press.
                            var tap = false
                            val still = withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
                                while (true) {
                                    val ev = awaitPointerEvent()
                                    val ch = ev.changes.firstOrNull { it.id == down.id }
                                    if (ch == null || ch.isConsumed) return@withTimeoutOrNull false
                                    if (!ch.pressed) { tap = true; return@withTimeoutOrNull false }
                                    if ((ch.position - down.position).getDistance() > slop) return@withTimeoutOrNull false
                                }
                            }
                            if (still != null) {
                                if (tap) curLaunch(app)
                                return@awaitEachGesture
                            }
                            // Long press: the app lifts.
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            val start = members.indexOf(key).coerceAtLeast(0)
                            dragPos = Offset((start % cols) * wPx, (start / cols) * hPx)
                            dragKey = key
                            var total = Offset.Zero
                            var moved = false
                            var out = false
                            var released = false
                            var rootNow = spot.origin + down.position
                            try {
                                while (true) {
                                    val ev = awaitPointerEvent()
                                    val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                                    // Read the movement before consuming: once a touch is consumed, positionChange() says zero.
                                    val d = ch.position - ch.previousPosition
                                    ch.consume()
                                    rootNow = spot.origin + ch.position
                                    if (!ch.pressed) { released = true; break }
                                    total += d
                                    if (!moved && total.getDistance() > slop) moved = true
                                    val fo = curOut
                                    if (fo != null && moved && !out && pulledOutOfFolder(rootNow, spot, outMargin)) {
                                        // Pulled out of the folder: from here Home carries the app to where it is dropped.
                                        out = true
                                        dragKey = null
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        fo.begin(app, rootNow)
                                    }
                                    if (out) {
                                        fo?.drag?.pos = rootNow
                                    } else if (moved) {
                                        dragPos += d
                                        val cx = (dragPos.x + wPx / 2f) / wPx
                                        val cy = (dragPos.y + hPx / 2f) / hPx
                                        val n = members.size
                                        val target = (cy.toInt().coerceAtLeast(0) * cols + cx.toInt().coerceIn(0, cols - 1))
                                            .coerceIn(0, n - 1)
                                        val cur = members.indexOf(key)
                                        if (cur >= 0 && target != cur) {
                                            members.add(target, members.removeAt(cur))
                                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        }
                                    }
                                }
                            } finally {
                                dragKey = null
                                // The touch was interrupted while the app was out: put it back rather than lose it.
                                if (out && !released) curOut?.onCancel?.invoke()
                            }
                            if (out) {
                                if (released) curOut?.onDrop?.invoke(rootNow)
                            } else if (moved) curCommit() else curMenu(app)
                        }
                    },
            ) {
                ordered.forEachIndexed { i, app ->
                    key(app.key) {
                        val slot = IntOffset(((i % cols) * wPx).roundToInt(), ((i / cols) * hPx).roundToInt())
                        val settled by animateIntOffsetAsState(slot, spring(dampingRatio = 0.8f, stiffness = 520f), label = "dslot")
                        val lifted = dragKey == app.key
                        Box(
                            Modifier
                                .offset { if (lifted) IntOffset(dragPos.x.roundToInt(), dragPos.y.roundToInt()) else settled }
                                .size(cellW, cellH)
                                .zIndex(if (lifted) 1f else 0f)
                                .graphicsLayer {
                                    val s = if (lifted) 1.1f else 1f
                                    scaleX = s
                                    scaleY = s
                                    alpha = if (lifted) 0.94f else 1f
                                },
                            contentAlignment = Alignment.TopCenter,
                        ) {
                            AppIconBody(app, iconDp, true)
                        }
                    }
                }
            }
        }
    }
}
