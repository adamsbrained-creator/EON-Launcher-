package ix.app.eon

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Article
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.SwapHoriz
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.Dp
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * What lies beyond the home pages. Swiping right on the first page opens [left], swiping left on the last page opens
 * [right]. Each is an action, so it can be Google's feed, Eon's feed, the app page, the search page or anything else.
 */
object PageSlots {
    var left by mutableStateOf(Act.GOOGLE_FEED)
    var right by mutableStateOf(Act.FEED)

    fun load(p: Prefs) {
        // Older versions had one choice, which feed a swipe right opens.
        val googleFirst = p.getBool("gFeedFirst", true)
        left = p.getString("slotLeft").ifEmpty { if (googleFirst) Act.GOOGLE_FEED else Act.FEED }
        right = p.getString("slotRight").ifEmpty { if (googleFirst) Act.FEED else Act.GOOGLE_FEED }
    }

    fun save(p: Prefs) {
        p.putString("slotLeft", left)
        p.putString("slotRight", right)
    }
}

/** The picture for what a direction opens, when it has no drawing of its own. */
private fun slotIcon(spec: String): ImageVector = when (spec) {
    Act.NOTIF -> Icons.Outlined.Notifications
    Act.SEARCH -> Icons.Outlined.Search
    Act.DRAWER -> Icons.Outlined.GridView
    Act.FEED -> Icons.Outlined.Article
    else -> Icons.Outlined.Tune
}

/** A short name that fits on a card. */
private fun shortLabel(spec: String, apps: List<AppEntry>): String = when (spec) {
    Act.GOOGLE_FEED -> "Google feed"
    Act.FEED -> "Eon feed"
    Act.DRAWER -> "App page"
    Act.SEARCH -> "Search page"
    Act.NOTIF -> "Notifications"
    Act.PANEL -> "Toggle panel"
    Act.RECENTS -> "Recent apps"
    Act.LOCK -> "Lock screen"
    Act.SCREEN_OFF -> "Screen off"
    Act.SETTINGS -> "Preferences"
    Act.NONE -> "Add a page"
    else -> Act.label(spec, apps)
}

/** Settings > Page manager: Home in the middle, the page each direction leads to around it, each drawn as a small picture. */
@Composable
fun PageManagerScreen(state: EonState, apps: List<AppEntry>, onBack: () -> Unit) {
    BackHandler { onBack() }
    Column(
        Modifier.fillMaxSize().background(Eon.Page.copy(alpha = 1f)).systemBarsPadding().padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Gap(12)
        Box(Modifier.fillMaxWidth()) { PageHeader("Page manager", onBack) }
        Gap(8)
        Text(
            "Tap a card to choose what that direction opens.",
            color = Eon.Muted, fontSize = 14.sp, modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
        )
        // The cross is sized from the room there is, so every card shows in full on any screen.
        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
            val link = 24.dp
            val cardW: Dp = ((maxWidth - link * 2) / 3).coerceAtMost(116.dp)
            val cardH: Dp = minOf(cardW * 1.45f, (maxHeight - link * 2) / 3)
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                SlotCard("Swipe up", GestureConfig.swipeUp, apps, state, "Swipe up", cardW, cardH) { GestureConfig.swipeUp = it; state.saveGestures() }
                Arrow(90f, GestureConfig.swipeUp != Act.NONE, link)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SlotCard("Swipe right", PageSlots.left, apps, state, "Swipe right on the first page", cardW, cardH) {
                        PageSlots.left = it; state.savePageSlots()
                    }
                    Arrow(0f, PageSlots.left != Act.NONE, link)
                    HomeCard(state.pages.size, cardW, cardH)
                    Arrow(180f, PageSlots.right != Act.NONE, link)
                    SlotCard("Swipe left", PageSlots.right, apps, state, "Swipe left on the last page", cardW, cardH) {
                        PageSlots.right = it; state.savePageSlots()
                    }
                }
                Arrow(270f, GestureConfig.swipeDown != Act.NONE, link)
                SlotCard("Swipe down", GestureConfig.swipeDown, apps, state, "Swipe down", cardW, cardH) { GestureConfig.swipeDown = it; state.saveGestures() }
            }
        }
        Row(
            Modifier.clip(CircleShape).background(Eon.P1).border(1.dp, Eon.Line, CircleShape).clickable {
                val l = PageSlots.left
                PageSlots.left = PageSlots.right
                PageSlots.right = l
                state.savePageSlots()
            }.padding(horizontal = 16.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Outlined.SwapHoriz, null, tint = Eon.Text, modifier = Modifier.size(18.dp))
            Text("  Swap left and right", color = Eon.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
        Gap(10)
        Text(
            "Right and left happen past the first and last home page. Up and down are the same gestures as in Settings > Gestures.",
            color = Eon.Faint, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
        )
        Gap(14)
    }
}

/** A short arrow from Home towards a card. [degrees] 0 points left, 180 right, 90 down, 270 up. */
@Composable
private fun Arrow(degrees: Float, on: Boolean, size: Dp) {
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Icon(
            Icons.Outlined.ArrowBack, null, tint = if (on) Eon.Accent else Eon.Faint,
            modifier = Modifier.size(16.dp).rotate(degrees),
        )
    }
}

@Composable
private fun Bar(w: Dp, h: Dp = 5.dp, alpha: Float = 0.45f) {
    Box(Modifier.width(w).height(h).clip(RoundedCornerShape(h)).background(Eon.Text.copy(alpha = alpha)))
}

/** A small drawing of what a card opens. */
@Composable
private fun Mini(spec: String) {
    when (spec) {
        Act.GOOGLE_FEED -> Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("G", color = Eon.Accent, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            Bar(34.dp, 6.dp)
            Bar(26.dp, 4.dp, 0.3f)
        }
        Act.FEED -> Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Box(Modifier.width(40.dp).height(18.dp).clip(RoundedCornerShape(5.dp)).background(Eon.Accent.copy(alpha = 0.55f)))
            Bar(34.dp, 4.dp)
            Bar(24.dp, 4.dp, 0.3f)
        }
        Act.DRAWER -> Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            repeat(3) {
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    repeat(4) { Box(Modifier.size(7.dp).clip(RoundedCornerShape(2.dp)).background(Eon.Text.copy(alpha = 0.55f))) }
                }
            }
        }
        Act.SEARCH -> Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Bar(40.dp, 9.dp, 0.5f)
            Bar(34.dp, 4.dp, 0.3f)
            Bar(28.dp, 4.dp, 0.3f)
        }
        Act.NONE -> Text("+", color = Eon.Accent, fontSize = 26.sp, fontWeight = FontWeight.Light)
        else -> Icon(slotIcon(spec), null, tint = Eon.Text, modifier = Modifier.size(24.dp))
    }
}

@Composable
private fun HomeCard(pages: Int, w: Dp, h: Dp) {
    Column(
        Modifier.width(w).height(h).clip(RoundedCornerShape(22.dp))
            .background(Brush.verticalGradient(listOf(Eon.P2, Eon.P1)))
            .border(1.5.dp, Eon.Accent, RoundedCornerShape(22.dp)).padding(horizontal = 8.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        Text("Home", color = Eon.Text, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
        // A little home screen: icons and a dock.
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp)) {
            repeat(2) {
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    repeat(3) { Box(Modifier.size(9.dp).clip(RoundedCornerShape(3.dp)).background(Eon.Text.copy(alpha = 0.6f))) }
                }
            }
            Bar(30.dp, 7.dp, 0.25f)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                repeat(pages.coerceIn(1, 6)) { i ->
                    Box(Modifier.size(if (i == 0) 7.dp else 5.dp).clip(CircleShape).background(if (i == 0) Eon.Text else Eon.Faint))
                }
            }
            Gap(3)
            Text("$pages ${if (pages == 1) "page" else "pages"}", color = Eon.Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun SlotCard(
    direction: String, spec: String, apps: List<AppEntry>, state: EonState, pickerTitle: String,
    w: Dp, h: Dp, onPick: (String) -> Unit,
) {
    val empty = spec == Act.NONE
    Column(
        Modifier.width(w).height(h).clip(RoundedCornerShape(22.dp)).background(Eon.P0)
            .border(1.dp, if (empty) Eon.Faint else Eon.Line, RoundedCornerShape(22.dp))
            .clickable { state.actionPicker = ActionRequest(pickerTitle, spec, onPick) }
            .padding(horizontal = 6.dp, vertical = 9.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(direction, color = Eon.Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 1)
        Box(
            Modifier.fillMaxWidth().weight(1f).padding(vertical = 6.dp).clip(RoundedCornerShape(14.dp)).background(Eon.P2),
            contentAlignment = Alignment.Center,
        ) { Mini(spec) }
        Text(
            shortLabel(spec, apps), color = Eon.Text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis,
        )
        Text("Change", color = Eon.Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}
