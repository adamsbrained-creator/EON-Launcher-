package ix.app.eon

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Call
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Message
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/** How an app is matched by the search box. Used by both drawers. */
object SearchIndex {
    fun norm(s: String): String =
        java.text.Normalizer.normalize(s, java.text.Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "").lowercase()

    private fun initials(label: String): String =
        norm(label).split(Regex("[^\\p{L}\\p{N}]+")).filter { it.isNotEmpty() }.joinToString("") { it.take(1) }

    /**
     * Every word of the search must be in the app's name, its original name (before you renamed it) or, from four
     * letters on, its package name. Two or more letters also match the first letters of the words: gm finds Google Maps.
     */
    fun matches(app: AppEntry, q: String): Boolean {
        val nq = norm(q.trim())
        if (nq.isEmpty()) return true
        val names = norm(app.label + " " + app.originalLabel)
        val hay = if (nq.length >= 4) names + " " + norm(app.packageName) else names
        val words = nq.split(' ').filter { it.isNotEmpty() }
        if (words.all { hay.contains(it) }) return true
        return nq.length >= 2 && !nq.contains(' ') && initials(app.label).startsWith(nq)
    }
}

/** The last searches you ran from a result. Kept on the phone only. */
object RecentSearches {
    val items = mutableStateListOf<String>()
    private var prefs: Prefs? = null

    fun load(p: Prefs) {
        prefs = p
        items.clear()
        items.addAll(p.getString("recentSearches").split("\n").filter { it.isNotBlank() }.take(8))
    }

    fun add(q: String) {
        val t = q.trim()
        if (t.length < 2) return
        items.remove(t)
        items.add(0, t)
        while (items.size > 8) items.removeAt(items.size - 1)
        prefs?.putString("recentSearches", items.joinToString("\n"))
    }

    fun clear() {
        items.clear()
        prefs?.putString("recentSearches", "")
    }
}

/** Lets a search result open one of Eon's own settings pages. Home fills it in. */
object SearchBridge {
    var openEonSettings: (String) -> Unit = {}
}

private class SettingsHit(val title: String, val words: String, val action: String?, val eonPage: String?)

private val SETTINGS_HITS = listOf(
    SettingsHit("Wi-Fi", "wifi wi-fi internet network", "android.settings.WIFI_SETTINGS", null),
    SettingsHit("Bluetooth", "bluetooth pair headphones", "android.settings.BLUETOOTH_SETTINGS", null),
    SettingsHit("Display", "display brightness screen dark mode font size", "android.settings.DISPLAY_SETTINGS", null),
    SettingsHit("Sound", "sound volume ringtone vibration", "android.settings.SOUND_SETTINGS", null),
    SettingsHit("Battery", "battery power saver usage", "android.intent.action.POWER_USAGE_SUMMARY", null),
    SettingsHit("Storage", "storage space memory", "android.settings.INTERNAL_STORAGE_SETTINGS", null),
    SettingsHit("Apps", "apps applications manage uninstall", "android.settings.APPLICATION_SETTINGS", null),
    SettingsHit("Default apps", "default apps home launcher browser", "android.settings.MANAGE_DEFAULT_APPS_SETTINGS", null),
    SettingsHit("Location", "location gps", "android.settings.LOCATION_SOURCE_SETTINGS", null),
    SettingsHit("Accessibility", "accessibility talkback", "android.settings.ACCESSIBILITY_SETTINGS", null),
    SettingsHit("Date and time", "date time clock timezone", "android.settings.DATE_SETTINGS", null),
    SettingsHit("Language", "language locale region", "android.settings.LOCALE_SETTINGS", null),
    SettingsHit("Keyboard", "keyboard input typing", "android.settings.INPUT_METHOD_SETTINGS", null),
    SettingsHit("Airplane mode", "airplane flight mode", "android.settings.AIRPLANE_MODE_SETTINGS", null),
    SettingsHit("Security", "security lock screen fingerprint password", "android.settings.SECURITY_SETTINGS", null),
    SettingsHit("Privacy", "privacy permissions", "android.settings.PRIVACY_SETTINGS", null),
    SettingsHit("Wallpaper", "wallpaper background", "android.intent.action.SET_WALLPAPER", null),
    SettingsHit("NFC", "nfc contactless payment", "android.settings.NFC_SETTINGS", null),
    SettingsHit("About phone", "about phone device info version", "android.settings.DEVICE_INFO_SETTINGS", null),
    SettingsHit("Developer options", "developer options debugging", "android.settings.APPLICATION_DEVELOPMENT_SETTINGS", null),
    SettingsHit("Eon: Theme and colours", "eon theme light dark auto schedule colours material you predicted", null, ""),
    SettingsHit("Eon: Gestures", "eon gestures swipe double tap shake knock popup", null, "gestures"),
    SettingsHit("Eon: Focus", "eon focus mode work sleep schedule", null, "focus"),
    SettingsHit("Eon: Feed", "eon feed news widgets today", null, "feed"),
    SettingsHit("Eon: App drawer", "eon drawer library app page", null, "drawer"),
    SettingsHit("Eon: Home grid", "eon home grid columns rows", null, "grid"),
    SettingsHit("Eon: Dock", "eon dock", null, "dock"),
    SettingsHit("Eon: Icon packs", "eon icon packs shapes themed icons", null, "icons"),
    SettingsHit("Eon: Animations", "eon animations motion", null, "anim"),
    SettingsHit("Eon: Backup", "eon backup restore", null, "backup"),
    SettingsHit("Eon: Hidden apps", "eon hidden apps", null, "hidden"),
)

private class ContactHit(val name: String, val number: String)

private fun searchContacts(ctx: Context, q: String): List<ContactHit> = try {
    val out = ArrayList<ContactHit>()
    ctx.contentResolver.query(
        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
        arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
        ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
        arrayOf("%$q%"),
        ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE NOCASE ASC",
    )?.use { c ->
        val seen = HashSet<String>()
        while (c.moveToNext() && out.size < 4) {
            val name = c.getString(0) ?: continue
            val number = c.getString(1) ?: continue
            if (seen.add(name + number.filter { it.isDigit() })) out.add(ContactHit(name, number))
        }
    }
    out
} catch (e: Exception) {
    emptyList()
}

private fun open(ctx: Context, intent: Intent) {
    try {
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        android.widget.Toast.makeText(ctx, "Nothing on this phone can open that", android.widget.Toast.LENGTH_SHORT).show()
    }
}

/**
 * More than apps: hidden apps that match, contacts (with Call and Message), phone and Eon settings, and a way to carry
 * the search on to the web, the Play Store, YouTube or Maps. Shown under the app results in both drawers.
 * [shown] are the apps already listed, so they are not repeated.
 */
@Composable
fun ExtraResults(
    q: String,
    state: EonState,
    shown: List<AppEntry>,
    onLaunch: (AppEntry) -> Unit,
    modifier: Modifier = Modifier,
) {
    val ctx = LocalContext.current
    val query = q.trim()
    if (query.length < 2) return
    val shownKeys = remember(shown) { shown.map { it.key }.toSet() }
    val hiddenHits = remember(query, shownKeys, state.hidden.size) {
        state.appsForLabels.filter { it.key !in shownKeys && SearchIndex.matches(it, query) }.take(4)
    }
    val nq = SearchIndex.norm(query)
    val settingsHits = remember(query) {
        SETTINGS_HITS.filter { h -> nq.split(' ').filter { it.isNotEmpty() }.all { w -> SearchIndex.norm(h.title + " " + h.words).contains(w) } }.take(3)
    }
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED)
    }
    val askContacts = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    var contacts by remember { mutableStateOf<List<ContactHit>>(emptyList()) }
    LaunchedEffect(query, granted) {
        contacts = emptyList()
        if (granted) {
            delay(250L)
            contacts = withContext(Dispatchers.IO) { searchContacts(ctx, query) }
        }
    }
    val enc = Uri.encode(query)

    Column(modifier.fillMaxWidth().padding(top = 6.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        if (hiddenHits.isNotEmpty()) {
            ExtraLabel("HIDDEN APPS")
            hiddenHits.forEach { app ->
                ExtraRow(null, app.label, "Hidden from the drawer", app) { RecentSearches.add(query); onLaunch(app) }
            }
        }
        if (contacts.isNotEmpty()) {
            ExtraLabel("CONTACTS")
            contacts.forEach { c ->
                ExtraRow(
                    Icons.Outlined.Call, c.name, c.number, null,
                    onClick = { open(ctx, Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + c.number))) },
                    trailing = {
                        Icon(
                            Icons.Outlined.Message, "Message", tint = Eon.DSoft,
                            modifier = Modifier.size(40.dp).clip(CircleShape)
                                .clickable { open(ctx, Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + c.number))) }.padding(9.dp),
                        )
                    },
                )
            }
        } else if (!granted) {
            ExtraRow(Icons.Outlined.Call, "Search contacts too", "Allow Eon to read your contacts", null) {
                askContacts.launch(Manifest.permission.READ_CONTACTS)
            }
        }
        if (settingsHits.isNotEmpty()) {
            ExtraLabel("SETTINGS")
            settingsHits.forEach { h ->
                ExtraRow(Icons.Outlined.Tune, h.title, if (h.eonPage != null) "Eon settings" else "Phone settings", null) {
                    RecentSearches.add(query)
                    if (h.eonPage != null) SearchBridge.openEonSettings(h.eonPage) else open(ctx, Intent(h.action))
                }
            }
        }
        ExtraLabel("SEARCH FOR \u201C" + query + "\u201D")
        ExtraRow(Icons.Outlined.Language, "Search the web", "Google", null) {
            RecentSearches.add(query)
            open(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$enc")))
        }
        ExtraRow(Icons.Outlined.Search, "Find an app on Google Play", "Apps that are not installed yet", null) {
            RecentSearches.add(query)
            open(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/search?q=$enc&c=apps")))
        }
        ExtraRow(Icons.Outlined.Language, "YouTube", "Videos", null) {
            RecentSearches.add(query)
            open(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$enc")))
        }
        ExtraRow(Icons.Outlined.Settings, "Maps", "Places", null) {
            RecentSearches.add(query)
            open(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=$enc")))
        }
    }
}

@Composable
private fun ExtraLabel(text: String) {
    Text(
        text, color = Eon.DMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp,
        modifier = Modifier.padding(start = 6.dp, top = 12.dp, bottom = 4.dp),
    )
}

@Composable
private fun ExtraRow(
    icon: ImageVector?, title: String, subtitle: String, app: AppEntry?,
    trailing: @Composable () -> Unit = {}, onClick: () -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(horizontal = 6.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (app != null) {
            Image(bitmap = app.icon, contentDescription = null, modifier = Modifier.size(40.dp))
        } else if (icon != null) {
            Icon(
                icon, null, tint = Eon.DSoft,
                modifier = Modifier.size(40.dp).clip(CircleShape).background(Color(0x22FFFFFF)).padding(9.dp),
            )
        }
        Column(Modifier.weight(1f).padding(start = 12.dp)) {
            Text(title, color = Eon.DText, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(subtitle, color = Eon.DMuted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        trailing()
    }
}

/** Your recent searches as chips. Tap one to run it again. Shown while the search box is empty. */
@Composable
fun RecentChips(onPick: (String) -> Unit, modifier: Modifier = Modifier) {
    if (RecentSearches.items.isEmpty()) return
    LazyRow(modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(RecentSearches.items.toList()) { t ->
            Text(
                t, color = Eon.DSoft, fontSize = 13.sp, maxLines = 1,
                modifier = Modifier.clip(CircleShape).background(Color(0x22FFFFFF)).clickable { onPick(t) }
                    .padding(horizontal = 14.dp, vertical = 8.dp),
            )
        }
    }
}

/** The line under "No apps match": says how many apps Eon was given, so a missing app can be understood. */
@Composable
fun NoAppsHint(state: EonState, modifier: Modifier = Modifier) {
    val all = state.appsForLabels.size
    val hidden = state.hidden.size
    Text(
        "Eon lists the $all apps that Android gives it a launcher icon for" +
            (if (hidden > 0) ", and $hidden of them are hidden by you" else "") +
            ". An app that has no launcher icon (some are only reachable through another app) cannot be listed.",
        color = Eon.DFaint, fontSize = 12.sp, modifier = modifier.padding(horizontal = 6.dp),
    )
}
