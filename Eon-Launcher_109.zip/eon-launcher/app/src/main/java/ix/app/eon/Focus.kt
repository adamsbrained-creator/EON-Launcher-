package ix.app.eon

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

/**
 * A Focus mode, such as Work or Sleep. Each one has its own set of home pages, so while it is on you see only those
 * pages and the apps on them. It can switch on and off by itself between two hours on the days you pick.
 */
class FocusMode(val name: String, from: Int = -1, to: Int = -1, days: Int = 127) {
    var from by mutableIntStateOf(from)
    var to by mutableIntStateOf(to)

    /** Bits 0 to 6 for Monday to Sunday. */
    var days by mutableIntStateOf(days)

    fun scheduled(): Boolean = from in 0..23 && to in 0..23 && from != to

    fun matches(hour: Int, dayBit: Int): Boolean {
        if (!scheduled()) return false
        val inWindow = if (from < to) hour in from until to else hour >= from || hour < to
        return inWindow && ((days shr dayBit) and 1) == 1
    }
}

object Focus {
    val modes = mutableStateListOf<FocusMode>()

    /** The name of the mode that is on, or "" for your normal home. */
    var active by mutableStateOf("")

    fun load(p: Prefs) {
        modes.clear()
        try {
            val arr = JSONArray(p.getString("focusModes").ifEmpty { "[]" })
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                modes.add(FocusMode(o.getString("n"), o.optInt("f", -1), o.optInt("t", -1), o.optInt("d", 127)))
            }
        } catch (_: Exception) {
        }
        val a = p.getString("focusActive")
        active = if (modes.any { it.name == a }) a else ""
        if (active != a) p.putString("focusActive", active)
    }

    fun save(p: Prefs) {
        val arr = JSONArray()
        modes.forEach { arr.put(JSONObject().put("n", it.name).put("f", it.from).put("t", it.to).put("d", it.days)) }
        p.putString("focusModes", arr.toString())
    }

    /** Where the home pages of [mode] are kept ("" is your normal home). */
    fun pagesKey(mode: String): String = if (mode.isEmpty()) "pages" else "pages:$mode"

    /** The mode whose schedule covers now, or "". */
    fun scheduled(hour: Int, dayBit: Int): String = modes.firstOrNull { it.matches(hour, dayBit) }?.name ?: ""

    /** 0 for Monday to 6 for Sunday. */
    fun dayBitNow(): Int = (java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_WEEK) + 5) % 7
}

private val DAY_LETTERS = listOf("M", "T", "W", "T", "F", "S", "S")

private fun hourText(h: Int) = h.toString().padStart(2, '0') + ":00"

/** Settings > Focus. */
@Composable
fun FocusPage(state: EonState, onBack: () -> Unit) {
    BackHandler { onBack() }
    var asking by remember { mutableStateOf(false) }
    var copyApps by remember { mutableStateOf(true) }
    Column(
        Modifier.fillMaxSize().background(Eon.Page).systemBarsPadding().padding(horizontal = 16.dp)
            .verticalScroll(rememberScrollState()),
    ) {
        Gap(12)
        PageHeader("Focus", onBack)
        Gap(10)
        Text(
            "A Focus mode has its own home pages. While it is on, only those pages and the apps on them show. " +
                "Turn one on here, from a gesture (Settings > Gestures), or let a schedule do it.",
            color = Eon.Muted, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 4.dp),
        )
        Gap(18)
        FocusCard(
            title = "Normal home", subtitle = "All your usual pages", on = Focus.active.isEmpty(),
            onClick = { state.switchFocus("") },
        )
        Focus.modes.toList().forEach { mode ->
            Gap(10)
            FocusCard(
                title = mode.name,
                subtitle = if (mode.scheduled()) "Auto " + hourText(mode.from) + " to " + hourText(mode.to) else "Turn on by hand",
                on = Focus.active == mode.name,
                onClick = { state.switchFocus(mode.name) },
            )
            ModeSchedule(state, mode)
        }
        Gap(20)
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Start a new mode with the apps from this home", color = Eon.Text, fontSize = 14.sp,
                modifier = Modifier.weight(1f).padding(end = 12.dp),
            )
            EonSwitch(copyApps) { copyApps = it }
        }
        Gap(12)
        Box(
            Modifier.fillMaxWidth().clip(CircleShape).background(Eon.Button).clickable { asking = true }.padding(vertical = 16.dp),
            contentAlignment = Alignment.Center,
        ) { Text("New focus mode", color = Eon.OnAccent, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold) }
        Gap(32)
    }
    if (asking) {
        NameDialog(
            title = "Name the mode", initial = "Work",
            onDone = { name ->
                asking = false
                state.addFocusMode(name, copyApps)
            },
            onDismiss = { asking = false },
        )
    }
}

@Composable
private fun FocusCard(title: String, subtitle: String, on: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Eon.P0)
            .border(if (on) 2.dp else 1.dp, if (on) Eon.Accent else Eon.Line, RoundedCornerShape(22.dp))
            .clickable(onClick = onClick).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Eon.Text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Eon.Muted, fontSize = 13.sp)
        }
        if (on) Text("On", color = Eon.Accent, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
    }
}

/** The schedule controls of one mode, and Delete. */
@Composable
private fun ModeSchedule(state: EonState, mode: FocusMode) {
    Column(Modifier.fillMaxWidth().padding(start = 8.dp, end = 8.dp, top = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Schedule", color = Eon.Text, fontSize = 14.sp, modifier = Modifier.weight(1f))
            EonSwitch(mode.scheduled()) { on ->
                if (on) {
                    mode.from = 9
                    mode.to = 17
                    mode.days = 31
                } else {
                    mode.from = -1
                    mode.to = -1
                }
                state.saveFocus()
            }
        }
        if (mode.scheduled()) {
            Gap(8)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("From", color = Eon.Muted, fontSize = 13.sp, modifier = Modifier.weight(1f))
                HourPicker(mode.from) { mode.from = it; state.saveFocus() }
            }
            Gap(6)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Until", color = Eon.Muted, fontSize = 13.sp, modifier = Modifier.weight(1f))
                HourPicker(mode.to) { mode.to = it; state.saveFocus() }
            }
            Gap(8)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                DAY_LETTERS.forEachIndexed { i, letter ->
                    val on = ((mode.days shr i) and 1) == 1
                    Box(
                        Modifier.size(38.dp).clip(CircleShape)
                            .then(if (on) Modifier.background(Eon.Button) else Modifier.background(Eon.P1))
                            .clickable { mode.days = mode.days xor (1 shl i); state.saveFocus() },
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            letter, color = if (on) Eon.OnAccent else Eon.Muted, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                        )
                    }
                }
            }
        }
        Gap(8)
        Text(
            "Delete this mode", color = Eon.Danger, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable { state.removeFocusMode(mode.name) }.padding(vertical = 6.dp),
        )
    }
}

@Composable
private fun HourPicker(hour: Int, onChange: (Int) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(34.dp).clip(CircleShape).background(Eon.P1).clickable { onChange((hour + 23) % 24) },
            contentAlignment = Alignment.Center,
        ) { Text("\u2212", color = Eon.Text, fontSize = 17.sp, fontWeight = FontWeight.Bold) }
        Text(
            hourText(hour), color = Eon.Text, fontSize = 15.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.width(62.dp), textAlign = TextAlign.Center,
        )
        Box(
            Modifier.size(34.dp).clip(CircleShape).background(Eon.P1).clickable { onChange((hour + 1) % 24) },
            contentAlignment = Alignment.Center,
        ) { Text("+", color = Eon.Text, fontSize = 17.sp, fontWeight = FontWeight.Bold) }
    }
}
