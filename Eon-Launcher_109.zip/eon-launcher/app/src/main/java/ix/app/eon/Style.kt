package ix.app.eon

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.material3.ColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp

object Eon {
    /**
     * True while the light theme is showing. [EonApp] sets it from Settings > Theme. Every colour below that
     * changes with the theme reads it, so the screens using them redraw when it flips.
     */
    var light by mutableStateOf(false)

    /** Set when Material You colours are on: the phone's wallpaper colours. Accent, buttons and switches then use them. */
    var dynamic by mutableStateOf<ColorScheme?>(null)

    val Ink: Color get() = if (light) Color(0xFFF2F3F6) else Color(0xFF0A0A0B)          // base behind settings pages
    val Surface: Color get() = if (light) Color(0xFFFFFFFF) else Color(0xFF111214)      // solid card
    val Accent: Color get() = dynamic?.primary ?: (if (light) Color(0xFF0A8CA6) else Color(0xFF35D6F0))       // cyan: text, borders, cursors, toggles
    val OnAccent: Color get() = dynamic?.onPrimary ?: Color(0xFF0A0A0B)     // text on the rainbow or the accent
    val Soft: Color get() = if (light) Color(0xFF474A52) else Color(0xFFB8BCC4)         // icons and glyphs
    val Text: Color get() = if (light) Color(0xFF15161A) else Color(0xFFF5F5F6)
    val Muted: Color get() = if (light) Color(0xFF5B5E66) else Color(0xFF9A9CA3)
    val Faint: Color get() = if (light) Color(0xFF8A8D95) else Color(0xFF74767C)
    val Good: Color get() = if (light) Color(0xFF0A8CA6) else Color(0xFF7DE3F4)
    val Danger: Color get() = if (light) Color(0xFFD64A38) else Color(0xFFFF8E7E)

    /** Surface steps from the deepest panel (P0) to a raised row or chip (P2). They swap with the theme. */
    val P0: Color get() = if (light) Color(0xFFF7F8FA) else Color(0xFF0D0D0F)
    val P1: Color get() = if (light) Color(0xFFECEDF1) else Color(0xFF18181B)
    val P2: Color get() = if (light) Color(0xFFDFE1E7) else Color(0xFF26272B)
    /** The full-screen backdrop of a settings page: almost solid, so the wallpaper only hints through. */
    val Page: Color get() = if (light) Color(0xF7F2F3F6) else Color(0xF7000000)
    /** Hairlines and dividers on a panel. */
    val Line: Color get() = if (light) Color(0xFFD9DBE1) else Color(0xFF1E1E22)

    /** The dark palette, for things that sit on the wallpaper or on the drawer's own colours and so never turn light. */
    val DText = Color(0xFFF5F5F6)
    val DSoft = Color(0xFFB8BCC4)
    val DMuted = Color(0xFF9A9CA3)
    val DFaint = Color(0xFF74767C)
    val DInk = Color(0xFF0A0A0B)
    val DAccent = Color(0xFF35D6F0)

    /** A see-through wash over a panel: white on dark, black on light. [a] is 0 to 255. */
    fun ov(a: Int): Color = if (light) Color(0xFF000000).copy(alpha = a * 0.6f / 255f) else Color(0xFFFFFFFF).copy(alpha = a / 255f)

    /** The rainbow from the Eon icon: filled buttons, selected chips, badges, step bars. */
    val Button: Brush get() = dynamic?.let { Brush.horizontalGradient(listOf(it.primary, it.tertiary)) }
        ?: Brush.horizontalGradient(
            listOf(Color(0xFF35D6F0), Color(0xFF5C9DFF), Color(0xFF9B7BFF), Color(0xFFF25CCB), Color(0xFFFFA63D)),
        )
    val Tile = Brush.verticalGradient(listOf(Color(0xFF34363A), Color(0xFF1B1C1F), Color(0xFF0E0F10)))
    val Sheen = Brush.verticalGradient(listOf(Color(0x1AFFFFFF), Color(0x05FFFFFF)))
}

/** Panel surface: smoked black glass, or solid black when the Flat look is chosen. In the light theme: frosted white. */
@Composable
fun Modifier.glass(shape: Shape): Modifier =
    if (Eon.light) {
        when (LocalLook.current) {
            "black" -> this.clip(shape).background(Color(0xFFFFFFFF)).border(1.dp, Color(0x26000000), shape)
            "flat" -> this.clip(shape).background(Color(0xFFF7F8FA)).border(1.dp, Color(0x14000000), shape)
            else -> this.clip(shape).background(Color(0xE6FFFFFF)).border(1.dp, Color(0x26000000), shape)
        }
    } else glassDark(shape)

/** The smoked glass that never turns light: the search pill and the drawers, which sit on the wallpaper. */
@Composable
fun Modifier.glassDark(shape: Shape): Modifier =
    if (LocalLook.current == "black") {
        // AMOLED: true black, so those pixels are switched off.
        this.clip(shape).background(Color(0xFF000000)).border(1.dp, Color(0x26FFFFFF), shape)
    } else if (LocalLook.current == "flat") {
        this.clip(shape).background(Color(0xFF0B0B0C))
    } else {
        this.clip(shape)
            .background(Color(0xB8000000))
            .background(Eon.Sheen)
            .border(1.dp, Color(0x40FFFFFF), shape)
    }

/** Rainbow fill when [on], otherwise the plain [off] colour. */
fun Modifier.accentFill(on: Boolean, off: Color): Modifier =
    if (on) this.background(Eon.Button) else this.background(off)
