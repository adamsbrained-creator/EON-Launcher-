package ix.app.eon

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.math.BigDecimal
import java.math.MathContext
import kotlin.math.abs
import kotlin.math.pow

/** What the search box can answer by itself: a sum such as 12*8, a percentage, or a unit change such as 5 km in miles. */
class SmartAnswer(val title: String, val sub: String, val copy: String)

object SmartSearch {
    private class Unit(val names: List<String>, val factor: Double, val kind: String)

    // Every unit is stored as a multiple of one base unit of its kind (metre, gram, litre, metre per second, byte, second).
    private val units = listOf(
        Unit(listOf("m", "meter", "metre"), 1.0, "length"),
        Unit(listOf("km", "kilometer", "kilometre"), 1000.0, "length"),
        Unit(listOf("cm", "centimeter", "centimetre"), 0.01, "length"),
        Unit(listOf("mm", "millimeter", "millimetre"), 0.001, "length"),
        Unit(listOf("mi", "mile"), 1609.344, "length"),
        Unit(listOf("ft", "foot", "feet"), 0.3048, "length"),
        Unit(listOf("inch", "inches"), 0.0254, "length"),
        Unit(listOf("yd", "yard"), 0.9144, "length"),
        Unit(listOf("g", "gram"), 1.0, "mass"),
        Unit(listOf("kg", "kilo", "kilogram"), 1000.0, "mass"),
        Unit(listOf("mg", "milligram"), 0.001, "mass"),
        Unit(listOf("lb", "lbs", "pound"), 453.59237, "mass"),
        Unit(listOf("oz", "ounce"), 28.349523125, "mass"),
        Unit(listOf("l", "liter", "litre"), 1.0, "volume"),
        Unit(listOf("ml", "milliliter", "millilitre"), 0.001, "volume"),
        Unit(listOf("gal", "gallon"), 3.785411784, "volume"),
        Unit(listOf("qt", "quart"), 0.946352946, "volume"),
        Unit(listOf("cup"), 0.2365882365, "volume"),
        Unit(listOf("tbsp", "tablespoon"), 0.01478676478, "volume"),
        Unit(listOf("tsp", "teaspoon"), 0.00492892159, "volume"),
        Unit(listOf("m/s"), 1.0, "speed"),
        Unit(listOf("kmh", "km/h", "kph"), 1000.0 / 3600.0, "speed"),
        Unit(listOf("mph"), 0.44704, "speed"),
        Unit(listOf("kn", "kt", "knot"), 1852.0 / 3600.0, "speed"),
        Unit(listOf("b", "byte"), 1.0, "data"),
        Unit(listOf("kb"), 1e3, "data"),
        Unit(listOf("mb"), 1e6, "data"),
        Unit(listOf("gb"), 1e9, "data"),
        Unit(listOf("tb"), 1e12, "data"),
        Unit(listOf("s", "sec", "second"), 1.0, "time"),
        Unit(listOf("min", "minute"), 60.0, "time"),
        Unit(listOf("h", "hr", "hour"), 3600.0, "time"),
        Unit(listOf("d", "day"), 86400.0, "time"),
        Unit(listOf("wk", "week"), 604800.0, "time"),
    )

    private val temps = mapOf(
        "c" to "c", "celsius" to "c", "f" to "f", "fahrenheit" to "f", "k" to "k", "kelvin" to "k",
    )

    private fun findUnit(raw: String): Unit? {
        val n = raw.lowercase().replace("\u00B0", "")
        return units.firstOrNull { n in it.names } ?: units.firstOrNull { n.removeSuffix("s") in it.names }
    }

    private fun findTemp(raw: String): String? {
        val n = raw.lowercase().replace("\u00B0", "")
        return temps[n] ?: temps[n.removeSuffix("s")]
    }

    private val unitPattern = Regex("""^(-?[\d.]+)\s*([a-zA-Z\u00B0/]+)\s+(?:in|to|as|into)\s+([a-zA-Z\u00B0/]+)$""", RegexOption.IGNORE_CASE)
    private val percentPattern = Regex("""^([\d.]+)\s*%\s*of\s*([\d.]+)$""", RegexOption.IGNORE_CASE)

    /** The answer to [raw], or null when it is just an app name or something this cannot work out. */
    fun answer(raw: String): SmartAnswer? {
        val q = raw.trim()
        if (q.length < 3 || q.none { it.isDigit() }) return null

        percentPattern.matchEntire(q)?.let { m ->
            val a = m.groupValues[1].toDoubleOrNull() ?: return null
            val b = m.groupValues[2].toDoubleOrNull() ?: return null
            val text = fmt(a / 100.0 * b)
            return SmartAnswer(text, q, text)
        }

        unitPattern.matchEntire(q)?.let { m ->
            val n = m.groupValues[1].toDoubleOrNull() ?: return null
            val fromRaw = m.groupValues[2]
            val toRaw = m.groupValues[3]
            val ft = findTemp(fromRaw)
            val tt = findTemp(toRaw)
            if (ft != null && tt != null) {
                val celsius = when (ft) { "f" -> (n - 32.0) * 5.0 / 9.0; "k" -> n - 273.15; else -> n }
                val out = when (tt) { "f" -> celsius * 9.0 / 5.0 + 32.0; "k" -> celsius + 273.15; else -> celsius }
                val label = when (tt) { "f" -> "\u00B0F"; "k" -> " K"; else -> "\u00B0C" }
                val text = fmt(out)
                return SmartAnswer(text + label, q, text)
            }
            val from = findUnit(fromRaw) ?: return null
            val to = findUnit(toRaw) ?: return null
            if (from.kind != to.kind) return null
            val text = fmt(n * from.factor / to.factor)
            return SmartAnswer("$text ${toRaw.lowercase()}", q, text)
        }

        // Plain sums need an operator, a bracket or a function, so a bare number such as 2048 is left alone.
        if (q.none { it in "+-*/^x()\u00D7\u00F7" } && !q.contains("sqrt", true) && !q.contains("pi", true)) return null
        val v = Parser(q.replace(',', '.')).parse() ?: return null
        if (v.isNaN() || v.isInfinite()) return null
        val text = fmt(v)
        return SmartAnswer("= $text", q, text)
    }

    private fun fmt(v: Double): String {
        if (v == Math.rint(v) && abs(v) < 1e15) return v.toLong().toString()
        return BigDecimal(v).round(MathContext(10)).stripTrailingZeros().toPlainString()
    }

    /** A small calculator: + - * / ^, brackets, pi, e, sqrt sin cos tan ln log abs. x or \u00D7 also multiply. */
    private class Parser(val s: String) {
        var i = 0

        fun parse(): Double? = try {
            val v = expr()
            skip()
            if (i == s.length) v else null
        } catch (e: Exception) {
            null
        }

        private fun skip() { while (i < s.length && s[i] == ' ') i++ }
        private fun peek(): Char { skip(); return if (i < s.length) s[i] else '\u0000' }

        private fun expr(): Double {
            var v = term()
            while (true) {
                val c = peek()
                if (c == '+') { i++; v += term() } else if (c == '-') { i++; v -= term() } else return v
            }
        }

        private fun term(): Double {
            var v = power()
            while (true) {
                val c = peek()
                if (c == '*' || c == 'x' || c == '\u00D7') { i++; v *= power() }
                else if (c == '/' || c == '\u00F7') { i++; v /= power() }
                else return v
            }
        }

        private fun power(): Double {
            val base = unary()
            if (peek() == '^') { i++; return base.pow(power()) }
            return base
        }

        private fun unary(): Double {
            val c = peek()
            if (c == '-') { i++; return -unary() }
            if (c == '+') { i++; return unary() }
            return atom()
        }

        private fun atom(): Double {
            val c = peek()
            if (c == '(') {
                i++
                val v = expr()
                if (peek() != ')') throw IllegalArgumentException("bracket")
                i++
                return v
            }
            if (c.isDigit() || c == '.') {
                val start = i
                while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
                return s.substring(start, i).toDouble()
            }
            if (c.isLetter()) {
                val start = i
                while (i < s.length && s[i].isLetter()) i++
                val name = s.substring(start, i).lowercase()
                if (peek() == '(') {
                    i++
                    val arg = expr()
                    if (peek() != ')') throw IllegalArgumentException("bracket")
                    i++
                    return when (name) {
                        "sqrt" -> kotlin.math.sqrt(arg)
                        "sin" -> kotlin.math.sin(Math.toRadians(arg))
                        "cos" -> kotlin.math.cos(Math.toRadians(arg))
                        "tan" -> kotlin.math.tan(Math.toRadians(arg))
                        "ln" -> kotlin.math.ln(arg)
                        "log" -> kotlin.math.log10(arg)
                        "abs" -> abs(arg)
                        else -> throw IllegalArgumentException("function")
                    }
                }
                return when (name) {
                    "pi" -> Math.PI
                    "e" -> Math.E
                    else -> throw IllegalArgumentException("name")
                }
            }
            throw IllegalArgumentException("unexpected")
        }
    }
}

/** The answer shown above the search results. Tap it to copy the number. */
@Composable
fun SmartAnswerCard(a: SmartAnswer, modifier: Modifier = Modifier) {
    val clipboard = LocalClipboardManager.current
    Column(
        modifier.fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0x22FFFFFF))
            .clickable { clipboard.setText(AnnotatedString(a.copy)) }
            .padding(horizontal = 18.dp, vertical = 14.dp),
    ) {
        Text(a.title, color = Eon.DText, fontSize = 28.sp, fontWeight = FontWeight.Light)
        Text(a.sub + "  \u00B7  tap to copy", color = Eon.DMuted, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
    }
}
