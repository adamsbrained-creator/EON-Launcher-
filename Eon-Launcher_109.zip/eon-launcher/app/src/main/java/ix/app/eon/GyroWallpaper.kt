package ix.app.eon

import android.app.WallpaperManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.PowerManager
import androidx.activity.ComponentActivity
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Reads the accelerometer and turns it into a smooth tilt: [outX] and [outY] go from -1 to 1.
 *
 * The "centre" is wherever you hold the phone when the home screen appears, and it follows slowly, so
 * the picture settles back to the middle if you hold the phone at a new angle or put it down.
 */
class TiltState {
    private var manager: SensorManager? = null

    @Volatile private var ax = 0f
    @Volatile private var ay = 0f
    @Volatile private var az = 0f
    @Volatile private var has = false

    private val listener = object : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent) {
            ax = event.values[0]
            ay = event.values[1]
            az = event.values[2]
            has = true
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }

    /** Smoothed tilt, read from the draw phase so only the drawing is redone when it changes. */
    var outX by mutableFloatStateOf(0f)
        private set
    var outY by mutableFloatStateOf(0f)
        private set

    private var baseRoll = 0f
    private var basePitch = 0f
    private var baseSet = false
    private var curX = 0f
    private var curY = 0f

    fun start(ctx: Context) {
        stop()
        val m = ctx.getSystemService(Context.SENSOR_SERVICE) as? SensorManager ?: return
        val s = m.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return
        m.registerListener(listener, s, SensorManager.SENSOR_DELAY_GAME)
        manager = m
        baseSet = false
    }

    fun stop() {
        manager?.unregisterListener(listener)
        manager = null
        has = false
        baseSet = false
    }

    /** Moves the smoothed tilt a step closer to the phone's real tilt. Returns true while it is still moving. */
    fun step(dt: Float, speed: Float): Boolean {
        var targetX = 0f
        var targetY = 0f
        val x = ax
        val y = ay
        val z = az
        val g = sqrt(x * x + y * y + z * z)
        if (has && g > 3f) {
            // roll: positive when the right edge goes down. pitch: 0 held upright, positive as the screen turns up.
            val roll = asin((-x / g).coerceIn(-1f, 1f))
            val pitch = atan2(z, y)
            if (!baseSet) {
                baseRoll = roll
                basePitch = pitch
                baseSet = true
            }
            val k = 1f - exp(-dt / RECENTRE_SECONDS)
            baseRoll += wrap(roll - baseRoll) * k
            basePitch += wrap(pitch - basePitch) * k
            targetX = (wrap(roll - baseRoll) / FULL_TILT).coerceIn(-1f, 1f)
            targetY = (wrap(pitch - basePitch) / FULL_TILT).coerceIn(-1f, 1f)
        }
        val tau = 0.30f - 0.27f * speed.coerceIn(0f, 1f)
        val a = 1f - exp(-dt / tau)
        curX += (targetX - curX) * a
        curY += (targetY - curY) * a
        outX = curX
        outY = curY
        return abs(targetX - curX) > 0.002f || abs(targetY - curY) > 0.002f
    }

    private fun wrap(a: Float): Float {
        var r = a
        val twoPi = (2.0 * PI).toFloat()
        while (r > PI) r -= twoPi
        while (r < -PI) r += twoPi
        return r
    }

    private companion object {
        /** Tilt (in radians, about 22 degrees) that moves the picture all the way to its edge. */
        const val FULL_TILT = 0.38f
        const val RECENTRE_SECONDS = 8f
    }
}

/**
 * The overlay effects (rain, ripples, snow). Particles live in plain arrays; [tick] makes the canvas redraw.
 * Rain is streaks plus glass drops: each big drop is a little lens that shows the picture upside down.
 */
class WallpaperFx {
    var tick by mutableLongStateOf(0L)
        private set

    private val maxParticles = 480
    private val px = FloatArray(maxParticles) { Random.nextFloat() }
    private val py = FloatArray(maxParticles) { Random.nextFloat() }
    private val pr = FloatArray(maxParticles) { Random.nextFloat() }
    private val pp = FloatArray(maxParticles) { Random.nextFloat() * 6.2832f }

    private val maxRipples = 24
    private val rx = FloatArray(maxRipples)
    private val ry = FloatArray(maxRipples)
    private val rage = FloatArray(maxRipples) { -1f }
    private var spawnTimer = 0f
    private var time = 0f

    // Glass drops: position and size are 0..1; a drop waits, slides a short way, waits again.
    private val maxDrops = 40
    private val gx = FloatArray(maxDrops)
    private val gy = FloatArray(maxDrops)
    private val gs = FloatArray(maxDrops)
    private val gwait = FloatArray(maxDrops)
    private val gleft = FloatArray(maxDrops)
    private val ga = FloatArray(maxDrops)

    private var flash = 0f
    private var flashTimer = 4f
    private var secondFlash = false

    init {
        for (i in 0 until maxDrops) reseedDrop(i, true)
    }

    /** True while something is being drawn that needs a new frame every time. */
    val running: Boolean get() = WallpaperConfig.fxOn

    private fun snowCount() = (24 + 400 * WallpaperConfig.snowDensity).toInt().coerceIn(1, maxParticles)
    private fun rainCount() = (30 + 450 * WallpaperConfig.rainIntensity).toInt().coerceIn(1, maxParticles)
    private fun dropCount() = (3 + 37 * WallpaperConfig.dropAmount).toInt().coerceIn(1, maxDrops)

    fun touch(x: Float, y: Float) {
        if (!WallpaperConfig.fxOn || WallpaperConfig.fxType != WallpaperConfig.FX_RIPPLE) return
        spawn(x, y)
    }

    private fun spawn(x: Float, y: Float) {
        for (i in 0 until maxRipples) {
            if (rage[i] < 0f) {
                rx[i] = x
                ry[i] = y
                rage[i] = 0f
                return
            }
        }
    }

    private fun reseedDrop(i: Int, initial: Boolean) {
        gx[i] = Random.nextFloat()
        gy[i] = if (initial) Random.nextFloat() else Random.nextFloat() * 0.6f
        val r = Random.nextFloat()
        gs[i] = 0.12f + 0.88f * r * r
        gwait[i] = 1f + Random.nextFloat() * 9f
        gleft[i] = 0f
        ga[i] = if (initial) 1f else 0f
    }

    private fun stepStreaks(dt: Float) {
        val fall = 0.8f + 1.6f * WallpaperConfig.rainSpeed
        for (i in 0 until rainCount()) {
            py[i] += fall * (0.7f + pr[i] * 0.6f) * dt
            px[i] -= 0.05f * fall * dt
            if (px[i] < 0f) px[i] += 1f
            if (py[i] > 1.1f) {
                py[i] = -0.1f
                px[i] = Random.nextFloat()
            }
        }
    }

    private fun stepDrops(dt: Float) {
        val v0 = 0.02f + 0.16f * WallpaperConfig.dropSpeed
        for (i in 0 until dropCount()) {
            ga[i] = min(1f, ga[i] + dt * 1.2f)
            if (gleft[i] > 0f) {
                val d = v0 * (0.4f + gs[i]) * dt
                gy[i] += d
                gleft[i] -= d
                if (gleft[i] <= 0f) {
                    gleft[i] = 0f
                    gwait[i] = 1.5f + Random.nextFloat() * 9f
                }
            } else {
                gwait[i] -= dt
                if (gwait[i] <= 0f) gleft[i] = 0.04f + Random.nextFloat() * 0.25f
            }
            if (gy[i] > 1.08f) reseedDrop(i, false)
        }
    }

    private fun stepLightning(dt: Float) {
        if (!WallpaperConfig.lightning) {
            flash = 0f
            return
        }
        flashTimer -= dt
        if (flashTimer <= 0f) {
            flash = 1f
            secondFlash = Random.nextBoolean()
            flashTimer = 4f + Random.nextFloat() * 10f
        } else if (flash > 0f) {
            flash = max(0f, flash - dt * 4f)
            if (secondFlash && flash < 0.25f) {
                flash = 0.8f
                secondFlash = false
            }
        }
    }

    fun step(rawDt: Float, w: Float, h: Float) {
        if (!WallpaperConfig.fxOn || w <= 0f || h <= 0f) return
        val dt = rawDt * WallpaperConfig.animSpeed
        time += dt
        when (WallpaperConfig.fxType) {
            WallpaperConfig.FX_SNOW -> {
                val fall = 0.03f + 0.14f * WallpaperConfig.snowSpeed
                for (i in 0 until snowCount()) {
                    py[i] += fall * (0.5f + pr[i]) * dt
                    if (py[i] > 1.05f) {
                        py[i] = -0.05f
                        px[i] = Random.nextFloat()
                    }
                }
            }
            WallpaperConfig.FX_RAIN -> {
                if (WallpaperConfig.rainStreaks) stepStreaks(dt)
                if (WallpaperConfig.rainDrops) stepDrops(dt)
                stepLightning(dt)
            }
            WallpaperConfig.FX_RIPPLE -> {
                val rate = 0.25f + 1.0f * WallpaperConfig.rippleSpeed
                for (i in 0 until maxRipples) {
                    if (rage[i] >= 0f) {
                        rage[i] += dt * rate
                        if (rage[i] > 1f) rage[i] = -1f
                    }
                }
                if (!WallpaperConfig.rippleTouchOnly) {
                    spawnTimer -= dt
                    if (spawnTimer <= 0f) {
                        spawn(Random.nextFloat() * w, Random.nextFloat() * h)
                        spawnTimer = 1.3f - 1.0f * WallpaperConfig.rippleSpeed + Random.nextFloat() * 0.4f
                    }
                }
                if (WallpaperConfig.rippleRainLines) stepStreaks(dt)
            }
        }
        tick += 1L
    }

    private fun drawStreaks(ds: DrawScope, w: Float, h: Float, density: Float) {
        val a0 = 0.12f + 0.6f * WallpaperConfig.rainBrightness
        for (i in 0 until rainCount()) {
            val len = (16f + 34f * pr[i]) * density
            val x = px[i] * w
            val y = py[i] * h
            val a = a0 * (0.5f + 0.5f * pr[i])
            ds.drawLine(
                Color.White.copy(alpha = a.coerceIn(0f, 1f)),
                Offset(x, y), Offset(x - len * 0.1f, y - len),
                strokeWidth = 1.3f * density,
            )
        }
    }

    private fun drawDrops(ds: DrawScope, w: Float, h: Float, density: Float, scene: DrawScope.() -> Unit) {
        val big = 5f + 22f * WallpaperConfig.dropSize
        for (i in 0 until dropCount()) {
            val a = ga[i]
            if (a <= 0.02f) continue
            val r = (2.5f + big * gs[i]) * density * a
            val c = Offset(gx[i] * w, gy[i] * h)
            if (r >= 7f * density) {
                // A lens: the picture around the drop, turned upside down and made smaller.
                val path = Path().apply { addOval(Rect(c, r)) }
                ds.clipPath(path) {
                    withTransform({
                        rotate(180f, c)
                        scale(0.55f, 0.55f, c)
                    }) { scene() }
                    drawCircle(Color.Black.copy(alpha = 0.10f), r, c)
                }
            } else {
                ds.drawCircle(Color.White.copy(alpha = 0.10f), r, c)
            }
            val topLeft = Offset(c.x - r, c.y - r)
            val box = Size(2f * r, 2f * r)
            val rim = max(1f, r * 0.12f)
            ds.drawArc(Color.White.copy(alpha = 0.5f), 195f, 100f, false, topLeft, box, style = Stroke(width = rim))
            ds.drawArc(Color.Black.copy(alpha = 0.4f), 15f, 120f, false, topLeft, box, style = Stroke(width = rim))
            ds.drawCircle(Color.White.copy(alpha = 0.75f), max(1f, r * 0.13f), Offset(c.x - r * 0.42f, c.y - r * 0.42f))
        }
    }

    /** [scene] redraws the picture (and dimming) behind the effects; the glass drops use it as their lens. */
    fun draw(ds: DrawScope, density: Float, scene: DrawScope.() -> Unit) {
        if (tick < 0L || !WallpaperConfig.fxOn) return
        val w = ds.size.width
        val h = ds.size.height
        when (WallpaperConfig.fxType) {
            WallpaperConfig.FX_SNOW -> {
                val base = (1.5f + 5f * WallpaperConfig.snowSize) * density
                for (i in 0 until snowCount()) {
                    val sway = sin(time * 0.6f + pp[i]) * 0.02f
                    val r = base * (0.45f + 0.8f * pr[i])
                    val a = WallpaperConfig.snowOpacity * (0.45f + 0.55f * pr[i])
                    ds.drawCircle(Color.White.copy(alpha = a.coerceIn(0f, 1f)), r, Offset((px[i] + sway) * w, py[i] * h))
                }
            }
            WallpaperConfig.FX_RAIN -> {
                if (WallpaperConfig.rainStreaks) drawStreaks(ds, w, h, density)
                if (WallpaperConfig.rainDrops) drawDrops(ds, w, h, density, scene)
                if (flash > 0.01f) ds.drawRect(Color.White.copy(alpha = (flash * 0.4f).coerceIn(0f, 1f)))
            }
            WallpaperConfig.FX_RIPPLE -> {
                if (WallpaperConfig.rippleRainLines) drawStreaks(ds, w, h, density)
                val maxR = (70f + 300f * WallpaperConfig.rippleSize) * density
                for (i in 0 until maxRipples) {
                    val age = rage[i]
                    if (age < 0f) continue
                    val fade = 1f - age
                    val a = (WallpaperConfig.rippleStrength * 0.9f * fade * fade).coerceIn(0f, 1f)
                    val c = Offset(rx[i], ry[i])
                    ds.drawCircle(Color.White.copy(alpha = a), age * maxR, c, style = Stroke(width = 2.2f * density))
                    ds.drawCircle(Color.White.copy(alpha = a * 0.55f), age * maxR * 0.7f, c, style = Stroke(width = 1.4f * density))
                }
            }
        }
    }
}

internal fun isPowerSave(ctx: Context): Boolean =
    (ctx.getSystemService(Context.POWER_SERVICE) as? PowerManager)?.isPowerSaveMode == true

/** True when Eon's own live wallpaper is the wallpaper of the home screen. */
fun isEonLiveWallpaper(ctx: Context): Boolean = try {
    WallpaperManager.getInstance(ctx).wallpaperInfo?.packageName == ctx.packageName
} catch (e: Exception) {
    false
}

/** Like [isEonLiveWallpaper], and refreshed whenever the home screen comes back to the front. */
@Composable
fun rememberLiveWallpaperActive(): Boolean {
    val ctx = LocalContext.current
    var live by remember { mutableStateOf(isEonLiveWallpaper(ctx)) }
    val lifecycle = (ctx as ComponentActivity).lifecycle
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) live = isEonLiveWallpaper(ctx)
        }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer) }
    }
    return live
}

/**
 * The wallpaper layer: sits behind the whole home screen. It draws the chosen picture a little larger than the
 * screen and slides it as the phone tilts and as you swipe between pages. Only call this when
 * [WallpaperConfig.active] is true and Eon's live wallpaper is not already doing the same job.
 *
 * [page] is the current pager position (page index plus the swipe fraction), [pageCount] the number of pages.
 */
@Composable
fun GyroWallpaper(fx: WallpaperFx, page: () -> Float, pageCount: () -> Int) {
    val ctx = LocalContext.current
    val density = LocalDensity.current.density
    val dm = ctx.resources.displayMetrics
    val screenW = dm.widthPixels
    val screenH = dm.heightPixels

    var image by remember { mutableStateOf<ImageBitmap?>(null) }
    var previous by remember { mutableStateOf<ImageBitmap?>(null) }
    val fade = remember { Animatable(1f) }

    val file = WallpaperConfig.current
    val quality = WallpaperConfig.quality
    LaunchedEffect(file, quality) {
        val bmp = withContext(Dispatchers.IO) { WallpaperStore.load(ctx, file, screenW, screenH, quality) }
        if (bmp != null) {
            val old = image
            previous = old
            image = bmp.asImageBitmap()
            if (old != null) {
                fade.snapTo(0f)
                fade.animateTo(1f, tween((600f / WallpaperConfig.animSpeed).toInt().coerceAtLeast(80)))
            } else {
                fade.snapTo(1f)
            }
            previous = null
        }
    }

    // Only run while the home screen is on screen.
    val lifecycle = (ctx as ComponentActivity).lifecycle
    var resumed by remember { mutableStateOf(lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) }
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) resumed = true
            if (event == Lifecycle.Event.ON_PAUSE) resumed = false
        }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer) }
    }

    var saver by remember { mutableStateOf(isPowerSave(ctx)) }
    DisposableEffect(Unit) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, intent: Intent?) {
                saver = isPowerSave(ctx)
            }
        }
        ContextCompat.registerReceiver(
            ctx, receiver, IntentFilter(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED), ContextCompat.RECEIVER_EXPORTED,
        )
        onDispose { ctx.unregisterReceiver(receiver) }
    }

    val tilt = remember { TiltState() }
    val sensing = resumed && !(WallpaperConfig.powerSaver && saver)
    DisposableEffect(sensing) {
        if (sensing) tilt.start(ctx)
        onDispose { tilt.stop() }
    }

    LaunchedEffect(resumed) {
        if (!resumed) return@LaunchedEffect
        var last = 0L
        while (isActive) {
            val now = withFrameNanos { it }
            val dt = if (last == 0L) 0.016f else ((now - last) / 1_000_000_000f).coerceIn(0.001f, 0.1f)
            last = now
            val moving = tilt.step(dt, WallpaperConfig.speed)
            fx.step(dt, screenW.toFloat(), screenH.toFloat())
            // Nothing is moving: wake up less often until the sensor or an effect needs a frame again.
            if (!moving && !fx.running) delay(60)
        }
    }

    Canvas(
        Modifier.fillMaxSize().graphicsLayer {
            // The Blur transition blurs the whole layer at its peak, in the middle of the change.
            val t = fade.value
            val r = if (WallpaperConfig.transition == WallpaperConfig.TRANSITION_BLUR && previous != null && t < 1f) {
                sin(t * PI.toFloat()) * 40f
            } else {
                0f
            }
            renderEffect = if (r > 0.5f) BlurEffect(r, r) else null
        },
    ) {
        drawWallpaperFrame(image, previous, fade.value, tilt.outX, tilt.outY, page(), pageCount(), fx, density)
    }
}

/** Everything the wallpaper shows in one frame. Shared by the home screen layer and the live wallpaper. */
internal fun DrawScope.drawWallpaperFrame(
    img: ImageBitmap?, prev: ImageBitmap?, progress: Float,
    tx: Float, ty: Float, page: Float, pages: Int,
    fx: WallpaperFx, density: Float,
) {
    // What the glass drops look through: the picture and the dimming, without the effects.
    val scene: DrawScope.() -> Unit = {
        drawRect(Eon.DInk)
        if (img != null) drawWallpaper(img, 1f, tx, ty, page, pages, 1f)
        drawDim()
    }
    drawRect(Eon.DInk)
    if (img != null) drawTransition(img, prev, progress, tx, ty, page, pages)
    drawDim()
    fx.draw(this, density, scene)
}

private fun DrawScope.drawDim() {
    if (WallpaperConfig.dim > 0.01f) drawRect(Color.Black.copy(alpha = WallpaperConfig.dim.coerceIn(0f, 0.6f)))
}

/** Which of the squares of a grid have already changed over, at progress [t]; each square flips at its own random moment. */
private fun DrawScope.cellsPath(t: Float, cols: Int, rows: Int): Path {
    val path = Path()
    val cw = size.width / cols
    val ch = size.height / rows
    for (j in 0 until rows) {
        for (i in 0 until cols) {
            val hsh = i * 374761393 + j * 668265263
            val x = (hsh xor (hsh ushr 13)) * 1274126177.toInt()
            val r = ((x xor (x ushr 16)) and 0xFFFF) / 65535f
            if (r < t) path.addRect(Rect(i * cw, j * ch, (i + 1) * cw + 1f, (j + 1) * ch + 1f))
        }
    }
    return path
}

private fun DrawScope.drawTransition(
    img: ImageBitmap, prev: ImageBitmap?, t: Float, tx: Float, ty: Float, page: Float, pages: Int,
) {
    if (prev == null || t >= 1f) {
        drawWallpaper(img, 1f, tx, ty, page, pages, 1f)
        return
    }
    drawWallpaper(prev, 1f, tx, ty, page, pages, 1f)
    when (WallpaperConfig.transition) {
        WallpaperConfig.TRANSITION_DISSOLVE ->
            clipPath(cellsPath(t, 30, 54)) { drawWallpaper(img, 1f, tx, ty, page, pages, 1f) }
        WallpaperConfig.TRANSITION_PIXELATE ->
            clipPath(cellsPath(t, 9, 16)) { drawWallpaper(img, 1f, tx, ty, page, pages, 1f) }
        WallpaperConfig.TRANSITION_WIPE ->
            clipRect(0f, 0f, size.width * t, size.height) { drawWallpaper(img, 1f, tx, ty, page, pages, 1f) }
        WallpaperConfig.TRANSITION_ZOOM ->
            drawWallpaper(img, t, tx, ty, page, pages, 1f + 0.25f * (1f - t))
        else -> drawWallpaper(img, t, tx, ty, page, pages, 1f)
    }
}

private fun DrawScope.drawWallpaper(
    img: ImageBitmap, alpha: Float, tx: Float, ty: Float, page: Float, pages: Int, zoom: Float,
) {
    val w = size.width
    val h = size.height
    val iw = img.width.toFloat()
    val ih = img.height.toFloat()
    // Draw a little larger than the screen: the extra is the room the picture has to move in.
    val s = max(w / iw, h / ih) * (1.04f + 0.16f * WallpaperConfig.range) * zoom
    val dw = iw * s
    val dh = ih * s
    val roomX = (dw - w) / 2f
    val roomY = (dh - h) / 2f
    val mode = WallpaperConfig.mode
    val dir = if (WallpaperConfig.invert) -1f else 1f
    val pageShift = WallpaperConfig.scrolling && pages > 1
    // With page scrolling on, half of the sideways room is kept for swiping between pages.
    val tiltShare = if (pageShift && mode != WallpaperConfig.MODE_VERTICAL) 0.5f else 1f

    var ox = 0f
    var oy = 0f
    if (mode != WallpaperConfig.MODE_VERTICAL) ox += tx * dir * roomX * tiltShare
    if (mode != WallpaperConfig.MODE_HORIZONTAL) oy += ty * dir * roomY
    if (pageShift) {
        val pageShare = if (mode != WallpaperConfig.MODE_VERTICAL) 0.5f else 1f
        val p = (page / (pages - 1)).coerceIn(0f, 1f)
        ox += (0.5f - p) * 2f * roomX * pageShare
    }
    val x = ((w - dw) / 2f + ox).coerceIn(w - dw, 0f)
    val y = ((h - dh) / 2f + oy).coerceIn(h - dh, 0f)
    translate(x, y) {
        scale(s, s, pivot = Offset.Zero) {
            drawImage(img, alpha = alpha.coerceIn(0f, 1f))
        }
    }
}
