package ix.app.eon

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Watches the accelerometer for a shake (three hard jolts in about a second) and a double knock (two short sharp taps on
 * the phone, 0.1 to 0.45 s apart). Nothing is recorded or kept: the readings are only compared with a threshold.
 */
class MotionDetector(private val onShake: () -> Unit, private val onKnock: () -> Unit) : SensorEventListener {
    private val gravity = FloatArray(3)
    private var primed = false
    private var shakeCount = 0
    private var firstJolt = 0L
    private var lastJolt = 0L
    private var lastSpike = 0L
    private var lastFired = 0L

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onSensorChanged(e: SensorEvent) {
        val now = e.timestamp / 1_000_000L
        val x = e.values[0]
        val y = e.values[1]
        val z = e.values[2]
        if (!primed) {
            gravity[0] = x; gravity[1] = y; gravity[2] = z
            primed = true
            return
        }
        // Take gravity out, so only the movement is left.
        gravity[0] = 0.8f * gravity[0] + 0.2f * x
        gravity[1] = 0.8f * gravity[1] + 0.2f * y
        gravity[2] = 0.8f * gravity[2] + 0.2f * z
        val lx = x - gravity[0]
        val ly = y - gravity[1]
        val lz = z - gravity[2]
        val strength = sqrt(lx * lx + ly * ly + lz * lz)
        if (now - lastFired < 1500L) return

        if (strength > 14f) {
            if (now - lastJolt > 120L) {
                if (shakeCount == 0 || now - firstJolt > 1200L) {
                    shakeCount = 1
                    firstJolt = now
                } else {
                    shakeCount++
                }
                lastJolt = now
                if (shakeCount >= 3) {
                    shakeCount = 0
                    lastFired = now
                    onShake()
                }
            }
            return
        }
        // A knock is a short sharp push straight into the screen, much softer than a shake.
        if (abs(lz) > 3f && strength < 10f) {
            val gap = now - lastSpike
            if (lastSpike != 0L && gap in 90L..450L) {
                lastSpike = 0L
                lastFired = now
                onKnock()
            } else if (lastSpike == 0L || gap > 450L) {
                lastSpike = now
            }
        }
    }
}

/** Runs [shake] or [knock] (an action, see [Act]) when the phone is shaken or knocked while Eon is on screen. */
@Composable
fun MotionActions(shake: String, knock: String, run: (String) -> Unit) {
    val ctx = LocalContext.current
    val runNow by rememberUpdatedState(run)
    val shakeNow by rememberUpdatedState(shake)
    val knockNow by rememberUpdatedState(knock)
    val wanted = shake != Act.NONE || knock != Act.NONE
    DisposableEffect(wanted) {
        val manager = ctx.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        val sensor = manager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        if (!wanted || manager == null || sensor == null) {
            onDispose { }
        } else {
            val detector = MotionDetector(
                onShake = { if (shakeNow != Act.NONE) runNow(shakeNow) },
                onKnock = { if (knockNow != Act.NONE) runNow(knockNow) },
            )
            var listening = false
            val start = {
                if (!listening) {
                    manager.registerListener(detector, sensor, SensorManager.SENSOR_DELAY_GAME)
                    listening = true
                }
            }
            val stop = {
                if (listening) {
                    manager.unregisterListener(detector)
                    listening = false
                }
            }
            val lifecycle = (ctx as? LifecycleOwner)?.lifecycle
            val observer = LifecycleEventObserver { _, event ->
                if (event == Lifecycle.Event.ON_RESUME) start() else if (event == Lifecycle.Event.ON_PAUSE) stop()
            }
            if (lifecycle != null) lifecycle.addObserver(observer) else start()
            onDispose {
                lifecycle?.removeObserver(observer)
                stop()
            }
        }
    }
}
