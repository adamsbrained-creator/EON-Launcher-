package ix.app.eon

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.lerp
import androidx.compose.ui.zIndex
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.roundToInt

/**
 * Where one widget sits in an open folder. Like on the home screen it is in cells of the home grid, from the top-left of
 * the screen (below the status bar), and it can be anywhere, at any size, overlapping the folder's name and apps.
 */
class FolderRect(col: Float, row: Float, w: Float, h: Float, z: Int = 0) {
    var col by mutableFloatStateOf(col)
    var row by mutableFloatStateOf(row)
    var w by mutableFloatStateOf(w)
    var h by mutableFloatStateOf(h)
    var z by mutableIntStateOf(z)
}

/** The places of the widgets in every folder, saved with the rest of the folder settings. */
object FolderWidgetLayout {
    private const val PREF = "folderWidgetRects"

    /** Key is "folder key|widget id". */
    private val rects = mutableStateMapOf<String, FolderRect>()

    /** The widget being moved or resized in the open folder, or null. */
    var editing by mutableStateOf<Int?>(null)

    private fun k(folderKey: String, id: Int) = "$folderKey|$id"

    fun get(folderKey: String, id: Int): FolderRect? = rects[k(folderKey, id)]

    fun load(p: Prefs) {
        rects.clear()
        val raw = p.getString(PREF)
        if (raw.isBlank()) return
        try {
            val root = JSONObject(raw)
            root.keys().forEach { key ->
                val a = root.getJSONArray(key)
                rects[key] = FolderRect(
                    a.getDouble(0).toFloat(), a.getDouble(1).toFloat(), a.getDouble(2).toFloat(), a.getDouble(3).toFloat(),
                    a.optInt(4, 0),
                )
            }
        } catch (_: Exception) {
        }
    }

    fun save(p: Prefs) {
        val root = JSONObject()
        rects.forEach { (key, r) ->
            root.put(
                key,
                JSONArray().put(r.col.toDouble()).put(r.row.toDouble()).put(r.w.toDouble()).put(r.h.toDouble()).put(r.z),
            )
        }
        p.putString(PREF, root.toString())
    }

    /** Lets go of the places of widgets that are no longer in the folder. True if something went. */
    fun prune(folderKey: String, ids: List<Int>): Boolean {
        val prefix = "$folderKey|"
        val gone = rects.keys.filter { key ->
            if (!key.startsWith(prefix)) {
                false
            } else {
                val id = key.removePrefix(prefix).toIntOrNull()
                id == null || id !in ids
            }
        }
        gone.forEach { rects.remove(it) }
        return gone.isNotEmpty()
    }

    fun forgetFolder(folderKey: String) {
        prune(folderKey, emptyList())
    }

    /**
     * Gives every widget that has no place yet one: full width near the top of the screen (above the folder's name),
     * one under the other, at the height chosen in Settings > Drawer > Folders. True if something was added.
     */
    fun fill(folderKey: String, ids: List<Int>, widthPx: Float, cellH: Float, density: Float, rows: Float): Boolean {
        var changed = false
        val cellW = widthPx / GRID_COLS
        val padX = 20f * density / cellW
        val h = (FolderStyle.widgetDp * density / cellH).coerceIn(MIN_SIZE, maxOf(rows, MIN_SIZE))
        ids.forEach { id ->
            if (rects[k(folderKey, id)] == null) {
                val bottom = ids.mapNotNull { rects[k(folderKey, it)] }.maxOfOrNull { it.row + it.h }
                val row = if (bottom == null) 0.3f else bottom + 0.1f
                rects[k(folderKey, id)] = FolderRect(
                    padX, row.coerceIn(0f, maxOf(rows - h, 0f)), (GRID_COLS - 2f * padX).coerceAtLeast(MIN_SIZE), h,
                )
                changed = true
            }
        }
        return changed
    }

    /** Sets a widget's place and size in cells, keeping it on the screen. */
    fun set(r: FolderRect, col: Float, row: Float, w: Float, h: Float, rows: Float) {
        val ww = w.coerceIn(MIN_SIZE, GRID_COLS.toFloat())
        val hh = h.coerceIn(MIN_SIZE, maxOf(rows, MIN_SIZE))
        r.w = ww
        r.h = hh
        r.col = col.coerceIn(0f, GRID_COLS - ww)
        r.row = row.coerceIn(0f, maxOf(rows - hh, 0f))
    }

    /** Moves one edge to [pos] (in cells), keeping the opposite edge where it is. */
    fun moveEdge(r: FolderRect, side: Side, pos: Float, rows: Float) {
        val right = r.col + r.w
        val bottom = r.row + r.h
        when (side) {
            Side.Left -> {
                val l = pos.coerceIn(0f, right - MIN_SIZE)
                set(r, l, r.row, right - l, r.h, rows)
            }
            Side.Right -> {
                val e = pos.coerceIn(r.col + MIN_SIZE, GRID_COLS.toFloat())
                set(r, r.col, r.row, e - r.col, r.h, rows)
            }
            Side.Top -> {
                val t = pos.coerceIn(0f, bottom - MIN_SIZE)
                set(r, r.col, t, r.w, bottom - t, rows)
            }
            Side.Bottom -> {
                val hi = maxOf(rows, r.row + MIN_SIZE)
                val b = pos.coerceIn(r.row + MIN_SIZE, hi)
                set(r, r.col, r.row, r.w, b - r.row, rows)
            }
        }
    }

    /** After a drag with Snap to grid on: eases the widget onto the nearest cell lines. */
    suspend fun glide(r: FolderRect, rows: Float) {
        val l = r.col.roundToInt().toFloat()
        val t = r.row.roundToInt().toFloat()
        var e = (r.col + r.w).roundToInt().toFloat()
        var b = (r.row + r.h).roundToInt().toFloat()
        if (e <= l) e = l + 1f
        if (b <= t) b = t + 1f
        val c0 = r.col
        val r0 = r.row
        val w0 = r.w
        val h0 = r.h
        animate(0f, 1f, animationSpec = tween(170)) { f, _ ->
            set(r, lerp(c0, l, f), lerp(r0, t, f), lerp(w0, e - l, f), lerp(h0, b - t, f), rows)
        }
        set(r, l, t, e - l, b - t, rows)
    }
}

/**
 * The widgets of an open folder, placed freely on the screen like on a home page, over the folder's name and apps.
 * Hold a widget to move and resize it (drag it, drag the dots on its edges, or use the steppers). Which widgets are
 * in the folder is still chosen on the Widget Stack page (the folder menu's Widgets).
 */
@Composable
fun FolderWidgetLayer(state: EonState, holder: WidgetHolder, folder: Item) {
    val stackId = folderStackId(folder.key)
    val ids = state.stacks[stackId]?.members?.toList().orEmpty()
    val density = LocalDensity.current
    val haptic = LocalHapticFeedback.current

    // A folder that closes is no longer being edited.
    DisposableEffect(folder.key) { onDispose { FolderWidgetLayout.editing = null } }
    LaunchedEffect(folder.key, ids) {
        if (FolderWidgetLayout.prune(folder.key, ids)) state.saveFolderWidgets()
    }
    val editId = FolderWidgetLayout.editing?.takeIf { it in ids }
    BackHandler(enabled = editId != null) { FolderWidgetLayout.editing = null }
    if (ids.isEmpty()) return

    BoxWithConstraints(Modifier.fillMaxSize().systemBarsPadding()) {
        val cellW = constraints.maxWidth.toFloat() / GRID_COLS
        val cellH = state.cellHeightPx
        val rows = constraints.maxHeight / cellH
        val cellWDp = with(density) { cellW.toDp() }
        val cellHDp = with(density) { cellH.toDp() }

        LaunchedEffect(folder.key, ids, cellW, cellH) {
            if (FolderWidgetLayout.fill(folder.key, ids, constraints.maxWidth.toFloat(), cellH, density.density, rows)) {
                state.saveFolderWidgets()
            }
        }

        ids.forEach { id ->
            key(id) {
                val r = FolderWidgetLayout.get(folder.key, id)
                if (r != null) {
                    Box(
                        Modifier
                            .offset { IntOffset((r.col * cellW).roundToInt(), (r.row * cellH).roundToInt()) }
                            .size(DpSize(cellWDp * r.w, cellHDp * r.h))
                            .zIndex(r.z.toFloat())
                            .padding(4.dp)
                            .pointerInput(id) {
                                // Hold a widget to edit it. Watching before the widget sees the touch (Initial pass)
                                // means this works even over widgets that handle touches themselves.
                                awaitEachGesture {
                                    val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                                    if (FolderWidgetLayout.editing == id) return@awaitEachGesture
                                    var cancelled = false
                                    withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
                                        while (!cancelled) {
                                            val ev = awaitPointerEvent(PointerEventPass.Initial)
                                            val c = ev.changes.firstOrNull { it.id == down.id }
                                            if (c == null || !c.pressed ||
                                                (c.position - down.position).getDistance() > viewConfiguration.touchSlop
                                            ) {
                                                cancelled = true
                                            }
                                        }
                                    }
                                    if (!cancelled) {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        FolderWidgetLayout.editing = id
                                        // Take over the rest of the touch so the widget does not also react to it.
                                        while (true) {
                                            val ev = awaitPointerEvent(PointerEventPass.Initial)
                                            ev.changes.forEach { it.consume() }
                                            if (ev.changes.none { it.pressed }) break
                                        }
                                    }
                                }
                            }
                            // A tap on a widget's empty part is not a tap on the folder's background.
                            .pointerInput(Unit) { detectTapGestures(onTap = { }) },
                    ) {
                        val wDp = (cellWDp * r.w).value.toInt() - 8
                        val hDp = (cellHDp * r.h).value.toInt() - 8
                        WidgetView(holder, id, wDp, hDp)
                    }
                }
            }
        }

        if (editId != null) {
            val r = FolderWidgetLayout.get(folder.key, editId)
            if (r != null) FolderEditLayer(state, holder, stackId, editId, folder.key, r, cellW, cellH, rows)
        }
    }
}

/** Edit mode for one folder widget, the same as on the home screen: drag to move, drag the dots to resize. */
@Composable
private fun BoxScope.FolderEditLayer(
    state: EonState, holder: WidgetHolder, stackId: Int, id: Int, folderKey: String,
    r: FolderRect, cellW: Float, cellH: Float, rows: Float,
) {
    val density = LocalDensity.current
    val pad = with(density) { 4.dp.toPx() }
    val raw = remember { FloatArray(1) }
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()

    fun settle() {
        if (state.snapToGrid) {
            scope.launch {
                FolderWidgetLayout.glide(r, rows)
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                state.saveFolderWidgets()
            }
        } else {
            state.saveFolderWidgets()
        }
    }

    // Tapping outside finishes editing.
    Box(Modifier.fillMaxSize().zIndex(1900f).pointerInput(Unit) { detectTapGestures { FolderWidgetLayout.editing = null } })

    // The widget itself: drag to move.
    Box(
        Modifier
            .offset { IntOffset((r.col * cellW).roundToInt(), (r.row * cellH).roundToInt()) }
            .size(with(density) { DpSize((r.w * cellW).toDp(), (r.h * cellH).toDp()) })
            .zIndex(2000f)
            .padding(4.dp)
            .border(1.5.dp, Eon.Button, RoundedCornerShape(24.dp))
            .pointerInput(r) { detectTapGestures { } }
            .pointerInput(r, cellW, cellH, rows) {
                var rc = 0f
                var rr = 0f
                detectDragGestures(
                    onDragStart = { rc = r.col; rr = r.row },
                    onDragEnd = { settle() },
                    onDragCancel = { settle() },
                ) { change, drag ->
                    change.consume()
                    rc += drag.x / cellW
                    rr += drag.y / cellH
                    FolderWidgetLayout.set(r, rc, rr, r.w, r.h, rows)
                }
            },
    )

    // Handles on the four edges.
    val left = r.col * cellW + pad
    val right = (r.col + r.w) * cellW - pad
    val top = r.row * cellH + pad
    val bottom = (r.row + r.h) * cellH - pad
    val midX = (left + right) / 2f
    val midY = (top + bottom) / 2f
    EdgeHandle(left, midY, { raw[0] = r.col }, { dx, _ ->
        raw[0] += dx / cellW
        FolderWidgetLayout.moveEdge(r, Side.Left, raw[0], rows)
    }, { settle() })
    EdgeHandle(right, midY, { raw[0] = r.col + r.w }, { dx, _ ->
        raw[0] += dx / cellW
        FolderWidgetLayout.moveEdge(r, Side.Right, raw[0], rows)
    }, { settle() })
    EdgeHandle(midX, top, { raw[0] = r.row }, { _, dy ->
        raw[0] += dy / cellH
        FolderWidgetLayout.moveEdge(r, Side.Top, raw[0], rows)
    }, { settle() })
    EdgeHandle(midX, bottom, { raw[0] = r.row + r.h }, { _, dy ->
        raw[0] += dy / cellH
        FolderWidgetLayout.moveEdge(r, Side.Bottom, raw[0], rows)
    }, { settle() })

    // The bar sits on the opposite half of the screen so it never covers the widget.
    val widgetLow = r.row + r.h / 2f > rows / 2f
    FolderEditPanel(
        state, holder, stackId, id, folderKey, r, rows,
        Modifier.align(if (widgetLow) Alignment.TopCenter else Alignment.BottomCenter).padding(vertical = 12.dp),
    )
}

/** The editing bar: position and size always showing, Done, and Move, Resize and Layer with exact steppers. */
@Composable
private fun FolderEditPanel(
    state: EonState, holder: WidgetHolder, stackId: Int, id: Int, folderKey: String,
    r: FolderRect, rows: Float, modifier: Modifier,
) {
    // 0 = move, 1 = resize, 2 = layer
    var tab by remember { mutableStateOf(0) }
    var fromCenter by remember { mutableStateOf(false) }
    var stepIdx by remember { mutableStateOf(1) }
    val steps = remember { listOf(0.01f, 0.1f, 1f) }
    val step = steps[stepIdx]

    fun r3(v: Float) = (v * 1000f).roundToInt() / 1000f
    fun place(c: Float, rw: Float) = FolderWidgetLayout.set(r, r3(c), r3(rw), r.w, r.h, rows)
    fun resize(w: Float, h: Float) {
        val nw = w.coerceIn(MIN_SIZE, GRID_COLS.toFloat())
        val nh = h.coerceIn(MIN_SIZE, maxOf(rows, MIN_SIZE))
        if (fromCenter) {
            FolderWidgetLayout.set(r, r3(r.col + (r.w - nw) / 2f), r3(r.row + (r.h - nh) / 2f), r3(nw), r3(nh), rows)
        } else {
            FolderWidgetLayout.set(r, r.col, r.row, r3(nw), r3(nh), rows)
        }
    }
    val end: () -> Unit = { state.saveFolderWidgets() }

    val bar = RoundedCornerShape(26.dp)
    Column(
        modifier
            .zIndex(2200f)
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .clip(bar)
            .background(Eon.P0)
            .border(1.5.dp, Eon.Button, bar)
            .pointerInput(Unit) { detectTapGestures { } },
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "X ${cellText(r.col)} · Y ${cellText(r.row)} · ${cellText(r.w)} × ${cellText(r.h)}",
                    color = Eon.Muted, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.6.sp,
                    modifier = Modifier.weight(1f),
                )
                Box(
                    Modifier.height(36.dp).clip(CircleShape).background(Eon.Button)
                        .clickable { FolderWidgetLayout.editing = null }.padding(horizontal = 20.dp),
                    contentAlignment = Alignment.Center,
                ) { Text("Done", color = Eon.OnAccent, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold) }
            }
            Row(Modifier.fillMaxWidth().height(44.dp).clip(RoundedCornerShape(14.dp)).background(Eon.P1).padding(3.dp)) {
                listOf("Move", "Resize", "Layer").forEachIndexed { i, label ->
                    Box(
                        Modifier.weight(1f).fillMaxSize().clip(RoundedCornerShape(11.dp))
                            .accentFill(tab == i, Color.Transparent).clickable { tab = i },
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            label, color = if (tab == i) Eon.OnAccent else Eon.Soft, fontSize = 14.sp,
                            fontWeight = if (tab == i) FontWeight.ExtraBold else FontWeight.Medium,
                        )
                    }
                }
            }
            when (tab) {
                0 -> Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    NudgeRow("X", cellText(r.col), { place(r.col - step, r.row) }, { place(r.col + step, r.row) }, end)
                    NudgeRow("Y", cellText(r.row), { place(r.col, r.row - step) }, { place(r.col, r.row + step) }, end)
                }
                1 -> Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    NudgeRow("Width", cellText(r.w), { resize(r.w - step, r.h) }, { resize(r.w + step, r.h) }, end)
                    NudgeRow("Height", cellText(r.h), { resize(r.w, r.h - step) }, { resize(r.w, r.h + step) }, end)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TinyChip("From corner", !fromCenter) { fromCenter = false }
                        TinyChip("From center", fromCenter) { fromCenter = true }
                        TinyChip("Full width", false) {
                            FolderWidgetLayout.set(r, 0f, r.row, GRID_COLS.toFloat(), r.h, rows)
                            end()
                        }
                    }
                }
                else -> Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    NudgeRow("Layer", "${r.z}", { r.z = (r.z - 1).coerceIn(-99, 99); end() }, { r.z = (r.z + 1).coerceIn(-99, 99); end() }, {})
                    PanelButton("Remove from folder") {
                        FolderWidgetLayout.editing = null
                        state.removeFromStack(stackId, id) { holder.host.deleteAppWidgetId(it) }
                        FolderWidgetLayout.prune(folderKey, state.stacks[stackId]?.members?.toList().orEmpty())
                        state.saveFolderWidgets()
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (tab < 2) {
                    Text("STEP", color = Eon.Faint, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.2.sp)
                    Spacer(Modifier.width(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("0.01", "0.1", "1").forEachIndexed { i, l -> TinyChip(l, stepIdx == i) { stepIdx = i } }
                    }
                }
                Spacer(Modifier.weight(1f))
                Text("Snap to grid", color = Eon.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.width(10.dp))
                EonSwitch(state.snapToGrid) { state.chooseSnap(it) }
            }
        }
    }
}
