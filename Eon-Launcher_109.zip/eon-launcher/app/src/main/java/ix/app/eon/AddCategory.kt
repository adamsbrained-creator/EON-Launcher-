package ix.app.eon

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Full-screen list of categories to add to the drawer's bottom bar. Ones already in the bar are
 * left out. "Custom category" makes an empty one you name yourself and fill with Change category.
 */
@Composable
fun AddCategoryScreen(
    existing: Set<String>,
    onPick: (CatDef) -> Unit,
    onCustom: () -> Unit,
    onBack: () -> Unit,
) {
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }

    BackHandler { onBack() }
    BackHandler(enabled = searching) {
        searching = false
        query = ""
    }
    LaunchedEffect(searching) {
        if (searching) {
            try {
                focus.requestFocus()
            } catch (_: Exception) {
            }
        }
    }

    val q = query.trim()
    val options = CATALOG.filter { it.id !in existing && (q.isEmpty() || it.name.contains(q, ignoreCase = true)) }

    Column(
        Modifier.fillMaxSize().background(Color.Black)
            .pointerInput(Unit) { detectTapGestures(onTap = { }) }
            .systemBarsPadding().imePadding(),
    ) {
        Row(
            Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 24.dp, bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (searching) {
                Box(Modifier.weight(1f).padding(vertical = 12.dp)) {
                    if (query.isEmpty()) Text("Search categories", color = Eon.DFaint, fontSize = 20.sp)
                    BasicTextField(
                        value = query,
                        onValueChange = { query = it },
                        singleLine = true,
                        textStyle = TextStyle(color = Eon.DText, fontSize = 20.sp),
                        cursorBrush = SolidColor(Eon.DAccent),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        modifier = Modifier.fillMaxWidth().focusRequester(focus),
                    )
                }
            } else {
                Text(
                    "Add category", color = Eon.DText, fontSize = 28.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f),
                )
            }
            IconButton(onClick = {
                if (searching) {
                    searching = false
                    query = ""
                } else {
                    searching = true
                }
            }) {
                Icon(if (searching) Icons.Outlined.Close else Icons.Outlined.Search, "Search", tint = Eon.DText)
            }
        }

        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
            if (q.isEmpty()) {
                item(key = "custom") { CategoryRow(Icons.Outlined.Folder, "Custom category", onCustom) }
            }
            items(options, key = { it.id }) { def ->
                CategoryRow(catIcon(def.icon), def.name) { onPick(def) }
            }
        }
    }
}

@Composable
private fun CategoryRow(icon: ImageVector, name: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(40.dp).clip(CircleShape).background(Color(0xFF1C1C1E)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.width(16.dp))
        Text(name, color = Eon.DText, fontSize = 16.sp)
    }
}
