package ix.app.eon

import android.app.Activity
import android.app.AlarmManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.BatteryManager
import android.view.OrientationEventListener
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Desk mode: "" is off, "charging" shows it while charging, "landscape" only while charging on its side. */
object DeskConfig {
    var mode by mutableStateOf("")
        private set
    val photos = mutableStateListOf<String>()
    private var prefs: Prefs? = null

    fun load(p: Prefs) {
        prefs = p
        mode = p.getString("deskMode")
        photos.clear()
        photos.addAll(p.getString("deskPhotos").split("\n").filter { it.isNotBlank() })
    }

    fun chooseMode(value: String) {
        mode = value
        prefs?.putString("deskMode", value)
    }

    private fun dir(ctx: Context) = File(ctx.filesDir, "desk").also { it.mkdirs() }

    /** Copies the chosen pictures, scaled down, into Eon's own storage. The originals are not kept or changed. */
    suspend fun importPhotos(ctx: Context, uris: List<android.net.Uri>) = withContext(Dispatchers.IO) {
        val d = dir(ctx)
        d.listFiles()?.forEach { it.delete() }
        val names = ArrayList<String>()
        uris.take(12).forEachIndexed { i, uri ->
            try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 1800) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                if (bmp != null) {
                    val name = "photo_$i.jpg"
                    File(d, name).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
                    names.add(name)
                }
            } catch (e: Exception) {
            }
        }
        withContext(Dispatchers.Main) {
            photos.clear()
            photos.addAll(names)
            prefs?.putString("deskPhotos", names.joinToString("\n"))
        }
    }

    fun clearPhotos(ctx: Context) {
        dir(ctx).listFiles()?.forEach { it.delete() }
        photos.clear()
        prefs?.putString("deskPhotos", "")
    }
}

/** The "Photos for desk mode" line in Settings: choose up to 12 pictures with Android's photo picker (no permission needed). */
@Composable
fun DeskPhotosRow() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(12)) { uris ->
        if (uris.isNotEmpty()) scope.launch { DeskConfig.importPhotos(ctx, uris) }
    }
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("Desk mode photos", color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text(
                if (DeskConfig.photos.isEmpty()) "None chosen" else "${DeskConfig.photos.size} chosen, shown one after another",
                color = Eon.Muted, fontSize = 12.sp,
            )
        }
        if (DeskConfig.photos.isNotEmpty()) {
            Text(
                "Clear", color = Eon.Danger, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable { DeskConfig.clearPhotos(ctx) }.padding(10.dp),
            )
        }
        Text(
            "Choose", color = Eon.Accent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable {
                picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            }.padding(10.dp),
        )
    }
}

/**
 * Desk mode, like iOS StandBy: while the phone charges (and, if chosen, lies on its side) Eon shows a big clock on a dark
 * screen. Swipe sideways for the weather, the music that is playing and your photos. Double tap or go back to leave it.
 * Over the layout Eon asks the screen to stay on, and the clock drifts a little every minute so it cannot burn in.
 */
@Composable
fun DeskModeLayer() {
    val mode = DeskConfig.mode
    val ctx = LocalContext.current
    var charging by remember { mutableStateOf(false) }
    var sideways by remember { mutableStateOf(false) }
    var resumed by remember { mutableStateOf(true) }
    var dismissed by remember { mutableStateOf(false) }

    DisposableEffect(mode) {
        if (mode.isEmpty()) {
            onDispose { }
        } else {
            val receiver = object : BroadcastReceiver() {
                override fun onReceive(c: Context?, intent: Intent?) {
                    charging = (intent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
                }
            }
            val sticky = ContextCompat.registerReceiver(
                ctx, receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED,
            )
            charging = (sticky?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
            val orientation = object : OrientationEventListener(ctx) {
                override fun onOrientationChanged(degrees: Int) {
                    if (degrees == ORIENTATION_UNKNOWN) return
                    sideways = degrees in 60..120 || degrees in 240..300
                }
            }
            if (mode == "landscape") orientation.enable()
            val lifecycle = (ctx as? LifecycleOwner)?.lifecycle
            val observer = LifecycleEventObserver { _, event ->
                if (event == Lifecycle.Event.ON_RESUME) resumed = true else if (event == Lifecycle.Event.ON_PAUSE) resumed = false
            }
            lifecycle?.addObserver(observer)
            onDispose {
                lifecycle?.removeObserver(observer)
                orientation.disable()
                try {
                    ctx.unregisterReceiver(receiver)
                } catch (_: Exception) {
                }
            }
        }
    }

    val wants = mode.isNotEmpty() && charging && (mode == "charging" || sideways)
    LaunchedEffect(wants) { if (!wants) dismissed = false }
    val active = wants && resumed && !dismissed

    // In "landscape" the app turns sideways while desk mode shows, and back again when it goes.
    val landscapeNow = active && mode == "landscape"
    DisposableEffect(landscapeNow) {
        val activity = ctx as? Activity
        if (landscapeNow) activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        onDispose { if (landscapeNow) activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT }
    }

    if (active) DeskScreen { dismissed = true }
}

@Composable
private fun DeskScreen(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    BackHandler { onDismiss() }
    val view = LocalView.current
    DisposableEffect(Unit) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }
    LaunchedEffect(Unit) { loadCachedWeather(ctx) }

    val pages = buildList {
        add("clock")
        add("weather")
        if (NowPlaying.title.isNotEmpty()) add("music")
        if (DeskConfig.photos.isNotEmpty()) add("photos")
    }
    val pager = rememberPagerState(pageCount = { pages.size })
    Box(
        Modifier.fillMaxSize().background(Color.Black).pointerInput(Unit) { detectTapGestures(onDoubleTap = { onDismiss() }) },
    ) {
        HorizontalPager(pager, Modifier.fillMaxSize()) { i ->
            when (pages.getOrNull(i)) {
                "clock" -> ClockPage()
                "weather" -> WeatherPage()
                "music" -> MusicPage()
                "photos" -> PhotoPage()
            }
        }
        Row(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 18.dp), horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            pages.indices.forEach { i ->
                Box(
                    Modifier.size(7.dp).clip(CircleShape)
                        .background(if (i == pager.currentPage) Color(0xCCFFFFFF) else Color(0x44FFFFFF)),
                )
            }
        }
    }
}

@Composable
private fun ClockPage() {
    val ctx = LocalContext.current
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(5_000L)
        }
    }
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val is24 = android.text.format.DateFormat.is24HourFormat(ctx)
    val time = SimpleDateFormat(if (is24) "HH:mm" else "h:mm", Locale.getDefault()).format(Date(now))
    val date = SimpleDateFormat("EEEE d MMMM", Locale.getDefault()).format(Date(now))
    val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
    val night = hour >= 22 || hour < 6
    val color = if (night) Color(0xFF9A2B20) else Color(0xFFF5F5F6)
    val minute = (now / 60_000L % 7L).toInt()
    val alarm = remember(now / 60_000L) {
        try {
            (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager).nextAlarmClock?.triggerTime?.let {
                SimpleDateFormat(if (is24) "EEE HH:mm" else "EEE h:mm a", Locale.getDefault()).format(Date(it))
            }
        } catch (e: Exception) {
            null
        }
    }
    val battery = remember(now / 60_000L) {
        (ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    }
    Column(
        Modifier.fillMaxSize().offset(x = ((minute - 3) * 3).dp, y = ((3 - minute) * 2).dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(time, color = color, fontSize = if (landscape) 170.sp else 120.sp, fontWeight = FontWeight.Thin)
        Text(date, color = color.copy(alpha = 0.75f), fontSize = if (landscape) 24.sp else 20.sp)
        Text(
            (if (alarm != null) "Alarm $alarm   " else "") + "$battery%",
            color = color.copy(alpha = 0.55f), fontSize = 15.sp, modifier = Modifier.padding(top = 10.dp),
        )
    }
}

@Composable
private fun WeatherPage() {
    val useF = remember { Locale.getDefault().country == "US" }
    fun show(c: Int?): String = if (c == null) "--" else if (useF) "${c * 9 / 5 + 32}\u00B0F" else "$c\u00B0C"
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        if (WeatherState.code >= 0) WeatherIcon(WeatherState.code, WeatherState.isDay, 110.dp)
        Text(show(WeatherState.temp), color = Color(0xFFF5F5F6), fontSize = 84.sp, fontWeight = FontWeight.Thin)
        if (WeatherState.temp != null) {
            Text("Feels like " + show(WeatherState.feels), color = Color(0xAAFFFFFF), fontSize = 18.sp)
        } else {
            Text("Add the weather widget once to load it", color = Color(0x88FFFFFF), fontSize = 14.sp)
        }
    }
}

@Composable
private fun MusicPage() {
    Column(
        Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        val art = NowPlaying.art
        if (art != null) {
            Image(
                bitmap = art, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.size(220.dp).clip(RoundedCornerShape(24.dp)),
            )
        }
        Text(
            NowPlaying.title, color = Color(0xFFF5F5F6), fontSize = 26.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 18.dp), maxLines = 2,
        )
        Text(NowPlaying.artist, color = Color(0xAAFFFFFF), fontSize = 18.sp, textAlign = TextAlign.Center, maxLines = 1)
    }
}

@Composable
private fun PhotoPage() {
    val ctx = LocalContext.current
    var images by remember { mutableStateOf<List<androidx.compose.ui.graphics.ImageBitmap>>(emptyList()) }
    LaunchedEffect(DeskConfig.photos.size) {
        images = withContext(Dispatchers.IO) {
            DeskConfig.photos.toList().mapNotNull { name ->
                try {
                    BitmapFactory.decodeFile(File(File(ctx.filesDir, "desk"), name).path)?.asImageBitmap()
                } catch (e: Exception) {
                    null
                }
            }
        }
    }
    var index by remember { mutableIntStateOf(0) }
    LaunchedEffect(images.size) {
        while (images.size > 1) {
            delay(15_000L)
            index = (index + 1) % images.size
        }
    }
    if (images.isEmpty()) return
    Crossfade(targetState = index % images.size, animationSpec = tween(1200), label = "deskPhotos") { i ->
        Image(bitmap = images[i], contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
    }
}
