package ix.app.eon

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Replay
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

/** Settings > Home screen: the list that leads to Grid properties, plus the page indicator switch. */
@Composable
fun HomeSettingsScreen(state: EonState, onBack: () -> Unit, onGrid: () -> Unit, onDock: () -> Unit) {
    BackHandler { onBack() }
    Column(
        Modifier.fillMaxSize().background(Eon.Page).systemBarsPadding().padding(horizontal = 20.dp)
            .verticalScroll(rememberScrollState()),
    ) {
        Gap(12)
        ScreenHeader("Home screen", onBack)
        Gap(24)
        Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(24.dp))) {
            NavRow(
                "Grid properties",
                "${HomeConfig.cols} columns · " + (if (HomeConfig.rowsSetting > 0) "${HomeConfig.rowsSetting} rows" else "auto rows") +
                    " · icons ${HomeConfig.iconDp} dp",
                onGrid,
            )
            NavRow(
                "Dock",
                if (HomeConfig.dockOn) {
                    "On · ${HomeConfig.dockCols}×${HomeConfig.dockRows} · icons ${HomeConfig.dockIconDp} dp"
                } else {
                    "Off"
                },
                onDock,
            )
            ToggleRow("Show indicator", "Show the page dots at the bottom", HomeConfig.indicator) {
                HomeConfig.indicator = it
                state.saveHome()
            }
        }
        Gap(24)
    }
}

/** Settings > Home screen > Grid properties. The home screen stays visible above the panel so you see changes live. */
@Composable
fun GridSettingsScreen(state: EonState, onBack: () -> Unit) {
    BackHandler { onBack() }
    fun changed() = state.saveHome()

    Column(Modifier.fillMaxSize()) {
        // Left empty on purpose: this is where you watch the grid change. Touches are blocked so nothing moves by accident.
        Box(Modifier.weight(0.36f).fillMaxWidth().pointerInput(Unit) { detectTapGestures { } })
        Column(
            Modifier
                .weight(0.64f).fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                .background(Color(0xFF050506))
                .border(1.dp, Eon.Line, RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
                .padding(horizontal = 20.dp),
        ) {
            Gap(16)
            ScreenHeader("Grid properties", onBack)
            Gap(18)
            SmallLabel("PRESETS")
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf(4 to 7, 5 to 8, 6 to 10).forEach { (c, r) ->
                    val on = HomeConfig.cols == c && HomeConfig.rowsSetting == r
                    Chip("${c}x$r", on) { state.choosePreset(c, r) }
                }
            }
            Gap(8)
            StepperRow("Columns", "${HomeConfig.cols}", { state.chooseCols(HomeConfig.cols - 1) }, { state.chooseCols(HomeConfig.cols + 1) })
            StepperRow(
                "Rows", if (HomeConfig.rowsSetting == 0) "Auto" else "${HomeConfig.rowsSetting}",
                { state.chooseRows(if (HomeConfig.rowsSetting <= 3) 0 else HomeConfig.rowsSetting - 1) },
                { state.chooseRows(if (HomeConfig.rowsSetting == 0) 3 else HomeConfig.rowsSetting + 1) },
            )
            SliderRow("Icon size", "${HomeConfig.iconDp} dp", HomeConfig.iconDp.toFloat(), 40f..84f, {
                HomeConfig.iconDp = it.roundToInt()
                changed()
            }) {
                HomeConfig.iconDp = 60
                changed()
            }
            Divider()
            ToggleRow("Icon label visibility", "Show the app's name under its icon", HomeConfig.showLabels) {
                HomeConfig.showLabels = it
                changed()
            }
            if (HomeConfig.showLabels) {
                SliderRow("Label size", "${cellText(HomeConfig.labelSp)} pt", HomeConfig.labelSp, 8f..16f, {
                    HomeConfig.labelSp = (it * 2f).roundToInt() / 2f
                    changed()
                }) {
                    HomeConfig.labelSp = 12f
                    changed()
                }
                ToggleRow("Allow two-line labels", "Let long names use two lines", HomeConfig.twoLine) {
                    HomeConfig.twoLine = it
                    changed()
                }
            }
            Divider()
            ToggleRow("Use custom padding", "Change the space around the grid", HomeConfig.customPad) {
                HomeConfig.customPad = it
                changed()
            }
            if (HomeConfig.customPad) {
                SliderRow("Side padding", "${HomeConfig.padSide} dp", HomeConfig.padSide.toFloat(), 0f..48f, {
                    HomeConfig.padSide = it.roundToInt()
                    changed()
                }) {
                    HomeConfig.padSide = 16
                    changed()
                }
                SliderRow("Top padding", "${HomeConfig.padTop} dp", HomeConfig.padTop.toFloat(), 0f..64f, {
                    HomeConfig.padTop = it.roundToInt()
                    changed()
                }) {
                    HomeConfig.padTop = 8
                    changed()
                }
                SliderRow("Bottom padding", "${HomeConfig.padBottom} dp", HomeConfig.padBottom.toFloat(), 0f..64f, {
                    HomeConfig.padBottom = it.roundToInt()
                    changed()
                }) {
                    HomeConfig.padBottom = 0
                    changed()
                }
            }
            Gap(24)
        }
    }
}

/** Settings > Home screen > Dock. The panel sits at the top so the real dock stays visible at the bottom. */
@Composable
fun DockSettingsScreen(state: EonState, onBack: () -> Unit) {
    BackHandler { onBack() }
    fun changed() = state.dockChanged()

    Column(Modifier.fillMaxSize()) {
        Column(
            Modifier
                .weight(0.64f).fillMaxWidth()
                .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
                .background(Color(0xFF050506))
                .border(1.dp, Eon.Line, RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
                .statusBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp),
        ) {
            Gap(12)
            ScreenHeader("Dock", onBack)
            Gap(18)
            ToggleRow("Enable", "Show a dock at the bottom of the home screen", HomeConfig.dockOn) {
                HomeConfig.dockOn = it
                changed()
            }
            if (HomeConfig.dockOn) {
                StepperRow(
                    "Columns", "${HomeConfig.dockCols}",
                    { HomeConfig.dockCols = (HomeConfig.dockCols - 1).coerceAtLeast(1); changed() },
                    { HomeConfig.dockCols = (HomeConfig.dockCols + 1).coerceAtMost(6); changed() },
                )
                StepperRow(
                    "Rows", "${HomeConfig.dockRows}",
                    { HomeConfig.dockRows = (HomeConfig.dockRows - 1).coerceAtLeast(1); changed() },
                    { HomeConfig.dockRows = (HomeConfig.dockRows + 1).coerceAtMost(3); changed() },
                )
                SliderRow("Icon size", "${HomeConfig.dockIconDp} dp", HomeConfig.dockIconDp.toFloat(), 40f..84f, {
                    HomeConfig.dockIconDp = it.roundToInt()
                    changed()
                }) {
                    HomeConfig.dockIconDp = 60
                    changed()
                }
                StepperRow(
                    "Pages", "${HomeConfig.dockPages}",
                    { HomeConfig.dockPages = (HomeConfig.dockPages - 1).coerceAtLeast(1); changed() },
                    { HomeConfig.dockPages = (HomeConfig.dockPages + 1).coerceAtMost(5); changed() },
                )
                Divider()
                ToggleRow("Icon label visibility", "Show the app's name under its icon", HomeConfig.dockLabels) {
                    HomeConfig.dockLabels = it
                    changed()
                }
                Gap(6)
                Text(
                    "Add apps by long-pressing them and choosing Move to dock.",
                    color = Eon.Faint, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.padding(horizontal = 4.dp),
                )
            }
            Gap(24)
        }
        // Left empty so you can watch the dock change. Touches are blocked so nothing moves by accident.
        Box(Modifier.weight(0.36f).fillMaxWidth().pointerInput(Unit) { detectTapGestures { } })
    }
}

@Composable
private fun ScreenHeader(title: String, onBack: () -> Unit) {
    PageHeader(title, onBack)
}

@Composable
private fun SmallLabel(text: String) {
    SettingsSectionLabel(text)
}

@Composable
private fun Divider() {
    Box(Modifier.padding(vertical = 8.dp).fillMaxWidth().height(1.dp).background(Eon.Line))
}

@Composable
private fun Chip(label: String, on: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.height(40.dp).clip(CircleShape)
            .accentFill(on, Eon.P1)
            .clickable(onClick = onClick).padding(horizontal = 20.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = if (on) Eon.OnAccent else Eon.Text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun NavRow(title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Eon.Muted, fontSize = 12.sp)
        }
        Text("›", color = Eon.Muted, fontSize = 22.sp)
    }
}

@Composable
private fun ToggleRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(horizontal = 4.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            if (subtitle != null) Text(subtitle, color = Eon.Muted, fontSize = 12.sp, lineHeight = 16.sp)
        }
        EonSwitch(checked, onChange)
    }
}

@Composable
private fun StepperRow(title: String, value: String, onMinus: () -> Unit, onPlus: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        StepButton("−", onMinus)
        Text(value, color = Eon.Text, fontSize = 16.sp, modifier = Modifier.width(56.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        StepButton("+", onPlus)
    }
}

@Composable
private fun StepButton(label: String, onClick: () -> Unit) {
    Box(
        Modifier.size(width = 52.dp, height = 44.dp).clip(RoundedCornerShape(14.dp)).background(Eon.P1).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = Eon.Text, fontSize = 22.sp) }
}

@Composable
private fun SliderRow(
    title: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit,
    onReset: () -> Unit,
) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text(valueText, color = Eon.Muted, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(12.dp))
            Box(
                Modifier.size(36.dp).clip(RoundedCornerShape(12.dp)).background(Eon.P1).clickable(onClick = onReset),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Outlined.Replay, "Reset", tint = Eon.Soft, modifier = Modifier.size(18.dp)) }
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange, valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = Color.White, activeTrackColor = Eon.Accent, inactiveTrackColor = Eon.ov(0x33),
            ),
        )
    }
}
