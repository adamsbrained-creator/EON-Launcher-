package ix.app.eon

import android.Manifest
import android.app.AlarmManager
import android.content.BroadcastReceiver
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.text.format.DateFormat
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Widgets drawn by Eon itself, so they match its look and need nothing installed: the next hours of your calendar, the
 * battery, the next alarm and the free space. Add them from the widget list like any other.
 */
const val W_AGENDA = -4
const val W_BATTERY = -5
const val W_ALARM = -6
const val W_STORAGE = -7

/** The shared dark card the smart widgets sit on. */
@Composable
private fun SmartCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable () -> Unit) {
    val shape = RoundedCornerShape(30.dp)
    Box(
        modifier.fillMaxSize().clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFF1E1F22), Color(0xFF0E0F10))))
            .border(1.dp, Color(0x40FFFFFF), shape)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 16.dp, vertical = 12.dp),
    ) { content() }
}

private fun open(ctx: Context, intent: Intent) {
    try {
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
    }
}

private class AgendaEvent(val title: String, val begin: Long, val end: Long, val allDay: Boolean, val color: Int)

private fun loadEvents(ctx: Context): List<AgendaEvent> = try {
    val now = System.currentTimeMillis()
    val builder = CalendarContract.Instances.CONTENT_URI.buildUpon()
    ContentUris.appendId(builder, now)
    ContentUris.appendId(builder, now + 36L * 3_600_000L)
    val out = ArrayList<AgendaEvent>()
    ctx.contentResolver.query(
        builder.build(),
        arrayOf(
            CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN, CalendarContract.Instances.END,
            CalendarContract.Instances.ALL_DAY, CalendarContract.Instances.CALENDAR_COLOR,
        ),
        null, null, CalendarContract.Instances.BEGIN + " ASC",
    )?.use { c ->
        while (c.moveToNext() && out.size < 12) {
            val title = c.getString(0)?.ifBlank { null } ?: "(no title)"
            val end = c.getLong(2)
            if (end < now) continue
            out.add(AgendaEvent(title, c.getLong(1), end, c.getInt(3) == 1, c.getInt(4)))
        }
    }
    out.sortedWith(compareBy({ !it.allDay }, { it.begin }))
} catch (e: Exception) {
    emptyList()
}

/** The next events of your calendar, today first. Needs the calendar permission, which it asks for when you tap it. */
@Composable
fun AgendaWidget() {
    val ctx = LocalContext.current
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED)
    }
    val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    var events by remember { mutableStateOf<List<AgendaEvent>>(emptyList()) }
    var loaded by remember { mutableStateOf(false) }
    LaunchedEffect(granted) {
        while (granted) {
            events = withContext(Dispatchers.IO) { loadEvents(ctx) }
            loaded = true
            delay(60_000L)
        }
    }
    val is24 = remember { DateFormat.is24HourFormat(ctx) }
    val timeFmt = remember { SimpleDateFormat(if (is24) "HH:mm" else "h:mm a", Locale.getDefault()) }
    val dayFmt = remember { SimpleDateFormat("EEEE d MMMM", Locale.getDefault()) }
    val now = System.currentTimeMillis()
    SmartCard(onClick = if (!granted) ({ ask.launch(Manifest.permission.READ_CALENDAR) }) else null) {
        Column(Modifier.fillMaxSize()) {
            Text(dayFmt.format(Date(now)), color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            when {
                !granted -> Text("Tap to let Eon read your calendar", color = Color(0xFFB5B8BF), fontSize = 13.sp)
                loaded && events.isEmpty() -> Text("Nothing planned for the next day and a half", color = Color(0xFFB5B8BF), fontSize = 13.sp)
                else -> events.take(4).forEach { e ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(8.dp).clip(CircleShape).background(if (e.color != 0) Color(e.color) else Eon.DAccent))
                        Text(
                            if (e.allDay) "All day" else if (e.begin <= now) "Now" else timeFmt.format(Date(e.begin)),
                            color = Color(0xFFB5B8BF), fontSize = 12.sp, modifier = Modifier.padding(start = 8.dp),
                        )
                        Text(
                            e.title, color = Color(0xFFF5F5F6), fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(start = 10.dp).weight(1f),
                        )
                    }
                }
            }
        }
    }
}

/** The battery level with a bar, and whether it is charging. */
@Composable
fun BatteryWidget() {
    val ctx = LocalContext.current
    var level by remember { mutableStateOf(0) }
    var charging by remember { mutableStateOf(false) }
    DisposableEffect(Unit) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, intent: Intent?) {
                val l = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
                val s = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
                if (l >= 0 && s > 0) level = l * 100 / s
                charging = (intent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
            }
        }
        val sticky = ContextCompat.registerReceiver(
            ctx, receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED,
        )
        receiver.onReceive(ctx, sticky)
        onDispose {
            try {
                ctx.unregisterReceiver(receiver)
            } catch (_: Exception) {
            }
        }
    }
    SmartCard(onClick = { open(ctx, Intent(Intent.ACTION_POWER_USAGE_SUMMARY)) }) {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center) {
            Row(verticalAlignment = Alignment.Bottom) {
                Text("$level%", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                Text(
                    if (charging) "  Charging" else "  Battery", color = Color(0xFFB5B8BF), fontSize = 13.sp,
                    modifier = Modifier.padding(bottom = 5.dp),
                )
            }
            Spacer(Modifier.height(8.dp))
            Box(Modifier.fillMaxWidth().height(6.dp).clip(CircleShape).background(Color(0x33FFFFFF))) {
                Box(Modifier.fillMaxHeight().fillMaxWidth(level.coerceIn(2, 100) / 100f).clip(CircleShape).background(Eon.Button))
            }
        }
    }
}

/** The next alarm. Tap to open your alarms. */
@Composable
fun AlarmWidget() {
    val ctx = LocalContext.current
    var tick by remember { mutableLongStateOf(0L) }
    DisposableEffect(Unit) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, intent: Intent?) {
                tick++
            }
        }
        ContextCompat.registerReceiver(
            ctx, receiver, IntentFilter(AlarmManager.ACTION_NEXT_ALARM_CLOCK_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED,
        )
        onDispose {
            try {
                ctx.unregisterReceiver(receiver)
            } catch (_: Exception) {
            }
        }
    }
    val next: Long? = remember(tick) {
        try {
            (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager).nextAlarmClock?.triggerTime
        } catch (e: Exception) {
            null
        }
    }
    val is24 = remember { DateFormat.is24HourFormat(ctx) }
    SmartCard(onClick = { open(ctx, Intent(AlarmClock.ACTION_SHOW_ALARMS)) }) {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center) {
            if (next == null) {
                Text("No alarm", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Nothing set", color = Color(0xFFB5B8BF), fontSize = 13.sp)
            } else {
                Text(
                    SimpleDateFormat(if (is24) "HH:mm" else "h:mm a", Locale.getDefault()).format(Date(next)),
                    color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold,
                )
                Text(
                    "Next alarm, " + SimpleDateFormat("EEEE", Locale.getDefault()).format(Date(next)),
                    color = Color(0xFFB5B8BF), fontSize = 13.sp,
                )
            }
        }
    }
}

/** How much of the phone's storage is free. Tap to open Android's storage page. */
@Composable
fun StorageWidget() {
    val ctx = LocalContext.current
    val usage: Pair<Long, Long> = remember {
        try {
            val s = StatFs(Environment.getDataDirectory().path)
            s.availableBytes to s.totalBytes
        } catch (e: Exception) {
            0L to 0L
        }
    }
    val (free, total) = usage
    fun gb(b: Long): String = if (b >= 1_000_000_000_000L) String.format(Locale.getDefault(), "%.1f TB", b / 1e12)
    else String.format(Locale.getDefault(), "%.0f GB", b / 1e9)
    val usedFraction = if (total > 0) 1f - free.toFloat() / total else 0f
    SmartCard(onClick = { open(ctx, Intent("android.settings.INTERNAL_STORAGE_SETTINGS")) }) {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center) {
            Text(gb(free) + " free", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("of " + gb(total), color = Color(0xFFB5B8BF), fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Box(Modifier.fillMaxWidth().height(6.dp).clip(CircleShape).background(Color(0x33FFFFFF))) {
                Box(Modifier.fillMaxHeight().fillMaxWidth(usedFraction.coerceIn(0.02f, 1f)).clip(CircleShape).background(Eon.Button))
            }
        }
    }
}
