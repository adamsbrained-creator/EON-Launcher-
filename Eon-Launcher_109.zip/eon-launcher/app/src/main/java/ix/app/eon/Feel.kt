package ix.app.eon

import android.os.Build
import android.view.HapticFeedbackConstants
import android.view.View
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

/** The names of the haptic levels, in the order of [Haptics.level]. */
val HAPTIC_LEVELS = listOf("Off", "Subtle", "Full")

/**
 * Vibration feedback for the whole launcher.
 * - Off: nothing.
 * - Subtle: only long presses and dragging (what Eon always did).
 * - Full: also a tap when an app opens, a tick for every page you swipe to, for the drawer and folders opening and
 *   closing, and for every switch you flip.
 * Android's own "touch feedback" setting still decides whether the phone vibrates at all.
 */
object Haptics {
    var level by mutableIntStateOf(2)
    private var view: View? = null
    private var prefs: Prefs? = null

    fun load(p: Prefs) {
        prefs = p
        level = p.getInt("hapticLevel", 2).coerceIn(0, HAPTIC_LEVELS.size - 1)
    }

    fun choose(v: Int) {
        level = v
        prefs?.putInt("hapticLevel", v)
    }

    fun attach(v: View) {
        view = v
    }

    private fun play(minLevel: Int, constant: Int) {
        if (level < minLevel) return
        try {
            view?.performHapticFeedback(constant)
        } catch (_: Exception) {
        }
    }

    /** A crisp tap: an app opens. */
    fun tap() = play(2, HapticFeedbackConstants.KEYBOARD_TAP)

    /** A light tick: a page snaps into place, the drawer or a folder opens or closes. */
    fun tick() = play(2, HapticFeedbackConstants.CLOCK_TICK)

    /** A switch flips on or off. */
    fun toggle(on: Boolean) = play(
        2,
        if (Build.VERSION.SDK_INT >= 34) {
            if (on) HapticFeedbackConstants.TOGGLE_ON else HapticFeedbackConstants.TOGGLE_OFF
        } else {
            HapticFeedbackConstants.CLOCK_TICK
        },
    )
}

/** Compose's own haptics (long press, drag ticks) pass through here, so "Off" silences them too. */
class GatedHaptic(private val base: HapticFeedback) : HapticFeedback {
    override fun performHapticFeedback(hapticFeedbackType: HapticFeedbackType) {
        if (Haptics.level > 0) base.performHapticFeedback(hapticFeedbackType)
    }
}

/** Shrinks a little under a finger and springs back with a small bounce. Only watches the touch. */
@Composable
fun Modifier.pressScale(amount: Float = 0.96f): Modifier {
    var pressed by remember { mutableStateOf(false) }
    val s by animateFloatAsState(
        if (pressed && AnimConfig.press) amount else 1f,
        spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMedium), label = "pressScale",
    )
    return this.pressFeedback { pressed = it }.graphicsLayer { scaleX = s; scaleY = s }
}

/** Fades and rises into place when it first appears; [index] staggers the start so a list builds up one by one. */
@Composable
fun Modifier.staggerIn(index: Int): Modifier {
    val t = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay((index.coerceAtMost(10) * 35).toLong())
        t.animateTo(1f, tween(380))
    }
    return this.graphicsLayer {
        val v = t.value
        alpha = v
        translationY = (1f - v) * 14.dp.toPx()
    }
}
