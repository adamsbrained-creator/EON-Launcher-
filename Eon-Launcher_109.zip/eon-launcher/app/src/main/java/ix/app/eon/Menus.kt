package ix.app.eon

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Category
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Image as ImageIcon
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.OpenWith
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.KeyboardArrowLeft
import androidx.compose.material.icons.outlined.KeyboardArrowRight
import androidx.compose.material.icons.outlined.Settings as SettingsIcon
import androidx.compose.material.icons.outlined.TouchApp
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material.icons.outlined.Widgets
import androidx.compose.material.icons.outlined.Wallpaper
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog

@Composable
private fun MenuRow(icon: ImageVector, text: String, color: Color = Eon.Text, chevron: Boolean = false, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Icon(icon, null, tint = if (color == Eon.Text) Eon.Soft else color, modifier = Modifier.size(20.dp))
        Text(text, color = color, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
        // A row that opens a smaller menu has an arrow at its end.
        if (chevron) Icon(Icons.Outlined.KeyboardArrowRight, null, tint = Eon.Muted, modifier = Modifier.size(20.dp))
    }
}

/** The top row of a smaller menu: tap it to go back to the menu it came from. */
@Composable
private fun SubMenuHeader(title: String, onBack: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onBack).padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Icon(Icons.Outlined.KeyboardArrowLeft, "Back", tint = Eon.Soft, modifier = Modifier.size(20.dp))
        Text(title, color = Eon.Text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun MenuDivider() {
    Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp).height(1.dp).background(Eon.ov(0x24)))
}

/** Long-press menu for an app icon. */
@Composable
fun AppMenu(
    app: AppEntry, state: EonState, onDismiss: () -> Unit,
) {
    val ctx = LocalContext.current
    var picking by remember { mutableStateOf(false) }
    var sub by remember { mutableStateOf("") } // "", "rename", "icon" or "folder"
    // The menu has two smaller menus so it stays short: "" (the main one), "organize" or "customize".
    var page by remember { mutableStateOf("") }
    if (sub == "folder") {
        AppFolderPicker(app, state, onDone = onDismiss, onBack = { sub = "" })
        return
    }
    if (sub == "rename") {
        RenameAppDialog(app, state, onBack = { sub = "" }, onDone = onDismiss)
        return
    }
    if (sub == "icon") {
        ChangeIconDialog(app, state, onBack = { sub = "" }, onDone = onDismiss)
        return
    }
    val category = state.overrides[app.packageName] ?: app.autoCategory
    val pinned = state.isPinned(app.key)
    val inDock = state.isInDock(app.key)

    Dialog(onDismissRequest = onDismiss) {
        Column(Modifier.width(300.dp).glass(RoundedCornerShape(26.dp)).padding(vertical = 8.dp)) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Image(app.icon, null, Modifier.size(44.dp))
                Column {
                    Text(app.label, color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    Text(state.categoryName(category), color = Eon.Muted, fontSize = 12.sp)
                }
            }
            MenuDivider()
            if (BadgeStyle.peek && !picking && page == "" && Badges.latest.containsKey(app.packageName)) {
                NotificationPeek(app)
                MenuDivider()
            }
            // The app's own shortcuts (only when Eon is the home app, since Android hides them from other apps).
            val shortcuts by produceState(emptyList<AppShortcut>(), app.key) { value = loadShortcuts(ctx, app) }
            if (!picking && page == "" && shortcuts.isNotEmpty()) {
                shortcuts.forEach { sc -> ShortcutRow(sc) { startShortcut(ctx, sc); onDismiss() } }
                MenuDivider()
            }
            if (!picking) {
                if (page == "") {
                    if (inDock) {
                        MenuRow(Icons.Outlined.Home, "Move to home") {
                            if (!state.dockToHome(app.key)) {
                                android.widget.Toast.makeText(ctx, "No space on this page", android.widget.Toast.LENGTH_SHORT).show()
                            }
                            onDismiss()
                        }
                        MenuRow(Icons.Outlined.GridView, "Remove from dock") {
                            state.removeFromDock(app.key)
                            onDismiss()
                        }
                    } else {
                        if (state.folderOf(app.key) != null) {
                            MenuRow(Icons.Outlined.GridView, "Take out of folder") {
                                if (!state.takeOutOfFolder(app.key)) {
                                    android.widget.Toast.makeText(ctx, "No space on this page", android.widget.Toast.LENGTH_SHORT).show()
                                }
                                onDismiss()
                            }
                        }
                        MenuRow(Icons.Outlined.Home, if (pinned) "Remove from home" else "Pin to home") {
                            if (!state.togglePin(app.key)) {
                                android.widget.Toast.makeText(ctx, "No space on this page", android.widget.Toast.LENGTH_SHORT).show()
                            }
                            onDismiss()
                        }
                        if (HomeConfig.dockOn) {
                            MenuRow(Icons.Outlined.GridView, "Move to dock") {
                                if (!state.moveToDock(app.key)) {
                                    android.widget.Toast.makeText(ctx, "The dock is full", android.widget.Toast.LENGTH_SHORT).show()
                                }
                                onDismiss()
                            }
                        }
                    }
                    MenuRow(Icons.Outlined.Folder, "Organize", chevron = true) { page = "organize" }
                    MenuRow(Icons.Outlined.Tune, "Customize", chevron = true) { page = "customize" }
                    MenuRow(Icons.Outlined.Info, "App info") {
                        ctx.startActivity(
                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.packageName}"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                        )
                        onDismiss()
                    }
                    MenuRow(Icons.Outlined.Delete, "Uninstall", Eon.Danger) {
                        try {
                            ctx.startActivity(
                                Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.packageName}"))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                            )
                        } catch (_: Exception) {
                            // No uninstaller answered: open the app's info page, which has an Uninstall button.
                            try {
                                ctx.startActivity(
                                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.packageName}"))
                                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                                )
                            } catch (_: Exception) {
                            }
                        }
                        onDismiss()
                    }
                } else if (page == "organize") {
                    SubMenuHeader("Organize") { page = "" }
                    MenuDivider()
                    val inAppFolder = state.drawerFolderOf(app.key)
                    if (inAppFolder != null) {
                        MenuRow(Icons.Outlined.Folder, "Take out of " + inAppFolder.name.ifBlank { "folder" }) {
                            state.removeFromDrawerFolder(app.key)
                            onDismiss()
                        }
                    }
                    MenuRow(Icons.Outlined.Folder, if (inAppFolder != null) "Move to another folder" else "Add to folder") { sub = "folder" }
                    MenuRow(Icons.Outlined.Category, "Change category") { picking = true }
                    MenuRow(Icons.Outlined.VisibilityOff, "Hide from drawer") {
                        state.hide(app.packageName); onDismiss()
                    }
                    MenuRow(Icons.Outlined.Lock, if (AppLock.isLocked(app.key)) "Unlock app" else "Lock app") {
                        AppLock.toggle(app.key); onDismiss()
                    }
                } else {
                    SubMenuHeader("Customize") { page = "" }
                    MenuDivider()
                    MenuRow(Icons.Outlined.Edit, "Rename") { sub = "rename" }
                    MenuRow(Icons.Outlined.ImageIcon, "Change icon") { sub = "icon" }
                    MenuRow(Icons.Outlined.TouchApp, "Gestures") {
                        state.gestureEditor = GestureTarget("a", app.key, app.label)
                        onDismiss()
                    }
                }
            } else {
                SubMenuHeader("Change category") { picking = false }
                MenuDivider()
                Column(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState())) {
                    state.categories.filter { it.id != CAT_ALL }.forEach { c ->
                        Text(
                            c.name, color = if (c.id == category) Eon.Accent else Eon.Text, fontSize = 15.sp,
                            fontWeight = if (c.id == category) FontWeight.Bold else FontWeight.Medium,
                            modifier = Modifier.fillMaxWidth()
                                .clickable { state.setCategory(app.packageName, c.id); onDismiss() }
                                .padding(horizontal = 20.dp, vertical = 12.dp),
                        )
                    }
                    if (state.overrides.containsKey(app.packageName)) {
                        Text(
                            "Automatic", color = Eon.Muted, fontSize = 15.sp, fontWeight = FontWeight.Medium,
                            modifier = Modifier.fillMaxWidth()
                                .clickable { state.clearCategory(app.packageName); onDismiss() }
                                .padding(horizontal = 20.dp, vertical = 12.dp),
                        )
                    }
                }
            }
        }
    }
}

/** Long-press menu for the empty home screen. */
@Composable
fun HomeMenu(
    onDismiss: () -> Unit, onWidgets: () -> Unit,
    onAddLeft: () -> Unit, onAddRight: () -> Unit,
    canRemove: Boolean, onRemove: () -> Unit,
    onSettings: () -> Unit, onWallpaper: () -> Unit,
    freeIcons: Boolean, onTogglePlacement: () -> Unit,
    searchHidden: Boolean, onShowSearch: () -> Unit,
) {
    Dialog(onDismissRequest = onDismiss) {
        Column(Modifier.width(280.dp).glass(RoundedCornerShape(26.dp)).padding(vertical = 8.dp)) {
            MenuRow(Icons.Outlined.Wallpaper, "Wallpaper", onClick = onWallpaper)
            MenuRow(Icons.Outlined.Widgets, "Widgets", onClick = onWidgets)
            MenuRow(
                if (freeIcons) Icons.Outlined.GridView else Icons.Outlined.OpenWith,
                if (freeIcons) "Snap icons to grid" else "Place icons freely",
                onClick = onTogglePlacement,
            )
            if (searchHidden) MenuRow(Icons.Outlined.Search, "Show search pill", onClick = onShowSearch)
            MenuRow(Icons.Outlined.KeyboardArrowLeft, "Add page to the left", onClick = onAddLeft)
            MenuRow(Icons.Outlined.KeyboardArrowRight, "Add page to the right", onClick = onAddRight)
            if (canRemove) MenuRow(Icons.Outlined.Delete, "Remove this page", Eon.Danger, onClick = onRemove)
            MenuRow(Icons.Outlined.SettingsIcon, "Eon settings", onClick = onSettings)
        }
    }
}
