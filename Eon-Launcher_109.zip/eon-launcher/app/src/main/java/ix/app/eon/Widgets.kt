package ix.app.eon

import android.app.Activity
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.delay
import kotlin.math.ceil

/** Owns the app widget host for the whole launcher. */
class WidgetHolder(context: Context) {
    val manager: AppWidgetManager = AppWidgetManager.getInstance(context)
    val host = AppWidgetHost(context, 1024)

    fun appLabel(context: Context, info: AppWidgetProviderInfo): String = try {
        val pm = context.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(info.provider.packageName, 0)).toString()
    } catch (_: Exception) {
        info.provider.packageName
    }

    fun providers(context: Context): List<AppWidgetProviderInfo> =
        manager.installedProviders.sortedWith(
            compareBy({ appLabel(context, it).lowercase() }, { it.loadLabel(context.packageManager).lowercase() }),
        )
}

/** Default size, in grid cells, of Eon's own widgets. */
fun builtinSize(id: Int): Pair<Int, Int>? = when (id) {
    W_NOW_PLAYING -> 4 to 1
    W_WEATHER -> 4 to 1
    W_WEEK -> 4 to 2
    W_AGENDA -> 4 to 2
    W_BATTERY -> 2 to 1
    W_ALARM -> 2 to 1
    W_STORAGE -> 2 to 1
    W_AI -> 3 to 1
    else -> null
}

/** A starting size in grid cells for a system widget, from what its provider asks for. */
fun suggestSize(ctx: Context, info: AppWidgetProviderInfo): Pair<Int, Int> {
    val d = ctx.resources.displayMetrics.density
    val cellWDp = (ctx.resources.configuration.screenWidthDp - 32) / GRID_COLS.toFloat()
    val w = ceil((info.minWidth / d) / cellWDp).toInt().coerceIn(1, GRID_COLS)
    val h = ceil((info.minHeight / d) / CELL_HEIGHT.value).toInt().coerceIn(1, 4)
    return w to h
}

/** One widget, filling the cells it was given. */
@Composable
fun WidgetView(holder: WidgetHolder, id: Int, wDp: Int, hDp: Int) {
    if (id == W_NOW_PLAYING) {
        NowPlayingWidget()
        return
    }
    if (id == W_WEEK) {
        WeekWidget()
        return
    }
    if (id == W_WEATHER) {
        WeatherQuoteWidget()
        return
    }
    if (id == W_AGENDA) {
        AgendaWidget()
        return
    }
    if (id == W_BATTERY) {
        BatteryWidget()
        return
    }
    if (id == W_ALARM) {
        AlarmWidget()
        return
    }
    if (id == W_STORAGE) {
        StorageWidget()
        return
    }
    if (id == W_AI) {
        AiWidget()
        return
    }
    val info = remember(id) { holder.manager.getAppWidgetInfo(id) } ?: return
    // The widget is told its new size only once resizing pauses, so dragging an edge stays smooth.
    var sw by remember { mutableIntStateOf(wDp) }
    var sh by remember { mutableIntStateOf(hDp) }
    LaunchedEffect(wDp, hDp) {
        delay(140)
        sw = wDp
        sh = hDp
    }
    AndroidView(
        factory = { c -> holder.host.createView(c, id, info) },
        update = { v -> runCatching { v.updateAppWidgetSize(Bundle(), sw, sh, sw, sh) } },
        modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(24.dp)),
    )
}

/** Full-screen widget picker and manager. */
@Composable
fun WidgetsScreen(state: EonState, holder: WidgetHolder, stackTarget: Int? = null, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var pending by remember { mutableStateOf<Pair<Int, AppWidgetProviderInfo>?>(null) }
    val providers = remember { holder.providers(ctx) }
    BackHandler { onClose() }

    fun addBuiltin(id: Int) {
        if (id == W_STACK_TILE) {
            state.stackSizeScreen = true
            return
        }
        if (stackTarget != null) {
            if (state.addToStack(stackTarget, id)) onClose()
            else Toast.makeText(ctx, "Already in this stack", Toast.LENGTH_SHORT).show()
            return
        }
        val (w, h) = builtinSize(id) ?: return
        if (state.addWidget(id, w, h)) {
            state.editing = id.toString()
            onClose()
        } else {
            Toast.makeText(ctx, "No space on this page", Toast.LENGTH_SHORT).show()
        }
    }

    fun commit(id: Int, info: AppWidgetProviderInfo) {
        if (stackTarget != null) {
            if (!state.addToStack(stackTarget, id)) holder.host.deleteAppWidgetId(id)
            pending = null
            onClose()
            return
        }
        val (w, h) = suggestSize(ctx, info)
        if (state.addWidget(id, w, h)) {
            state.editing = id.toString()
            onClose()
        } else {
            holder.host.deleteAppWidgetId(id)
            Toast.makeText(ctx, "No space on this page", Toast.LENGTH_SHORT).show()
        }
        pending = null
    }

    fun cancel() {
        pending?.first?.let { holder.host.deleteAppWidgetId(it) }
        pending = null
    }

    val configure = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val p = pending
        if (p != null) {
            if (r.resultCode == Activity.RESULT_OK) commit(p.first, p.second) else cancel()
        }
    }

    fun afterBind(id: Int, info: AppWidgetProviderInfo) {
        pending = id to info
        val cfg = info.configure
        if (cfg != null) {
            try {
                configure.launch(
                    Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE)
                        .setComponent(cfg)
                        .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id),
                )
            } catch (_: Exception) {
                commit(id, info)
            }
        } else {
            commit(id, info)
        }
    }

    val bind = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val p = pending
        if (p != null) {
            if (r.resultCode == Activity.RESULT_OK) afterBind(p.first, p.second) else cancel()
        }
    }

    fun add(info: AppWidgetProviderInfo) {
        val id = holder.host.allocateAppWidgetId()
        pending = id to info
        if (holder.manager.bindAppWidgetIdIfAllowed(id, info.provider)) {
            afterBind(id, info)
        } else {
            bind.launch(
                Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider),
            )
        }
    }

    if (state.stackSizeScreen) {
        StackSizeScreen(state, onBack = { state.stackSizeScreen = false }, onAdded = { state.stackSizeScreen = false; onClose() })
        return
    }
    if (tab == 0) {
        WidgetPicker(
            state, holder, allowStack = stackTarget == null, onBack = onClose, onManage = { tab = 1 },
            onAddBuiltin = ::addBuiltin, onAddProvider = ::add,
        )
        return
    }

    Column(
        Modifier.fillMaxSize().background(Eon.Page).systemBarsPadding().padding(horizontal = 20.dp),
    ) {
        Gap(12)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(Eon.ov(0x24)).clickable { tab = 0 },
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Outlined.ArrowBack, "Back", tint = Eon.Text, modifier = Modifier.size(22.dp)) }
            Text("On this page", color = Eon.Text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
        Gap(16)
        run {
            if (state.widgetItems().isEmpty()) {
                Text("No widgets on this page yet.", color = Eon.Muted, fontSize = 14.sp)
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(state.widgetItems(), key = { it.key }) { item ->
                    val id = item.key.toIntOrNull() ?: 0
                    val info = holder.manager.getAppWidgetInfo(id)
                    Column(
                        Modifier.fillMaxWidth().glass(RoundedCornerShape(22.dp)).padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    builtinLabel(id) ?: info?.loadLabel(ctx.packageManager)?.toString() ?: "Widget",
                                    color = Eon.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                                )
                                Text("${cellText(item.w)} × ${cellText(item.h)} cells", color = Eon.Muted, fontSize = 12.sp)
                            }
                            if (isStackId(id)) {
                                SmallBtn("Configure") { state.stackConfig = id }
                                Spacer(Modifier.width(8.dp))
                            }
                            SmallBtn("Remove", Eon.Danger) {
                                state.removeWidget(id) { holder.host.deleteAppWidgetId(it) }
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            SmallBtn("←") { state.nudgeWidget(item.key, -1, 0) }
                            SmallBtn("→") { state.nudgeWidget(item.key, 1, 0) }
                            SmallBtn("↑") { state.nudgeWidget(item.key, 0, -1) }
                            SmallBtn("↓") { state.nudgeWidget(item.key, 0, 1) }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            SmallBtn("Taller") { state.resizeWidget(item.key, 0, 1) }
                            SmallBtn("Shorter") { state.resizeWidget(item.key, 0, -1) }
                            SmallBtn("Wider") { state.resizeWidget(item.key, 1, 0) }
                            SmallBtn("Narrower") { state.resizeWidget(item.key, -1, 0) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SmallBtn(label: String, color: Color = Eon.Text, onClick: () -> Unit) {
    Box(
        Modifier.height(32.dp).clip(CircleShape).background(Eon.ov(0x24)).clickable(onClick = onClick)
            .padding(horizontal = 12.dp),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = color, fontSize = 13.sp, fontWeight = FontWeight.Medium) }
}
