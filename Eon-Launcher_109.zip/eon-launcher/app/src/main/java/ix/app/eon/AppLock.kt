package ix.app.eon

import android.app.Activity
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.os.CancellationSignal
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.lang.ref.WeakReference

/**
 * Apps you locked (long-press an app, Organize, Lock app). Opening one from Eon asks for your fingerprint, face or screen
 * lock first. It guards the app only when it is opened from Eon: another launcher, a notification or a shortcut can still
 * start it, so this is a screen in front of the icon rather than a lock on the app.
 */
object AppLock {
    var locked by mutableStateOf<Set<String>>(emptySet())
        private set

    private var prefs: Prefs? = null

    /** The screen the prompt is shown over. Set by [MainActivity]. */
    var activity: WeakReference<Activity>? = null

    fun load(p: Prefs) {
        prefs = p
        locked = p.getString("lockedApps").split("\n").filter { it.isNotBlank() }.toSet()
    }

    fun isLocked(key: String): Boolean = key in locked

    fun toggle(key: String) {
        locked = if (key in locked) locked - key else locked + key
        prefs?.putString("lockedApps", locked.joinToString("\n"))
    }

    /** Runs [then] at once for an app that is not locked, otherwise after the person has proved who they are. */
    fun guard(app: AppEntry, then: () -> Unit) {
        if (app.key !in locked) {
            then()
            return
        }
        val act = activity?.get() ?: return
        try {
            val prompt = BiometricPrompt.Builder(act)
                .setTitle("Unlock " + app.label)
                .setAllowedAuthenticators(
                    BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL,
                )
                .build()
            prompt.authenticate(
                CancellationSignal(),
                act.mainExecutor,
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) {
                        then()
                    }

                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) {
                        // 14: the phone has no screen lock or fingerprint set up, so there is nothing to ask for.
                        if (errorCode == 14) {
                            Toast.makeText(act, "Set a screen lock in Android settings to use app lock", Toast.LENGTH_LONG).show()
                        }
                    }
                },
            )
        } catch (e: Exception) {
            Toast.makeText(act, "Could not ask for your fingerprint or screen lock", Toast.LENGTH_SHORT).show()
        }
    }
}
