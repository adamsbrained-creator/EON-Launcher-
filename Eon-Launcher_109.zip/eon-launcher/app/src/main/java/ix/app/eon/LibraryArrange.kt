package ix.app.eon

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.VectorConverter
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateIntOffsetAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Remove
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.positionInParent
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.ceil
import kotlin.math.roundToInt

/**
 * Arrange: your boxes as cards you can move. Hold a box and drag it, and the others make room; let go and the order
 * is saved. The minus takes a box away (its apps go back to their automatic box), New box adds one, and the switch at
 * the top lets Eon order the boxes by how often you open them (then they cannot be moved by hand).
 */
@Composable
internal fun LibArrangeScreen(
    boxes: List<LibTile>, state: EonState, onNewBox: () -> Unit, onDone: () -> Unit,
) {
    BackHandler { onDone() }
    val cols = DrawerConfig.libColumns
    val haptic = LocalHapticFeedback.current
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    val scroll = rememberScrollState()
    val canDrag = !LibraryConfig.smartBoxes

    val baseIds = boxes.map { it.id }
    var dragOrder by remember { mutableStateOf<List<String>?>(null) }
    var dragId by remember { mutableStateOf<String?>(null) }
    var pointer by remember { mutableStateOf(Offset.Zero) }   // the finger, in the grid's own coordinates
    var grab by remember { mutableStateOf(Offset.Zero) }      // where on the box the finger took hold
    var releasing by remember { mutableStateOf(false) }
    var settlePos by remember { mutableStateOf(Offset.Zero) }
    var viewportH by remember { mutableIntStateOf(0) }
    var gridTop by remember { mutableFloatStateOf(0f) }
    val order = dragOrder ?: baseIds
    val byId = boxes.associateBy { it.id }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 20.dp, end = 16.dp, top = 10.dp),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("Arrange", color = Eon.DText, fontSize = 30.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.7).sp, lineHeight = 33.sp)
                Text(
                    if (canDrag) "Hold and drag a box to move it." else "Boxes follow how often you open them.",
                    color = Eon.DText.copy(alpha = 0.76f), fontSize = 13.sp,
                )
            }
            Box(
                Modifier.height(44.dp).clip(RoundedCornerShape(22.dp)).background(libGrad3()).clickable(onClick = onDone)
                    .padding(horizontal = 22.dp),
                contentAlignment = Alignment.Center,
            ) { Text("Done", color = Eon.DInk, fontSize = 15.sp, fontWeight = FontWeight.SemiBold) }
        }

        Column(
            Modifier.weight(1f).fillMaxWidth().onSizeChanged { viewportH = it.height }
                .verticalScroll(scroll).padding(horizontal = 16.dp),
        ) {
            // Most used boxes first.
            val cardShape = RoundedCornerShape(22.dp)
            Row(
                Modifier.padding(top = 20.dp).fillMaxWidth().height(64.dp).clip(cardShape).background(Color(0x1AFFFFFF))
                    .border(1.dp, Color(0x2EFFFFFF), cardShape).padding(start = 18.dp, end = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("Most used boxes first", color = Eon.DText, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    Text("Eon orders boxes by how often you open them", color = Eon.DText.copy(alpha = 0.72f), fontSize = 12.sp)
                }
                EonSwitch(LibraryConfig.smartBoxes) { LibraryConfig.chooseSmartBoxes(it) }
            }
            Spacer(Modifier.height(16.dp))

            BoxWithConstraints(Modifier.fillMaxWidth().onGloballyPositioned { gridTop = it.positionInParent().y }) {
                val gap = 12.dp
                val tileW = (maxWidth - gap * (cols - 1)) / cols
                val tileH = tileW + 26.dp   // the square plus its name underneath
                val wPx = with(density) { tileW.toPx() }
                val hPx = with(density) { tileH.toPx() }
                val gPx = with(density) { gap.toPx() }
                val orderNow by rememberUpdatedState(order)
                val baseNow by rememberUpdatedState(baseIds)
                val slots = order.size + 1
                val rows = ceil(slots / cols.toFloat()).toInt()
                fun slotOf(i: Int) = Offset((i % cols) * (wPx + gPx), (i / cols) * (hPx + gPx))

                // Which place in the grid the finger is over; the dragged box takes that place and the rest shuffle.
                fun retarget() {
                    val id = dragId ?: return
                    val ids = dragOrder ?: return
                    val col = (pointer.x / (wPx + gPx)).toInt().coerceIn(0, cols - 1)
                    val row = (pointer.y / (hPx + gPx)).toInt().coerceAtLeast(0)
                    val to = (row * cols + col).coerceIn(0, ids.size - 1)
                    val from = ids.indexOf(id)
                    if (from >= 0 && to != from) {
                        dragOrder = ids.toMutableList().also {
                            it.removeAt(from)
                            it.add(to, id)
                        }
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    }
                }

                fun finish() {
                    val id = dragId ?: return
                    if (releasing) return
                    releasing = true
                    val ids = dragOrder ?: orderNow
                    val to = ids.indexOf(id)
                    val from = baseNow.indexOf(id)
                    val target = slotOf(to.coerceAtLeast(0))
                    settlePos = pointer - grab
                    scope.launch {
                        val a = Animatable(settlePos, Offset.VectorConverter)
                        a.animateTo(target, spring(dampingRatio = 0.8f, stiffness = 500f)) { settlePos = value }
                        if (from >= 0 && to >= 0 && to != from) state.moveCategory(id, to - from)
                        dragId = null
                        dragOrder = null
                        releasing = false
                    }
                }

                // Near the top or the bottom of the screen the page scrolls by itself while a box is held.
                LaunchedEffect(dragId, releasing) {
                    if (dragId == null || releasing) return@LaunchedEffect
                    val edge = with(density) { 90.dp.toPx() }
                    while (true) {
                        val y = gridTop + pointer.y - scroll.value
                        val dy = when {
                            y < edge -> -(edge - y) / edge * 22f
                            y > viewportH - edge -> (y - (viewportH - edge)) / edge * 22f
                            else -> 0f
                        }
                        if (dy != 0f) {
                            val used = scroll.scrollBy(dy)
                            if (used != 0f) {
                                pointer = Offset(pointer.x, pointer.y + used)
                                retarget()
                            }
                        }
                        delay(16)
                    }
                }

                Box(
                    Modifier.fillMaxWidth().height(tileH * rows + gap * (rows - 1))
                        .pointerInput(canDrag, wPx, hPx, cols) {
                            if (!canDrag) return@pointerInput
                            detectDragGesturesAfterLongPress(
                                onDragStart = { off ->
                                    val col = (off.x / (wPx + gPx)).toInt()
                                    val row = (off.y / (hPx + gPx)).toInt()
                                    val inX = off.x - col * (wPx + gPx) <= wPx
                                    val inY = off.y - row * (hPx + gPx) <= hPx
                                    val idx = row * cols + col
                                    val ids = orderNow
                                    if (!releasing && col in 0 until cols && inX && inY && idx in ids.indices) {
                                        dragOrder = ids
                                        dragId = ids[idx]
                                        pointer = off
                                        grab = off - slotOf(idx)
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    }
                                },
                                onDrag = { change, _ ->
                                    if (dragId != null && !releasing) {
                                        change.consume()
                                        pointer = change.position
                                        retarget()
                                    }
                                },
                                onDragEnd = { finish() },
                                onDragCancel = { finish() },
                            )
                        },
                ) {
                    order.forEachIndexed { index, id ->
                        val tile = byId[id] ?: return@forEachIndexed
                        androidx.compose.runtime.key(id) {
                            val dragging = id == dragId
                            val target = slotOf(index)
                            val resting by animateIntOffsetAsState(
                                IntOffset(target.x.roundToInt(), target.y.roundToInt()),
                                spring(stiffness = Spring.StiffnessMediumLow), label = "slot",
                            )
                            val pos = if (dragging) {
                                val p = if (releasing) settlePos else pointer - grab
                                IntOffset(p.x.roundToInt(), p.y.roundToInt())
                            } else {
                                resting
                            }
                            ArrangeTile(
                                tile = tile, dragging = dragging, handleOn = canDrag,
                                onRemove = { state.removeCategory(id) },
                                modifier = Modifier.offset { pos }.size(tileW, tileH).zIndex(if (dragging) 1f else 0f),
                            )
                        }
                    }
                    // New box
                    val newAt = slotOf(order.size)
                    val dash = RoundedCornerShape(DrawerConfig.tileRadius.dp)
                    Column(
                        Modifier.offset { IntOffset(newAt.x.roundToInt(), newAt.y.roundToInt()) }.size(tileW, tileH),
                        verticalArrangement = Arrangement.spacedBy(8.dp), horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Box(
                            Modifier.fillMaxWidth().aspectRatio(1f)
                                .drawBehind {
                                    val sw = 2.dp.toPx()
                                    drawRoundRect(
                                        Color(0x5CFFFFFF), topLeft = Offset(sw / 2, sw / 2), size = Size(size.width - sw, size.height - sw),
                                        cornerRadius = CornerRadius(DrawerConfig.tileRadius.dp.toPx()),
                                        style = Stroke(width = sw, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10.dp.toPx(), 8.dp.toPx()))),
                                    )
                                }
                                .clip(dash).clickable(onClick = onNewBox),
                            contentAlignment = Alignment.Center,
                        ) {
                            Box(Modifier.size(56.dp).clip(CircleShape).background(Color(0x1FFFFFFF)), contentAlignment = Alignment.Center) {
                                Icon(Icons.Outlined.Add, null, tint = Eon.DText, modifier = Modifier.size(28.dp))
                            }
                        }
                        Text("New box", color = Eon.DText, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.height(18.dp))
                    }
                }
            }
            Spacer(Modifier.navigationBarsPadding().height(40.dp))
        }
    }
}

/** One box while arranging: the same square as the Library with its name underneath, the minus at the corner. Lifts and glows while held. */
@Composable
private fun ArrangeTile(tile: LibTile, dragging: Boolean, handleOn: Boolean, onRemove: () -> Unit, modifier: Modifier) {
    val shape = RoundedCornerShape(DrawerConfig.tileRadius.dp)
    val lift by animateFloatAsState(if (dragging) 1.05f else 1f, tween(140), label = "lift")
    val wob by rememberInfiniteTransition(label = "wob").animateFloat(
        -0.7f, 0.7f, infiniteRepeatable(tween(150 + (tile.id.hashCode() and 15) * 8), RepeatMode.Reverse), label = "wobv",
    )
    val fill = DrawerConfig.tileColor.copy(alpha = if (dragging) 0.26f else (DrawerConfig.tileOpacity + 0.02f).coerceAtMost(1f))
    Box(modifier.graphicsLayer { scaleX = lift; scaleY = lift; rotationZ = if (dragging) 0f else wob }) {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            BoxWithConstraints(
                Modifier.fillMaxWidth().aspectRatio(1f)
                    .drawBehind {
                        if (dragging) {
                            val g = 6.dp.toPx()
                            drawRoundRect(
                                Eon.DAccent.copy(alpha = 0.18f), topLeft = Offset(-g, -g),
                                size = Size(size.width + g * 2, size.height + g * 2), cornerRadius = CornerRadius(DrawerConfig.tileRadius.dp.toPx() + g),
                            )
                        }
                    }
                    .background(fill, shape)
                    .border(if (dragging) 2.dp else 1.dp, if (dragging) Eon.DAccent else Color(0x2EFFFFFF), shape),
            ) {
                val w = maxWidth
                val pad = w * 0.08f
                val gap = w * 0.06f
                val icon = w * 0.39f
                val apps = tile.apps
                if (apps.isEmpty()) {
                    Box(Modifier.matchParentSize(), contentAlignment = Alignment.Center) {
                        Icon(catIcon(tile.icon ?: "folder"), null, tint = Color(0x66FFFFFF), modifier = Modifier.size(w * 0.3f))
                    }
                } else {
                    val overflow = apps.size > 4
                    val shown = if (overflow) apps.take(3) else apps
                    val near = pad
                    val far = pad + icon + gap
                    val mid = (w - icon) / 2
                    val slots: List<Pair<Dp, Dp>> = when {
                        overflow || apps.size == 4 -> listOf(near to near, far to near, near to far, far to far)
                        apps.size == 3 -> listOf(near to near, far to near, mid to far)
                        apps.size == 2 -> listOf(near to mid, far to mid)
                        else -> listOf(mid to mid)
                    }
                    shown.forEachIndexed { i, app ->
                        Image(
                            bitmap = app.icon, contentDescription = null,
                            modifier = Modifier.offset(slots[i].first, slots[i].second).size(icon),
                        )
                    }
                    if (overflow) {
                        val chip = RoundedCornerShape(icon * 0.32f)
                        Box(
                            Modifier.offset(slots[3].first, slots[3].second).size(icon).clip(chip).background(Color(0x24FFFFFF))
                                .border(1.dp, Color(0x38FFFFFF), chip),
                            contentAlignment = Alignment.Center,
                        ) { Text("+${apps.size - 3}", color = Eon.DText, fontSize = 17.sp, fontWeight = FontWeight.SemiBold) }
                    }
                }
            }
            Row(
                Modifier.fillMaxWidth().height(18.dp), horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    tile.name, color = DrawerConfig.textColor, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false),
                )
                Text("${tile.apps.size}", color = DrawerConfig.textColor.copy(alpha = 0.7f), fontSize = 12.sp, maxLines = 1)
                Canvas(Modifier.size(14.dp).alpha(if (handleOn) 0.9f else 0.3f)) {
                    val r = 1.6f / 24f * size.width
                    val c = Color(0xBFF5F5F6)
                    for (x in listOf(9f, 15f)) for (y in listOf(6f, 12f, 18f)) {
                        drawCircle(c, r, Offset(x / 24f * size.width, y / 24f * size.height))
                    }
                }
            }
        }
        Box(
            Modifier.offset((-8).dp, (-8).dp).size(30.dp).clip(CircleShape).background(Color(0xFF1C1C1F))
                .border(1.dp, Color(0x4DFFFFFF), CircleShape).clickable(onClick = onRemove),
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Outlined.Remove, "Remove ${tile.name}", tint = Eon.DText, modifier = Modifier.size(16.dp)) }
    }
}
