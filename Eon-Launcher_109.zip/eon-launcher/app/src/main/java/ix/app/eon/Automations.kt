package ix.app.eon

import android.Manifest
import android.content.BroadcastReceiver
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiInfo
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject

/** "When [trigger], do [action]." The action is anything the gesture list offers (an app, a Focus mode, a popup widget...). */
class Automation(val id: Int, trigger: String, action: String, enabled: Boolean = true) {
    var trigger by mutableStateOf(trigger)
    var action by mutableStateOf(action)
    var enabled by mutableStateOf(enabled)
}

object Automations {
    const val HEADPHONES_ON = "headphones:on"
    const val HEADPHONES_OFF = "headphones:off"
    const val CHARGER_ON = "charger:on"
    const val CHARGER_OFF = "charger:off"

    val list = mutableStateListOf<Automation>()
    private var prefs: Prefs? = null

    fun load(p: Prefs) {
        prefs = p
        list.clear()
        try {
            val arr = JSONArray(p.getString("automations").ifEmpty { "[]" })
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(Automation(o.getInt("i"), o.getString("t"), o.getString("a"), o.optInt("e", 1) == 1))
            }
        } catch (_: Exception) {
        }
    }

    fun save() {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("i", it.id).put("t", it.trigger).put("a", it.action).put("e", if (it.enabled) 1 else 0)) }
        prefs?.putString("automations", arr.toString())
    }

    fun add(trigger: String, action: String) {
        val id = (list.maxOfOrNull { it.id } ?: 0) + 1
        list.add(Automation(id, trigger, action))
        save()
    }

    fun remove(a: Automation) {
        list.remove(a)
        save()
    }

    fun timeTrigger(hour: Int, minute: Int, days: Int): String = "time:%02d:%02d:%d".format(hour, minute, days)

    private val DAY_NAMES = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")

    private fun dayText(mask: Int): String = when (mask) {
        127 -> " every day"
        31 -> " on weekdays"
        else -> " on " + DAY_NAMES.filterIndexed { i, _ -> ((mask shr i) and 1) == 1 }.joinToString(", ")
    }

    fun describe(trigger: String): String = when {
        trigger == HEADPHONES_ON -> "Headphones connect"
        trigger == HEADPHONES_OFF -> "Headphones disconnect"
        trigger == CHARGER_ON -> "Charger connected"
        trigger == CHARGER_OFF -> "Charger disconnected"
        trigger.startsWith("wifi:") || trigger.startsWith("bt:") -> {
            val p = trigger.split(":", limit = 3)
            val on = p.getOrNull(1) == "on"
            val name = p.getOrNull(2).orEmpty()
            val any = name.isEmpty() || name == "*"
            if (p[0] == "wifi") {
                (if (on) "Joined " else "Left ") + (if (any) "any Wi-Fi network" else "Wi-Fi $name")
            } else {
                (if (any) "Any Bluetooth device" else name) + (if (on) " connects" else " disconnects")
            }
        }
        trigger.startsWith("time:") -> {
            val p = trigger.split(":")
            if (p.size >= 4) "At " + p[1] + ":" + p[2] + dayText(p[3].toIntOrNull() ?: 127) else trigger
        }
        else -> trigger
    }
}

private val HEADPHONE_TYPES = setOf(
    AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_USB_HEADSET,
    AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLE_HEADSET,
)

/**
 * Watches for the things automations wait for (headphones, the charger, a time of day) and runs the action with [run].
 * It runs while Eon is, which as your home app is nearly always. Android does not let an app open other apps from the
 * background, so an "open this app" action only works while Eon is on screen; Focus modes, popups and the like work anywhere.
 */
@Composable
fun AutomationEngine(run: (String) -> Unit) {
    val ctx = LocalContext.current
    val runNow by rememberUpdatedState(run)

    DisposableEffect(Unit) {
        fun fire(kind: String) {
            Automations.list.toList().filter { it.enabled && it.trigger == kind }.forEach { runNow(it.action) }
        }
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, intent: Intent?) {
                when (intent?.action) {
                    Intent.ACTION_POWER_CONNECTED -> fire(Automations.CHARGER_ON)
                    Intent.ACTION_POWER_DISCONNECTED -> fire(Automations.CHARGER_OFF)
                }
            }
        }
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
        }
        ContextCompat.registerReceiver(ctx, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)

        val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        fun connected(): Boolean = audio.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any { it.type in HEADPHONE_TYPES }
        var was = connected()
        fun check() {
            val now = connected()
            if (now != was) {
                was = now
                fire(if (now) Automations.HEADPHONES_ON else Automations.HEADPHONES_OFF)
            }
        }
        val callback = object : AudioDeviceCallback() {
            override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) { check() }
            override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) { check() }
        }
        audio.registerAudioDeviceCallback(callback, null)

        // Bluetooth devices connecting and disconnecting. The name needs the Bluetooth permission; without it only "any device" fires.
        val btReceiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, intent: Intent?) {
                val joined = intent?.action == android.bluetooth.BluetoothDevice.ACTION_ACL_CONNECTED
                val left = intent?.action == android.bluetooth.BluetoothDevice.ACTION_ACL_DISCONNECTED
                if (!joined && !left) return
                val name: String? = try {
                    @Suppress("DEPRECATION")
                    intent?.getParcelableExtra<android.bluetooth.BluetoothDevice>(android.bluetooth.BluetoothDevice.EXTRA_DEVICE)?.name
                } catch (e: SecurityException) {
                    null
                }
                val word = if (joined) "on" else "off"
                fire("bt:$word:*")
                if (!name.isNullOrEmpty()) fire("bt:$word:$name")
            }
        }
        val btFilter = IntentFilter().apply {
            addAction(android.bluetooth.BluetoothDevice.ACTION_ACL_CONNECTED)
            addAction(android.bluetooth.BluetoothDevice.ACTION_ACL_DISCONNECTED)
        }
        ContextCompat.registerReceiver(ctx, btReceiver, btFilter, ContextCompat.RECEIVER_EXPORTED)

        // Joining and leaving a Wi-Fi network. The network name needs the location permission; without it only "any network" fires.
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val startedAt = System.currentTimeMillis()
        var currentSsid: String? = null
        val wifiCallback = object : ConnectivityManager.NetworkCallback(ConnectivityManager.NetworkCallback.FLAG_INCLUDE_LOCATION_INFO) {
            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                val info = caps.transportInfo as? WifiInfo ?: return
                val raw = info.ssid?.trim('"') ?: ""
                val ssid = if (raw == "<unknown ssid>") "" else raw
                val prev = currentSsid
                if (prev == null) {
                    currentSsid = ssid
                    // The network that was already there when Eon started is not "joined".
                    if (System.currentTimeMillis() - startedAt > 3000L) {
                        fire("wifi:on:*")
                        if (ssid.isNotEmpty()) fire("wifi:on:$ssid")
                    }
                } else if (ssid.isNotEmpty() && prev.isNotEmpty() && ssid != prev) {
                    currentSsid = ssid
                    fire("wifi:off:$prev")
                    fire("wifi:on:$ssid")
                } else if (ssid.isNotEmpty() && prev.isEmpty()) {
                    currentSsid = ssid
                }
            }

            override fun onLost(network: Network) {
                val prev = currentSsid ?: return
                currentSsid = null
                fire("wifi:off:*")
                if (prev.isNotEmpty()) fire("wifi:off:$prev")
            }
        }
        try {
            cm.registerNetworkCallback(
                NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build(),
                wifiCallback,
            )
        } catch (e: Exception) {
        }

        onDispose {
            try {
                ctx.unregisterReceiver(receiver)
                ctx.unregisterReceiver(btReceiver)
            } catch (_: Exception) {
            }
            try {
                cm.unregisterNetworkCallback(wifiCallback)
            } catch (_: Exception) {
            }
            audio.unregisterAudioDeviceCallback(callback)
        }
    }

    LaunchedEffect(Unit) {
        var lastMinute = -1L
        while (true) {
            val cal = java.util.Calendar.getInstance()
            val minuteKey = cal.timeInMillis / 60_000L
            if (minuteKey != lastMinute) {
                lastMinute = minuteKey
                val h = cal.get(java.util.Calendar.HOUR_OF_DAY)
                val m = cal.get(java.util.Calendar.MINUTE)
                val day = Focus.dayBitNow()
                Automations.list.toList().filter { it.enabled && it.trigger.startsWith("time:") }.forEach { a ->
                    val p = a.trigger.split(":")
                    if (p.size >= 4 && p[1].toIntOrNull() == h && p[2].toIntOrNull() == m &&
                        (((p[3].toIntOrNull() ?: 127) shr day) and 1) == 1
                    ) {
                        runNow(a.action)
                    }
                }
            }
            delay(15_000L)
        }
    }
}

private val KINDS = listOf(
    Automations.HEADPHONES_ON to "Headphones connect",
    Automations.HEADPHONES_OFF to "Headphones disconnect",
    Automations.CHARGER_ON to "Charger connected",
    Automations.CHARGER_OFF to "Charger disconnected",
    "wifi:on" to "Wi-Fi joined",
    "wifi:off" to "Wi-Fi left",
    "bt:on" to "Bluetooth connects",
    "bt:off" to "Bluetooth disconnects",
    "time" to "At a time",
)

private fun granted(ctx: Context, permission: String): Boolean =
    ContextCompat.checkSelfPermission(ctx, permission) == PackageManager.PERMISSION_GRANTED

/** The name of the Wi-Fi network the phone is on now, or null when there is none or Android hides it. */
@Suppress("DEPRECATION")
private fun currentWifiName(ctx: Context): String? = try {
    val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as android.net.wifi.WifiManager
    val raw = wm.connectionInfo?.ssid?.trim('"')
    if (raw.isNullOrEmpty() || raw == "<unknown ssid>") null else raw
} catch (e: Exception) {
    null
}

/** The names of the Bluetooth devices this phone is paired with. */
private fun pairedNames(ctx: Context): List<String> = try {
    val bm = ctx.getSystemService(Context.BLUETOOTH_SERVICE) as android.bluetooth.BluetoothManager
    bm.adapter?.bondedDevices?.mapNotNull { it.name }?.distinct()?.sorted() ?: emptyList()
} catch (e: SecurityException) {
    emptyList()
}

private val DAY_LETTERS_A = listOf("M", "T", "W", "T", "F", "S", "S")

/** Settings > Automations. */
@Composable
fun AutomationsPage(state: EonState, onBack: () -> Unit) {
    BackHandler { onBack() }
    var adding by remember { mutableStateOf(false) }
    var kind by remember { mutableStateOf(Automations.HEADPHONES_ON) }
    var hour by remember { mutableIntStateOf(22) }
    var minute by remember { mutableIntStateOf(0) }
    var days by remember { mutableIntStateOf(127) }
    var act by remember { mutableStateOf(Act.NONE) }
    var target by remember { mutableStateOf("*") }
    val ctx = LocalContext.current
    var locationOk by remember { mutableStateOf(granted(ctx, Manifest.permission.ACCESS_FINE_LOCATION)) }
    var bluetoothOk by remember { mutableStateOf(granted(ctx, Manifest.permission.BLUETOOTH_CONNECT)) }
    val askLocation = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { locationOk = it }
    val askBluetooth = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { bluetoothOk = it }

    Column(
        Modifier.fillMaxSize().background(Eon.Page).systemBarsPadding().padding(horizontal = 16.dp)
            .verticalScroll(rememberScrollState()),
    ) {
        Gap(12)
        PageHeader("Automations", onBack)
        Gap(10)
        Text(
            "If this, then that: when headphones connect open Music, at 22:00 turn on Sleep, when the charger goes in show a widget. " +
                "They run while Eon is running. Android does not let an app open other apps from the background, so \"open an app\" " +
                "actions only work while Eon is on screen; Focus modes and popups work anywhere.",
            color = Eon.Muted, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 4.dp),
        )
        Gap(16)
        if (Automations.list.isEmpty()) {
            Text("No automations yet.", color = Eon.Faint, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 4.dp))
        }
        Automations.list.toList().forEach { a ->
            Row(
                Modifier.fillMaxWidth().padding(bottom = 10.dp).clip(RoundedCornerShape(20.dp)).background(Eon.P0)
                    .border(1.dp, Eon.Line, RoundedCornerShape(20.dp)).padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f).padding(end = 8.dp)) {
                    Text("When " + Automations.describe(a.trigger), color = Eon.Text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text(Act.label(a.action, state.appsForLabels), color = Eon.Accent, fontSize = 13.sp)
                    Text(
                        "Delete", color = Eon.Danger, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { Automations.remove(a) }.padding(vertical = 6.dp),
                    )
                }
                EonSwitch(a.enabled) { a.enabled = it; Automations.save() }
            }
        }
        Gap(8)
        if (!adding) {
            Box(
                Modifier.fillMaxWidth().clip(CircleShape).background(Eon.Button).clickable { adding = true }.padding(vertical = 16.dp),
                contentAlignment = Alignment.Center,
            ) { Text("New automation", color = Eon.OnAccent, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold) }
        } else {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Eon.P0)
                    .border(1.dp, Eon.Line, RoundedCornerShape(24.dp)).padding(16.dp),
            ) {
                Text("When", color = Eon.Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Gap(6)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    KINDS.forEach { (key, label) ->
                        val on = kind == key
                        Text(
                            label, color = if (on) Eon.OnAccent else Eon.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.clip(CircleShape)
                                .then(if (on) Modifier.background(Eon.Button) else Modifier.background(Eon.P1))
                                .clickable { kind = key; target = "*" }.padding(horizontal = 14.dp, vertical = 9.dp),
                        )
                    }
                }
                if (kind.startsWith("wifi:")) {
                    Gap(12)
                    Text("Network", color = Eon.Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Gap(6)
                    if (!locationOk) {
                        PermissionRow("Allow location so Eon can read the Wi-Fi name (Android asks for it)") {
                            askLocation.launch(Manifest.permission.ACCESS_FINE_LOCATION)
                        }
                        Gap(6)
                    }
                    val here = remember(locationOk, kind) { if (locationOk) currentWifiName(ctx) else null }
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TargetChip("Any network", target == "*") { target = "*" }
                        if (here != null) TargetChip("This one: $here", target == here) { target = here }
                    }
                }
                if (kind.startsWith("bt:")) {
                    Gap(12)
                    Text("Device", color = Eon.Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Gap(6)
                    if (!bluetoothOk) {
                        PermissionRow("Allow Bluetooth so Eon can see your paired devices") {
                            askBluetooth.launch(Manifest.permission.BLUETOOTH_CONNECT)
                        }
                        Gap(6)
                    }
                    val paired = remember(bluetoothOk) { if (bluetoothOk) pairedNames(ctx) else emptyList() }
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TargetChip("Any device", target == "*") { target = "*" }
                        paired.forEach { n -> TargetChip(n, target == n) { target = n } }
                    }
                }
                if (kind == "time") {
                    Gap(12)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Hour", color = Eon.Muted, fontSize = 13.sp, modifier = Modifier.weight(1f))
                        Stepper(hour.toString().padStart(2, '0'), { hour = (hour + 23) % 24 }, { hour = (hour + 1) % 24 })
                    }
                    Gap(6)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Minute", color = Eon.Muted, fontSize = 13.sp, modifier = Modifier.weight(1f))
                        Stepper(minute.toString().padStart(2, '0'), { minute = (minute + 55) % 60 }, { minute = (minute + 5) % 60 })
                    }
                    Gap(10)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        DAY_LETTERS_A.forEachIndexed { i, letter ->
                            val on = ((days shr i) and 1) == 1
                            Box(
                                Modifier.size(38.dp).clip(CircleShape)
                                    .then(if (on) Modifier.background(Eon.Button) else Modifier.background(Eon.P1))
                                    .clickable { days = days xor (1 shl i) },
                                contentAlignment = Alignment.Center,
                            ) {
                                Text(letter, color = if (on) Eon.OnAccent else Eon.Muted, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                Gap(14)
                Text("Do this", color = Eon.Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Gap(6)
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Eon.P1)
                        .clickable { state.actionPicker = ActionRequest("Do this", act) { act = it } }.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        if (act == Act.NONE) "Choose an action" else Act.label(act, state.appsForLabels),
                        color = if (act == Act.NONE) Eon.Faint else Eon.Accent, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f),
                    )
                }
                Gap(14)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Cancel", color = Eon.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center,
                        modifier = Modifier.weight(1f).clip(CircleShape).background(Eon.P1).clickable { adding = false }.padding(vertical = 13.dp),
                    )
                    val ready = act != Act.NONE
                    Text(
                        "Save", color = if (ready) Eon.OnAccent else Eon.Faint, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.weight(1f).clip(CircleShape)
                            .then(if (ready) Modifier.background(Eon.Button) else Modifier.background(Eon.P1))
                            .clickable(enabled = ready) {
                                Automations.add(
                                    when {
                                        kind == "time" -> Automations.timeTrigger(hour, minute, days)
                                        kind.startsWith("wifi:") || kind.startsWith("bt:") -> "$kind:$target"
                                        else -> kind
                                    },
                                    act,
                                )
                                act = Act.NONE
                                adding = false
                            }.padding(vertical = 13.dp),
                    )
                }
            }
        }
        Gap(32)
    }
}

@Composable
private fun Stepper(text: String, onMinus: () -> Unit, onPlus: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(34.dp).clip(CircleShape).background(Eon.P1).clickable(onClick = onMinus),
            contentAlignment = Alignment.Center,
        ) { Text("\u2212", color = Eon.Text, fontSize = 17.sp, fontWeight = FontWeight.Bold) }
        Text(
            text, color = Eon.Text, fontSize = 15.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.width(52.dp), textAlign = TextAlign.Center,
        )
        Box(
            Modifier.size(34.dp).clip(CircleShape).background(Eon.P1).clickable(onClick = onPlus),
            contentAlignment = Alignment.Center,
        ) { Text("+", color = Eon.Text, fontSize = 17.sp, fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun TargetChip(label: String, on: Boolean, onClick: () -> Unit) {
    Text(
        label, color = if (on) Eon.OnAccent else Eon.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
        modifier = Modifier.clip(CircleShape)
            .then(if (on) Modifier.background(Eon.Button) else Modifier.background(Eon.P1))
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 9.dp),
    )
}

@Composable
private fun PermissionRow(text: String, onClick: () -> Unit) {
    Text(
        text, color = Eon.Accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Eon.P1).clickable(onClick = onClick).padding(12.dp),
    )
}
