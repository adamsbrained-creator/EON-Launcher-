package ix.app.eon

import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Replay
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

private fun pct(v: Float) = "${(v * 100f).roundToInt()}%"

/** Settings > Wallpaper: switch the gyro wallpaper on and pick (or add) a picture. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun WallpaperScreen(state: EonState, onBack: () -> Unit, onSettings: () -> Unit) {
    BackHandler { onBack() }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var files by remember { mutableStateOf(WallpaperStore.list(ctx)) }
    var confirmDelete by remember { mutableStateOf<String?>(null) }
    val live = rememberLiveWallpaperActive()

    fun toast(text: String) = Toast.makeText(ctx, text, Toast.LENGTH_SHORT).show()

    /** Opens Android's own preview for Eon's live wallpaper, where you choose home screen, lock screen or both. */
    fun openLive() {
        if (WallpaperConfig.current.isBlank()) {
            toast("Pick a picture first")
            return
        }
        try {
            ctx.startActivity(
                Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).putExtra(
                    WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, ComponentName(ctx, GyroWallpaperService::class.java),
                ),
            )
        } catch (e: Exception) {
            try {
                ctx.startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
            } catch (e2: Exception) {
                toast("This phone has no live wallpaper picker")
            }
        }
    }

    /** Sets the picture as a normal, still system wallpaper for the home screen, the lock screen or both. */
    fun setStill(which: Int) {
        val name = WallpaperConfig.current
        if (name.isBlank()) {
            toast("Pick a picture first")
            return
        }
        scope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    val dm = ctx.resources.displayMetrics
                    val bmp = WallpaperStore.load(
                        ctx, name, dm.widthPixels, dm.heightPixels, WallpaperConfig.QUALITY_HIGH, software = true,
                    )
                    if (bmp == null) {
                        false
                    } else {
                        WallpaperManager.getInstance(ctx).setBitmap(bmp, null, true, which)
                        true
                    }
                } catch (e: Exception) {
                    false
                }
            }
            toast(if (ok) "Wallpaper set" else "Could not set the wallpaper")
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                val name = WallpaperStore.import(ctx, uri)
                if (name != null) {
                    files = WallpaperStore.list(ctx)
                    WallpaperConfig.current = name
                    WallpaperConfig.enabled = true
                    state.saveWallpaper()
                } else {
                    Toast.makeText(ctx, "Could not read that picture", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    Column(
        Modifier.fillMaxSize().background(Color(0xD60A0A0B)).systemBarsPadding().padding(horizontal = 20.dp)
            .verticalScroll(rememberScrollState()),
    ) {
        Gap(12)
        WpHeader("Wallpaper", onBack)
        Gap(22)
        Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(24.dp))) {
            WpToggle("Gyro wallpaper", "Move the picture as you tilt the phone", WallpaperConfig.enabled) { on ->
                WallpaperConfig.enabled = on
                // Turning it on with nothing chosen yet: use the newest picture.
                if (on && WallpaperConfig.current.isBlank()) WallpaperConfig.current = files.firstOrNull() ?: ""
                state.saveWallpaper()
            }
            WpNav("Wallpaper settings", "Direction, range, speed, quality, effects", onSettings)
        }
        Gap(22)
        WpLabel("YOUR PICTURES")
        val tiles: List<String?> = listOf<String?>(null) + files
        tiles.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { name ->
                    Box(Modifier.weight(1f)) {
                        if (name == null) {
                            WpAddTile {
                                picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            }
                        } else {
                            WpTile(
                                name = name,
                                selected = WallpaperConfig.current == name,
                                onClick = {
                                    WallpaperConfig.current = name
                                    WallpaperConfig.enabled = true
                                    state.saveWallpaper()
                                },
                                onLongClick = { confirmDelete = name },
                            )
                        }
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        Text(
            "Tap a picture to use it. Long-press one to delete it.",
            color = Eon.Faint, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.padding(horizontal = 4.dp),
        )
        Gap(22)
        WpLabel("HOME AND LOCK SCREEN")
        Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(24.dp)).padding(bottom = 6.dp)) {
            WpNav(
                "Set as live wallpaper",
                if (live) "Active. It moves on your home screen and lock screen." else "Moves on the home and lock screen, not only in Eon",
                ::openLive,
            )
            Text(
                "OR SET A STILL PICTURE", color = Eon.Faint, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp,
                modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 10.dp),
            )
            Row(Modifier.padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                WpChip("Home", false) { setStill(WallpaperManager.FLAG_SYSTEM) }
                WpChip("Lock", false) { setStill(WallpaperManager.FLAG_LOCK) }
                WpChip("Both", false) { setStill(WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK) }
            }
            Gap(8)
        }
        Gap(22)
        Box(
            Modifier.fillMaxWidth().clip(CircleShape).background(Eon.ov(0x1F))
                .clickable {
                    WallpaperConfig.enabled = false
                    state.saveWallpaper()
                    ctx.startActivity(
                        Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper")
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    )
                }
                .padding(vertical = 14.dp),
            contentAlignment = Alignment.Center,
        ) { Text("Use a normal system wallpaper", color = Eon.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium) }
        Gap(24)
    }

    confirmDelete?.let { name ->
        Dialog(onDismissRequest = { confirmDelete = null }) {
            Column(Modifier.width(280.dp).glass(RoundedCornerShape(26.dp)).padding(vertical = 8.dp)) {
                Text(
                    "Delete this picture?", color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 14.dp),
                )
                Text(
                    "Delete", color = Eon.Danger, fontSize = 15.sp, fontWeight = FontWeight.Medium,
                    modifier = Modifier.fillMaxWidth().clickable {
                        WallpaperStore.delete(ctx, name)
                        files = WallpaperStore.list(ctx)
                        if (WallpaperConfig.current == name) {
                            WallpaperConfig.current = files.firstOrNull() ?: ""
                            if (WallpaperConfig.current.isBlank()) WallpaperConfig.enabled = false
                        }
                        state.saveWallpaper()
                        confirmDelete = null
                    }.padding(horizontal = 20.dp, vertical = 14.dp),
                )
                Text(
                    "Cancel", color = Eon.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium,
                    modifier = Modifier.fillMaxWidth().clickable { confirmDelete = null }
                        .padding(horizontal = 20.dp, vertical = 14.dp),
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun WpTile(name: String, selected: Boolean, onClick: () -> Unit, onLongClick: () -> Unit) {
    val ctx = LocalContext.current
    val thumb by produceState<ImageBitmap?>(null, name) {
        value = withContext(Dispatchers.IO) { WallpaperStore.thumb(ctx, name)?.asImageBitmap() }
    }
    val shape = RoundedCornerShape(18.dp)
    Box(
        Modifier.fillMaxWidth().aspectRatio(0.62f).clip(shape).background(Eon.ov(0x1F))
            .border(if (selected) 2.dp else 1.dp, if (selected) Eon.Accent else Eon.ov(0x33), shape)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick),
    ) {
        thumb?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
        if (selected) {
            Box(
                Modifier.align(Alignment.Center).size(48.dp).clip(CircleShape).background(Eon.Button),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Outlined.Check, "In use", tint = Eon.OnAccent, modifier = Modifier.size(28.dp)) }
        }
    }
}

@Composable
private fun WpAddTile(onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().aspectRatio(0.62f).glass(RoundedCornerShape(18.dp)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier.size(52.dp).clip(CircleShape).background(Eon.Button),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Outlined.Add, "Add a picture", tint = Eon.OnAccent, modifier = Modifier.size(28.dp)) }
            Gap(10)
            Text("Add picture", color = Eon.Text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        }
    }
}

/** Settings > Wallpaper > Wallpaper settings. The wallpaper stays visible above the panel so you can tilt and watch it. */
@Composable
fun WallpaperSettingsScreen(state: EonState, onBack: () -> Unit) {
    BackHandler { onBack() }
    fun changed() = state.saveWallpaper()

    Column(Modifier.fillMaxSize()) {
        // Left empty on purpose: tilt the phone here to see the wallpaper move. Touches are blocked so nothing opens.
        Box(Modifier.weight(0.34f).fillMaxWidth().pointerInput(Unit) { detectTapGestures { } })
        Column(
            Modifier
                .weight(0.66f).fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                .background(Color(0xFF050506))
                .border(1.dp, Eon.Line, RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
                .padding(horizontal = 20.dp),
        ) {
            Gap(16)
            WpHeader("Wallpaper settings", onBack)
            Gap(18)
            WpLabel("DIRECTION")
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                WpChip("Horizontal", WallpaperConfig.mode == WallpaperConfig.MODE_HORIZONTAL) {
                    WallpaperConfig.mode = WallpaperConfig.MODE_HORIZONTAL; changed()
                }
                WpChip("Vertical", WallpaperConfig.mode == WallpaperConfig.MODE_VERTICAL) {
                    WallpaperConfig.mode = WallpaperConfig.MODE_VERTICAL; changed()
                }
                WpChip("Both", WallpaperConfig.mode == WallpaperConfig.MODE_BOTH) {
                    WallpaperConfig.mode = WallpaperConfig.MODE_BOTH; changed()
                }
            }
            Gap(8)
            WpSlider("Range", pct(WallpaperConfig.range), WallpaperConfig.range, 0f..1f, {
                WallpaperConfig.range = it; changed()
            }) { WallpaperConfig.range = 0.5f; changed() }
            WpSlider("Speed", pct(WallpaperConfig.speed), WallpaperConfig.speed, 0f..1f, {
                WallpaperConfig.speed = it; changed()
            }) { WallpaperConfig.speed = 0.5f; changed() }
            WpSlider("Dim", pct(WallpaperConfig.dim), WallpaperConfig.dim, 0f..0.6f, {
                WallpaperConfig.dim = it; changed()
            }) { WallpaperConfig.dim = 0.15f; changed() }
            WpDivider()
            WpToggle("Reverse direction", "Flip which way the picture moves", WallpaperConfig.invert) {
                WallpaperConfig.invert = it; changed()
            }
            WpToggle("Wallpaper scrolling", "Shift the picture when you swipe between pages", WallpaperConfig.scrolling) {
                WallpaperConfig.scrolling = it; changed()
            }
            WpToggle("Power saver mode", "Pause motion while the phone is in battery saver", WallpaperConfig.powerSaver) {
                WallpaperConfig.powerSaver = it; changed()
            }
            WpDivider()
            WpLabel("QUALITY")
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                WpChip("High", WallpaperConfig.quality == WallpaperConfig.QUALITY_HIGH) {
                    WallpaperConfig.quality = WallpaperConfig.QUALITY_HIGH; changed()
                }
                WpChip("Standard", WallpaperConfig.quality == WallpaperConfig.QUALITY_STANDARD) {
                    WallpaperConfig.quality = WallpaperConfig.QUALITY_STANDARD; changed()
                }
                WpChip("Low", WallpaperConfig.quality == WallpaperConfig.QUALITY_LOW) {
                    WallpaperConfig.quality = WallpaperConfig.QUALITY_LOW; changed()
                }
            }
            Gap(8)
            Text(
                when (WallpaperConfig.quality) {
                    WallpaperConfig.QUALITY_HIGH -> "Sharpest. Uses the most memory."
                    WallpaperConfig.QUALITY_STANDARD -> "Full colour at screen size. A good balance."
                    else -> "16-bit colour at screen size. Saves memory."
                },
                color = Eon.Faint, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.padding(horizontal = 4.dp),
            )
            WpDivider()
            WpLabel("TRANSITION ANIMATION")
            WpChipGrid(listOf("Fade", "Dissolve", "Pixelate", "Wipe", "Blur", "Zoom"), WallpaperConfig.transition) {
                WallpaperConfig.transition = it; changed()
            }
            Text(
                "How the picture changes when you choose another one. Blur shows only inside Eon, on the live wallpaper it fades.",
                color = Eon.Faint, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.padding(horizontal = 4.dp),
            )
            Gap(14)
            WpLabel("ANIMATION SPEED")
            WpChipGrid(WallpaperConfig.ANIM_SPEED_LABELS, WallpaperConfig.animSpeedIdx) {
                WallpaperConfig.animSpeedIdx = it; changed()
            }
            Text(
                "Speeds up or slows down the effects and the transition.",
                color = Eon.Faint, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.padding(horizontal = 4.dp),
            )
            WpDivider()
            WpLabel("EFFECTS")
            WpToggle("Overlay effect", "Adds an animated overlay on top of the wallpaper", WallpaperConfig.fxOn) {
                WallpaperConfig.fxOn = it; changed()
            }
            if (WallpaperConfig.fxOn) {
                Gap(6)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    WpChip("Rain", WallpaperConfig.fxType == WallpaperConfig.FX_RAIN) {
                        WallpaperConfig.fxType = WallpaperConfig.FX_RAIN; changed()
                    }
                    WpChip("Ripple", WallpaperConfig.fxType == WallpaperConfig.FX_RIPPLE) {
                        WallpaperConfig.fxType = WallpaperConfig.FX_RIPPLE; changed()
                    }
                    WpChip("Snow", WallpaperConfig.fxType == WallpaperConfig.FX_SNOW) {
                        WallpaperConfig.fxType = WallpaperConfig.FX_SNOW; changed()
                    }
                }
                Gap(8)
                when (WallpaperConfig.fxType) {
                    WallpaperConfig.FX_RAIN -> {
                        WpToggle("Glass drops", "Big water drops on the glass that show the picture upside down", WallpaperConfig.rainDrops) {
                            WallpaperConfig.rainDrops = it; changed()
                        }
                        if (WallpaperConfig.rainDrops) {
                            WpSlider("Drop amount", pct(WallpaperConfig.dropAmount), WallpaperConfig.dropAmount, 0f..1f, {
                                WallpaperConfig.dropAmount = it; changed()
                            }) { WallpaperConfig.dropAmount = 0.5f; changed() }
                            WpSlider("Drop size", pct(WallpaperConfig.dropSize), WallpaperConfig.dropSize, 0f..1f, {
                                WallpaperConfig.dropSize = it; changed()
                            }) { WallpaperConfig.dropSize = 0.6f; changed() }
                            WpSlider("Drop slide speed", pct(WallpaperConfig.dropSpeed), WallpaperConfig.dropSpeed, 0f..1f, {
                                WallpaperConfig.dropSpeed = it; changed()
                            }) { WallpaperConfig.dropSpeed = 0.4f; changed() }
                        }
                        WpToggle("Rain streaks", "Thin falling lines", WallpaperConfig.rainStreaks) {
                            WallpaperConfig.rainStreaks = it; changed()
                        }
                        if (WallpaperConfig.rainStreaks) {
                            WpSlider("Intensity", pct(WallpaperConfig.rainIntensity), WallpaperConfig.rainIntensity, 0f..1f, {
                                WallpaperConfig.rainIntensity = it; changed()
                            }) { WallpaperConfig.rainIntensity = 0.5f; changed() }
                            WpSlider("Speed", pct(WallpaperConfig.rainSpeed), WallpaperConfig.rainSpeed, 0f..1f, {
                                WallpaperConfig.rainSpeed = it; changed()
                            }) { WallpaperConfig.rainSpeed = 0.5f; changed() }
                            WpSlider("Brightness", pct(WallpaperConfig.rainBrightness), WallpaperConfig.rainBrightness, 0f..1f, {
                                WallpaperConfig.rainBrightness = it; changed()
                            }) { WallpaperConfig.rainBrightness = 0.35f; changed() }
                        }
                        WpToggle("Lightning", "Flashes the wallpaper now and then, like lightning", WallpaperConfig.lightning) {
                            WallpaperConfig.lightning = it; changed()
                        }
                    }
                    WallpaperConfig.FX_RIPPLE -> {
                        WpToggle("Touch-only ripples", "Ripples appear only where you touch", WallpaperConfig.rippleTouchOnly) {
                            WallpaperConfig.rippleTouchOnly = it; changed()
                        }
                        WpToggle("Rain lines", "Adds a virtual rain effect alongside the ripples", WallpaperConfig.rippleRainLines) {
                            WallpaperConfig.rippleRainLines = it; changed()
                        }
                        WpSlider("Speed", pct(WallpaperConfig.rippleSpeed), WallpaperConfig.rippleSpeed, 0f..1f, {
                            WallpaperConfig.rippleSpeed = it; changed()
                        }) { WallpaperConfig.rippleSpeed = 0.3f; changed() }
                        WpSlider("Ripple size", pct(WallpaperConfig.rippleSize), WallpaperConfig.rippleSize, 0f..1f, {
                            WallpaperConfig.rippleSize = it; changed()
                        }) { WallpaperConfig.rippleSize = 0.7f; changed() }
                        WpSlider("Strength", pct(WallpaperConfig.rippleStrength), WallpaperConfig.rippleStrength, 0f..1f, {
                            WallpaperConfig.rippleStrength = it; changed()
                        }) { WallpaperConfig.rippleStrength = 0.45f; changed() }
                    }
                    else -> {
                        WpSlider("Speed", pct(WallpaperConfig.snowSpeed), WallpaperConfig.snowSpeed, 0f..1f, {
                            WallpaperConfig.snowSpeed = it; changed()
                        }) { WallpaperConfig.snowSpeed = 0.25f; changed() }
                        WpSlider("Density", pct(WallpaperConfig.snowDensity), WallpaperConfig.snowDensity, 0f..1f, {
                            WallpaperConfig.snowDensity = it; changed()
                        }) { WallpaperConfig.snowDensity = 0.35f; changed() }
                        WpSlider("Flake size", pct(WallpaperConfig.snowSize), WallpaperConfig.snowSize, 0f..1f, {
                            WallpaperConfig.snowSize = it; changed()
                        }) { WallpaperConfig.snowSize = 0.55f; changed() }
                        WpSlider("Opacity", pct(WallpaperConfig.snowOpacity), WallpaperConfig.snowOpacity, 0f..1f, {
                            WallpaperConfig.snowOpacity = it; changed()
                        }) { WallpaperConfig.snowOpacity = 0.7f; changed() }
                    }
                }
            }
            Gap(24)
        }
    }
}

// ---- small building blocks, in the same look as the Home screen settings

@Composable
private fun WpHeader(title: String, onBack: () -> Unit) {
    PageHeader(title, onBack)
}

@Composable
private fun WpLabel(text: String) {
    SettingsSectionLabel(text)
}

@Composable
private fun WpDivider() {
    Box(Modifier.padding(vertical = 8.dp).fillMaxWidth().height(1.dp).background(Eon.Line))
}

@Composable
private fun RowScope.WpChip(label: String, on: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.weight(1f).height(40.dp).clip(CircleShape)
            .accentFill(on, Eon.P1)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = if (on) Eon.OnAccent else Eon.Text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
    }
}

/** Chips in rows of three. */
@Composable
private fun WpChipGrid(labels: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    labels.chunked(3).forEachIndexed { row, chunk ->
        Row(Modifier.padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            chunk.forEachIndexed { i, label ->
                val index = row * 3 + i
                WpChip(label, index == selected) { onSelect(index) }
            }
            repeat(3 - chunk.size) { Spacer(Modifier.weight(1f)) }
        }
    }
}

@Composable
private fun WpNav(title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Eon.Muted, fontSize = 12.sp)
        }
        Text("›", color = Eon.Muted, fontSize = 22.sp)
    }
}

@Composable
private fun WpToggle(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            if (subtitle != null) Text(subtitle, color = Eon.Muted, fontSize = 12.sp, lineHeight = 16.sp)
        }
        EonSwitch(checked, onChange)
    }
}

@Composable
private fun WpSlider(
    title: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit,
    onReset: () -> Unit,
) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text(valueText, color = Eon.Muted, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(12.dp))
            Box(
                Modifier.size(36.dp).clip(RoundedCornerShape(12.dp)).background(Eon.P1).clickable(onClick = onReset),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Outlined.Replay, "Reset", tint = Eon.Soft, modifier = Modifier.size(18.dp)) }
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange, valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = Color.White, activeTrackColor = Eon.Accent, inactiveTrackColor = Eon.ov(0x33),
            ),
        )
    }
}
