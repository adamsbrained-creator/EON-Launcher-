package ix.app.eon

import androidx.activity.compose.BackHandler
import kotlin.math.roundToInt
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Calculate
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material.icons.outlined.ViewModule
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntRect
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupPositionProvider
import androidx.compose.ui.window.PopupProperties
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** One box in the App Library. [manage] is true for your own boxes (long-press for Rename and so on). */
internal data class LibTile(
    val id: String, val name: String, val icon: String?, val apps: List<AppEntry>, val manage: Boolean,
)

/** Every box in the order the Library shows them: Recently added, your boxes, then Other apps. */
internal fun buildTiles(apps: List<AppEntry>, state: EonState): List<LibTile> {
    val out = ArrayList<LibTile>()
    // First box: what you tend to open around now. Left out until Eon has seen enough launches to suggest anything.
    val suggested = if (LibraryConfig.suggestBox) Usage.suggestions(apps, 12) else emptyList()
    if (suggested.isNotEmpty()) out.add(LibTile("~suggest", "Suggestions", "star", suggested, false))
    val recent = apps.sortedByDescending { it.firstInstall }.take(8)
    if (DrawerConfig.showRecent && recent.isNotEmpty()) out.add(LibTile("~recent", "Recently added", null, recent, false))
    val cats = state.categories.filter { it.id != CAT_ALL }
    val contents = cats.map { c -> c to apps.filter { state.inCategory(it, c.id) } }
    // Smart order: boxes you open the most come first.
    val ordered = if (LibraryConfig.smartBoxes) {
        contents.sortedByDescending { (_, list) -> list.sumOf { Usage.count(it.key, 30) } }
    } else {
        contents
    }
    ordered.forEach { (c, list) -> out.add(LibTile(c.id, c.name, c.icon, LibraryConfig.sorted(c.id, list), true)) }
    // Apps that no box above holds, so every app can be reached without searching.
    val rest = apps.filter { a -> cats.none { state.inCategory(a, it.id) } }
    if (DrawerConfig.showOther && rest.isNotEmpty()) out.add(LibTile("~other", "Other apps", null, LibraryConfig.sorted("~other", rest), false))
    return out
}

private fun initial(label: String): String {
    val c = label.trim().firstOrNull()?.uppercaseChar()
    return if (c != null && c.isLetter()) c.toString() else "#"
}

private enum class LibMode { HOME, AZ }

/**
 * The App Library: a search pill, the cards above the boxes (Insights) and a grid of boxes. Each box shows its first
 * apps and, when there are more, a "+N" tile; tap the box to open all of them in a sheet. The Library / A to Z switch
 * at the bottom flips to an alphabetical list with a letter rail and search, and the pencil next to it arranges the
 * boxes. The three dots by the search pill hold New box, Customize and the drawer settings. Long-press one of your
 * boxes for Add category, Edit icon, Rename and Remove. Fling down at the top to close.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppLibrary(
    apps: List<AppEntry>, state: EonState, focusSearch: Boolean,
    onLaunch: (AppEntry) -> Unit, onMenu: (AppEntry) -> Unit, onClose: () -> Unit,
    drag: DragState, onDrop: (AppEntry, Offset) -> Unit,
    onSettings: () -> Unit = {},
) {
    val ctx = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val focus = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    val startTyping = focusSearch || DrawerConfig.autoKeyboard
    var mode by remember { mutableStateOf(if (startTyping) LibMode.AZ else LibMode.HOME) }
    var wantFocus by remember { mutableStateOf(startTyping) }
    var focused by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var openId by remember { mutableStateOf<String?>(null) }
    var arranging by remember { mutableStateOf(false) }
    var adding by remember { mutableStateOf(false) }
    var menuFor by remember { mutableStateOf<String?>(null) }
    var renaming by remember { mutableStateOf<String?>(null) }
    var picking by remember { mutableStateOf<String?>(null) }
    var customizing by remember { mutableStateOf(false) }
    var moreMenu by remember { mutableStateOf(false) }
    var moreAnchor by remember { mutableStateOf<Rect?>(null) }
    val bounds = remember { HashMap<String, Rect>() }
    val tiles by remember(apps) { derivedStateOf { buildTiles(apps, state) } }
    val close by rememberUpdatedState(onClose)
    val pull = remember {
        object : NestedScrollConnection {
            override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
                // A strong fling that runs into the top. A pull you make yourself is handled by pullToClose.
                if (available.y > 3500f) close()
                return Velocity.Zero
            }
        }
    }
    val hideKeyboard = remember {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (available.y != 0f) focusManager.clearFocus()
                return Offset.Zero
            }
        }
    }

    // Pull past the top or the end of the list and the drawer comes with your finger, then goes home (Settings > Drawer).
    val listState = rememberLazyListState()
    val edgePull = remember { EdgePull() }
    val pullPx = LocalContext.current.resources.displayMetrics.heightPixels * 0.4f
    LaunchedEffect(Unit) {
        androidx.compose.runtime.snapshotFlow { (Math.abs(edgePull.offset) / pullPx).coerceIn(0f, 1f) }.collect { LibPull.p = it }
    }
    DisposableEffect(Unit) { onDispose { LibPull.p = 0f } }

    // How long you have used each app today. Looked at again every minute, or every few seconds while waiting for the
    // person to switch Usage access on, so the pill changes as soon as they come back.
    LaunchedEffect(Unit) {
        while (true) {
            ScreenTime.refresh(ctx)
            delay(if (ScreenTime.granted) 60_000L else 3_000L)
        }
    }
    // The blurred wallpaper the boxes show through (only when the wallpaper is Eon's own picture).
    LaunchedEffect(WallpaperConfig.enabled, WallpaperConfig.current) { LibBackdrop.refresh(ctx) }
    LaunchedEffect(mode, wantFocus) {
        if (mode == LibMode.AZ && wantFocus) {
            try {
                focus.requestFocus()
            } catch (_: Exception) {
            }
        }
    }
    val exitAz = {
        mode = LibMode.HOME
        wantFocus = false
        focused = false
        query = ""
        focusManager.clearFocus()
    }
    BackHandler(enabled = mode == LibMode.AZ && !arranging) { exitAz() }

    val imeVisible = WindowInsets.ime.getBottom(LocalDensity.current) > 0
    val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    Box(
        Modifier.fillMaxSize()
            .pullToClose(
                pull = edgePull,
                enabled = { mode == LibMode.HOME && !arranging && openId == null && drag.app == null },
                atTop = { !listState.canScrollBackward }, atBottom = { !listState.canScrollForward },
                onClose = onClose, follow = 1f, slopDp = 20f, closeFrac = 0.3f, flickV = 2400f,
            )
            .graphicsLayer {
                // Closing: the Library settles back and fades (shrinking a little, corners rounding) as you pull, rather than
                // sliding away, and the home screen's blur eases off with it.
                val p = (Math.abs(edgePull.offset) / (size.height * 0.4f)).coerceIn(0f, 1f)
                translationY = edgePull.offset * 0.3f
                val sc = 1f - 0.1f * p
                scaleX = sc
                scaleY = sc
                alpha = 1f - 0.85f * p
                if (p > 0f) {
                    shape = RoundedCornerShape(40.dp * p)
                    clip = true
                }
            },
    ) {
        Box(
            Modifier.fillMaxSize()
                .background(DrawerConfig.scrim())
                // Keeps home-screen widgets from showing through the boxes as ghost text.
                .background(Color(0x59000000))
                .pointerInput(Unit) { detectTapGestures(onTap = { }) },
        ) {
            if (arranging) {
                LibArrangeScreen(
                    boxes = tiles.filter { it.manage }, state = state,
                    onNewBox = { adding = true }, onDone = { arranging = false },
                )
            } else {
                val behind by animateFloatAsState(if (openId != null) 1f else 0f, tween(320, easing = LibEase), label = "behind")
                Column(Modifier.fillMaxSize().statusBarsPadding().imePadding().graphicsLayer { scaleX = 1f - 0.05f * behind; scaleY = scaleX }) {
                    Gap(8)
                    if (mode == LibMode.HOME) {
                        // Just the search pill, like iOS. Tap it to search; hold it for New box, Arrange and the settings.
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp).height(48.dp)
                                .onGloballyPositioned { moreAnchor = it.boundsInWindow() }
                                .libGlass(RoundedCornerShape(24.dp))
                                .combinedClickable(
                                    onClick = { mode = LibMode.AZ; wantFocus = true },
                                    onLongClick = {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        moreMenu = true
                                    },
                                )
                                .padding(horizontal = 16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(Icons.Outlined.Search, null, tint = Eon.DSoft, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(10.dp))
                            Text("App Library", color = Eon.DSoft.copy(alpha = 0.8f), fontSize = 16.sp)
                        }
                    } else {
                        // The search field, with a glow while you type.
                        Row(
                            Modifier.fillMaxWidth().padding(start = 16.dp, end = 6.dp, top = 4.dp, bottom = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            val fieldShape = RoundedCornerShape(24.dp)
                            Row(
                                Modifier.weight(1f).height(48.dp)
                                    .libGlass(fieldShape)
                                    .then(if (focused) Modifier.border(1.5.dp, Eon.DAccent.copy(alpha = 0.8f), fieldShape) else Modifier)
                                    .padding(horizontal = 16.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(Icons.Outlined.Search, null, tint = Eon.DSoft, modifier = Modifier.size(20.dp))
                                Spacer(Modifier.width(10.dp))
                                Box(Modifier.weight(1f)) {
                                    if (query.isEmpty()) Text("Search", color = Eon.DSoft.copy(alpha = 0.8f), fontSize = 16.sp)
                                    BasicTextField(
                                        value = query,
                                        onValueChange = { query = it },
                                        singleLine = true,
                                        textStyle = TextStyle(color = Eon.DText, fontSize = 16.sp),
                                        cursorBrush = SolidColor(Eon.DAccent),
                                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                                        modifier = Modifier.fillMaxWidth().focusRequester(focus).onFocusChanged { focused = it.isFocused },
                                    )
                                }
                            }
                            Text(
                                "Cancel", color = Eon.DAccent, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.clickable { exitAz() }.padding(horizontal = 14.dp, vertical = 12.dp),
                            )
                        }
                    }

                    if (mode == LibMode.AZ) {
                        LibAzList(
                            apps = apps, query = query, state = state, showRail = !imeVisible,
                            bottomPad = 24.dp + (if (imeVisible) 0.dp else navBottom),
                            railBottom = 16.dp + navBottom,
                            onPickRecent = { query = it }, onLaunch = onLaunch, onMenu = onMenu,
                            modifier = Modifier.weight(1f).nestedScroll(hideKeyboard),
                        )
                    } else {
                        val perRow = DrawerConfig.libColumns
                        val rows = remember(tiles, perRow) { tiles.chunked(perRow) }
                        LazyColumn(
                            Modifier.weight(1f).fillMaxWidth().nestedScroll(pull)
                            ,
                            state = listState,
                            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 32.dp + navBottom),
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                        ) {
                            if (LibraryConfig.showInsights) {
                                item(key = "insights") {
                                    InsightsPanel(apps, onLaunch, onMenu, onHideApp = { state.hide(it.packageName) })
                                }
                            }
                            items(rows, key = { r -> r.joinToString("|") { it.id } }) { row ->
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.Top) {
                                    row.forEach { t ->
                                        Box(Modifier.weight(1f)) {
                                            LibFolderTile(
                                                tile = t, cols = perRow, selected = openId == t.id,
                                                drag = drag, onLaunch = onLaunch, onMenu = onMenu, onDrop = onDrop,
                                                onOpen = { openId = t.id },
                                                onLongPress = { if (t.manage) menuFor = t.id else { moreAnchor = bounds[t.id]; moreMenu = true } },
                                                onBounds = { r -> bounds[t.id] = r },
                                            )
                                        }
                                    }
                                    repeat(perRow - row.size) { Spacer(Modifier.weight(1f)) }
                                }
                            }
                        }
                    }
                }

            }

            openId?.let { id ->
                tiles.firstOrNull { it.id == id }?.let { t ->
                    LibBoxSheet(t, state, apps, onLaunch, onMenu, drag, onDrop, origin = bounds[t.id]) { openId = null }
                }
            }
            if (adding) {
                AddCategoryScreen(
                    existing = state.categories.map { it.id }.toSet(),
                    onPick = { def -> state.addCategory(def); adding = false },
                    onCustom = {
                        val id = state.addCustomCategory()
                        adding = false
                        renaming = id
                    },
                    onBack = { adding = false },
                )
            }
        }
    }

    if (moreMenu) {
        LibMenu(
            anchor = moreAnchor,
            items = listOf(
                PopupAction(Icons.Outlined.Add, "New box") { moreMenu = false; adding = true },
                PopupAction(Icons.Outlined.Edit, "Arrange boxes") { moreMenu = false; arranging = true },
                PopupAction(Icons.Outlined.AutoAwesome, "Customize Library") { moreMenu = false; customizing = true },
                PopupAction(Icons.Outlined.Tune, "Drawer settings") { moreMenu = false; onSettings() },
                PopupAction(Icons.Outlined.ViewModule, "Switch to Bar") { moreMenu = false; state.chooseDrawerStyle("bar") },
            ),
            onDismiss = { moreMenu = false },
        )
    }
    if (customizing) {
        LibraryCustomizeDialog(onOrganize = { state.organizeLibrary(apps) }, onDismiss = { customizing = false })
    }
    menuFor?.let { id ->
        val cat = state.categories.firstOrNull { it.id == id }
        if (cat != null) {
            CategoryPopup(
                title = cat.name, anchor = bounds[id], canRemove = id != CAT_ALL,
                onAdd = { menuFor = null; adding = true },
                onEditIcon = { menuFor = null; picking = id },
                onRename = { menuFor = null; renaming = id },
                onRemove = { menuFor = null; state.removeCategory(id) },
                onDismiss = { menuFor = null },
                extras = listOf(
                    PopupAction(Icons.Outlined.Edit, "Arrange boxes") {
                        menuFor = null
                        arranging = true
                    },
                    PopupAction(Icons.Outlined.AutoAwesome, "Customize Library") {
                        menuFor = null
                        customizing = true
                    },
                    PopupAction(Icons.Outlined.ViewModule, "Switch to Bar") {
                        menuFor = null
                        state.chooseDrawerStyle("bar")
                    },
                    PopupAction(Icons.Outlined.Tune, "Drawer settings") {
                        menuFor = null
                        onSettings()
                    },
                ),
            )
        }
    }
    renaming?.let { id ->
        val cat = state.categories.firstOrNull { it.id == id }
        if (cat != null) {
            NameDialog(
                title = "Rename category", initial = cat.name,
                onDone = { state.renameCategory(id, it); renaming = null },
                onDismiss = { renaming = null },
            )
        }
    }
    picking?.let { id ->
        val cat = state.categories.firstOrNull { it.id == id }
        if (cat != null) {
            IconPickerDialog(
                current = cat.icon,
                onPick = { state.setCategoryIcon(id, it); picking = null },
                onDismiss = { picking = null },
            )
        }
    }
}

/** The menu you get by holding the search pill or a box that is not yours: New box, Arrange, Customize, drawer settings, Switch to Bar. */
@Composable
private fun LibMenu(anchor: Rect?, items: List<PopupAction>, onDismiss: () -> Unit) {
    val density = LocalDensity.current
    val gap = with(density) { 6.dp.roundToPx() }
    val margin = with(density) { 12.dp.roundToPx() }
    val provider = remember(anchor) {
        object : PopupPositionProvider {
            override fun calculatePosition(
                anchorBounds: IntRect, windowSize: IntSize,
                layoutDirection: LayoutDirection, popupContentSize: IntSize,
            ): IntOffset {
                val right = anchor?.right?.toInt() ?: (windowSize.width - margin)
                val top = (anchor?.bottom?.toInt() ?: margin) + gap
                return IntOffset((right - popupContentSize.width).coerceAtLeast(margin), top)
            }
        }
    }
    val shape = RoundedCornerShape(22.dp)
    Popup(popupPositionProvider = provider, onDismissRequest = onDismiss, properties = PopupProperties(focusable = true)) {
        PopAnim { Column(
            Modifier.width(240.dp).clip(shape).background(Color(0xF21B1B1D)).border(1.dp, Color(0x24FFFFFF), shape)
                .padding(vertical = 8.dp),
        ) {
            items.forEach { a ->
                Row(
                    Modifier.fillMaxWidth().clickable(onClick = a.onClick).padding(horizontal = 20.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                ) {
                    Icon(a.icon, null, tint = Eon.DText, modifier = Modifier.size(22.dp))
                    Text(a.label, color = Eon.DText, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                }
            }
        } }
    }
}

/**
 * One box: a rounded, see-through card with its name, how many apps it holds and a badge when something is waiting,
 * then four slots. Up to four apps show as icons; with more, three show and the fourth slot says "+N". Icons can be
 * launched, opened for their menu or dragged out to the home screen like in the other drawer. [selected] puts the
 * cyan outline on the box whose sheet is open.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun LibFolderTile(
    tile: LibTile, cols: Int, selected: Boolean, drag: DragState,
    onLaunch: (AppEntry) -> Unit, onMenu: (AppEntry) -> Unit, onDrop: (AppEntry, Offset) -> Unit,
    onOpen: () -> Unit, onLongPress: () -> Unit, onBounds: (Rect) -> Unit,
) {
    val haptic = LocalHapticFeedback.current
    val shape = RoundedCornerShape(DrawerConfig.tileRadius.dp)
    val badge = tile.apps.sumOf { Badges.counts[it.packageName] ?: 0 }
    val small = cols >= 3
    // A box dips a little while a finger is on it (watched without taking the touch, so icons still work).
    var pressed by remember { mutableStateOf(false) }
    val dip by animateFloatAsState(if (pressed) 0.96f else 1f, tween(if (pressed) 110 else 220, easing = LibEase), label = "dip")
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(
            Modifier.fillMaxWidth()
                .graphicsLayer { scaleX = dip; scaleY = dip }
                .pointerInput(Unit) {
                    awaitEachGesture {
                        awaitFirstDown(requireUnconsumed = false, pass = androidx.compose.ui.input.pointer.PointerEventPass.Initial)
                        pressed = true
                        do {
                            val ev = awaitPointerEvent(androidx.compose.ui.input.pointer.PointerEventPass.Initial)
                        } while (ev.changes.any { it.pressed })
                        pressed = false
                    }
                },
        ) {
            // A true square: the icons below are laid out on a fixed 2 x 2 grid of slots measured from its width.
            BoxWithConstraints(
                Modifier.fillMaxWidth().aspectRatio(1f).libTileGlass(shape, selected)
                    .onGloballyPositioned { onBounds(it.boundsInWindow()) },
            ) {
                // Behind the icons: a tap on an icon launches it (unless Settings > Drawer says to open the box), a tap anywhere else opens the box.
                Box(
                    Modifier.matchParentSize().combinedClickable(
                        onClick = onOpen,
                        onLongClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            onLongPress()
                        },
                    ),
                )
                val w = maxWidth
                val pad = w * 0.10f
                val gap = w * 0.07f
                val icon = w * 0.365f
                val apps = tile.apps
                if (apps.isEmpty()) {
                    Box(Modifier.matchParentSize(), contentAlignment = Alignment.Center) {
                        Icon(catIcon(tile.icon ?: "folder"), null, tint = Color(0x66FFFFFF), modifier = Modifier.size(w * 0.3f))
                    }
                } else {
                    val overflow = apps.size > 4
                    val shown = if (overflow) apps.take(3) else apps
                    val near = pad
                    val far = pad + icon + gap
                    val mid = (w - icon) / 2
                    val slots: List<Pair<Dp, Dp>> = when {
                        overflow || apps.size == 4 -> listOf(near to near, far to near, near to far, far to far)
                        apps.size == 3 -> listOf(near to near, far to near, mid to far)
                        apps.size == 2 -> listOf(near to mid, far to mid)
                        else -> listOf(mid to mid)
                    }
                    shown.forEachIndexed { i, app ->
                        Box(Modifier.offset(slots[i].first, slots[i].second).size(icon), contentAlignment = Alignment.Center) {
                            DragAppIcon(
                                app, icon, drag,
                                { if (DrawerConfig.libDirectLaunch) onLaunch(app) else onOpen() }, { onMenu(app) }, onDrop,
                                showLabel = false,
                            )
                        }
                    }
                    if (overflow) {
                        LibMiniCluster(apps.drop(3), icon, Modifier.offset(slots[3].first, slots[3].second), onOpen)
                    }
                }
            }
            if (badge > 0) {
                Box(
                    Modifier.align(Alignment.TopEnd).offset(x = 4.dp, y = (-4).dp).height(if (small) 20.dp else 24.dp)
                        .widthIn(min = if (small) 20.dp else 24.dp).clip(CircleShape).background(LibPink)
                        .padding(horizontal = 7.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(if (badge > 99) "99+" else "$badge", color = Eon.DInk, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        // The name under the tile, centred, with a soft shadow so it reads on any wallpaper.
        Text(
            tile.name, color = DrawerConfig.textColor, fontSize = if (small) 12.sp else 13.sp, fontWeight = FontWeight.Medium,
            maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
            style = TextStyle(shadow = Shadow(Color(0x73000000), Offset(0f, 2f), 8f)),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 2.dp),
        )
    }
}

private sealed class AzItem(val key: String) {
    class Smart(val answer: SmartAnswer) : AzItem("smart")
    object Hint : AzItem("hint")
    object Recents : AzItem("recents")
    object None : AzItem("none")
    class Head(val letter: String) : AzItem("h$letter")
    class AppRow(val app: AppEntry) : AzItem(app.key)
    object Extras : AzItem("extras")
}

/**
 * The A to Z tab: recent searches and a hint (or the answer to a sum) while the box is empty, then every app under its
 * letter, with a rail of letters at the right edge that you can tap or slide along to jump.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun LibAzList(
    apps: List<AppEntry>, query: String, state: EonState, showRail: Boolean, bottomPad: Dp, railBottom: Dp,
    onPickRecent: (String) -> Unit, onLaunch: (AppEntry) -> Unit, onMenu: (AppEntry) -> Unit, modifier: Modifier,
) {
    val q = query.trim()
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val list = remember(apps, q) {
        (if (q.isEmpty()) apps else apps.filter { SearchIndex.matches(it, q) }).sortedBy { it.label.lowercase() }
    }
    val smart = remember(q) { SmartSearch.answer(q) }
    val groups = remember(list) {
        list.groupBy { initial(it.label) }.toList().sortedBy { if (it.first == "#") "~" else it.first }
    }
    val entries = remember(groups, smart, q) {
        buildList<AzItem> {
            if (smart != null) add(AzItem.Smart(smart)) else if (q.isEmpty()) add(AzItem.Hint)
            if (q.isEmpty()) add(AzItem.Recents)
            if (groups.isEmpty()) add(AzItem.None)
            groups.forEach { (letter, group) ->
                add(AzItem.Head(letter))
                group.forEach { add(AzItem.AppRow(it)) }
            }
            if (q.length >= 2) add(AzItem.Extras)
        }
    }
    val present = remember(groups) { groups.map { it.first }.toSet() }

    Box(modifier.fillMaxWidth()) {
        LazyColumn(
            Modifier.fillMaxSize(), state = listState,
            contentPadding = PaddingValues(start = 16.dp, end = 40.dp, top = 8.dp, bottom = bottomPad),
        ) {
            entries.forEachIndexed { index, item ->
                if (item is AzItem.Head) {
                    // Plain headers (no pinned band over the blurred background, which showed as dark boxes).
                    item(key = item.key) {
                        Box(
                            Modifier.fillMaxWidth().height(34.dp).padding(start = 8.dp, bottom = 4.dp),
                            contentAlignment = Alignment.BottomStart,
                        ) {
                            Text(item.letter, color = Eon.DText.copy(alpha = 0.78f), fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                } else {
                    item(key = item.key) {
                        when (item) {
                            is AzItem.Smart -> SmartAnswerCard(item.answer, Modifier.padding(top = 8.dp))
                            is AzItem.Hint -> LibHintCard()
                            is AzItem.Recents -> LibRecents(onPickRecent)
                            is AzItem.None -> {
                                Column(Modifier.fillMaxWidth().padding(top = 28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("No apps match", color = Eon.DMuted, fontSize = 14.sp, textAlign = TextAlign.Center)
                                    if (q.length >= 2) {
                                        Gap(6)
                                        NoAppsHint(state)
                                    }
                                }
                            }
                            is AzItem.AppRow -> LibAzRow(
                                item.app, entries.getOrNull(index + 1) is AzItem.AppRow,
                                { RecentSearches.add(q); onLaunch(it) }, onMenu,
                            )
                            is AzItem.Extras -> ExtraResults(q, state, list, onLaunch)
                            is AzItem.Head -> {}
                        }
                    }
                }
            }
        }
        if (showRail) {
            val density = LocalDensity.current
            val railTop = 10.dp
            // The bubble that follows your finger down the rail and fades when you let go.
            var bubble by remember { mutableStateOf<Pair<String, Float>?>(null) }
            var lastBubble by remember { mutableStateOf("A" to 0f) }
            val bubbleAlpha by animateFloatAsState(if (bubble != null) 1f else 0f, tween(120), label = "bubble")
            if (bubbleAlpha > 0.01f) {
                val shape = RoundedCornerShape(24.dp)
                Box(
                    Modifier.align(Alignment.TopEnd).padding(end = 56.dp)
                        .offset { IntOffset(0, (with(density) { railTop.toPx() } + lastBubble.second - with(density) { 32.dp.toPx() }).roundToInt()) }
                        .graphicsLayer { alpha = bubbleAlpha; scaleX = 0.85f + 0.15f * bubbleAlpha; scaleY = scaleX }
                        .size(64.dp).clip(shape).background(Color(0xF01C1C1F)).border(1.dp, Color(0x40FFFFFF), shape),
                    contentAlignment = Alignment.Center,
                ) { Text(lastBubble.first, color = Eon.DText, fontSize = 32.sp, fontWeight = FontWeight.SemiBold) }
            }
            LibLetterRail(
                present = present,
                onActive = { letter, y ->
                    if (letter != null) {
                        lastBubble = letter to y
                        bubble = lastBubble
                    } else {
                        bubble = null
                    }
                },
                onJump = { letter ->
                    val at = entries.indexOfFirst { it is AzItem.Head && it.letter == letter }
                    if (at >= 0) scope.launch { listState.scrollToItem(at) }
                },
                modifier = Modifier.align(Alignment.CenterEnd).fillMaxHeight().padding(top = railTop, bottom = railBottom, end = 4.dp),
            )
        }
    }
}

/** A row in the A to Z list: the icon and the name, with a hairline under it that starts at the name (not on the last row of a letter). */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun LibAzRow(app: AppEntry, divider: Boolean, onLaunch: (AppEntry) -> Unit, onMenu: (AppEntry) -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().height(56.dp)
                .combinedClickable(onClick = { onLaunch(app) }, onLongClick = { onMenu(app) })
                .padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Image(bitmap = app.icon, contentDescription = null, modifier = Modifier.size(42.dp).scaledIcon(app.iconScale))
            Spacer(Modifier.width(16.dp))
            Text(app.label, color = DrawerConfig.textColor, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (divider) Box(Modifier.padding(start = 62.dp).fillMaxWidth().height(0.5.dp).background(Color(0x1FFFFFFF)))
    }
}

/** The line that says the search box also does sums and conversions. */
@Composable
private fun LibHintCard() {
    val shape = RoundedCornerShape(22.dp)
    Row(
        Modifier.fillMaxWidth().padding(top = 12.dp).libGlass(shape)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Box(Modifier.size(38.dp).clip(CircleShape).background(Color(0x1FFFFFFF)), contentAlignment = Alignment.Center) {
            Icon(Icons.Outlined.Calculate, null, tint = Eon.DAccent, modifier = Modifier.size(20.dp))
        }
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text("Type a sum or a conversion", color = Eon.DText, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text("Try 12 * 8 or 5 km in miles", color = Eon.DText.copy(alpha = 0.76f), fontSize = 12.sp)
        }
    }
}

/** Your recent searches under a small heading, with Clear. Tap one to run it again. */
@Composable
private fun LibRecents(onPick: (String) -> Unit) {
    if (RecentSearches.items.isEmpty()) return
    Column(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 4.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
            Text(
                "RECENT SEARCHES", color = Eon.DText.copy(alpha = 0.74f), fontSize = 11.sp, fontWeight = FontWeight.SemiBold,
                letterSpacing = 1.sp,
            )
            Text(
                "Clear", color = Eon.DText.copy(alpha = 0.7f), fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clip(CircleShape).clickable { RecentSearches.clear() }.padding(horizontal = 6.dp, vertical = 2.dp),
            )
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            RecentSearches.items.toList().forEach { t ->
                Box(
                    Modifier.height(34.dp).libGlass(RoundedCornerShape(17.dp)).clickable { onPick(t) }
                        .padding(horizontal = 14.dp),
                    contentAlignment = Alignment.Center,
                ) { Text(t, color = Eon.DText, fontSize = 13.sp, maxLines = 1) }
            }
        }
    }
}

/**
 * A to Z and # down the right edge. Letters that have apps are bright, the others dim. Tap a letter or slide a finger
 * along the rail and the list jumps to it (a letter with no apps goes to the nearest one that has some). While a
 * finger is on the rail the current letter turns accent-coloured and [onActive] says which letter and how far down
 * the rail the finger is, so the list can show a big bubble beside it; it gets null when the finger lifts.
 */
@Composable
private fun LibLetterRail(
    present: Set<String>, onJump: (String) -> Unit, onActive: (String?, Float) -> Unit, modifier: Modifier,
) {
    val letters = remember { ('A'..'Z').map { it.toString() } + "#" }
    val haptic = LocalHapticFeedback.current
    var height by remember { mutableIntStateOf(1) }
    var current by remember { mutableStateOf<String?>(null) }
    val jump by rememberUpdatedState(onJump)
    val active by rememberUpdatedState(onActive)
    Column(
        modifier.width(24.dp).onSizeChanged { height = it.height.coerceAtLeast(1) }
            .pointerInput(present) {
                var last = ""
                fun pick(y: Float) {
                    val i = ((y / height) * letters.size).toInt().coerceIn(0, letters.size - 1)
                    val at = (i until letters.size).firstOrNull { letters[it] in present }
                        ?: (i downTo 0).firstOrNull { letters[it] in present }
                        ?: return
                    val letter = letters[at]
                    if (letter != last) {
                        last = letter
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        jump(letter)
                    }
                    current = letter
                    active(letter, y.coerceIn(0f, height.toFloat()))
                }
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    last = ""
                    pick(down.position.y)
                    down.consume()
                    drag(down.id) { change ->
                        change.consume()
                        pick(change.position.y)
                    }
                    current = null
                    active(null, 0f)
                }
            },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        letters.forEach { l ->
            val on = l in present
            Text(
                l, fontSize = 10.sp, lineHeight = 10.sp, fontWeight = if (on || l == current) FontWeight.Bold else FontWeight.SemiBold,
                color = when {
                    l == current -> Eon.DAccent
                    on -> Eon.DText
                    else -> Color(0xFF5B5E66)
                },
            )
        }
    }
}

/** The Library's own glass: a clearly visible white wash and edge, so the controls read on any wallpaper. */
private fun Modifier.libGlass(shape: androidx.compose.ui.graphics.Shape): Modifier =
    this.clip(shape)
        .background(Brush.verticalGradient(listOf(Color(0x26FFFFFF), Color(0x12FFFFFF))))
        .border(1.dp, Brush.verticalGradient(listOf(Color(0x59FFFFFF), Color(0x14FFFFFF))), shape)
