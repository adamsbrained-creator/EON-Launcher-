package ix.app.eon

import android.app.Activity
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.graphics.drawable.toBitmap
import kotlin.math.ceil

/** Owns the app widget host for the whole launcher. */
class WidgetHolder(context: Context) {
    val manager: AppWidgetManager = AppWidgetManager.getInstance(context)
    val host = AppWidgetHost(context, 1024)

    fun appLabel(context: Context, info: AppWidgetProviderInfo): String = try {
        val pm = context.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(info.provider.packageName, 0)).toString()
    } catch (_: Exception) {
        info.provider.packageName
    }

    fun providers(context: Context): List<AppWidgetProviderInfo> =
        manager.installedProviders.sortedWith(
            compareBy({ appLabel(context, it).lowercase() }, { it.loadLabel(context.packageManager).lowercase() }),
        )
}

/** Default size, in grid cells, of Eon's own widgets. */
fun builtinSize(id: Int): Pair<Int, Int>? = when (id) {
    W_NOW_PLAYING -> 4 to 1
    W_WEATHER -> 4 to 1
    W_WEEK -> 4 to 2
    else -> null
}

/** A starting size in grid cells for a system widget, from what its provider asks for. */
fun suggestSize(ctx: Context, info: AppWidgetProviderInfo): Pair<Int, Int> {
    val d = ctx.resources.displayMetrics.density
    val cellWDp = (ctx.resources.configuration.screenWidthDp - 32) / GRID_COLS.toFloat()
    val w = ceil((info.minWidth / d) / cellWDp).toInt().coerceIn(1, GRID_COLS)
    val h = ceil((info.minHeight / d) / CELL_HEIGHT.value).toInt().coerceIn(1, 4)
    return w to h
}

/** One widget, filling the cells it was given. */
@Composable
fun WidgetView(holder: WidgetHolder, id: Int, wDp: Int, hDp: Int) {
    if (id == W_NOW_PLAYING) {
        NowPlayingWidget()
        return
    }
    if (id == W_WEEK) {
        WeekWidget()
        return
    }
    if (id == W_WEATHER) {
        WeatherQuoteWidget()
        return
    }
    val info = remember(id) { holder.manager.getAppWidgetInfo(id) } ?: return
    AndroidView(
        factory = { c -> holder.host.createView(c, id, info) },
        update = { v -> runCatching { v.updateAppWidgetSize(Bundle(), wDp, hDp, wDp, hDp) } },
        modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(24.dp)),
    )
}

/** Full-screen widget picker and manager. */
@Composable
fun WidgetsScreen(state: EonState, holder: WidgetHolder, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var pending by remember { mutableStateOf<Pair<Int, AppWidgetProviderInfo>?>(null) }
    val providers = remember { holder.providers(ctx) }
    BackHandler { onClose() }

    fun addBuiltin(id: Int) {
        val (w, h) = builtinSize(id) ?: return
        if (state.addWidget(id, w, h)) tab = 1
        else Toast.makeText(ctx, "No space on this page", Toast.LENGTH_SHORT).show()
    }

    fun commit(id: Int, info: AppWidgetProviderInfo) {
        val (w, h) = suggestSize(ctx, info)
        if (state.addWidget(id, w, h)) {
            tab = 1
        } else {
            holder.host.deleteAppWidgetId(id)
            Toast.makeText(ctx, "No space on this page", Toast.LENGTH_SHORT).show()
        }
        pending = null
    }

    fun cancel() {
        pending?.first?.let { holder.host.deleteAppWidgetId(it) }
        pending = null
    }

    val configure = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val p = pending
        if (p != null) {
            if (r.resultCode == Activity.RESULT_OK) commit(p.first, p.second) else cancel()
        }
    }

    fun afterBind(id: Int, info: AppWidgetProviderInfo) {
        pending = id to info
        val cfg = info.configure
        if (cfg != null) {
            try {
                configure.launch(
                    Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE)
                        .setComponent(cfg)
                        .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id),
                )
            } catch (_: Exception) {
                commit(id, info)
            }
        } else {
            commit(id, info)
        }
    }

    val bind = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val p = pending
        if (p != null) {
            if (r.resultCode == Activity.RESULT_OK) afterBind(p.first, p.second) else cancel()
        }
    }

    fun add(info: AppWidgetProviderInfo) {
        val id = holder.host.allocateAppWidgetId()
        pending = id to info
        if (holder.manager.bindAppWidgetIdIfAllowed(id, info.provider)) {
            afterBind(id, info)
        } else {
            bind.launch(
                Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider),
            )
        }
    }

    Column(
        Modifier.fillMaxSize().background(Color(0xF50A0A0B)).systemBarsPadding().padding(horizontal = 20.dp),
    ) {
        Gap(12)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(Color(0x24FFFFFF)).clickable(onClick = onClose),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Outlined.ArrowBack, "Back", tint = Eon.Text, modifier = Modifier.size(22.dp)) }
            Text("Widgets", color = Eon.Text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
        Gap(16)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            WTab("Add", tab == 0, Modifier.weight(1f)) { tab = 0 }
            WTab("On this page (${state.widgetItems().size})", tab == 1, Modifier.weight(1f)) { tab = 1 }
        }
        Gap(14)
        if (tab == 0) {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
                item(key = "h:eon") {
                    Text(
                        "EON", color = Eon.Faint, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                        letterSpacing = 1.4.sp, modifier = Modifier.padding(start = 4.dp, top = 10.dp),
                    )
                }
                item(key = "w:np") {
                    BuiltinRow("Now playing", "Track and artist from your music app") { addBuiltin(W_NOW_PLAYING) }
                }
                item(key = "w:weather") {
                    BuiltinRow("Weather and quote", "Local weather and a daily quote (tap for another)") { addBuiltin(W_WEATHER) }
                }
                item(key = "w:week") {
                    BuiltinRow("Week", "This week, the month and the time") { addBuiltin(W_WEEK) }
                }
                providers.groupBy { holder.appLabel(ctx, it) }.forEach { (app, list) ->
                    item(key = "h:$app") {
                        Text(
                            app.uppercase(), color = Eon.Faint, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                            letterSpacing = 1.4.sp, modifier = Modifier.padding(start = 4.dp, top = 10.dp),
                        )
                    }
                    items(list, key = { "w:${it.provider.flattenToString()}" }) { info ->
                        ProviderRow(info) { add(info) }
                    }
                }
            }
        } else {
            if (state.widgetItems().isEmpty()) {
                Text("No widgets on this page yet.", color = Eon.Muted, fontSize = 14.sp)
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(state.widgetItems(), key = { it.key }) { item ->
                    val id = item.key.toIntOrNull() ?: 0
                    val info = holder.manager.getAppWidgetInfo(id)
                    Column(
                        Modifier.fillMaxWidth().glass(RoundedCornerShape(22.dp)).padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    builtinLabel(id) ?: info?.loadLabel(ctx.packageManager)?.toString() ?: "Widget",
                                    color = Eon.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                                )
                                Text("${item.w} × ${item.h} cells", color = Eon.Muted, fontSize = 12.sp)
                            }
                            SmallBtn("Remove", Eon.Danger) {
                                if (id > 0) holder.host.deleteAppWidgetId(id)
                                state.removeWidget(id)
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            SmallBtn("←") { state.nudgeWidget(item.key, -1, 0) }
                            SmallBtn("→") { state.nudgeWidget(item.key, 1, 0) }
                            SmallBtn("↑") { state.nudgeWidget(item.key, 0, -1) }
                            SmallBtn("↓") { state.nudgeWidget(item.key, 0, 1) }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            SmallBtn("Taller") { state.resizeWidget(item.key, 0, 1) }
                            SmallBtn("Shorter") { state.resizeWidget(item.key, 0, -1) }
                            SmallBtn("Wider") { state.resizeWidget(item.key, 1, 0) }
                            SmallBtn("Narrower") { state.resizeWidget(item.key, -1, 0) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BuiltinRow(title: String, subtitle: String, onClick: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().glass(RoundedCornerShape(22.dp)).clickable(onClick = onClick).padding(14.dp),
    ) {
        Text(title, color = Eon.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        Text(subtitle, color = Eon.Muted, fontSize = 12.sp)
    }
}

@Composable
private fun ProviderRow(info: AppWidgetProviderInfo, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val density = LocalDensity.current.density
    val preview: ImageBitmap? = remember(info) {
        runCatching {
            val d = info.loadPreviewImage(ctx, 0)
            if (d == null) null else {
                val w = d.intrinsicWidth.coerceAtLeast(1)
                val h = d.intrinsicHeight.coerceAtLeast(1)
                d.toBitmap(300, (300f * h / w).toInt().coerceIn(60, 300)).asImageBitmap()
            }
        }.getOrNull()
    }
    val cols = ((info.minWidth / density + 30) / 70).toInt().coerceAtLeast(1)
    val rows = ((info.minHeight / density + 30) / 70).toInt().coerceAtLeast(1)
    Row(
        Modifier.fillMaxWidth().glass(RoundedCornerShape(22.dp)).clickable(onClick = onClick).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        if (preview != null) {
            Image(
                preview, null, Modifier.width(96.dp).heightIn(max = 72.dp).clip(RoundedCornerShape(12.dp)),
                contentScale = ContentScale.Fit,
            )
        }
        Column(Modifier.weight(1f)) {
            Text(
                info.loadLabel(ctx.packageManager).toString(), color = Eon.Text, fontSize = 15.sp,
                fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis,
            )
            Text("$cols × $rows", color = Eon.Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun WTab(label: String, on: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val look = if (on) Modifier.background(Eon.Button)
    else Modifier.background(Color(0x1FFFFFFF)).border(1.dp, Color(0x33FFFFFF), CircleShape)
    Box(
        modifier.height(40.dp).clip(CircleShape).then(look).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label, color = if (on) Color.White else Color(0xFFC8CAD0), fontSize = 14.sp,
            fontWeight = if (on) FontWeight.Bold else FontWeight.Medium,
        )
    }
}

@Composable
private fun SmallBtn(label: String, color: Color = Eon.Text, onClick: () -> Unit) {
    Box(
        Modifier.height(32.dp).clip(CircleShape).background(Color(0x24FFFFFF)).clickable(onClick = onClick)
            .padding(horizontal = 12.dp),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = color, fontSize = 13.sp, fontWeight = FontWeight.Medium) }
}
