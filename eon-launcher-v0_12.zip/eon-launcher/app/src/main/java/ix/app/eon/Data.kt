package ix.app.eon

import android.content.ComponentName
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.LauncherApps
import android.os.UserHandle
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

val CATEGORIES = listOf("Social", "Media", "Games", "Work", "Reading", "Maps", "Tools", "Other")

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("eon", Context.MODE_PRIVATE)

    var onboarded: Boolean
        get() = sp.getBoolean("onboarded", false)
        set(v) { sp.edit().putBoolean("onboarded", v).apply() }

    /** "glassy" or "flat" */
    var look: String
        get() = sp.getString("look", "glassy") ?: "glassy"
        set(v) { sp.edit().putString("look", v).apply() }

    /** "dark", "light" or "auto" (stored, not applied yet) */
    var theme: String
        get() = sp.getString("theme", "dark") ?: "dark"
        set(v) { sp.edit().putString("theme", v).apply() }

    /** Component names of apps pinned to the home screen, in order. */
    var pinned: List<String>
        get() = (sp.getString("pinned", "") ?: "").split("\n").filter { it.isNotBlank() }
        set(v) { sp.edit().putString("pinned", v.joinToString("\n")).apply() }

    /** Home pages as JSON: [{"pinned":[...],"widgets":[...]}]. Empty means "not migrated yet". */
    var pagesJson: String
        get() = sp.getString("pages", "") ?: ""
        set(v) { sp.edit().putString("pages", v).apply() }

    /** App widget ids shown on the home screen, in order. */
    var widgets: List<Int>
        get() = (sp.getString("widgets", "") ?: "").split(",").mapNotNull { it.trim().toIntOrNull() }
        set(v) { sp.edit().putString("widgets", v.joinToString(",")).apply() }

    /** Package names hidden from the drawer. */
    var hidden: Set<String>
        get() = sp.getStringSet("hidden", emptySet()) ?: emptySet()
        set(v) { sp.edit().putStringSet("hidden", HashSet(v)).apply() }

    /** Manual category per package. */
    var overrides: Map<String, String>
        get() = (sp.getStringSet("cats", emptySet()) ?: emptySet()).mapNotNull {
            val i = it.indexOf('|')
            if (i > 0) it.substring(0, i) to it.substring(i + 1) else null
        }.toMap()
        set(v) { sp.edit().putStringSet("cats", v.map { "${it.key}|${it.value}" }.toHashSet()).apply() }
}

data class AppEntry(
    val label: String,
    val packageName: String,
    val component: ComponentName,
    val user: UserHandle,
    val icon: ImageBitmap,
    val autoCategory: String,
) {
    val key: String = component.flattenToString()
}

class AppRepo(private val context: Context) {
    private val launcherApps =
        context.getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps

    private fun categoryOf(pkg: String): String {
        val info = try {
            context.packageManager.getApplicationInfo(pkg, 0)
        } catch (_: Exception) {
            return "Other"
        }
        return when (info.category) {
            ApplicationInfo.CATEGORY_SOCIAL -> "Social"
            ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_VIDEO, ApplicationInfo.CATEGORY_IMAGE -> "Media"
            ApplicationInfo.CATEGORY_GAME -> "Games"
            ApplicationInfo.CATEGORY_PRODUCTIVITY -> "Work"
            ApplicationInfo.CATEGORY_NEWS -> "Reading"
            ApplicationInfo.CATEGORY_MAPS -> "Maps"
            else -> if (info.flags and ApplicationInfo.FLAG_SYSTEM != 0) "Tools" else "Other"
        }
    }

    suspend fun load(): List<AppEntry> = withContext(Dispatchers.Default) {
        val px = (context.resources.displayMetrics.density * ICON_SIZE.value * 1.25f).toInt().coerceAtLeast(128)
        launcherApps.profiles
            .flatMap { user ->
                launcherApps.getActivityList(null, user).map { info ->
                    val pkg = info.componentName.packageName
                    AppEntry(
                        label = info.label.toString(),
                        packageName = pkg,
                        component = info.componentName,
                        user = user,
                        icon = IconShaper.shape(info.getBadgedIcon(0), px).asImageBitmap(),
                        autoCategory = categoryOf(pkg),
                    )
                }
            }
            .filter { it.packageName != context.packageName }
            .sortedBy { it.label.lowercase() }
    }

    fun launch(app: AppEntry) {
        try {
            launcherApps.startMainActivity(app.component, app.user, null, null)
        } catch (_: Exception) {
        }
    }

    /** Calls [onChange] when apps are installed, removed or updated. Returns an unregister function. */
    fun watch(onChange: () -> Unit): () -> Unit {
        val callback = object : LauncherApps.Callback() {
            override fun onPackageRemoved(packageName: String, user: UserHandle) = onChange()
            override fun onPackageAdded(packageName: String, user: UserHandle) = onChange()
            override fun onPackageChanged(packageName: String, user: UserHandle) = onChange()
            override fun onPackagesAvailable(
                packageNames: Array<out String>, user: UserHandle, replacing: Boolean,
            ) = onChange()
            override fun onPackagesUnavailable(
                packageNames: Array<out String>, user: UserHandle, replacing: Boolean,
            ) = onChange()
        }
        launcherApps.registerCallback(callback)
        return { launcherApps.unregisterCallback(callback) }
    }
}
