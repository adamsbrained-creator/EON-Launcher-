# Eon: what's new

## v0.9.4
- New icon shape: every app icon is now the same rounded square (about 26% rounded corners, measured from Smart Launcher), in the drawer, on the home grid and in the app menu. Adaptive icons are cut to the shape; old icons with a transparent margin sit centred on a light or dark plate so the grid looks even.
- Icons are a little bigger (60 dp instead of 56 dp). The size and corner radius are two values at the top of IconShape.kt.

## v0.9.3
- New colours: Eon moves from blue to near-black with soft grey text and a green accent (selected chips, badges, toggles, the playing dot). Panels are smoked black glass instead of blue, the welcome screen and the app icon are charcoal, and the Week widget and cover art match.

## v0.9.2
- Removed the dock: the home screen is now just the clock, your pages and the search pill. "Add to dock" is gone from the app menu. The dark fade at the bottom is shorter now that there is no dock behind it.

## v0.9.1
- Fixed: the build failed on one line in the home menu that still used the old way of checking whether a page is empty. Nothing else changed, so v0.9.1 has everything from v0.9.

## v0.9.0
- Free home grid: apps and widgets now sit on a 4-column grid. Long-press an app and drag it to any empty spot (or onto another app to swap); a highlight shows where it will land. Your existing home screen is moved onto the grid automatically.
- Widgets on the grid: each widget takes a number of cells. In the Widgets screen, the "On this page" tab lets you nudge a widget left, right, up or down and make it taller, shorter, wider or narrower. If a page is full, Eon says there is no space.
- Fixed: weather said "Allow location" even when location was allowed. It now asks the phone for a fresh coarse location itself, and says "No location fix" if there is none. Now playing also shows how many players it can see, to help find out why it stays empty.
- Not yet: dragging widgets directly, moving apps between pages.

## v0.8.0
- Fixed: long-pressing empty space on the home screen did nothing since pages arrived in v0.5, because the page swiper was catching the touch; it now opens the home menu (widgets, pages, settings) again, and long-pressing an app no longer risks opening it twice.
- New: tapping the page marker at the bottom also opens the home menu, as a second way in.

## v0.7.1
- Fixed: the build failed because two functions in the settings state had the same internal name (a naming clash on the look setting). Nothing else changed, so v0.7.1 has everything from v0.5 to v0.7, including home pages, the Eon widgets and weather.

## v0.7.0
- Weather and quote: a new Eon widget with the local weather on the left (angular icon, temperature, feels like) and a daily quote on the right; tap the weather to refresh or to allow location, tap the quote for another one. Weather comes from Open-Meteo using your last known coarse location, so Eon now asks for internet access.
- Not yet: your own quotes, folders, dragging apps between pages.

## v0.6.0
- Eon widgets: two built-in widgets under "EON" in the widget picker. Now playing shows the track and artist as plain text with a round cover and a green dot while playing (tap to open the player; needs notification access), and Week shows seven days around today with the month and the time.
- Gesture: swipe down on the home screen to pull the notification shade.
- Not yet: weather, folders, dragging apps between pages.

## v0.5.0
- Home pages: swipe sideways between pages, each with its own pinned apps and widgets; the marker at the bottom shows where you are, with the Eon glyph always standing for page one.
- Page controls: long-press empty space to add a page to the left or right, or to remove an empty one; pressing Home takes you back to page one.
- Changed: pinning an app or adding a widget now goes to the page you are on, and the widget manager shows that page's widgets.
- Not yet: dragging apps between pages, resizing widgets, folders.

## v0.4.0
- Widgets: long-press empty space and choose Widgets to add any widget from any app, then move or remove them in the "On this page" tab; they sit above your pinned apps.

## v0.3.0
- Drag to rearrange: long-press a pinned app or a dock app and drag it to a new spot; long-press and release still opens the app menu, which can now add or remove dock apps.

## v0.2.0
- Every app now shows in the drawer, Eon appears in the notification access list, and icons get notification counts.
- The drawer has category chips with search across all apps; long-press an app to pin, recategorize, hide, open app info or uninstall.
- Eon settings (Glassy or Flat look, notification access, hidden apps) and a more solid drawer background.

## v0.1.0
- First build: greeting flow, home with clock and dock, app drawer with search.
