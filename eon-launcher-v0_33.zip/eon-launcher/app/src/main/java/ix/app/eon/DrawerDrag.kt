package ix.app.eon

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateIntOffsetAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitLongPressOrCancellation
import androidx.compose.foundation.gestures.drag as dragGesture
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.roundToInt

/**
 * A drag that started on an app in the drawer. [pos] is the finger in root coordinates.
 * While [app] is set the drawer fades away and Home shows the icon under the finger.
 */
class DragState {
    var app by mutableStateOf<AppEntry?>(null)
    var pos by mutableStateOf(Offset.Zero)

    /** Index of a page made by holding at the edge during this drag, or -1. It goes away again if it stays empty. */
    var addedPage = -1
}

/**
 * Where an icon dropped with the finger at [pos] would land on the current home page, as (col, row),
 * or null when the finger is outside the grid. Whole cells in grid mode, exact spot in free mode.
 */
fun dragTarget(pos: Offset, grid: Rect, state: EonState): Pair<Float, Float>? {
    if (grid.width <= 0f || !grid.contains(pos)) return null
    val cellW = grid.width / GRID_COLS
    val cellH = state.cellHeightPx
    val rows = maxOf(state.gridRows, 1)
    val fx = (pos.x - grid.left) / cellW
    val fy = (pos.y - grid.top) / cellH
    if (fy >= rows) return null
    return if (state.freeIcons) {
        snapValue(fx - 0.5f, false).coerceIn(0f, GRID_COLS - 1f) to snapValue(fy - 0.5f, false).coerceIn(0f, rows - 1f)
    } else {
        floor(fx).coerceIn(0f, GRID_COLS - 1f) to floor(fy).coerceIn(0f, rows - 1f)
    }
}

/** Where a dragged icon would land. */
sealed interface DropTarget {
    data class Home(val col: Float, val row: Float) : DropTarget
    data class Dock(val page: Int, val col: Int, val row: Int) : DropTarget
}

/** The dock cell under [pos] when it is over the dock, otherwise the home cell. [dpPx] is pixels per dp. */
fun dropTarget(pos: Offset, grid: Rect, dock: Rect, dpPx: Float, state: EonState): DropTarget? {
    if (dock.width > 0f && dock.contains(pos)) {
        val pad = 8f * dpPx
        val cols = HomeConfig.dockCols
        val rows = HomeConfig.dockRows
        val cw = (dock.width - 2f * pad) / cols
        val ch = dockCellHeightDp().value * dpPx
        val c = floor((pos.x - dock.left - pad) / cw).toInt().coerceIn(0, cols - 1)
        val r = floor((pos.y - dock.top - pad) / ch).toInt().coerceIn(0, rows - 1)
        return DropTarget.Dock(state.dockPage, c, r)
    }
    return dragTarget(pos, grid, state)?.let { DropTarget.Home(it.first, it.second) }
}

/**
 * An app icon in the drawer. Tap launches it. Long-press and drag lifts it so it can be dropped on the
 * home screen; long-press and let go without moving opens the app menu.
 */
@Composable
fun DragAppIcon(
    app: AppEntry, iconSize: Dp, drag: DragState,
    onLaunch: () -> Unit, onMenu: () -> Unit, onDrop: (AppEntry, Offset) -> Unit,
) {
    val haptic = LocalHapticFeedback.current
    var origin by remember { mutableStateOf(Offset.Zero) }
    val latestLaunch by rememberUpdatedState(onLaunch)
    val latestMenu by rememberUpdatedState(onMenu)
    val latestDrop by rememberUpdatedState(onDrop)
    Box(
        Modifier
            .clip(RoundedCornerShape(16.dp))
            .onGloballyPositioned { origin = it.positionInRoot() }
            .pointerInput(app.key) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val press = awaitLongPressOrCancellation(down.id)
                    if (press == null) {
                        val ev = currentEvent.changes.firstOrNull { it.id == down.id }
                        if (ev != null && !ev.pressed &&
                            (ev.position - down.position).getDistance() < viewConfiguration.touchSlop * 2
                        ) {
                            latestLaunch()
                        }
                        return@awaitEachGesture
                    }
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    var cur = origin + down.position
                    var travelled = 0f
                    var started = false
                    val finished = dragGesture(down.id) { change ->
                        val d = change.positionChange()
                        travelled += d.getDistance()
                        cur += d
                        change.consume()
                        if (!started && travelled > viewConfiguration.touchSlop) {
                            started = true
                            drag.app = app
                        }
                        if (started) drag.pos = cur
                    }
                    if (started) {
                        drag.app = null
                        if (finished) latestDrop(app, cur)
                    } else {
                        latestMenu()
                    }
                }
            },
    ) { AppIconBody(app, iconSize, true) }
}

/**
 * Drawn over the home screen while an icon is being dragged out of the drawer: the target cell, the icon
 * under the finger, and page switching when the finger rests at the left or right edge.
 * [grid] is the pager's rectangle and [homeOrigin] the top-left of this layer, both in root coordinates.
 */
@Composable
fun DragLayer(drag: DragState, state: EonState, grid: Rect, dock: Rect, homeOrigin: Offset, pager: PagerState) {
    val app = drag.app ?: return
    val density = LocalDensity.current
    val cellW = grid.width / GRID_COLS
    val cellH = state.cellHeightPx
    val cellWDp = with(density) { cellW.toDp() }
    val cellHDp = with(density) { cellH.toDp() }

    // Rest the finger at an edge to move to the next page.
    val edge = with(density) { 40.dp.toPx() }
    val overDock = dock.width > 0f && dock.contains(drag.pos)
    val side = when {
        overDock -> 0
        drag.pos.x < grid.left + edge -> -1
        drag.pos.x > grid.right - edge -> 1
        else -> 0
    }
    LaunchedEffect(side) {
        if (side != 0) {
            while (true) {
                delay(650)
                val next = pager.currentPage + side
                if (next in 0 until pager.pageCount) {
                    pager.animateScrollToPage(next)
                } else if (side == 1 && next == pager.pageCount && state.pages.lastOrNull()?.items?.isNotEmpty() == true) {
                    // Past the last page: make a new one.
                    state.addPage(next)
                    drag.addedPage = next
                    delay(120)
                    pager.animateScrollToPage(next)
                }
            }
        }
    }

    val dpPx = density.density
    val target = dropTarget(drag.pos, grid, dock, dpPx, state)
    if (target != null) {
        // Rainbow outline when the icon would land on another icon (it would make or join a folder).
        var onIcon = false
        val ghostX: Float
        val ghostY: Float
        var ghostW = cellW
        var ghostH = cellH
        when (target) {
            is DropTarget.Home -> {
                ghostX = grid.left - homeOrigin.x + target.col * cellW
                ghostY = grid.top - homeOrigin.y + target.row * cellH
                onIcon = state.pages.getOrNull(pager.targetPage)?.items?.any {
                    it.kind != "w" && it.key != app.key &&
                        abs(it.col - target.col) < 0.6f && abs(it.row - target.row) < 0.6f
                } == true
            }
            is DropTarget.Dock -> {
                val pad = 8f * dpPx
                ghostW = (dock.width - 2f * pad) / HomeConfig.dockCols
                ghostH = dockCellHeightDp().value * dpPx
                ghostX = dock.left - homeOrigin.x + pad + target.col * ghostW
                ghostY = dock.top - homeOrigin.y + pad + target.row * ghostH
            }
        }
        val ghost by animateIntOffsetAsState(
            IntOffset(ghostX.roundToInt(), ghostY.roundToInt()),
            spring(stiffness = Spring.StiffnessMedium),
            label = "dropGhost",
        )
        val shape = RoundedCornerShape(20.dp)
        Box(
            Modifier
                .offset { ghost }
                .size(DpSize(with(density) { ghostW.toDp() }, with(density) { ghostH.toDp() }))
                .padding(4.dp)
                .clip(shape)
                .background(Color(0x22FFFFFF))
                .border(
                    if (onIcon) 2.dp else 1.dp,
                    if (onIcon) Eon.Button else SolidColor(Color(0x66FFFFFF)),
                    shape,
                ),
        )
    }
    Box(
        Modifier
            .offset {
                IntOffset(
                    (drag.pos.x - homeOrigin.x - cellW / 2f).roundToInt(),
                    (drag.pos.y - homeOrigin.y - cellH / 2f).roundToInt(),
                )
            }
            .size(DpSize(cellWDp, cellHDp))
            .zIndex(1000f)
            .graphicsLayer {
                scaleX = 1.12f
                scaleY = 1.12f
                alpha = 0.92f
            },
        contentAlignment = Alignment.Center,
    ) {
        AppIconBody(app, HomeConfig.iconDp.dp, HomeConfig.showLabels, HomeConfig.labelSp, HomeConfig.twoLine)
    }
}
