package ix.app.eon

import android.accessibilityservice.AccessibilityService
import android.app.WallpaperManager
import android.widget.Toast
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.tween
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.unit.toSize
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.activity.ComponentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.changedToDown
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.LocalViewConfiguration
import kotlinx.coroutines.delay
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerDefaults
import androidx.compose.foundation.pager.rememberPagerState

@Composable
fun Home(
    repo: AppRepo, state: EonState, widgets: WidgetHolder, apps: List<AppEntry>, homeTick: Int,
    onResetGreeting: () -> Unit,
) {
    val ctx = LocalContext.current
    val density = LocalDensity.current.density
    var drawer by rememberSaveable { mutableStateOf(false) }
    var settings by rememberSaveable { mutableStateOf(false) }
    var focusSearch by remember { mutableStateOf(false) }
    var menuApp by remember { mutableStateOf<AppEntry?>(null) }
    var homeMenu by remember { mutableStateOf(false) }
    var widgetScreen by rememberSaveable { mutableStateOf(false) }
    var settingsStart by remember { mutableStateOf("") }
    val drag = remember { DragState() }
    var gridBox by remember { mutableStateOf(Rect.Zero) }
    var dockBox by remember { mutableStateOf(Rect.Zero) }
    var homeOrigin by remember { mutableStateOf(Offset.Zero) }
    val fx = remember { WallpaperFx() }
    // When Eon's live wallpaper is the system wallpaper it draws the picture itself (home and lock screen).
    val live = rememberLiveWallpaperActive()
    val rootView = LocalView.current
    val touchSlop = LocalViewConfiguration.current.touchSlop
    val pagerState = rememberPagerState(pageCount = { state.pages.size })
    var scrollTo by remember { mutableIntStateOf(-1) }
    LaunchedEffect(pagerState) { snapshotFlow { pagerState.currentPage }.collect { state.currentPage = it } }
    LaunchedEffect(scrollTo) {
        if (scrollTo >= 0) {
            pagerState.animateScrollToPage(scrollTo)
            scrollTo = -1
        }
    }

    // The home animation: icons hide when Eon goes off screen and play in when it comes back.
    val introScope = rememberCoroutineScope()
    DisposableEffect(Unit) {
        val lifecycle = (ctx as ComponentActivity).lifecycle
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_STOP -> introScope.launch { AnimConfig.arm() }
                Lifecycle.Event.ON_START -> AnimConfig.introTick++
                else -> {}
            }
        }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer) }
    }
    LaunchedEffect(AnimConfig.introTick) {
        if (AnimConfig.introTick > 0) AnimConfig.play()
    }

    state.appsForLabels = apps
    // One backup a day (when it is on in Settings > Backup).
    LaunchedEffect(Unit) { withContext(Dispatchers.IO) { Backup.daily(ctx) } }
    // Frosted glass: the wallpaper behind blurs while the drawer or settings are open (Settings > Animations).
    val blurTarget = if (BlurConfig.level > 0 && ((drawer && drag.app == null) || settings || widgetScreen)) BlurConfig.radius() else 0
    // Blur fades in softly but is gone quickly, so closing the drawer does not drag.
    val blurNow by animateIntAsState(blurTarget, tween(if (blurTarget == 0) 140 else 320), label = "blur")
    SideEffect {
        try {
            (ctx as ComponentActivity).window.setBackgroundBlurRadius(blurNow)
        } catch (_: Exception) {
        }
    }
    val dockRect = if (HomeConfig.dockOn) dockBox else Rect.Zero
    val visible = remember(apps, state.hidden.size, DrawerConfig.hidePlayStore, DrawerConfig.hideIconPacks) {
        apps.filter { it.packageName !in state.hidden && !DrawerConfig.hiddenByRules(it) }
    }
    val shadow = Shadow(Color(0x73000000), Offset(0f, 2f), 8f)

    DisposableEffect(Unit) {
        widgets.host.startListening()
        onDispose { widgets.host.stopListening() }
    }
    // Tell the live wallpaper which page you are on, so the picture shifts as you swipe.
    LaunchedEffect(live) {
        if (live) {
            snapshotFlow { pagerState.currentPage + pagerState.currentPageOffsetFraction to state.pages.size }.collect { (pos, n) ->
                val offset = if (n > 1) (pos / (n - 1)).coerceIn(0f, 1f) else 0.5f
                try {
                    WallpaperManager.getInstance(ctx).setWallpaperOffsets(rootView.windowToken, offset, 0.5f)
                } catch (_: Exception) {
                }
            }
        }
    }
    // A page made by holding at the edge while dragging goes away again if nothing was dropped on it.
    LaunchedEffect(drag.app, drag.folder) {
        if (drag.app == null && drag.folder == null && drag.addedPage >= 0) {
            val i = drag.addedPage
            drag.addedPage = -1
            state.removePage(i)
        }
    }
    // Apps that were uninstalled leave their folders. (An empty list means the apps have not loaded yet.)
    LaunchedEffect(apps) {
        if (apps.isNotEmpty()) state.pruneFolders(apps.map { it.key }.toSet())
    }
    // Move home screens saved by older versions onto the grid.
    LaunchedEffect(Unit) {
        state.migrate { id ->
            builtinSize(id)
                ?: widgets.manager.getAppWidgetInfo(id)?.let { suggestSize(ctx, it) }
                ?: (4 to 2)
        }
    }
    // Forget widgets whose provider app was removed.
    LaunchedEffect(Unit) {
        state.allWidgets().filter { it > 0 && widgets.manager.getAppWidgetInfo(it) == null }.forEach { state.removeWidget(it) }
        state.stackedWidgets().filter { (_, w) -> w > 0 && widgets.manager.getAppWidgetInfo(w) == null }
            .forEach { (stack, w) -> state.removeFromStack(stack, w) }
    }
    LaunchedEffect(homeTick) {
        if (homeTick > 0) {
            drawer = false
            settings = false
            widgetScreen = false
            state.stackConfig = null
            state.stackPicker = null
            state.stackSizeScreen = false
            state.editing = null
            state.openFolder = null
            state.gestureEditor = null
            state.actionPicker = null
            pagerState.animateScrollToPage(0)
        }
    }
    // What a gesture does (see Settings > Gestures). Actions are written as text, see [Act].
    val runAction: (String) -> Unit = { spec ->
        when {
            spec == Act.LOCK -> lockScreen(ctx)
            spec == Act.SCREEN_OFF ->
                if (!EonAccessibilityService.run(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)) lockScreen(ctx)
            spec == Act.DRAWER -> { focusSearch = false; drawer = true }
            spec == Act.SEARCH -> { focusSearch = true; drawer = true }
            spec == Act.NOTIF ->
                if (!EonAccessibilityService.run(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)) expandNotifications(ctx)
            spec == Act.PANEL ->
                if (!EonAccessibilityService.run(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)) expandQuickSettings(ctx)
            spec == Act.RECENTS ->
                if (!EonAccessibilityService.run(AccessibilityService.GLOBAL_ACTION_RECENTS)) {
                    Toast.makeText(ctx, "Turn on the Eon gesture helper in Settings > Gestures", Toast.LENGTH_LONG).show()
                }
            spec == Act.SETTINGS -> { settingsStart = ""; settings = true }
            spec == Act.NEXT_PAGE -> introScope.launch {
                pagerState.animateScrollToPage((pagerState.currentPage + 1) % maxOf(1, state.pages.size))
            }
            spec == Act.PREV_PAGE -> introScope.launch {
                val n = maxOf(1, state.pages.size)
                pagerState.animateScrollToPage((pagerState.currentPage - 1 + n) % n)
            }
            spec == Act.FIRST_PAGE -> introScope.launch { pagerState.animateScrollToPage(0) }
            spec.startsWith(Act.APP) -> apps.firstOrNull { it.key == spec.removePrefix(Act.APP) }?.let { repo.launch(it) }
            spec.startsWith(Act.URL) -> try {
                ctx.startActivity(
                    android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(spec.removePrefix(Act.URL)))
                        .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK),
                )
            } catch (_: Exception) {
            }
        }
    }
    // An icon lifted from the home screen was let go: drop it where it is, or open its menu if it never moved.
    val finishHomeDrag: (Offset) -> Unit = { pos ->
        val a = drag.app
        val f = drag.folder
        val moved = drag.started
        val click = drag.onClick
        drag.app = null
        drag.folder = null
        drag.fromHome = false
        drag.started = false
        drag.pendingApp = null
        drag.pendingFolder = null
        drag.onClick = null
        if (!moved) {
            click?.invoke()
        } else {
            when (val t = dropTarget(pos, gridBox, dockRect, density, state)) {
                is DropTarget.Home -> {
                    val ok = when {
                        a != null -> state.placeApp(pagerState.targetPage, a.key, t.col, t.row)
                        f != null -> state.placeFolder(pagerState.targetPage, f.key, t.col, t.row)
                        else -> true
                    }
                    if (!ok) Toast.makeText(ctx, "No room on this page", Toast.LENGTH_SHORT).show()
                }
                is DropTarget.Dock -> {
                    if (a != null) {
                        if (!state.dropToDock(a.key, t.page, t.col, t.row)) Toast.makeText(ctx, "The dock is full", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(ctx, "Folders can't go in the dock", Toast.LENGTH_SHORT).show()
                    }
                }
                null -> {}
            }
        }
    }
    // A widget being moved: rest the finger at the left or right edge and it goes to the next page.
    LaunchedEffect(state.dragEdge) {
        val side = state.dragEdge
        if (side != 0) {
            while (true) {
                delay(650)
                val item = state.editingItem() ?: break
                val cur = pagerState.currentPage
                val next = cur + side
                if (next in 0 until state.pages.size) {
                    state.moveItemToPage(item, next)
                    pagerState.animateScrollToPage(next)
                } else if (side == 1 && next == state.pages.size && (state.pages.getOrNull(cur)?.items?.size ?: 0) > 1) {
                    // Past the last page: make a new one.
                    state.addPage(next)
                    state.moveItemToPage(item, next)
                    pagerState.animateScrollToPage(next)
                }
            }
        }
    }
    LaunchedEffect(state.editing) { if (state.editing == null) state.dragEdge = 0 }
    BackHandler(enabled = drawer) { drawer = false }
    BackHandler(enabled = state.editing != null) { state.editing = null }
    BackHandler(enabled = state.openFolder != null) { state.commitLayout(); state.openFolder = null }

    Box(
        Modifier
            .fillMaxSize()
            .onGloballyPositioned { homeOrigin = it.positionInRoot() }
            // Watches touches (without using them) so the Ripple effect can start where you touch.
            .pointerInput(live) {
                awaitPointerEventScope {
                    while (true) {
                        val event = awaitPointerEvent(PointerEventPass.Initial)
                        event.changes.forEach {
                            if (it.changedToDown()) {
                                LaunchOrigin.view = rootView
                                LaunchOrigin.x = it.position.x.toInt()
                                LaunchOrigin.y = it.position.y.toInt()
                                LaunchOrigin.half = (34f * density).toInt()
                                if (live) {
                                    // The live wallpaper draws the effect, so tell it where you touched.
                                    try {
                                        WallpaperManager.getInstance(ctx).sendWallpaperCommand(
                                            rootView.windowToken, WallpaperManager.COMMAND_TAP,
                                            it.position.x.toInt(), it.position.y.toInt(), 0, null,
                                        )
                                    } catch (_: Exception) {
                                    }
                                } else {
                                    fx.touch(it.position.x, it.position.y)
                                }
                            }
                        }
                    }
                }
            }
            // Follows an icon lifted from the home screen. Watching before anything else sees the touch (Initial pass)
            // keeps it going when the page under the finger slides away, and stops the pager scrolling with it.
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                        val id = drag.pointer ?: continue
                        val c = ev.changes.firstOrNull { it.id == id } ?: continue
                        val root = homeOrigin + c.position
                        drag.travelled += (root - drag.last).getDistance()
                        drag.last = root
                        drag.pos = root
                        if (!drag.started && drag.travelled > touchSlop) {
                            drag.started = true
                            drag.app = drag.pendingApp
                            drag.folder = drag.pendingFolder
                            drag.fromHome = true
                        }
                        c.consume()
                        if (!c.pressed) {
                            drag.pointer = null
                            finishHomeDrag(root)
                        }
                    }
                }
            }
            // Two fingers up or down anywhere on the home screen (Settings > Gestures).
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    val starts = HashMap<androidx.compose.ui.input.pointer.PointerId, Offset>()
                    var fired = false
                    while (true) {
                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                        val down = ev.changes.filter { it.pressed }
                        if (down.isEmpty()) break
                        if (!fired && down.size >= 2 && state.editing == null && !drawer && !settings && !widgetScreen) {
                            down.forEach { if (it.id !in starts) starts[it.id] = it.position }
                            val dys = down.mapNotNull { c -> starts[c.id]?.let { c.position.y - it.y } }
                            if (dys.size >= 2) {
                                val avg = dys.average().toFloat()
                                if (kotlin.math.abs(avg) > 90.dp.toPx()) {
                                    val spec = if (avg < 0f) GestureConfig.twoUp else GestureConfig.twoDown
                                    if (spec != Act.NONE) {
                                        fired = true
                                        runAction(spec)
                                    }
                                }
                            }
                        }
                        if (fired) ev.changes.forEach { it.consume() }
                    }
                }
            }
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = {
                        val free = !drawer && !settings && !widgetScreen
                        if (state.editing != null) {
                            // finishing a widget edit: swipes do nothing
                        } else if (DrawerConfig.swipeUpHome && free && total > 240f) {
                            // Swipe up goes home: swipe down on the home screen opens the drawer.
                            runAction(Act.DRAWER)
                        } else if (total < -160f && (free || GestureConfig.swipeUp == Act.DRAWER)) {
                            // With swipe up goes home on, swiping up on the home screen no longer opens the drawer.
                            if (!(DrawerConfig.swipeUpHome && GestureConfig.swipeUp == Act.DRAWER)) runAction(GestureConfig.swipeUp)
                        } else if (total > 240f && free) {
                            runAction(GestureConfig.swipeDown)
                        }
                    },
                    onDragCancel = { total = 0f },
                    onVerticalDrag = { _, dy -> total += dy },
                )
            },
    ) {
        // The gyro wallpaper, when it is on, sits behind everything. Otherwise the system wallpaper shows through.
        if (WallpaperConfig.active && !live) {
            GyroWallpaper(
                fx = fx,
                page = { pagerState.currentPage + pagerState.currentPageOffsetFraction },
                pageCount = { state.pages.size },
            )
        }
        // Empty-space layer: long-press here opens the home menu.
        Box(
            Modifier.fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures(
                        onLongPress = { if (state.editing == null && !state.widgetTouch) homeMenu = true },
                        onDoubleTap = { runAction(GestureConfig.doubleTap) },
                    )
                },
        )
        Box(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(160.dp)
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xA6000000)))),
        )

        // The home screen sinks back a little while the drawer or settings are open, which gives the screens depth.
        val recede by animateFloatAsState(
            if ((drawer && drag.app == null) || settings || widgetScreen) 1f else 0f,
            // Sinks back softly, but comes forward again quickly.
            if ((drawer && drag.app == null) || settings || widgetScreen) tween(320, easing = Motion.Decel)
            else tween(160, easing = androidx.compose.animation.core.FastOutSlowInEasing),
            label = "recede",
        )
        Column(
            Modifier.fillMaxSize().graphicsLayer {
                val s = 1f - 0.05f * recede
                scaleX = s
                scaleY = s
                alpha = 1f - 0.4f * recede
            }.systemBarsPadding().padding(horizontal = HomeConfig.sidePad.dp),
        ) {
            Gap(HomeConfig.topPad)
            BoxWithConstraints(
                Modifier.weight(1f).fillMaxWidth()
                    .onGloballyPositioned { c -> gridBox = Rect(c.positionInRoot(), c.size.toSize()) },
            ) {
            HorizontalPager(
                pagerState,
                Modifier.fillMaxSize().onSizeChanged { size ->
                    state.setArea(size.height.toFloat(), CELL_HEIGHT.value * density)
                },
                userScrollEnabled = state.editing == null,
                flingBehavior = PagerDefaults.flingBehavior(
                    state = pagerState,
                    snapAnimationSpec = spring(dampingRatio = 0.88f, stiffness = 330f),
                ),
            ) { index ->
                val page = state.pages.getOrNull(index)
                if (page != null) {
                    Box(Modifier.fillMaxSize().pageEffect(pagerState, index)) {
                        PageGrid(
                            page = page, pageIndex = index, state = state, apps = apps, widgets = widgets, drag = drag,
                            onTap = { repo.launch(it) },
                            onMenu = { menuApp = it },
                            onEmptyLongPress = { homeMenu = true },
                            onDoubleTap = { runAction(GestureConfig.doubleTap) },
                            onAction = runAction,
                        )
                        if (index == 0 && page.items.isEmpty() && page.legacyPinned.isEmpty() && page.legacyWidgets.isEmpty()) {
                            Text(
                                "Long-press an app in the drawer and drag it here.",
                                style = TextStyle(color = Color(0xFFE2E3E6), fontSize = 13.sp, shadow = shadow),
                                modifier = Modifier.padding(start = 12.dp, top = 8.dp),
                            )
                        }
                    }
                }
            }
            // The search pill floats over the grid, so icons can sit anywhere, including the bottom.
            if (!state.searchHidden) SearchLayer(state, onOpen = { focusSearch = true; drawer = true })
            // The editing layer sits over the pager, not inside a page, so a widget can be carried to another page.
            state.editingItem()?.let { item ->
                WidgetEditLayer(state, widgets, item, constraints.maxWidth.toFloat() / GRID_COLS, state.cellHeightPx, state.gridRows)
            }
            }
            if (HomeConfig.dockOn) {
                Dock(
                    state, apps, onTap = { repo.launch(it) }, onMenu = { menuApp = it }, onAction = runAction,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
                        .onGloballyPositioned { c -> dockBox = Rect(c.positionInRoot(), c.size.toSize()) },
                )
            }
            if (HomeConfig.indicator) Column(
                Modifier.fillMaxWidth().padding(bottom = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Row(
                    Modifier.clip(CircleShape).clickable { homeMenu = true }
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    state.pages.forEachIndexed { i, _ ->
                        val on = i == pagerState.currentPage
                        if (i == 0) {
                            EonMark(Modifier.size(16.dp), brush = SolidColor(if (on) Eon.Text else Color(0x80FFFFFF)))
                        } else {
                            Box(
                                Modifier.size(if (on) 8.dp else 6.dp).clip(CircleShape)
                                    .background(if (on) Eon.Text else Color(0x66FFFFFF)),
                            )
                        }
                    }
                }
            }
            Gap(HomeConfig.bottomPad)
        }

        AnimatedVisibility(
            visible = drawer,
            enter = drawerEnter(AnimConfig.drawer),
            exit = drawerExit(AnimConfig.drawer),
        ) {
            // The drawer fades out while an icon is being dragged, so the home screen shows through.
            val drawerAlpha by animateFloatAsState(if (drag.app != null) 0f else 1f, tween(140), label = "drawerAlpha")
            Box(Modifier.fillMaxSize().graphicsLayer { alpha = drawerAlpha }) {
                val dropOnHome: (AppEntry, Offset) -> Unit = { app, pos ->
                    when (val t = dropTarget(pos, gridBox, dockRect, density, state)) {
                        is DropTarget.Home -> {
                            if (state.placeApp(pagerState.targetPage, app.key, t.col, t.row)) {
                                drawer = false
                            } else {
                                Toast.makeText(ctx, "No room on this page", Toast.LENGTH_SHORT).show()
                            }
                        }
                        is DropTarget.Dock -> {
                            if (state.dropToDock(app.key, t.page, t.col, t.row)) {
                                drawer = false
                            } else {
                                Toast.makeText(ctx, "The dock is full", Toast.LENGTH_SHORT).show()
                            }
                        }
                        null -> {}
                    }
                }
                val drawerApps = remember(visible, DrawerConfig.sort) { sortApps(visible, DrawerConfig.sort) }
                val openDrawerSettings = { drawer = false; settingsStart = "drawer"; settings = true }
                if (state.drawerStyle == "library") {
                    AppLibrary(
                        apps = drawerApps, state = state, focusSearch = focusSearch,
                        onLaunch = { app -> repo.launch(app); if (DrawerConfig.closeAfterLaunch) drawer = false },
                        onMenu = { app -> menuApp = app },
                        onClose = { drawer = false },
                        drag = drag, onDrop = dropOnHome, onSettings = openDrawerSettings,
                    )
                } else {
                    Drawer(
                        apps = drawerApps, state = state, focusSearch = focusSearch,
                        onLaunch = { app -> repo.launch(app); if (DrawerConfig.closeAfterLaunch) drawer = false },
                        onMenu = { app -> menuApp = app },
                        onClose = { drawer = false },
                        drag = drag, onDrop = dropOnHome, onSettings = openDrawerSettings,
                    )
                }
            }
        }
        DragLayer(drag, state, apps, gridBox, dockRect, homeOrigin, pagerState)

        val openFolder = state.openFolder?.let { state.findFolder(it) }
        LaunchedEffect(state.openFolder, openFolder == null) {
            if (state.openFolder != null && openFolder == null) state.openFolder = null
        }
        if (openFolder != null) {
            PopAnim {
                FolderPopup(
                    state, openFolder, apps,
                    onLaunch = { app -> state.commitLayout(); state.openFolder = null; repo.launch(app) },
                    onMenu = { app -> menuApp = app },
                    onClose = { state.commitLayout(); state.openFolder = null },
                )
            }
        }

        ScreenAnim(settings) { SettingsScreen(state, { settings = false; settingsStart = "" }, onResetGreeting, settingsStart) }
        state.stackConfig?.let { sid -> EnterAnim { StackConfigScreen(state, widgets, sid) } }
        ScreenAnim(widgetScreen || state.stackPicker != null) {
            WidgetsScreen(state, widgets, state.stackPicker) {
                widgetScreen = false
                state.stackPicker = null
                state.stackSizeScreen = false
            }
        }
        state.gestureEditor?.let { t -> EnterAnim { GestureEditorScreen(state, t, apps) { state.gestureEditor = null } } }
        state.actionPicker?.let { r -> EnterAnim { ActionPickerScreen(r, apps) { state.actionPicker = null } } }
    }

    menuApp?.let { app ->
        AppMenu(app, state) { menuApp = null }
    }
    if (homeMenu) {
        val cur = pagerState.currentPage
        HomeMenu(
            onDismiss = { homeMenu = false },
            onWidgets = { homeMenu = false; widgetScreen = true },
            onAddLeft = { homeMenu = false; state.addPage(cur) },
            onAddRight = { homeMenu = false; state.addPage(cur + 1); scrollTo = cur + 1 },
            canRemove = state.pages.size > 1 && state.pages.getOrNull(cur)?.items?.isEmpty() == true,
            onRemove = { homeMenu = false; state.removePage(cur) },
            onSettings = { homeMenu = false; settingsStart = ""; settings = true },
            onWallpaper = { homeMenu = false; settingsStart = "wallpaper"; settings = true },
            freeIcons = state.freeIcons,
            onTogglePlacement = { homeMenu = false; state.chooseFreeIcons(!state.freeIcons) },
            searchHidden = state.searchHidden,
            onShowSearch = { homeMenu = false; state.resetSearch(); state.chooseSearchHidden(false) },
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppIcon(
    app: AppEntry, iconSize: Dp, showLabel: Boolean,
    onClick: () -> Unit, onLongClick: () -> Unit,
) {
    Box(
        Modifier.clip(RoundedCornerShape(16.dp))
            .combinedClickable(onClick = onClick, onLongClick = onLongClick),
    ) { AppIconBody(app, iconSize, showLabel) }
}

/** The icon, badge and label, without any touch handling. */
@Composable
fun AppIconBody(
    app: AppEntry, iconSize: Dp, showLabel: Boolean,
    labelSp: Float = 12f, twoLine: Boolean = false, labelColor: Color = Eon.Text,
) {
    val count = Badges.counts[app.packageName] ?: 0
    // Icons shrink a little under a finger.
    var pressed by remember { mutableStateOf(false) }
    val pressScale by animateFloatAsState(
        if (pressed && AnimConfig.press) 0.9f else 1f,
        spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMedium), label = "press",
    )
    Column(
        Modifier.pressFeedback { pressed = it }
            .graphicsLayer { scaleX = pressScale; scaleY = pressScale }
            .padding(vertical = 4.dp, horizontal = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box {
            Image(bitmap = app.icon, contentDescription = app.label, modifier = Modifier.size(iconSize).scaledIcon(app.iconScale))
            if (count > 0) {
                Box(
                    Modifier.align(Alignment.TopEnd).offset(x = 5.dp, y = (-4).dp)
                        .defaultMinSize(minWidth = 18.dp, minHeight = 18.dp)
                        .clip(CircleShape).background(Eon.Button)
                        .border(1.5.dp, Eon.Text, CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        if (count > 99) "99+" else "$count", color = Eon.OnAccent,
                        fontSize = 10.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 4.dp),
                    )
                }
            }
        }
        if (showLabel) {
            Gap(6)
            Text(
                app.label, color = labelColor, fontSize = labelSp.sp, maxLines = if (twoLine) 2 else 1, overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                style = TextStyle(shadow = Shadow(Color(0x99000000), Offset(0f, 1f), 4f)),
            )
        }
    }
}

/** Pulls down the system notification shade (needs the EXPAND_STATUS_BAR permission). */
fun expandNotifications(ctx: android.content.Context) {
    try {
        val service = ctx.getSystemService("statusbar") ?: return
        service.javaClass.getMethod("expandNotificationsPanel").invoke(service)
    } catch (_: Exception) {
    }
}
