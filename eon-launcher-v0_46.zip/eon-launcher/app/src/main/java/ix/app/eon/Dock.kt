package ix.app.eon

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.VectorConverter
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitLongPressOrCancellation
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import kotlin.math.roundToInt

/** Height of one dock cell. Also used to work out which cell a dragged icon is over. */
fun dockCellHeightDp(): Dp = (HomeConfig.dockIconDp + 14 + (if (HomeConfig.dockLabels) 18 else 0)).dp

/**
 * The dock: a rounded, see-through bar at the bottom of the home screen, like on iOS. It stays in place
 * while you swipe between home pages. Add apps with "Move to dock" in an app's menu; long-press and drag
 * an icon in the dock to rearrange them.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Dock(
    state: EonState,
    apps: List<AppEntry>,
    onTap: (AppEntry) -> Unit,
    onMenu: (AppEntry) -> Unit,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(30.dp)
    val cellHDp = (HomeConfig.dockIconDp + 14 + (if (HomeConfig.dockLabels) 18 else 0)).dp
    val height = cellHDp * HomeConfig.dockRows + 16.dp
    val pageCount = maxOf(1, state.dock.size)
    val pagerState = rememberPagerState { pageCount }
    LaunchedEffect(pagerState) { snapshotFlow { pagerState.currentPage }.collect { state.dockPage = it } }
    val look = if (LocalLook.current == "flat") {
        Modifier.background(Color(0xFF17181A), shape)
    } else {
        Modifier.background(Color(0x38FFFFFF), shape).border(1.dp, Color(0x2EFFFFFF), shape)
    }

    Box(modifier.height(height).then(look)) {
        HorizontalPager(pagerState, Modifier.fillMaxSize(), userScrollEnabled = pageCount > 1) { index ->
            val page = state.dock.getOrNull(index)
            if (page != null) DockPage(state, page, index, apps, onTap, onMenu, cellHDp)
        }
        if (state.dock.all { it.items.isEmpty() }) {
            Text(
                "Long-press an app, then choose Move to dock",
                color = Color(0xCCFFFFFF), fontSize = 13.sp,
                modifier = Modifier.align(Alignment.Center),
            )
        }
        if (pageCount > 1) {
            Row(
                Modifier.align(Alignment.BottomCenter).padding(bottom = 3.dp),
                horizontalArrangement = Arrangement.spacedBy(5.dp),
            ) {
                repeat(pageCount) { i ->
                    Box(
                        Modifier.size(5.dp).clip(CircleShape)
                            .background(if (i == pagerState.currentPage) Color.White else Color(0x66FFFFFF)),
                    )
                }
            }
        }
    }
}

@Composable
private fun DockPage(
    state: EonState,
    page: PageData,
    pageIndex: Int,
    apps: List<AppEntry>,
    onTap: (AppEntry) -> Unit,
    onMenu: (AppEntry) -> Unit,
    cellHDp: Dp,
) {
    val density = LocalDensity.current
    val haptic = LocalHapticFeedback.current
    var dragKey by remember { mutableStateOf<String?>(null) }
    var dragPos by remember { mutableStateOf(Offset.Zero) }
    var targetCol by remember { mutableIntStateOf(0) }
    var targetRow by remember { mutableIntStateOf(0) }
    val latestApps by rememberUpdatedState(apps)
    val latestTap by rememberUpdatedState(onTap)
    val latestMenu by rememberUpdatedState(onMenu)

    BoxWithConstraints(Modifier.fillMaxSize().padding(horizontal = 8.dp, vertical = 8.dp)) {
        val cols = HomeConfig.dockCols
        val rows = HomeConfig.dockRows
        val cellW = constraints.maxWidth.toFloat() / cols
        val cellH = with(density) { cellHDp.toPx() }
        val cellWDp = with(density) { cellW.toDp() }

        if (dragKey != null) {
            val shape = RoundedCornerShape(18.dp)
            Box(
                Modifier
                    .offset { IntOffset((targetCol * cellW).roundToInt(), (targetRow * cellH).roundToInt()) }
                    .size(DpSize(cellWDp, cellHDp))
                    .padding(3.dp)
                    .clip(shape)
                    .background(Color(0x22FFFFFF))
                    .border(1.dp, Color(0x66FFFFFF), shape),
            )
        }

        page.items.toList().forEach { item ->
            key(item.key) {
                val app = apps.firstOrNull { it.key == item.key }
                if (app != null) {
                    val isDragged = dragKey == item.key
                    val slot = Offset(item.col * cellW, item.row * cellH)
                    val glide = remember { Animatable(slot, Offset.VectorConverter) }
                    var wasDragged by remember { mutableStateOf(false) }
                    LaunchedEffect(isDragged, slot) {
                        if (isDragged) {
                            wasDragged = true
                        } else {
                            if (wasDragged) {
                                glide.snapTo(dragPos)
                                wasDragged = false
                            }
                            glide.animateTo(slot, spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMedium))
                        }
                    }
                    val lift by animateFloatAsState(
                        if (isDragged) 1.12f else 1f,
                        spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMedium), label = "lift",
                    )
                    val pos = if (isDragged) dragPos else glide.value
                    Box(
                        Modifier
                            .offset { IntOffset(pos.x.roundToInt(), pos.y.roundToInt()) }
                            .size(DpSize(cellWDp, cellHDp))
                            .zIndex(if (isDragged) 10f else 0f)
                            .homeIntro(0.85f + 0.15f * (item.col / cols.toFloat()), 0f, dock = true)
                            .graphicsLayer {
                                scaleX = lift
                                scaleY = lift
                            }
                            .pointerInput(item.key) {
                                awaitEachGesture {
                                    val down = awaitFirstDown(requireUnconsumed = false)
                                    down.consume()
                                    val press = awaitLongPressOrCancellation(down.id)
                                    if (press == null) {
                                        val ev = currentEvent.changes.firstOrNull { it.id == down.id }
                                        if (ev != null && !ev.pressed &&
                                            (ev.position - down.position).getDistance() < viewConfiguration.touchSlop * 2
                                        ) {
                                            latestApps.firstOrNull { it.key == item.key }?.let { latestTap(it) }
                                        }
                                        return@awaitEachGesture
                                    }
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    dragKey = item.key
                                    dragPos = Offset(item.col * cellW, item.row * cellH)
                                    targetCol = item.col.roundToInt()
                                    targetRow = item.row.roundToInt()
                                    var travelled = 0f
                                    drag(down.id) { change ->
                                        val d = change.positionChange()
                                        travelled += d.getDistance()
                                        dragPos += d
                                        change.consume()
                                        val nc = ((dragPos.x + cellW / 2f) / cellW).toInt().coerceIn(0, cols - 1)
                                        val nr = ((dragPos.y + cellH / 2f) / cellH).toInt().coerceIn(0, rows - 1)
                                        if (nc != targetCol || nr != targetRow) {
                                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        }
                                        targetCol = nc
                                        targetRow = nr
                                    }
                                    val tc = targetCol
                                    val tr = targetRow
                                    dragKey = null
                                    if (travelled > viewConfiguration.touchSlop * 2) {
                                        if (tc.toFloat() != item.col || tr.toFloat() != item.row) {
                                            state.moveDockApp(pageIndex, item.key, tc, tr)
                                        }
                                    } else {
                                        latestApps.firstOrNull { it.key == item.key }?.let { latestMenu(it) }
                                    }
                                }
                            },
                        contentAlignment = Alignment.Center,
                    ) {
                        AppIconBody(app, HomeConfig.dockIconDp.dp, HomeConfig.dockLabels, 11f, false)
                    }
                }
            }
        }
    }
}
