package ix.app.eon

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowDownward
import androidx.compose.material.icons.outlined.ArrowUpward
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import kotlin.math.exp
import kotlin.math.max

private const val DAY = 24L * 60L * 60L * 1000L

/**
 * What you open, kept on the phone and never sent anywhere: a list of "this app, at this time" (the last 1000).
 * The suggestions, the stats and the "most used" sorting all come from it.
 */
object Usage {
    private class Entry(val key: String, val at: Long)

    private val log = ArrayList<Entry>()
    private var prefs: Prefs? = null

    /** Goes up on every launch, so anything showing numbers from here updates. */
    var tick by mutableIntStateOf(0)
        private set

    /** When Eon started keeping the list. */
    var since = 0L
        private set

    fun init(p: Prefs) {
        prefs = p
        log.clear()
        try {
            val arr = JSONArray(p.getString("usageLog").ifEmpty { "[]" })
            for (i in 0 until arr.length()) {
                val o = arr.getJSONArray(i)
                log.add(Entry(o.getString(0), o.getLong(1)))
            }
        } catch (_: Exception) {
        }
        since = p.getString("usageSince").toLongOrNull() ?: 0L
        if (since == 0L) {
            since = System.currentTimeMillis()
            p.putString("usageSince", since.toString())
        }
    }

    fun record(key: String) {
        log.add(Entry(key, System.currentTimeMillis()))
        while (log.size > 1000) log.removeAt(0)
        save()
        tick++
    }

    fun clear() {
        log.clear()
        since = System.currentTimeMillis()
        prefs?.putString("usageSince", since.toString())
        save()
        tick++
    }

    private fun save() {
        val arr = JSONArray()
        log.forEach { arr.put(JSONArray().put(it.key).put(it.at)) }
        prefs?.putString("usageLog", arr.toString())
    }

    /** How many days Eon has been keeping the list. */
    fun spanDays(): Int {
        tick
        return ((System.currentTimeMillis() - since) / DAY).toInt()
    }

    fun count(key: String, days: Int = 30): Int {
        tick
        val from = System.currentTimeMillis() - days * DAY
        return log.count { it.key == key && it.at >= from }
    }

    fun last(key: String): Long {
        tick
        return log.lastOrNull { it.key == key }?.at ?: 0L
    }

    fun total(days: Int): Int {
        tick
        val from = System.currentTimeMillis() - days * DAY
        return log.count { it.at >= from }
    }

    /** Opens per day for the last [days] days, oldest first, with the first day's start for the labels. */
    fun perDay(days: Int): IntArray {
        tick
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val firstDay = cal.timeInMillis - (days - 1) * DAY
        val out = IntArray(days)
        log.forEach {
            if (it.at >= firstDay) out[((it.at - firstDay) / DAY).toInt().coerceIn(0, days - 1)]++
        }
        return out
    }

    /** The app opened most in the last [days] days, with how many times. */
    fun top(days: Int, apps: List<AppEntry>): Pair<AppEntry, Int>? {
        tick
        val from = System.currentTimeMillis() - days * DAY
        val counts = HashMap<String, Int>()
        log.forEach { if (it.at >= from) counts[it.key] = (counts[it.key] ?: 0) + 1 }
        return apps.mapNotNull { a -> counts[a.key]?.let { a to it } }.maxByOrNull { it.second }
    }

    /**
     * Apps you tend to open around now. Each launch in the last 30 days counts, more when it was at about this time
     * of day and more when it was recent.
     */
    fun suggestions(apps: List<AppEntry>, n: Int): List<AppEntry> {
        tick
        val now = System.currentTimeMillis()
        val cal = Calendar.getInstance()
        val nowBucket = cal.get(Calendar.HOUR_OF_DAY) / 3
        val scores = HashMap<String, Double>()
        val c = Calendar.getInstance()
        log.forEach { e ->
            val ageDays = (now - e.at) / DAY.toDouble()
            if (ageDays <= 30.0) {
                c.timeInMillis = e.at
                val b = c.get(Calendar.HOUR_OF_DAY) / 3
                val dist = minOf((b - nowBucket + 8) % 8, (nowBucket - b + 8) % 8)
                val w = when (dist) {
                    0 -> 1.0
                    1 -> 0.5
                    else -> 0.1
                }
                scores[e.key] = (scores[e.key] ?: 0.0) + w * exp(-ageDays / 14.0)
            }
        }
        return apps.filter { (scores[it.key] ?: 0.0) > 0.3 }.sortedByDescending { scores[it.key] ?: 0.0 }.take(n)
    }

    /** Apps installed a while ago that were not opened through Eon for [days] days. */
    fun unused(apps: List<AppEntry>, days: Int, n: Int): List<AppEntry> {
        tick
        val now = System.currentTimeMillis()
        return apps.filter { a ->
            a.firstInstall in 1 until (now - 14 * DAY) && now - last(a.key).coerceAtLeast(since) > days * DAY
        }.sortedBy { a -> last(a.key) }.take(n)
    }
}

/** The insight cards you can have above the boxes. */
val INSIGHT_CARDS = listOf(
    "suggested" to "Suggested for you",
    "stats" to "Your stats",
    "recent" to "Recently added",
    "unused" to "Not opened lately",
    "notifs" to "Waiting for you",
)

/** How to sort the apps inside a box. */
val BOX_SORTS = listOf(
    "auto" to "Default", "az" to "A to Z", "used" to "Most used", "recent" to "Recently used",
    "new" to "Newest", "custom" to "My order",
)

/** What you chose for the App Library: insight cards, how each box sorts, the order you gave the apps. */
object LibraryConfig {
    var showInsights by mutableStateOf(true)
    var smartBoxes by mutableStateOf(false)

    /** The cards in order, and whether each shows. */
    val cards = mutableStateListOf<Pair<String, Boolean>>()
    val sorts = mutableStateMapOf<String, String>()
    val orders = mutableStateMapOf<String, List<String>>()
    private var prefs: Prefs? = null

    fun load(p: Prefs) {
        prefs = p
        cards.clear()
        sorts.clear()
        orders.clear()
        try {
            val o = JSONObject(p.getString("libCfg").ifEmpty { "{}" })
            showInsights = o.optBoolean("insights", true)
            smartBoxes = o.optBoolean("smart", false)
            o.optJSONArray("cards")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val c = arr.getJSONObject(i)
                    if (INSIGHT_CARDS.any { it.first == c.getString("id") }) cards.add(c.getString("id") to c.optBoolean("on", true))
                }
            }
            o.optJSONObject("sorts")?.let { s -> s.keys().forEach { k -> sorts[k] = s.getString(k) } }
            o.optJSONObject("orders")?.let { s ->
                s.keys().forEach { k ->
                    val a = s.getJSONArray(k)
                    orders[k] = (0 until a.length()).map { a.getString(it) }
                }
            }
        } catch (_: Exception) {
        }
        INSIGHT_CARDS.forEach { (id, _) -> if (cards.none { it.first == id }) cards.add(id to true) }
    }

    private fun save() {
        val o = JSONObject().put("insights", showInsights).put("smart", smartBoxes)
        val arr = JSONArray()
        cards.forEach { arr.put(JSONObject().put("id", it.first).put("on", it.second)) }
        o.put("cards", arr)
        val s = JSONObject()
        sorts.forEach { (k, v) -> s.put(k, v) }
        o.put("sorts", s)
        val ord = JSONObject()
        orders.forEach { (k, v) -> ord.put(k, JSONArray(v)) }
        o.put("orders", ord)
        prefs?.putString("libCfg", o.toString())
    }

    fun chooseInsights(on: Boolean) { showInsights = on; save() }
    fun chooseSmartBoxes(on: Boolean) { smartBoxes = on; save() }

    fun cardOn(id: String): Boolean = cards.firstOrNull { it.first == id }?.second ?: false

    fun setCard(id: String, on: Boolean) {
        val i = cards.indexOfFirst { it.first == id }
        if (i >= 0) cards[i] = id to on
        save()
    }

    fun moveCard(id: String, delta: Int) {
        val i = cards.indexOfFirst { it.first == id }
        val j = i + delta
        if (i < 0 || j !in cards.indices) return
        val c = cards.removeAt(i)
        cards.add(j, c)
        save()
    }

    fun sortOf(box: String): String = sorts[box] ?: "auto"

    fun setSort(box: String, mode: String) {
        sorts[box] = mode
        save()
    }

    /** Applies the box's sort to [apps], which come in the drawer's own order. */
    fun sorted(box: String, apps: List<AppEntry>): List<AppEntry> = when (sortOf(box)) {
        "az" -> apps.sortedBy { it.label.lowercase() }
        "used" -> apps.sortedWith(compareByDescending<AppEntry> { Usage.count(it.key, 30) }.thenBy { it.label.lowercase() })
        "recent" -> apps.sortedByDescending { Usage.last(it.key) }
        "new" -> apps.sortedByDescending { it.firstInstall }
        "custom" -> {
            val order = orders[box] ?: emptyList()
            apps.withIndex().sortedBy { (i, a) ->
                val at = order.indexOf(a.key)
                if (at >= 0) at else order.size + i
            }.map { it.value }
        }
        else -> apps
    }

    /** Moves one app one step earlier or later in a box and switches the box to "My order". */
    fun moveApp(box: String, shownKeys: List<String>, key: String, delta: Int) {
        val i = shownKeys.indexOf(key)
        val j = i + delta
        if (i < 0 || j !in shownKeys.indices) return
        val list = shownKeys.toMutableList()
        list.removeAt(i)
        list.add(j, key)
        orders[box] = list
        sorts[box] = "custom"
        save()
    }

    fun forgetBox(box: String) {
        sorts.remove(box)
        orders.remove(box)
        save()
    }
}

/** The cards above the boxes. Hidden ones and the whole panel can be turned off in [LibraryCustomizeDialog]. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun InsightsPanel(
    apps: List<AppEntry>, onLaunch: (AppEntry) -> Unit, onMenu: (AppEntry) -> Unit, onHideApp: (AppEntry) -> Unit,
) {
    if (!LibraryConfig.showInsights) return
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        LibraryConfig.cards.toList().forEach { (id, on) ->
            if (!on) return@forEach
            when (id) {
                "suggested" -> {
                    val list = Usage.suggestions(apps, 5)
                    InsightCard("Suggested for you", if (list.isEmpty()) null else "Around this time you often open", id) {
                        if (list.isEmpty()) {
                            Text(
                                "Open a few apps and Eon will start suggesting the ones you use at this time of day.",
                                color = Eon.Muted, fontSize = 13.sp, lineHeight = 18.sp,
                            )
                        } else {
                            AppsRow(list, onLaunch, onMenu)
                        }
                    }
                }
                "stats" -> InsightCard("Your stats", "Kept on this phone only", id) { StatsBody(apps) }
                "recent" -> {
                    val list = apps.filter { it.firstInstall > 0 }.sortedByDescending { it.firstInstall }.take(5)
                    if (list.isNotEmpty()) InsightCard("Recently added", null, id) { AppsRow(list, onLaunch, onMenu) }
                }
                "unused" -> {
                    val list = Usage.unused(apps, 30, 4)
                    if (list.isNotEmpty() && Usage.spanDays() >= 7) {
                        InsightCard("Not opened lately", "Not opened here in a month. Hide to tidy up.", id) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                list.forEach { app ->
                                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                        Image(bitmap = app.icon, contentDescription = null, modifier = Modifier.size(44.dp))
                                        Text(
                                            app.label, color = Eon.Soft, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.padding(top = 4.dp),
                                        )
                                        Text(
                                            "Hide", color = Eon.Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                                            modifier = Modifier.clip(CircleShape).clickable { onHideApp(app) }
                                                .padding(horizontal = 10.dp, vertical = 4.dp),
                                        )
                                    }
                                }
                                repeat(4 - list.size) { Spacer(Modifier.weight(1f)) }
                            }
                        }
                    }
                }
                "notifs" -> {
                    val list = apps.filter { (Badges.counts[it.packageName] ?: 0) > 0 }
                        .sortedByDescending { Badges.counts[it.packageName] ?: 0 }.take(5)
                    if (list.isNotEmpty()) {
                        InsightCard("Waiting for you", "Apps with something new", id) { AppsRow(list, onLaunch, onMenu) }
                    }
                }
            }
        }
    }
}

@Composable
private fun InsightCard(title: String, subtitle: String?, id: String, content: @Composable () -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Column(
        Modifier.fillMaxWidth().clip(shape).background(Color(0x26FFFFFF)).border(1.dp, Color(0x1AFFFFFF), shape).padding(16.dp),
    ) {
        Row(verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                if (subtitle != null) Text(subtitle, color = Eon.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
            }
            Text(
                "Hide", color = Eon.Faint, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clip(CircleShape).clickable { LibraryConfig.setCard(id, false) }
                    .padding(horizontal = 8.dp, vertical = 4.dp),
            )
        }
        Spacer(Modifier.height(12.dp))
        content()
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppsRow(list: List<AppEntry>, onLaunch: (AppEntry) -> Unit, onMenu: (AppEntry) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        list.forEach { app ->
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(14.dp))
                    .combinedClickable(onClick = { onLaunch(app) }, onLongClick = { onMenu(app) })
                    .padding(vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Image(bitmap = app.icon, contentDescription = app.label, modifier = Modifier.size(48.dp))
                Text(
                    app.label, color = Eon.Soft, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center, modifier = Modifier.padding(top = 4.dp),
                )
            }
        }
        repeat(5 - list.size) { Spacer(Modifier.weight(1f)) }
    }
}

@Composable
private fun StatsBody(apps: List<AppEntry>) {
    val week = Usage.total(7)
    val top = Usage.top(30, apps)
    val days = Usage.perDay(7)
    val biggest = max(1, days.maxOrNull() ?: 1)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        StatBlock("${apps.size}", "apps", Modifier.weight(1f))
        StatBlock("$week", "opens this week", Modifier.weight(1f))
        StatBlock(top?.first?.label ?: "none yet", "most opened", Modifier.weight(1f))
    }
    Spacer(Modifier.height(14.dp))
    val cal = Calendar.getInstance()
    val letters = "SMTWTFS"
    Row(Modifier.fillMaxWidth().height(70.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.Bottom) {
        days.forEachIndexed { i, n ->
            cal.timeInMillis = System.currentTimeMillis() - (6 - i) * DAY
            val letter = letters[cal.get(Calendar.DAY_OF_WEEK) - 1]
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.BottomCenter) {
                    Box(
                        Modifier.fillMaxWidth(0.55f).height((6 + 40 * n / biggest.toFloat()).dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (n > 0) Eon.Button else androidx.compose.ui.graphics.SolidColor(Color(0x22FFFFFF))),
                    )
                }
                Text(letter.toString(), color = Eon.Faint, fontSize = 10.sp, modifier = Modifier.padding(top = 4.dp))
            }
        }
    }
}

@Composable
private fun StatBlock(value: String, label: String, modifier: Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(16.dp)).background(Color(0x1AFFFFFF)).padding(vertical = 10.dp, horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(value, color = Eon.Text, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(label, color = Eon.Muted, fontSize = 11.sp, maxLines = 1, textAlign = TextAlign.Center)
    }
}

/** Settings for the App Library: which insight cards show and in what order, smart box order, tidy up and reset. */
@Composable
fun LibraryCustomizeDialog(onOrganize: () -> Int, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier.fillMaxWidth().glass(RoundedCornerShape(28.dp)).padding(18.dp),
        ) {
            Text("Customize Library", color = Eon.Text, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(14.dp))
            SwitchLine("Insights", "Cards above your boxes", LibraryConfig.showInsights) { LibraryConfig.chooseInsights(it) }
            if (LibraryConfig.showInsights) {
                LibraryConfig.cards.toList().forEachIndexed { i, (id, on) ->
                    val name = INSIGHT_CARDS.firstOrNull { it.first == id }?.second ?: id
                    Row(
                        Modifier.fillMaxWidth().padding(start = 8.dp, top = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(name, color = if (on) Eon.Text else Eon.Faint, fontSize = 14.sp, modifier = Modifier.weight(1f))
                        MiniArrow(Icons.Outlined.ArrowUpward, i > 0) { LibraryConfig.moveCard(id, -1) }
                        MiniArrow(Icons.Outlined.ArrowDownward, i < LibraryConfig.cards.size - 1) { LibraryConfig.moveCard(id, 1) }
                        Spacer(Modifier.width(8.dp))
                        EonSwitch(on) { LibraryConfig.setCard(id, it) }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            SwitchLine("Smart box order", "Boxes you open most come first", LibraryConfig.smartBoxes) { LibraryConfig.chooseSmartBoxes(it) }
            Spacer(Modifier.height(10.dp))
            var note by remember { mutableStateOf("") }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DialogChip("Organize boxes", Modifier.weight(1f)) {
                    val n = onOrganize()
                    note = if (n == 0) "Everything fits your boxes already." else "Added $n new box" + (if (n == 1) "." else "es.")
                }
                DialogChip("Clear my usage", Modifier.weight(1f)) {
                    Usage.clear()
                    note = "Usage cleared."
                }
            }
            if (note.isNotEmpty()) Text(note, color = Eon.Accent, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp, start = 4.dp))
            Spacer(Modifier.height(14.dp))
            Box(Modifier.align(Alignment.End).clip(CircleShape).background(Eon.Button).clickable(onClick = onDismiss).padding(horizontal = 24.dp, vertical = 10.dp)) {
                Text("Done", color = Eon.OnAccent, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun SwitchLine(title: String, sub: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Eon.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text(sub, color = Eon.Muted, fontSize = 12.sp)
        }
        EonSwitch(on, onChange)
    }
}

@Composable
private fun MiniArrow(icon: androidx.compose.ui.graphics.vector.ImageVector, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(32.dp).clip(CircleShape).then(if (enabled) Modifier.clickable(onClick = onClick) else Modifier),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, null, tint = if (enabled) Eon.Soft else Color(0xFF3A3A3E), modifier = Modifier.size(18.dp)) }
}

@Composable
private fun DialogChip(label: String, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.clip(RoundedCornerShape(14.dp)).background(Color(0x22FFFFFF)).clickable(onClick = onClick).padding(vertical = 12.dp),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = Eon.Soft, fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
}
