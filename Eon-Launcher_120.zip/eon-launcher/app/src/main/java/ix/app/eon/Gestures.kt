package ix.app.eon

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

/** What the double tap and the swipes on empty space on the home screen do. Swipe up opens the drawer unless you change it. */
object GestureConfig {
    var doubleTap by mutableStateOf(Act.NONE)
    var swipeDown by mutableStateOf(Act.NOTIF)
    var swipeUp by mutableStateOf(Act.DRAWER)
    var twoUp by mutableStateOf(Act.NONE)
    var twoDown by mutableStateOf(Act.NONE)
    var shake by mutableStateOf(Act.NONE)
    var knock by mutableStateOf(Act.NONE)

    private fun read(p: Prefs, key: String, legacyKey: String, legacyDef: Int): String {
        val s = p.getString(key)
        return if (s.isNotEmpty()) s else Act.fromLegacy(p.getInt(legacyKey, legacyDef))
    }

    fun load(p: Prefs) {
        doubleTap = read(p, "gestureDoubleS", "gestureDouble", 0)
        swipeDown = read(p, "gestureDownS", "gestureDown", 4)
        swipeUp = p.getString("gestureUpS").ifEmpty { Act.DRAWER }
        twoUp = p.getString("gestureTwoUpS").ifEmpty { Act.NONE }
        twoDown = p.getString("gestureTwoDownS").ifEmpty { Act.NONE }
        shake = p.getString("gestureShakeS").ifEmpty { Act.NONE }
        knock = p.getString("gestureKnockS").ifEmpty { Act.NONE }
    }

    fun save(p: Prefs) {
        p.putString("gestureDoubleS", doubleTap)
        p.putString("gestureDownS", swipeDown)
        p.putString("gestureUpS", swipeUp)
        p.putString("gestureTwoUpS", twoUp)
        p.putString("gestureTwoDownS", twoDown)
        p.putString("gestureShakeS", shake)
        p.putString("gestureKnockS", knock)
    }
}

/** What a drawer's list says about itself, so a pull at its edge can close the drawer. */
class ListEdges {
    /** The list cannot scroll up any further (it is at its top, or too short to scroll). */
    var atTop = true

    /** The list cannot scroll down any further (it is at its end, or too short to scroll). */
    var atBottom = true
}

/** How far a drawer has been pulled from its place while you pull it closed: positive is down, negative is up. */
class EdgePull {
    var offset by mutableFloatStateOf(0f)
}

/** The drawer moves this much of the way your finger moves, so it feels a little heavy, like a page being turned. */
private const val EDGE_FOLLOW = 0.7f

/**
 * Pull past the edge of a drawer's list and the drawer comes with your finger, like turning a page but up and down:
 *  - Pull down once the list is at its top (Settings > Drawer > Pull down at the top goes home);
 *  - Pull up once the list is at its end (Settings > Drawer > Swipe up goes home).
 * Let go and it decides by how far you took it and how fast you were going: far enough, or a quick flick, and it
 * carries on out at the speed you left it. Otherwise it springs back. Catch it in the middle and you are holding it
 * again, so you can pull it back. A light pull moves nothing at all.
 *
 * Put this before the [graphicsLayer] that moves the drawer by [pull], so the finger is measured against the screen
 * and not against a drawer that is moving with it. It watches the finger before the list does, so the list's own
 * stretch effect cannot hide the pull, and it takes the finger over once the drawer is moving.
 */
fun Modifier.pullToClose(
    pull: EdgePull, enabled: () -> Boolean, atTop: () -> Boolean, atBottom: () -> Boolean, onClose: () -> Unit,
    follow: Float = EDGE_FOLLOW, slopDp: Float = 12f, closeFrac: Float = 0.2f, flickV: Float = 1500f,
): Modifier = this.pointerInput(Unit) {
    val slop = slopDp.dp.toPx()
    val minFlick = 16.dp.toPx()
    kotlinx.coroutines.coroutineScope {
        var settle: kotlinx.coroutines.Job? = null
        awaitEachGesture {
            val first = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
            settle?.cancel()
            settle = null
            val tracker = VelocityTracker()
            tracker.addPosition(first.uptimeMillis, first.position)
            var dir = 0 // 1: pulling it down, -1: pulling it up, 0: not pulling yet
            var raw = 0f // how far the finger has gone in that direction, slop included
            var down = 0f
            var up = 0f
            if (pull.offset != 0f) {
                // Caught in the middle of a settle: carry on from where it is.
                dir = if (pull.offset > 0f) 1 else -1
                raw = kotlin.math.abs(pull.offset) / follow + slop
            }
            while (true) {
                val event = awaitPointerEvent(PointerEventPass.Initial)
                val change = event.changes[0]
                tracker.addPosition(change.uptimeMillis, change.position)
                if (event.changes.all { !it.pressed }) break
                if (event.changes.size != 1) continue
                val d = change.positionChange()
                if (dir != 0) {
                    raw = kotlin.math.max(0f, raw + dir * d.y)
                    pull.offset = dir * kotlin.math.max(0f, raw - slop) * follow
                    change.consume()
                } else if (kotlin.math.abs(d.y) > kotlin.math.abs(d.x)) {
                    val on = enabled()
                    val canDown = on && DrawerConfig.pullDownHome && atTop()
                    val canUp = on && DrawerConfig.swipeUpHome && atBottom()
                    down = if (canDown) kotlin.math.max(0f, down + d.y) else 0f
                    up = if (canUp) kotlin.math.max(0f, up - d.y) else 0f
                    if (down > slop) {
                        dir = 1
                        raw = down
                    } else if (up > slop) {
                        dir = -1
                        raw = up
                    }
                    if (dir != 0) {
                        pull.offset = dir * kotlin.math.max(0f, raw - slop) * follow
                        change.consume()
                    }
                }
            }
            if (dir != 0) {
                val height = size.height.toFloat()
                val vy = tracker.calculateVelocity().y
                val off = kotlin.math.abs(pull.offset)
                val goes = off > height * closeFrac || (vy * dir > flickV && off > minFlick)
                val from = pull.offset
                settle = if (goes) {
                    // Closed from this moment, so the home screen is already on its way back while this goes out.
                    onClose()
                    launch {
                        androidx.compose.animation.core.animate(
                            from, dir * height, vy * follow, androidx.compose.animation.core.spring(1f, 1200f),
                        ) { v, _ -> pull.offset = v }
                    }
                } else {
                    launch {
                        androidx.compose.animation.core.animate(
                            from, 0f, vy * follow, androidx.compose.animation.core.spring(1f, 600f),
                        ) { v, _ -> pull.offset = v }
                    }
                }
            }
        }
    }
}

/** Needed so Eon can lock the screen. Android asks the user to turn it on the first time. */
class EonAdminReceiver : DeviceAdminReceiver()

/** Locks the screen. The first time, opens Android's screen to make Eon a device administrator. */
fun lockScreen(ctx: Context) {
    try {
        val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val admin = ComponentName(ctx, EonAdminReceiver::class.java)
        if (dpm.isAdminActive(admin)) {
            dpm.lockNow()
        } else {
            ctx.startActivity(
                Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
                    .putExtra(
                        DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                        "Eon only uses this to lock the screen when you use the lock gesture.",
                    )
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
        }
    } catch (_: Exception) {
    }
}
