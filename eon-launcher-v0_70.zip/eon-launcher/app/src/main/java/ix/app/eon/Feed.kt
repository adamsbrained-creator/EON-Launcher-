package ix.app.eon

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.text.Html
import android.util.LruCache
import android.util.Xml
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Locale

/** One story in the feed. [time] is when it was published, in milliseconds, or 0 when the source does not say. */
data class Article(val title: String, val link: String, val source: String, val time: Long, val image: String, val topic: String = "")

class FeedSource(val id: String, val name: String, val group: String, val url: String)

private const val GN = "?hl=en-US&gl=US&ceid=US:en"

/** Sources Eon knows. Any other RSS or Atom address can be added by hand. */
val FEED_SOURCES = listOf(
    FeedSource("bbc-top", "BBC News", "News", "https://feeds.bbci.co.uk/news/rss.xml"),
    FeedSource("bbc-world", "BBC World", "News", "https://feeds.bbci.co.uk/news/world/rss.xml"),
    FeedSource("bbc-tech", "BBC Technology", "Technology", "https://feeds.bbci.co.uk/news/technology/rss.xml"),
    FeedSource("bbc-sci", "BBC Science", "Science", "https://feeds.bbci.co.uk/news/science_and_environment/rss.xml"),
    FeedSource("bbc-biz", "BBC Business", "Business", "https://feeds.bbci.co.uk/news/business/rss.xml"),
    FeedSource("bbc-sport", "BBC Sport", "Sport", "https://feeds.bbci.co.uk/sport/rss.xml"),
    FeedSource("gu-world", "The Guardian · World", "News", "https://www.theguardian.com/world/rss"),
    FeedSource("gu-tech", "The Guardian · Technology", "Technology", "https://www.theguardian.com/technology/rss"),
    FeedSource("gu-sport", "The Guardian · Sport", "Sport", "https://www.theguardian.com/sport/rss"),
    FeedSource("gu-sci", "The Guardian · Science", "Science", "https://www.theguardian.com/science/rss"),
    FeedSource("gu-cult", "The Guardian · Culture", "Entertainment", "https://www.theguardian.com/culture/rss"),
    FeedSource("npr", "NPR", "News", "https://feeds.npr.org/1001/rss.xml"),
    FeedSource("ars", "Ars Technica", "Technology", "https://feeds.arstechnica.com/arstechnica/index"),
    FeedSource("hn", "Hacker News", "Technology", "https://hnrss.org/frontpage"),
    FeedSource("gn-top", "Google News · Top stories", "Google News", "https://news.google.com/rss$GN"),
    FeedSource("gn-world", "Google News · World", "Google News", "https://news.google.com/rss/headlines/section/topic/WORLD$GN"),
    FeedSource("gn-biz", "Google News · Business", "Google News", "https://news.google.com/rss/headlines/section/topic/BUSINESS$GN"),
    FeedSource("gn-tech", "Google News · Technology", "Google News", "https://news.google.com/rss/headlines/section/topic/TECHNOLOGY$GN"),
    FeedSource("gn-ent", "Google News · Entertainment", "Google News", "https://news.google.com/rss/headlines/section/topic/ENTERTAINMENT$GN"),
    FeedSource("gn-sport", "Google News · Sports", "Google News", "https://news.google.com/rss/headlines/section/topic/SPORTS$GN"),
    FeedSource("gn-sci", "Google News · Science", "Google News", "https://news.google.com/rss/headlines/section/topic/SCIENCE$GN"),
    FeedSource("gn-health", "Google News · Health", "Google News", "https://news.google.com/rss/headlines/section/topic/HEALTH$GN"),
)

/** What the feed shows and whether swiping right from the first page opens it. */
object FeedConfig {
    var enabled by mutableStateOf(true)
    var selected by mutableStateOf(setOf("bbc-top", "gu-world", "bbc-tech"))
    var custom by mutableStateOf(listOf<String>())

    /** Words you want stories about (football, the Beatles). Each one is searched for in the news. */
    var topics by mutableStateOf(listOf<String>())

    fun load(p: Prefs) {
        topics = p.getString("feedTopics").split("\n").filter { it.isNotBlank() }
        enabled = p.getBool("feedOn", true)
        val sel = p.getString("feedSel")
        if (sel.isNotEmpty()) selected = sel.split("\n").filter { it.isNotBlank() }.toSet()
        custom = p.getString("feedCustom").split("\n").filter { it.isNotBlank() }
    }

    private fun save(ctx: Context) {
        val p = Prefs(ctx)
        p.putBool("feedOn", enabled)
        p.putString("feedSel", selected.joinToString("\n"))
        p.putString("feedCustom", custom.joinToString("\n"))
        p.putString("feedTopics", topics.joinToString("\n"))
    }

    fun addTopic(ctx: Context, word: String): Boolean {
        val w = word.trim().take(40)
        if (w.isEmpty()) return false
        if (topics.none { it.equals(w, true) }) topics = topics + w
        save(ctx)
        FeedStore.stale()
        return true
    }

    fun removeTopic(ctx: Context, word: String) {
        topics = topics - word
        save(ctx)
        FeedStore.stale()
    }

    fun setEnabled(ctx: Context, on: Boolean) { enabled = on; save(ctx) }

    fun toggle(ctx: Context, id: String) {
        selected = if (id in selected) selected - id else selected + id
        save(ctx)
        FeedStore.stale()
    }

    fun addCustom(ctx: Context, address: String): Boolean {
        var a = address.trim()
        if (a.isEmpty()) return false
        if (!a.startsWith("http")) a = "https://$a"
        if (a in custom) return true
        custom = custom + a
        selected = selected + "c:$a"
        save(ctx)
        FeedStore.stale()
        return true
    }

    fun removeCustom(ctx: Context, address: String) {
        custom = custom - address
        selected = selected - "c:$address"
        save(ctx)
        FeedStore.stale()
    }

    /** One thing to fetch: where, what to call the source (null = the feed's own title), the topic word if any, and a second address to try. */
    class Fetch(val url: String, val name: String?, val topic: String = "", val backup: String? = null)

    /** Everything to read: the sources you picked, your own addresses, and a news search for each topic word. */
    fun active(): List<Fetch> {
        val out = mutableListOf<Fetch>()
        FEED_SOURCES.filter { it.id in selected }.forEach {
            out.add(Fetch(it.url, if (it.group == "Google News") null else it.name.substringBefore(" \u00b7 ")))
        }
        custom.filter { "c:$it" in selected }.forEach { out.add(Fetch(it, null)) }
        topics.forEach { t ->
            val q = URLEncoder.encode(t, "UTF-8")
            out.add(
                Fetch(
                    "https://www.bing.com/news/search?q=$q&format=rss&setlang=en-US", null, t,
                    "https://news.google.com/rss/search?q=$q+when:7d&hl=en-US&gl=US&ceid=US:en",
                ),
            )
        }
        return out
    }
}

private fun open(url: String): HttpURLConnection {
    val c = URL(url).openConnection() as HttpURLConnection
    c.connectTimeout = 8000
    c.readTimeout = 10000
    c.instanceFollowRedirects = true
    c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) Eon")
    c.setRequestProperty("Accept", "application/rss+xml, application/atom+xml, application/xml, text/xml, text/html, */*")
    return c
}

private val IMG_TAG = Regex("<img[^>]+src=[\"']([^\"']+)[\"']", RegexOption.IGNORE_CASE)
private val OG_IMAGE = Regex("<meta[^>]+property=[\"']og:image[\"'][^>]+content=[\"']([^\"']+)[\"']|<meta[^>]+content=[\"']([^\"']+)[\"'][^>]+property=[\"']og:image[\"']", RegexOption.IGNORE_CASE)
private val DATE_FORMATS = listOf(
    "EEE, dd MMM yyyy HH:mm:ss Z", "EEE, dd MMM yyyy HH:mm:ss zzz", "EEE, d MMM yyyy HH:mm:ss Z",
    "yyyy-MM-dd'T'HH:mm:ssXXX", "yyyy-MM-dd'T'HH:mm:ss'Z'", "yyyy-MM-dd'T'HH:mm:ss.SSSXXX",
)

private fun parseDate(s: String): Long {
    val t = s.trim()
    if (t.isEmpty()) return 0L
    for (f in DATE_FORMATS) {
        try {
            val d = SimpleDateFormat(f, Locale.US).parse(t)
            if (d != null) return d.time
        } catch (_: Exception) {
        }
    }
    return 0L
}

private fun plain(s: String): String = Html.fromHtml(s, Html.FROM_HTML_MODE_LEGACY).toString().trim()

/** Bing wraps the real address of a story in its own link; this gives the real one back. */
private fun cleanLink(link: String): String {
    if (!link.contains("bing.com/news/apiclick")) return link
    val m = Regex("[?&]url=([^&]+)").find(link) ?: return link
    return try {
        java.net.URLDecoder.decode(m.groupValues[1], "UTF-8")
    } catch (_: Exception) {
        link
    }
}

/** Reads an RSS or Atom document. [name] is the source name; when null the feed's own title is used. */
fun parseFeed(stream: InputStream, name: String?): List<Article> {
    val p = Xml.newPullParser()
    p.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
    p.setInput(stream, null)
    val out = mutableListOf<Article>()
    var channel = ""
    var inItem = false
    var title = ""; var link = ""; var date = ""; var src = ""; var img = ""
    var ev = p.eventType
    while (ev != XmlPullParser.END_DOCUMENT) {
        if (ev == XmlPullParser.START_TAG) {
            val n = p.name
            if (n == "item" || n == "entry") {
                inItem = true
                title = ""; link = ""; date = ""; src = ""; img = ""
            } else if (inItem) {
                when (n) {
                    "title" -> title = p.nextText()
                    "link" -> {
                        val href = p.getAttributeValue(null, "href")
                        val rel = p.getAttributeValue(null, "rel")
                        val text = p.nextText().trim()
                        if (href != null) {
                            if (rel == null || rel == "alternate") link = href
                        } else if (text.isNotEmpty()) link = text
                    }
                    "pubDate", "published", "updated", "dc:date" -> if (date.isEmpty()) date = p.nextText()
                    "source", "News:Source" -> src = p.nextText()
                    "News:Image" -> { val u = p.nextText().trim(); if (img.isEmpty()) img = u }
                    "media:thumbnail", "media:content" -> {
                        val u = p.getAttributeValue(null, "url")
                        val type = p.getAttributeValue(null, "type") ?: ""
                        val medium = p.getAttributeValue(null, "medium") ?: ""
                        val isImage = type.startsWith("image") || medium == "image" || (type.isEmpty() && medium.isEmpty())
                        if (u != null && isImage && (img.isEmpty() || n == "media:content")) img = u
                    }
                    "enclosure" -> {
                        val u = p.getAttributeValue(null, "url")
                        val type = p.getAttributeValue(null, "type") ?: ""
                        if (u != null && type.startsWith("image") && img.isEmpty()) img = u
                    }
                    "description", "summary", "content:encoded" -> {
                        val html = p.nextText()
                        if (img.isEmpty()) IMG_TAG.find(html)?.let { img = it.groupValues[1] }
                    }
                }
            } else if (n == "title" && channel.isEmpty()) {
                channel = p.nextText()
            }
        } else if (ev == XmlPullParser.END_TAG && (p.name == "item" || p.name == "entry") && inItem) {
            inItem = false
            var t = plain(title)
            val s = plain(src).ifEmpty { name ?: plain(channel) }
            if (s.isNotEmpty() && t.endsWith(" - $s")) t = t.removeSuffix(" - $s")
            if (t.isNotEmpty() && link.isNotEmpty()) {
                out.add(Article(t, cleanLink(link), s, parseDate(date), if (img.startsWith("http")) img else ""))
            }
        }
        ev = p.next()
    }
    return out
}

/** The stories, kept in memory and in the preferences so the page shows at once. */
object FeedStore {
    var articles by mutableStateOf<List<Article>>(emptyList())
    var loading by mutableStateOf(false)
    var failed by mutableStateOf(false)
    private var updated by mutableLongStateOf(0L)
    private var loaded = false

    fun stale() { updated = 0L }

    private fun loadCache(ctx: Context) {
        if (loaded) return
        loaded = true
        try {
            val a = JSONArray(Prefs(ctx).getString("feedCache").ifEmpty { "[]" })
            articles = (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Article(o.getString("t"), o.getString("l"), o.optString("s"), o.optLong("d"), o.optString("i"), o.optString("p"))
            }
        } catch (_: Exception) {
        }
    }

    private fun saveCache(ctx: Context, list: List<Article>) {
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().put("t", it.title).put("l", it.link).put("s", it.source).put("d", it.time).put("i", it.image).put("p", it.topic))
        }
        Prefs(ctx).putString("feedCache", a.toString())
    }

    /** Shows what was saved, and fetches again when it is older than a quarter of an hour. */
    suspend fun ensure(ctx: Context) {
        loadCache(ctx)
        if (System.currentTimeMillis() - updated > 15 * 60_000L) refresh(ctx)
    }

    suspend fun refresh(ctx: Context) {
        if (loading) return
        loading = true
        failed = false
        val got = withContext(Dispatchers.IO) {
            val jobs = coroutineScope {
                FeedConfig.active().map { f ->
                    async {
                        fun read(url: String): List<Article>? = try {
                            val c = open(url)
                            try {
                                parseFeed(c.inputStream, f.name).take(if (f.topic.isEmpty()) 25 else 20)
                            } finally {
                                c.disconnect()
                            }
                        } catch (_: Exception) {
                            null
                        }
                        var got = read(f.url)
                        if (got.isNullOrEmpty() && f.backup != null) got = read(f.backup)
                        got?.map { it.copy(topic = f.topic) }
                    }
                }.awaitAll()
            }
            if (jobs.isNotEmpty() && jobs.all { it == null }) null
            else {
                val seen = HashSet<String>()
                val merged = jobs.filterNotNull().flatten()
                    .filter { seen.add(it.title.lowercase()) }
                    .sortedByDescending { it.time }
                    .take(90)
                fillImages(merged)
            }
        }
        if (got == null) {
            failed = true
        } else {
            articles = got
            updated = System.currentTimeMillis()
            withContext(Dispatchers.IO) { saveCache(ctx, got) }
        }
        loading = false
    }

    /** Sources that give no picture often have one on the story's own page. Looks for the first few. */
    private suspend fun fillImages(list: List<Article>): List<Article> = coroutineScope {
        val missing = list.filter { it.image.isEmpty() && !it.link.contains("news.google.com") }.take(14)
        val found = missing.map { a ->
            async {
                try {
                    val c = open(a.link)
                    c.connectTimeout = 4000
                    c.readTimeout = 4000
                    try {
                        val head = c.inputStream.use { s ->
                            val buf = ByteArray(120_000)
                            var n = 0
                            while (n < buf.size) {
                                val r = s.read(buf, n, buf.size - n)
                                if (r < 0) break
                                n += r
                            }
                            String(buf, 0, n)
                        }
                        val m = OG_IMAGE.find(head)
                        val u = m?.groupValues?.get(1)?.ifEmpty { m.groupValues[2] } ?: ""
                        a.link to Html.fromHtml(u, Html.FROM_HTML_MODE_LEGACY).toString()
                    } finally {
                        c.disconnect()
                    }
                } catch (_: Exception) {
                    a.link to ""
                }
            }
        }.awaitAll().toMap()
        list.map { a -> found[a.link]?.takeIf { it.startsWith("http") }?.let { a.copy(image = it) } ?: a }
    }
}

/** Pictures for the cards, shrunk and kept in memory. */
object FeedImages {
    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 1024 / 10).toInt()) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount / 1024
    }

    fun peek(url: String): Bitmap? = cache.get(url)

    suspend fun get(url: String): Bitmap? = withContext(Dispatchers.IO) {
        cache.get(url) ?: try {
            val c = open(url)
            val bytes = try {
                c.inputStream.use { it.readBytes() }
            } finally {
                c.disconnect()
            }
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= 800) sample *= 2
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
            if (bmp != null) cache.put(url, bmp)
            bmp
        } catch (_: Exception) {
            null
        }
    }
}

@Composable
fun RemoteImage(url: String, modifier: Modifier) {
    val bmp by produceState<Bitmap?>(FeedImages.peek(url), url) {
        if (value == null) value = FeedImages.get(url)
    }
    val b = bmp
    if (b != null) {
        Image(b.asImageBitmap(), null, modifier, contentScale = ContentScale.Crop)
    } else {
        Box(modifier.background(Eon.ov(0x1F)))
    }
}

private fun ago(time: Long): String {
    if (time <= 0L) return ""
    val m = (System.currentTimeMillis() - time) / 60_000
    return when {
        m < 1 -> "now"
        m < 60 -> "${m}m"
        m < 60 * 24 -> "${m / 60}h"
        m < 60 * 24 * 7 -> "${m / (60 * 24)}d"
        else -> "${m / (60 * 24 * 7)}w"
    }
}

private fun openUrl(ctx: Context, url: String) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {
    }
}

private fun share(ctx: Context, a: Article) {
    try {
        val i = Intent(Intent.ACTION_SEND).setType("text/plain")
            .putExtra(Intent.EXTRA_TEXT, "${a.title}\n${a.link}")
        ctx.startActivity(Intent.createChooser(i, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {
    }
}

/**
 * The feed page: a search bar, a row of sources to filter by, and a column of story cards.
 * Typing narrows the stories; pressing search on the keyboard searches the web. Swipe left to go back to Home.
 */
@Composable
fun FeedScreen(state: EonState, holder: WidgetHolder, onSettings: () -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    BackHandler { onClose() }
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { FeedStore.ensure(ctx) }

    val all = FeedStore.articles
    val sourceChips = all.map { it.source }.filter { it.isNotBlank() }.groupingBy { it }.eachCount()
        .entries.sortedByDescending { it.value }.take(8).map { it.key }
    val chips = (FeedConfig.topics + sourceChips).distinct()
    val q = query.trim().lowercase()
    val list = all.filter { (filter.isEmpty() || it.source == filter || it.topic.equals(filter, true)) && (q.isEmpty() || it.title.lowercase().contains(q)) }

    Column(
        Modifier.fillMaxSize().background(Eon.Page).systemBarsPadding()
            .pointerInput(Unit) {
                var total = 0f
                detectHorizontalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total < -150f) onClose() },
                    onDragCancel = { total = 0f },
                ) { _, dx -> total += dx }
            }
            .padding(horizontal = 14.dp),
    ) {
        Gap(10)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                Modifier.weight(1f).clip(CircleShape).background(Eon.P1).border(1.dp, Eon.P2, CircleShape)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Outlined.Search, null, tint = Eon.Muted, modifier = Modifier.size(20.dp))
                Box(Modifier.weight(1f).padding(start = 10.dp)) {
                    if (query.isEmpty()) Text("Search the web or the feed", color = Eon.Faint, fontSize = 15.sp, maxLines = 1)
                    BasicTextField(
                        value = query,
                        onValueChange = { query = it },
                        singleLine = true,
                        textStyle = TextStyle(color = Eon.Text, fontSize = 15.sp),
                        cursorBrush = SolidColor(Eon.Accent),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = {
                            if (query.isNotBlank()) {
                                openUrl(ctx, "https://www.google.com/search?q=" + URLEncoder.encode(query.trim(), "UTF-8"))
                            }
                        }),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                if (query.isNotEmpty()) {
                    Icon(
                        Icons.Outlined.Close, "Clear", tint = Eon.Muted,
                        modifier = Modifier.size(20.dp).clip(CircleShape).clickable { query = "" },
                    )
                }
            }
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(Eon.P1).clickable {
                    scope.launch { FeedStore.refresh(ctx) }
                },
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Outlined.Refresh, "Refresh", tint = if (FeedStore.loading) Eon.Accent else Eon.Soft, modifier = Modifier.size(22.dp)) }
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(Eon.P1).clickable(onClick = onSettings),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Outlined.Tune, "Feed settings", tint = Eon.Soft, modifier = Modifier.size(22.dp)) }
        }
        if (chips.size > 1) {
            Gap(10)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    FeedChip("All", filter.isEmpty()) { filter = "" }
                }
                items(chips, key = { it }) { c -> FeedChip(c, filter == c) { filter = if (filter == c) "" else c } }
            }
        }
        Gap(10)
        val showWidgets = q.isEmpty() && filter.isEmpty() && (state.stacks[FEED_STACK]?.members?.isNotEmpty() == true)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxSize()) {
            if (showWidgets) item(key = "widgets") { FeedWidgets(state, holder) }
            if (list.isEmpty()) {
                item(key = "msg") {
            val msg = when {
                FeedStore.loading -> "Loading stories…"
                FeedStore.failed && all.isEmpty() -> "Could not load the feed. Check your connection, then tap refresh."
                FeedConfig.selected.isEmpty() && FeedConfig.topics.isEmpty() -> "No sources picked yet. Tap the sliders to choose some."
                all.isEmpty() -> "Nothing here yet."
                else -> "No stories match."
            }
            Box(Modifier.fillMaxWidth().padding(top = 60.dp, start = 24.dp, end = 24.dp), contentAlignment = Alignment.TopCenter) {
                Text(msg, color = Eon.Muted, fontSize = 15.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            }
                }
            } else {
                items(list, key = { it.link }) { a ->
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Eon.P0)
                            .border(1.dp, Eon.Line, RoundedCornerShape(22.dp)).clickable { openUrl(ctx, a.link) },
                    ) {
                        if (a.image.isNotEmpty()) RemoteImage(a.image, Modifier.fillMaxWidth().aspectRatio(16f / 9f))
                        Column(Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
                            Text(
                                a.title, color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold,
                                maxLines = 4, overflow = TextOverflow.Ellipsis, lineHeight = 21.sp,
                            )
                            Gap(10)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    listOf(a.source, ago(a.time)).filter { it.isNotEmpty() }.joinToString(" · "),
                                    color = Eon.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f),
                                )
                                Icon(
                                    Icons.Outlined.Share, "Share", tint = Eon.Muted,
                                    modifier = Modifier.size(32.dp).clip(CircleShape).clickable { share(ctx, a) }.padding(6.dp),
                                )
                            }
                        }
                    }
                }
            }
            item { Gap(24) }
        }
    }
}

/** Your widgets, one under another, above the stories. They are chosen in Settings > Feed. */
@Composable
private fun FeedWidgets(state: EonState, holder: WidgetHolder) {
    val stack = state.stacks[FEED_STACK] ?: return
    androidx.compose.foundation.layout.Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        stack.members.toList().forEach { id ->
            BoxWithConstraints(Modifier.fillMaxWidth().height(160.dp).clip(RoundedCornerShape(22.dp))) {
                WidgetView(holder, id, maxWidth.value.toInt(), 160)
            }
        }
    }
}

@Composable
private fun FeedChip(label: String, on: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.clip(CircleShape).accentFill(on, Eon.ov(0x1F)).clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
    ) {
        Text(label, color = if (on) Eon.OnAccent else Eon.Soft, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@OptIn(ExperimentalLayoutApi::class)
/** Settings > Feed: switch it on or off, pick the sources, add your own RSS address. */
@Composable
fun FeedPage(state: EonState, onBack: () -> Unit) {
    val ctx = LocalContext.current
    BackHandler { onBack() }
    var address by remember { mutableStateOf("") }
    var topic by remember { mutableStateOf("") }
    val groups = FEED_SOURCES.groupBy { it.group }
    Column(
        Modifier.fillMaxSize().background(Eon.Page).systemBarsPadding().padding(horizontal = 16.dp)
            .verticalScroll(rememberScrollState()),
    ) {
        Gap(12)
        PageHeader("Feed", onBack)
        Gap(18)
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Eon.P0)
                .border(1.dp, Eon.Line, RoundedCornerShape(24.dp)).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f).padding(end = 12.dp)) {
                Text("News feed", color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Swipe right on the first home page to open it. Also an action for any gesture.",
                    color = Eon.Muted, fontSize = 13.sp,
                )
            }
            EonSwitch(FeedConfig.enabled) { FeedConfig.setEnabled(ctx, it) }
        }
        Gap(8)
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Eon.P0)
                .border(1.dp, Eon.Line, RoundedCornerShape(24.dp))
                .clickable { state.ensureFeedStack(); state.stackConfig = FEED_STACK }.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f).padding(end = 12.dp)) {
                Text("Widgets on the feed page", color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Show your widgets above the news, so one swipe right gives a Today page.",
                    color = Eon.Muted, fontSize = 13.sp,
                )
            }
            Text("Manage", color = Eon.Accent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        }
        Gap(8)
        Text(
            "This is Eon's own feed, built from the sources below. It is not Google's Discover.",
            color = Eon.Faint, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 6.dp),
        )
        Gap(18)
        Text("Google feed (experimental)", color = Eon.Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 6.dp))
        Gap(8)
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Eon.P0)
                .border(1.dp, Eon.Line, RoundedCornerShape(24.dp)).padding(16.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f).padding(end = 12.dp)) {
                    Text("Use Google's feed", color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text(GoogleFeed.status(ctx), color = if (GoogleFeed.connected) Eon.Good else Eon.Muted, fontSize = 13.sp)
                }
                EonSwitch(GoogleFeed.enabled) { GoogleFeed.setEnabled(ctx, it) }
            }
            Gap(10)
            Text(
                "Shows the real Google Discover, chosen by your Google account, when you swipe right on the first page. " +
                    "It needs a bridge app that you install yourself, such as Smart Launcher's Bridge, Lawnfeed or AIDL Bridge. " +
                    "Eon connects only to the one you pick here, and gives it the size of Eon's window so the feed can slide over it. " +
                    "When it is connected, Eon's own feed opens from the News feed gesture action instead.",
                color = Eon.Muted, fontSize = 13.sp,
            )
            Gap(10)
            val found = GoogleFeed.providers(ctx)
            if (found.isEmpty()) {
                Text("No bridge app found on this phone yet.", color = Eon.Faint, fontSize = 13.sp)
            } else {
                found.forEach { (pkg, label) ->
                    val on = GoogleFeed.provider == pkg
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable { GoogleFeed.choose(ctx, pkg) }
                            .padding(vertical = 10.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            Modifier.size(20.dp).clip(CircleShape).background(if (on) Eon.Button else SolidColor(Eon.P2)),
                        )
                        Column(Modifier.padding(start = 12.dp)) {
                            Text(label, color = Eon.Text, fontSize = 15.sp)
                            Text(pkg, color = Eon.Faint, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
        if (GoogleFeed.enabled) {
            Gap(10)
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Eon.P0)
                    .border(1.dp, Eon.Line, RoundedCornerShape(24.dp)).padding(16.dp),
            ) {
                val clip = androidx.compose.ui.platform.LocalClipboardManager.current
                Text("Connection log", color = Eon.Text, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Gap(6)
                Text(
                    if (GoogleFeed.log.isEmpty()) "Nothing yet. Press Reconnect." else GoogleFeed.log.takeLast(14).joinToString("\n"),
                    color = Eon.Muted, fontSize = 11.sp, lineHeight = 15.sp,
                )
                Gap(10)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(
                        Modifier.clip(CircleShape).background(Eon.Button).clickable { GoogleFeed.reconnect() }
                            .padding(horizontal = 18.dp, vertical = 9.dp),
                    ) { Text("Reconnect", color = Eon.OnAccent, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                    Box(
                        Modifier.clip(CircleShape).background(Eon.ov(0x1F))
                            .clickable { clip.setText(androidx.compose.ui.text.AnnotatedString(GoogleFeed.log.joinToString("\n"))) }
                            .padding(horizontal = 18.dp, vertical = 9.dp),
                    ) { Text("Copy", color = Eon.Soft, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                }
            }
        }
        Gap(18)
        Text("Your interests", color = Eon.Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 6.dp))
        Gap(8)
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Eon.P0)
                .border(1.dp, Eon.Line, RoundedCornerShape(24.dp)).padding(16.dp),
        ) {
            Text(
                "Add anything you like to read about, a team, a band, a hobby. Eon searches the news for each word and mixes the stories in.",
                color = Eon.Muted, fontSize = 13.sp,
            )
            Gap(12)
            if (FeedConfig.topics.isNotEmpty()) {
                androidx.compose.foundation.layout.FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    FeedConfig.topics.forEach { t ->
                        Row(
                            Modifier.clip(CircleShape).background(Eon.Button).clickable { FeedConfig.removeTopic(ctx, t) }
                                .padding(start = 14.dp, end = 8.dp, top = 7.dp, bottom = 7.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(t, color = Eon.OnAccent, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Icon(Icons.Outlined.Close, "Remove", tint = Eon.OnAccent, modifier = Modifier.padding(start = 6.dp).size(16.dp))
                        }
                    }
                }
                Gap(12)
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(
                    Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(Eon.ov(0x1F))
                        .padding(horizontal = 14.dp, vertical = 11.dp),
                ) {
                    if (topic.isEmpty()) Text("For example: football, Beatles", color = Eon.Faint, fontSize = 14.sp)
                    BasicTextField(
                        value = topic, onValueChange = { topic = it }, singleLine = true,
                        textStyle = TextStyle(color = Eon.Text, fontSize = 14.sp),
                        cursorBrush = SolidColor(Eon.Accent),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { if (FeedConfig.addTopic(ctx, topic)) topic = "" }),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                Box(
                    Modifier.clip(CircleShape).background(Eon.Button)
                        .clickable { if (FeedConfig.addTopic(ctx, topic)) topic = "" }
                        .padding(horizontal = 18.dp, vertical = 11.dp),
                ) { Text("Add", color = Eon.OnAccent, fontSize = 14.sp, fontWeight = FontWeight.Bold) }
            }
            Gap(12)
            androidx.compose.foundation.layout.FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                listOf("Football", "Music", "Movies", "Science", "Space", "Technology", "Gaming", "Cooking", "Travel")
                    .filter { s -> FeedConfig.topics.none { it.equals(s, true) } }
                    .forEach { s ->
                        Text(
                            "+ $s", color = Eon.Soft, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.clip(CircleShape).background(Eon.ov(0x1F))
                                .clickable { FeedConfig.addTopic(ctx, s) }.padding(horizontal = 12.dp, vertical = 7.dp),
                        )
                    }
            }
        }
        groups.forEach { (group, sources) ->
            Gap(18)
            Text(group, color = Eon.Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 6.dp))
            Gap(8)
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Eon.P0)
                    .border(1.dp, Eon.Line, RoundedCornerShape(24.dp)),
            ) {
                sources.forEach { s ->
                    Row(
                        Modifier.fillMaxWidth().clickable { FeedConfig.toggle(ctx, s.id) }.padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(s.name, color = Eon.Text, fontSize = 15.sp, modifier = Modifier.weight(1f).padding(end = 12.dp))
                        EonSwitch(s.id in FeedConfig.selected) { FeedConfig.toggle(ctx, s.id) }
                    }
                }
            }
        }
        Gap(18)
        Text("Your own sources", color = Eon.Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 6.dp))
        Gap(8)
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Eon.P0)
                .border(1.dp, Eon.Line, RoundedCornerShape(24.dp)).padding(16.dp),
        ) {
            FeedConfig.custom.forEach { u ->
                Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        u.removePrefix("https://").removePrefix("http://"), color = Eon.Text, fontSize = 14.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f).padding(end = 8.dp),
                    )
                    EonSwitch("c:$u" in FeedConfig.selected) { FeedConfig.toggle(ctx, "c:$u") }
                    Icon(
                        Icons.Outlined.Close, "Remove", tint = Eon.Muted,
                        modifier = Modifier.padding(start = 8.dp).size(32.dp).clip(CircleShape)
                            .clickable { FeedConfig.removeCustom(ctx, u) }.padding(6.dp),
                    )
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(
                    Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(Eon.ov(0x1F))
                        .padding(horizontal = 14.dp, vertical = 11.dp),
                ) {
                    if (address.isEmpty()) Text("RSS or Atom address", color = Eon.Faint, fontSize = 14.sp)
                    BasicTextField(
                        value = address, onValueChange = { address = it }, singleLine = true,
                        textStyle = TextStyle(color = Eon.Text, fontSize = 14.sp),
                        cursorBrush = SolidColor(Eon.Accent),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { if (FeedConfig.addCustom(ctx, address)) address = "" }),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                Box(
                    Modifier.clip(CircleShape).background(Eon.Button)
                        .clickable { if (FeedConfig.addCustom(ctx, address)) address = "" }
                        .padding(horizontal = 18.dp, vertical = 11.dp),
                ) { Text("Add", color = Eon.OnAccent, fontSize = 14.sp, fontWeight = FontWeight.Bold) }
            }
        }
        Gap(40)
    }
}
