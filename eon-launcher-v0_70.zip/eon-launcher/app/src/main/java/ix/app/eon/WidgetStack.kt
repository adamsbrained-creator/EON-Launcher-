package ix.app.eon

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.DragIndicator
import androidx.compose.material.icons.outlined.SwapHoriz
import androidx.compose.material.icons.outlined.SwapVert
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import kotlin.math.abs
import kotlinx.coroutines.delay

/**
 * Widget stacks: one widget that holds several others. Swipe it to flip through them, like Smart Launcher's
 * Widget Stack. A stack lives on the home page as a widget with an id of [W_STACK_BASE] or lower.
 */

/** Not a real widget: the "Widget Stack" tile in the picker. */
const val W_STACK_TILE = -999

/** Stack ids start here and count down (-1000, -1001, ...). */
const val W_STACK_BASE = -1000

/** The stack that holds the widgets shown on the feed page. It is not on any home page. */
const val FEED_STACK = -50000

/** The stack that holds the widgets a "Popup widget" action can open. It is not on any home page. */
const val POPUP_STACK = -50001

fun isStackId(id: Int): Boolean = id <= W_STACK_BASE

/** How many pages the endless loop has. The stack starts in the middle, so you can swipe either way for a very long time. */
private const val LOOP_PAGES = 20_000

/** A stack on the home screen: the widgets flip by swiping, round and round, with dots that show where you are. */
@Composable
fun StackView(holder: WidgetHolder, state: EonState, id: Int, wDp: Int, hDp: Int) {
    val stack = state.stacks[id] ?: return
    if (stack.members.isEmpty()) {
        Box(
            Modifier.fillMaxSize().clip(RoundedCornerShape(24.dp)).background(Color(0x66000000))
                .border(1.dp, Color(0x40FFFFFF), RoundedCornerShape(24.dp))
                .clickable { state.stackConfig = id },
            contentAlignment = Alignment.Center,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(Icons.Outlined.Add, null, tint = Eon.DAccent, modifier = Modifier.size(30.dp))
                Text("Empty stack", color = Eon.DText, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Text("Tap to add widgets", color = Eon.DMuted, fontSize = 12.sp)
            }
        }
        return
    }
    // Starts afresh when the widgets in the stack change (added, removed or reordered).
    key(stack.members.toList()) { StackPager(holder, stack, wDp, hDp) }
}

@Composable
private fun StackPager(holder: WidgetHolder, stack: WidgetStack, wDp: Int, hDp: Int) {
    val members = remember { stack.members.toList() }
    val n = members.size
    // With two or more widgets the pages repeat: after the last one comes the first again, and the other way round.
    val loop = n > 1
    val start = if (loop) LOOP_PAGES / 2 - (LOOP_PAGES / 2) % n + stack.current.coerceIn(0, n - 1) else 0
    val haptic = LocalHapticFeedback.current
    val pager = rememberPagerState(initialPage = start) { if (loop) LOOP_PAGES else n }
    val shown = pager.currentPage % n
    if (stack.smart && n > 1) SmartRotation(holder, members, pager)
    var first by remember { mutableStateOf(true) }
    LaunchedEffect(pager) {
        snapshotFlow { pager.currentPage % n }.collect {
            stack.current = it
            if (first) first = false else haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        }
    }
    // The page you leave shrinks and fades a little, so flipping feels soft. (Read while drawing: no recomposition.)
    val page: @Composable (Int) -> Unit = { i ->
        Box(
            Modifier.fillMaxSize().graphicsLayer {
                val away = abs(pager.currentPage - i + pager.currentPageOffsetFraction).coerceIn(0f, 1f)
                val scale = 1f - 0.07f * away
                scaleX = scale
                scaleY = scale
                alpha = 1f - 0.45f * away
            },
        ) { WidgetView(holder, members[i % n], wDp, hDp) }
    }
    // Neighbouring pages are kept ready only when they are other widgets. With two widgets the next page on
    // both sides would be the same one, and a widget can only be drawn in one place at a time.
    val ahead = if (n >= 3) 1 else 0
    Box(Modifier.fillMaxSize()) {
        if (stack.vertical) {
            VerticalPager(pager, Modifier.fillMaxSize(), beyondViewportPageCount = ahead, key = { it }) { page(it) }
        } else {
            HorizontalPager(pager, Modifier.fillMaxSize(), beyondViewportPageCount = ahead, key = { it }) { page(it) }
        }
        if (n > 1) {
            StackDots(
                n, shown, stack.vertical,
                Modifier.align(if (stack.vertical) Alignment.CenterEnd else Alignment.BottomCenter).padding(8.dp),
            )
        }
    }
}

/**
 * Smart rotate: every half minute, and when headphones connect, the stack turns to the widget that suits the moment
 * (calendar and weather in the morning, weather at midday, music in the evening, a clock at night, music with headphones
 * or while something plays). A swipe of your own pauses it for ten minutes, except that headphones always win.
 */
@Composable
private fun SmartRotation(holder: WidgetHolder, members: List<Int>, pager: androidx.compose.foundation.pager.PagerState) {
    val ctx = LocalContext.current
    val n = members.size
    val kinds = remember(members) {
        members.map { id -> val mi = memberInfo(ctx, holder, id); kindOf(mi.title, mi.sub, mi.pkg) }
    }
    val headphones = rememberHeadphones()
    var tick by remember { mutableIntStateOf(0) }
    var userUntil by remember { mutableLongStateOf(0L) }
    var ours by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(30_000L)
            tick++
        }
    }
    LaunchedEffect(headphones) { if (headphones) userUntil = 0L }
    LaunchedEffect(pager) {
        snapshotFlow { pager.isScrollInProgress }.collect { moving ->
            if (moving && !ours) userUntil = System.currentTimeMillis() + 600_000L
        }
    }
    LaunchedEffect(tick, headphones, kinds) {
        if (System.currentTimeMillis() < userUntil) return@LaunchedEffect
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        val want = smartPick(kinds, hour, headphones, NowPlaying.pkg.isNotEmpty())
        val current = pager.currentPage
        if (want >= 0 && want != current % n) {
            // The nearest page that shows that widget, going whichever way is shorter.
            val forward = ((want - current % n) % n + n) % n
            val target = if (forward <= n / 2) current + forward else current + forward - n
            ours = true
            try {
                pager.animateScrollToPage(target)
            } finally {
                ours = false
            }
        }
    }
}

/** The index of the widget that suits [hour] best, or -1 when none of them is a kind this knows about. */
private fun smartPick(kinds: List<String>, hour: Int, headphones: Boolean, playing: Boolean): Int {
    val table: Map<String, Int> = when (hour) {
        in 5..10 -> mapOf("Calendar" to 3, "Weather" to 2, "News" to 2, "Clock" to 1, "Notes" to 1)
        in 11..16 -> mapOf("Weather" to 3, "Calendar" to 2, "Notes" to 1, "News" to 1)
        in 17..22 -> mapOf("Music" to 3, "Calendar" to 1, "Weather" to 1)
        else -> mapOf("Clock" to 3, "Weather" to 1)
    }
    var best = -1
    var bestScore = 0
    kinds.forEachIndexed { i, kind ->
        var score = table[kind] ?: 0
        if (kind == "Music") {
            if (headphones) score += 5
            if (playing) score += 4
        }
        if (score > bestScore) {
            best = i
            bestScore = score
        }
    }
    return best
}

/** True while headphones (wired, USB or Bluetooth) are connected. */
@Composable
private fun rememberHeadphones(): Boolean {
    val ctx = LocalContext.current
    val audio = remember { ctx.getSystemService(android.content.Context.AUDIO_SERVICE) as android.media.AudioManager }
    fun connected(): Boolean = audio.getDevices(android.media.AudioManager.GET_DEVICES_OUTPUTS).any {
        it.type == android.media.AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
            it.type == android.media.AudioDeviceInfo.TYPE_WIRED_HEADSET ||
            it.type == android.media.AudioDeviceInfo.TYPE_USB_HEADSET ||
            it.type == android.media.AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
            it.type == android.media.AudioDeviceInfo.TYPE_BLE_HEADSET
    }
    var on by remember { mutableStateOf(connected()) }
    DisposableEffect(audio) {
        val callback = object : android.media.AudioDeviceCallback() {
            override fun onAudioDevicesAdded(addedDevices: Array<out android.media.AudioDeviceInfo>?) { on = connected() }
            override fun onAudioDevicesRemoved(removedDevices: Array<out android.media.AudioDeviceInfo>?) { on = connected() }
        }
        audio.registerAudioDeviceCallback(callback, null)
        onDispose { audio.unregisterAudioDeviceCallback(callback) }
    }
    return on
}

/** The little dots that show which widget of the stack is showing. They never take touches. */
@Composable
private fun StackDots(count: Int, current: Int, vertical: Boolean, modifier: Modifier) {
    val shown = minOf(count, 7)
    val start = (current - shown / 2).coerceIn(0, count - shown)
    val pill = Modifier.clip(CircleShape).background(Color(0x59000000)).padding(5.dp)
    val dot: @Composable (Int) -> Unit = { i ->
        val on = i == current
        Box(Modifier.size(if (on) 7.dp else 5.dp).clip(CircleShape).background(if (on) Color.White else Color(0x80FFFFFF)))
    }
    if (vertical) {
        Column(modifier.then(pill), verticalArrangement = Arrangement.spacedBy(5.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            for (i in start until start + shown) dot(i)
        }
    } else {
        Row(modifier.then(pill), horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
            for (i in start until start + shown) dot(i)
        }
    }
}

// ---------------------------------------------------------------- choosing a size

private class StackSize(val name: String, val w: Int, val h: Int)

private val STACK_SIZES = listOf(
    StackSize("Landscape", 3, 2),
    StackSize("Square", 3, 3),
    StackSize("Portrait", 2, 3),
    StackSize("Square", 2, 2),
)

/** The page after tapping Widget Stack in the picker: swipe through the sizes, then Add widget. */
@Composable
fun StackSizeScreen(state: EonState, onBack: () -> Unit, onAdded: () -> Unit) {
    val ctx = LocalContext.current
    val pager = rememberPagerState { STACK_SIZES.size }
    BackHandler(onBack = onBack)
    Column(
        Modifier.fillMaxSize().background(Color(0xFF000000)).systemBarsPadding().padding(horizontal = 20.dp)
            .pointerInput(Unit) { detectTapGestures { } },
    ) {
        Gap(12)
        Box(
            Modifier.size(44.dp).clip(CircleShape).background(Color(0xFF161618)).border(1.dp, Color(0xFF28282C), CircleShape)
                .clickable(onClick = onBack),
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Outlined.ArrowBack, "Back", tint = Eon.Text, modifier = Modifier.size(22.dp)) }
        Gap(28)
        Text(
            if (id == FEED_STACK) "Feed widgets" else if (id == POPUP_STACK) "Popup widgets" else "Widget Stack", color = Eon.Text, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(),
        )
        Gap(8)
        Text(
            if (id == FEED_STACK) "These show one under another, above the news stories on the feed page." else if (id == POPUP_STACK) "Widgets a gesture can open in a small window. Give a double tap the action Popup widget." else "Several widgets in one place. Swipe the stack to flip through them.", color = Eon.Muted, fontSize = 15.sp,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
        )
        HorizontalPager(pager, Modifier.weight(1f).fillMaxWidth()) { i ->
            val size = STACK_SIZES[i]
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                StackPreview(size)
                Gap(14)
                Text(size.name, color = Eon.Text, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                Text("${size.w}×${size.h}", color = Eon.Muted, fontSize = 14.sp)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            repeat(STACK_SIZES.size) { i ->
                val on = i == pager.currentPage
                Box(
                    Modifier.padding(horizontal = 6.dp).size(10.dp).clip(CircleShape)
                        .background(if (on) Color(0xFF35D6F0) else Color(0xFF38393D)),
                )
            }
        }
        Gap(22)
        Box(
            Modifier.fillMaxWidth().height(54.dp).clip(CircleShape).background(Eon.Button).clickable {
                val size = STACK_SIZES[pager.currentPage]
                val id = state.addStack(size.w, size.h)
                if (id != null) {
                    state.editing = id.toString()
                    state.stackConfig = id
                    onAdded()
                } else {
                    Toast.makeText(ctx, "No space on this page", Toast.LENGTH_SHORT).show()
                }
            },
            contentAlignment = Alignment.Center,
        ) { Text("Add widget", color = Eon.OnAccent, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold) }
        Gap(16)
    }
}

/** A drawing of a stack in one size: the front widget with the next ones peeking in from the sides. */
@Composable
private fun StackPreview(size: StackSize) {
    val unit = 78.dp
    val frame = RoundedCornerShape(34.dp)
    Box(
        Modifier.size(unit * size.w, unit * size.h).clip(frame).background(Color.Black)
            .border(2.dp, Color(0xFF2E2F33), frame),
    ) {
        Row(Modifier.fillMaxSize().padding(top = 14.dp, bottom = 30.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.width(12.dp).fillMaxHeight()
                    .clip(RoundedCornerShape(topEnd = 14.dp, bottomEnd = 14.dp)).background(Color(0xFF1C1D20)),
            )
            Spacer(Modifier.width(8.dp))
            Box(
                Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(20.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF5C9DFF), Color(0xFF9B7BFF)))),
                contentAlignment = Alignment.BottomStart,
            ) {
                Column(Modifier.padding(14.dp)) {
                    Text("Widget", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text("1 of 3", color = Color(0xCCFFFFFF), fontSize = 12.sp)
                }
            }
            Spacer(Modifier.width(8.dp))
            Box(
                Modifier.width(12.dp).fillMaxHeight()
                    .clip(RoundedCornerShape(topStart = 14.dp, bottomStart = 14.dp)).background(Color(0xFFF7D26E)),
            )
        }
        Row(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            repeat(5) { i ->
                Box(Modifier.size(6.dp).clip(CircleShape).background(if (i == 2) Color.White else Color(0xFF6A6C72)))
            }
        }
    }
}

// ---------------------------------------------------------------- the Widget Stack page

private class MemberInfo(val title: String, val sub: String, val pkg: String)

private fun memberInfo(ctx: android.content.Context, holder: WidgetHolder, id: Int): MemberInfo {
    builtinLabel(id)?.let { return MemberInfo(it, "Eon", ctx.packageName) }
    val info = holder.manager.getAppWidgetInfo(id)
        ?: return MemberInfo("Widget", "Not available", "")
    return MemberInfo(info.loadLabel(ctx.packageManager).toString(), holder.appLabel(ctx, info), info.provider.packageName)
}

/**
 * The Widget Stack page: the widgets in the stack in order (drag the handle to reorder, the bin to remove),
 * Add widget, and which way the stack scrolls.
 */
@Composable
fun StackConfigScreen(state: EonState, holder: WidgetHolder, id: Int) {
    val stack = state.stacks[id]
    if (stack == null) {
        LaunchedEffect(Unit) { state.stackConfig = null }
        return
    }
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val haptic = LocalHapticFeedback.current
    BackHandler { state.stackConfig = null }

    val rowHeight = 72.dp
    val gap = 10.dp
    val stridePx = with(density) { (rowHeight + gap).toPx() }
    var dragId by remember { mutableStateOf<Int?>(null) }
    var dragOffset by remember { mutableFloatStateOf(0f) }

    Box(
        Modifier.fillMaxSize().background(Color(0xFF000000)).pointerInput(Unit) { detectTapGestures { } },
    ) {
        LazyColumn(
            Modifier.fillMaxSize().systemBarsPadding(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(gap),
        ) {
            item(key = "head") {
                Column {
                    PageHeader("Widget Stack") { state.stackConfig = null }
                    Gap(18)
                    Text(
                        "Add widgets to the stack, press and drag to reorder the widgets within the stack",
                        color = Eon.Muted, fontSize = 15.sp,
                    )
                    Gap(10)
                }
            }
            itemsIndexed(stack.members.toList(), key = { _, m -> m }) { _, mid ->
                val info = remember(mid) { memberInfo(ctx, holder, mid) }
                val icon: ImageBitmap? = remember(info.pkg) {
                    if (info.pkg.isEmpty()) null
                    else runCatching { IconShaper.shape(ctx.packageManager.getApplicationIcon(info.pkg), 96).asImageBitmap() }.getOrNull()
                }
                val dragging = dragId == mid
                val shape = RoundedCornerShape(20.dp)
                Row(
                    Modifier.fillMaxWidth().height(rowHeight)
                        .zIndex(if (dragging) 1f else 0f)
                        .graphicsLayer { translationY = if (dragging) dragOffset else 0f }
                        .then(if (dragging) Modifier.shadow(12.dp, shape) else Modifier.animateItem())
                        .clip(shape).background(Color(0xFF161618)),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(
                        Modifier.width(60.dp).fillMaxHeight()
                            .pointerInput(mid) {
                                detectDragGestures(
                                    onDragStart = {
                                        dragId = mid
                                        dragOffset = 0f
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    },
                                    onDragEnd = { dragId = null; dragOffset = 0f; state.saveStacks() },
                                    onDragCancel = { dragId = null; dragOffset = 0f; state.saveStacks() },
                                ) { change, amount ->
                                    change.consume()
                                    dragOffset += amount.y
                                    // Moving past half a row swaps places; the row stays under the finger.
                                    while (dragOffset > stridePx / 2f) {
                                        val from = stack.members.indexOf(mid)
                                        if (from < 0 || from >= stack.members.size - 1) break
                                        stack.members.add(from + 1, stack.members.removeAt(from))
                                        dragOffset -= stridePx
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    }
                                    while (dragOffset < -stridePx / 2f) {
                                        val from = stack.members.indexOf(mid)
                                        if (from <= 0) break
                                        stack.members.add(from - 1, stack.members.removeAt(from))
                                        dragOffset += stridePx
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    }
                                }
                            },
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Outlined.DragIndicator, "Reorder", tint = Eon.Faint, modifier = Modifier.size(26.dp)) }
                    if (icon != null) {
                        Image(icon, null, Modifier.size(44.dp))
                    } else {
                        Box(Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF26272B)))
                    }
                    Column(Modifier.weight(1f).padding(horizontal = 16.dp)) {
                        Text(
                            info.title, color = Eon.Text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                        Text(info.sub, color = Eon.Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Box(
                        Modifier.width(64.dp).fillMaxHeight()
                            .clickable { state.removeFromStack(id, mid) { holder.host.deleteAppWidgetId(it) } },
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Outlined.Delete, "Remove", tint = Eon.Danger, modifier = Modifier.size(26.dp)) }
                }
            }
            item(key = "add") {
                Row(
                    Modifier.fillMaxWidth().height(rowHeight).clip(RoundedCornerShape(20.dp)).background(Color(0xFF161618))
                        .clickable { state.stackPicker = id }.padding(horizontal = 22.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(18.dp),
                ) {
                    Icon(Icons.Outlined.Add, null, tint = Eon.Accent, modifier = Modifier.size(28.dp))
                    Text("Add widget", color = Eon.Accent, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                }
            }
            if (id != FEED_STACK && id != POPUP_STACK) item(key = "prefs") {
                Column {
                    Gap(14)
                    Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF28282C)))
                    Gap(26)
                    SettingsSectionLabel("PREFERENCES")
                    Gap(6)
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Scroll orientation", color = Eon.Text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                            Text(if (stack.vertical) "Vertical" else "Horizontal", color = Eon.Muted, fontSize = 15.sp)
                        }
                        Box(
                            Modifier.size(width = 70.dp, height = 56.dp).clip(RoundedCornerShape(18.dp)).background(Color(0xFF1C1D20))
                                .clickable { state.setStackVertical(id, !stack.vertical) },
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                if (stack.vertical) Icons.Outlined.SwapVert else Icons.Outlined.SwapHoriz,
                                "Change orientation", tint = Eon.Text, modifier = Modifier.size(26.dp),
                            )
                        }
                    }
                    Gap(20)
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Smart rotate", color = Eon.Text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                            Text(
                                if (stack.smart) "Picks the widget for the time of day" else "Off",
                                color = Eon.Muted, fontSize = 15.sp,
                            )
                        }
                        Box(
                            Modifier.size(width = 70.dp, height = 56.dp).clip(RoundedCornerShape(18.dp))
                                .then(if (stack.smart) Modifier.background(Eon.Button) else Modifier.background(Eon.P1))
                                .clickable { state.setStackSmart(id, !stack.smart) },
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                if (stack.smart) "On" else "Off",
                                color = if (stack.smart) Eon.OnAccent else Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold,
                            )
                        }
                    }
                    Gap(40)
                }
            }
        }
    }
}
