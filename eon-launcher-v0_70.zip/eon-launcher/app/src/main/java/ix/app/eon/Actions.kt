package ix.app.eon

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/**
 * What a gesture can do, written as a short piece of text so it can be saved: "none", "lock", "app:<component>",
 * "url:<address>" and so on. Use [Act.label] for the words shown to the person.
 */
object Act {
    const val NONE = "none"
    const val LOCK = "lock"
    const val SCREEN_OFF = "screenoff"
    const val DRAWER = "drawer"
    const val SEARCH = "search"
    const val NOTIF = "notif"
    const val PANEL = "panel"
    const val RECENTS = "recents"
    const val SETTINGS = "settings"
    const val NEXT_PAGE = "nextpage"
    const val PREV_PAGE = "prevpage"
    const val FIRST_PAGE = "firstpage"
    const val FEED = "feed"
    const val POPUP = "popup"
    const val APP = "app:"
    const val URL = "url:"

    /** "focus:Work" turns that Focus mode on, "focus:" goes back to the normal home. */
    const val FOCUS = "focus:"

    /** "popup:<widget id>" opens that widget in a small window over the home screen. */
    const val POPUP = "popup:"

    /** "pair:<app key>|<app key>" opens two apps side by side. */
    const val PAIR = "pair:"

    /** Gestures saved by older versions were numbers. */
    fun fromLegacy(i: Int): String = when (i) {
        1 -> LOCK
        2 -> DRAWER
        3 -> SEARCH
        4 -> NOTIF
        5 -> SETTINGS
        else -> NONE
    }

    fun label(spec: String, apps: List<AppEntry>): String = when {
        spec.startsWith(APP) -> apps.firstOrNull { it.key == spec.removePrefix(APP) }?.label ?: "App"
        spec.startsWith(POPUP) -> "Popup widget"
        spec.startsWith(PAIR) -> "Open app pair"
        spec.startsWith(FOCUS) -> "Focus: " + spec.removePrefix(FOCUS).ifEmpty { "off" }
        spec.startsWith(URL) -> spec.removePrefix(URL).removePrefix("https://").removePrefix("http://").take(28)
        else -> when (spec) {
            LOCK -> "Lock screen (device admin)"
            SCREEN_OFF -> "Turn off the screen"
            DRAWER -> "App page"
            SEARCH -> "Search page"
            NOTIF -> "Show notifications panel"
            PANEL -> "Show toggle panel"
            RECENTS -> "Show recent apps"
            SETTINGS -> "Preferences"
            NEXT_PAGE -> "Next home page"
            PREV_PAGE -> "Previous home page"
            FIRST_PAGE -> "First home page"
            FEED -> "News feed"
            POPUP -> "Popup widget"
            else -> "None"
        }
    }
}

/**
 * Lets Eon turn the screen off, show the recent apps and open the toggle panel, which Android only allows through
 * an accessibility service. It reads nothing from the screen: it has no event types and cannot see window content.
 */
class EonAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    companion object {
        @Volatile
        var instance: EonAccessibilityService? = null

        val enabled: Boolean get() = instance != null

        /** Does one of the global actions. False when the helper is not turned on. */
        fun run(action: Int): Boolean = try {
            instance?.performGlobalAction(action) ?: false
        } catch (_: Exception) {
            false
        }
    }
}

/** Pulls down the quick settings (toggle) panel without the accessibility helper. */
fun expandQuickSettings(ctx: android.content.Context) {
    try {
        val service = ctx.getSystemService("statusbar") ?: return
        service.javaClass.getMethod("expandSettingsPanel").invoke(service)
    } catch (_: Exception) {
    }
}
