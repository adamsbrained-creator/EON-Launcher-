package ix.app.eon

import android.text.format.DateFormat
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun Home(
    repo: AppRepo, state: EonState, widgets: WidgetHolder, apps: List<AppEntry>, homeTick: Int,
    onResetGreeting: () -> Unit,
) {
    val ctx = LocalContext.current
    val density = LocalDensity.current.density
    var drawer by rememberSaveable { mutableStateOf(false) }
    var settings by rememberSaveable { mutableStateOf(false) }
    var focusSearch by remember { mutableStateOf(false) }
    var menuApp by remember { mutableStateOf<AppEntry?>(null) }
    var homeMenu by remember { mutableStateOf(false) }
    var widgetScreen by rememberSaveable { mutableStateOf(false) }
    val pagerState = rememberPagerState(pageCount = { state.pages.size })
    var scrollTo by remember { mutableIntStateOf(-1) }
    LaunchedEffect(pagerState) { snapshotFlow { pagerState.currentPage }.collect { state.currentPage = it } }
    LaunchedEffect(scrollTo) {
        if (scrollTo >= 0) {
            pagerState.animateScrollToPage(scrollTo)
            scrollTo = -1
        }
    }

    val visible = remember(apps, state.hidden.size) { apps.filter { it.packageName !in state.hidden } }
    val defaultDock = remember(apps) { repo.defaultDock(apps) }
    val dockApps = if (!state.dockCustom) defaultDock
    else state.dock.mapNotNull { k -> apps.firstOrNull { it.key == k } }

    fun toggleDock(app: AppEntry) {
        val keys = dockApps.map { it.key }.toMutableList()
        if (!keys.remove(app.key) && keys.size < 4) keys.add(app.key)
        state.setDock(keys)
    }
    fun moveDock(from: Int, to: Int) {
        val keys = dockApps.map { it.key }.toMutableList()
        if (from in keys.indices && to in keys.indices) {
            keys.add(to, keys.removeAt(from))
            state.setDock(keys)
        }
    }

    val now by produceState(LocalDateTime.now()) {
        while (true) {
            value = LocalDateTime.now()
            delay(60_000L - System.currentTimeMillis() % 60_000L)
        }
    }
    val is24 = remember { DateFormat.is24HourFormat(ctx) }
    val time = now.format(DateTimeFormatter.ofPattern(if (is24) "HH:mm" else "h:mm"))
    val date = now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.getDefault()))
    val shadow = Shadow(Color(0x73000000), Offset(0f, 2f), 8f)

    DisposableEffect(Unit) {
        widgets.host.startListening()
        onDispose { widgets.host.stopListening() }
    }
    // Move home screens saved by older versions onto the grid.
    LaunchedEffect(Unit) {
        state.migrate { id ->
            builtinSize(id)
                ?: widgets.manager.getAppWidgetInfo(id)?.let { suggestSize(ctx, it) }
                ?: (4 to 2)
        }
    }
    // Forget widgets whose provider app was removed.
    LaunchedEffect(Unit) {
        state.allWidgets().filter { it > 0 && widgets.manager.getAppWidgetInfo(it) == null }.forEach { state.removeWidget(it) }
    }
    LaunchedEffect(homeTick) {
        if (homeTick > 0) {
            drawer = false
            settings = false
            widgetScreen = false
            pagerState.animateScrollToPage(0)
        }
    }
    BackHandler(enabled = drawer) { drawer = false }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = {
                        val free = !drawer && !settings && !widgetScreen
                        if (total < -160f) {
                            focusSearch = false
                            drawer = true
                        } else if (total > 240f && free) {
                            expandNotifications(ctx)
                        }
                    },
                    onDragCancel = { total = 0f },
                    onVerticalDrag = { _, dy -> total += dy },
                )
            },
    ) {
        // Empty-space layer: long-press here opens the home menu.
        Box(
            Modifier.fillMaxSize()
                .pointerInput(Unit) { detectTapGestures(onLongPress = { homeMenu = true }) },
        )
        Box(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(340.dp)
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xA6070B24)))),
        )

        Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 16.dp)) {
            Column(Modifier.padding(start = 12.dp, top = 40.dp)) {
                Text(
                    time,
                    style = TextStyle(
                        color = Eon.Text, fontSize = 72.sp, fontWeight = FontWeight.Light,
                        letterSpacing = (-2).sp, shadow = shadow,
                    ),
                )
                Text(date, style = TextStyle(color = Color(0xFFDDE3FF), fontSize = 15.sp, shadow = shadow))
            }
            Gap(20)
            HorizontalPager(
                pagerState,
                Modifier.weight(1f).fillMaxWidth().onSizeChanged { size ->
                    state.gridRows = maxOf(1, (size.height / (CELL_HEIGHT.value * density)).toInt())
                },
            ) { index ->
                val page = state.pages.getOrNull(index)
                if (page != null) {
                    Box(Modifier.fillMaxSize()) {
                        PageGrid(
                            page = page, pageIndex = index, state = state, apps = apps, widgets = widgets,
                            onTap = { repo.launch(it) },
                            onMenu = { menuApp = it },
                            onEmptyLongPress = { homeMenu = true },
                        )
                        if (index == 0 && page.items.isEmpty() && page.legacyPinned.isEmpty() && page.legacyWidgets.isEmpty()) {
                            Text(
                                "Long-press an app in the drawer to pin it here.",
                                style = TextStyle(color = Color(0xFFDDE3FF), fontSize = 13.sp, shadow = shadow),
                                modifier = Modifier.padding(start = 12.dp, top = 8.dp),
                            )
                        }
                    }
                }
            }
            Column(
                Modifier.fillMaxWidth().padding(bottom = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Row(
                    Modifier.glass(CircleShape).clickable { focusSearch = true; drawer = true }
                        .padding(horizontal = 20.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    EonMark(Modifier.size(16.dp), brush = SolidColor(Eon.Periwinkle))
                    Spacer(Modifier.width(10.dp))
                    Text("Search apps", color = Color(0xFFC9D1F5), fontSize = 14.sp)
                }
                Gap(12)
                Row(
                    Modifier.clip(CircleShape).clickable { homeMenu = true }
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    state.pages.forEachIndexed { i, _ ->
                        val on = i == pagerState.currentPage
                        if (i == 0) {
                            EonMark(Modifier.size(16.dp), brush = SolidColor(if (on) Eon.Text else Color(0x80A0B2FF)))
                        } else {
                            Box(
                                Modifier.size(if (on) 8.dp else 6.dp).clip(CircleShape)
                                    .background(if (on) Eon.Text else Color(0x73A0B2FF)),
                            )
                        }
                    }
                }
                Gap(12)
                Box(
                    Modifier.fillMaxWidth().glass(RoundedCornerShape(34.dp))
                        .padding(horizontal = 6.dp, vertical = 6.dp),
                ) {
                    ReorderGrid(
                        items = dockApps,
                        idOf = { it.key },
                        columns = 4,
                        cellHeight = 76.dp,
                        onMove = { from, to -> moveDock(from, to) },
                        onTap = { repo.launch(it) },
                        onMenu = { menuApp = it },
                        modifier = Modifier.fillMaxWidth(),
                    ) { AppIconBody(it, 56.dp, false) }
                }
            }
        }

        AnimatedVisibility(
            visible = drawer,
            enter = slideInVertically { it / 3 } + fadeIn(),
            exit = slideOutVertically { it / 3 } + fadeOut(),
        ) {
            Drawer(
                apps = visible, state = state, focusSearch = focusSearch,
                onLaunch = { app -> repo.launch(app); drawer = false },
                onMenu = { app -> menuApp = app },
            )
        }

        if (settings) SettingsScreen(state, { settings = false }, onResetGreeting)
        if (widgetScreen) WidgetsScreen(state, widgets) { widgetScreen = false }
    }

    menuApp?.let { app ->
        AppMenu(
            app, state,
            inDock = dockApps.any { it.key == app.key },
            canAddToDock = dockApps.size < 4,
            onToggleDock = { toggleDock(app) },
        ) { menuApp = null }
    }
    if (homeMenu) {
        val cur = pagerState.currentPage
        HomeMenu(
            onDismiss = { homeMenu = false },
            onWidgets = { homeMenu = false; widgetScreen = true },
            onAddLeft = { homeMenu = false; state.addPage(cur) },
            onAddRight = { homeMenu = false; state.addPage(cur + 1); scrollTo = cur + 1 },
            canRemove = state.pages.size > 1 && state.pages.getOrNull(cur)?.isEmpty == true,
            onRemove = { homeMenu = false; state.removePage(cur) },
            onSettings = { homeMenu = false; settings = true },
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppIcon(
    app: AppEntry, iconSize: Dp, showLabel: Boolean,
    onClick: () -> Unit, onLongClick: () -> Unit,
) {
    Box(
        Modifier.clip(RoundedCornerShape(16.dp))
            .combinedClickable(onClick = onClick, onLongClick = onLongClick),
    ) { AppIconBody(app, iconSize, showLabel) }
}

/** The icon, badge and label, without any touch handling. */
@Composable
fun AppIconBody(app: AppEntry, iconSize: Dp, showLabel: Boolean) {
    val count = Badges.counts[app.packageName] ?: 0
    Column(
        Modifier.padding(vertical = 6.dp, horizontal = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box {
            Image(bitmap = app.icon, contentDescription = app.label, modifier = Modifier.size(iconSize))
            if (count > 0) {
                Box(
                    Modifier.align(Alignment.TopEnd).offset(x = 5.dp, y = (-4).dp)
                        .defaultMinSize(minWidth = 18.dp, minHeight = 18.dp)
                        .clip(CircleShape).background(Eon.BlueLight)
                        .border(1.5.dp, Color(0xFFF4F6FF), CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        if (count > 99) "99+" else "$count", color = Color.White,
                        fontSize = 10.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 4.dp),
                    )
                }
            }
        }
        if (showLabel) {
            Gap(6)
            Text(
                app.label, color = Eon.Text, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                style = TextStyle(shadow = Shadow(Color(0x99000000), Offset(0f, 1f), 4f)),
            )
        }
    }
}

/** Pulls down the system notification shade (needs the EXPAND_STATUS_BAR permission). */
fun expandNotifications(ctx: android.content.Context) {
    try {
        val service = ctx.getSystemService("statusbar") ?: return
        service.javaClass.getMethod("expandNotificationsPanel").invoke(service)
    } catch (_: Exception) {
    }
}
