package ix.app.eon

import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener

val LocalLook = compositionLocalOf { "glassy" }

const val GRID_COLS = 4

/** Something placed on a home page: an app ("a") or a widget ("w") on a grid cell, with a size in cells. */
class Item(val kind: String, val key: String, col: Int, row: Int, w: Int, h: Int) {
    var col by mutableIntStateOf(col)
    var row by mutableIntStateOf(row)
    var w by mutableIntStateOf(w)
    var h by mutableIntStateOf(h)
}

/** One home page. The legacy lists only hold data from versions before v0.9 until it is migrated. */
class PageData(
    var legacyPinned: List<String> = emptyList(),
    var legacyWidgets: List<Int> = emptyList(),
) {
    val items = mutableStateListOf<Item>()
}

private fun JSONArray.strings(): List<String> = (0 until length()).map { getString(it) }
private fun JSONArray.ints(): List<Int> = (0 until length()).map { getInt(it) }

/** Everything the user can change, kept in memory and saved to [Prefs]. */
class EonState(private val prefs: Prefs) {
    var look by mutableStateOf(prefs.look)
        private set
    val pages = mutableStateListOf<PageData>().also { it.addAll(loadPages()) }
    var currentPage by mutableIntStateOf(0)
    var gridRows by mutableIntStateOf(6)
    val dock = mutableStateListOf<String>().also { it.addAll(prefs.dock) }
    var dockCustom by mutableStateOf(prefs.dockCustom)
        private set
    val hidden = mutableStateListOf<String>().also { it.addAll(prefs.hidden) }
    val overrides = mutableStateMapOf<String, String>().also { it.putAll(prefs.overrides) }

    // ---- saving and loading
    private fun loadPages(): List<PageData> {
        val raw = prefs.pagesJson
        if (raw.isBlank()) return listOf(PageData(prefs.pinned, prefs.widgets))
        return try {
            val root = JSONTokener(raw).nextValue()
            if (root is JSONObject) {
                val arr = root.getJSONArray("pages")
                (0 until arr.length()).map { i ->
                    val page = PageData()
                    val items = arr.getJSONObject(i).getJSONArray("items")
                    for (j in 0 until items.length()) {
                        val o = items.getJSONObject(j)
                        page.items.add(
                            Item(o.getString("t"), o.getString("k"), o.getInt("c"), o.getInt("r"), o.getInt("w"), o.getInt("h")),
                        )
                    }
                    page
                }.ifEmpty { listOf(PageData()) }
            } else {
                // v0.5 to v0.8 format: plain lists per page
                val arr = root as JSONArray
                (0 until arr.length()).map { i ->
                    val o = arr.getJSONObject(i)
                    PageData(o.getJSONArray("pinned").strings(), o.getJSONArray("widgets").ints())
                }.ifEmpty { listOf(PageData()) }
            }
        } catch (_: Exception) {
            listOf(PageData(prefs.pinned, prefs.widgets))
        }
    }

    private fun savePages() {
        val pagesArr = JSONArray()
        pages.forEach { p ->
            val items = JSONArray()
            p.items.forEach { i ->
                items.put(
                    JSONObject().put("t", i.kind).put("k", i.key)
                        .put("c", i.col).put("r", i.row).put("w", i.w).put("h", i.h),
                )
            }
            pagesArr.put(JSONObject().put("items", items))
        }
        prefs.pagesJson = JSONObject().put("v", 2).put("pages", pagesArr).toString()
    }

    /** Moves data from older versions onto the grid: widgets first, then apps, in the order they had. */
    fun migrate(sizeOf: (Int) -> Pair<Int, Int>) {
        var changed = false
        pages.forEach { p ->
            if (p.legacyWidgets.isNotEmpty() || p.legacyPinned.isNotEmpty()) {
                changed = true
                p.legacyWidgets.forEach { id ->
                    val (w, h) = sizeOf(id)
                    place(p, "w", id.toString(), w, h, 20)
                }
                p.legacyPinned.forEach { k -> place(p, "a", k, 1, 1, 20) }
                p.legacyWidgets = emptyList()
                p.legacyPinned = emptyList()
            }
        }
        if (changed) savePages()
    }

    fun chooseLook(value: String) {
        look = value
        prefs.look = value
    }

    // ---- grid helpers
    private fun fits(p: PageData, c: Int, r: Int, w: Int, h: Int, rows: Int, ignore: Item? = null): Boolean {
        if (c < 0 || r < 0 || w < 1 || h < 1 || c + w > GRID_COLS || r + h > rows) return false
        return p.items.none {
            it !== ignore && c < it.col + it.w && c + w > it.col && r < it.row + it.h && r + h > it.row
        }
    }

    private fun firstFree(p: PageData, w: Int, h: Int, rows: Int): Pair<Int, Int>? {
        for (r in 0..(rows - h)) {
            for (c in 0..(GRID_COLS - w)) {
                if (fits(p, c, r, w, h, rows)) return c to r
            }
        }
        return null
    }

    private fun place(p: PageData, kind: String, key: String, w: Int, h: Int, rows: Int = gridRows): Boolean {
        val spot = firstFree(p, w, h, rows) ?: return false
        p.items.add(Item(kind, key, spot.first, spot.second, w, h))
        return true
    }

    // ---- apps on pages
    fun isPinned(key: String): Boolean = pages.any { p -> p.items.any { it.kind == "a" && it.key == key } }

    /** Pins or unpins an app. Returns false when there is no free cell on the current page. */
    fun togglePin(key: String): Boolean {
        val holder = pages.firstOrNull { p -> p.items.any { it.kind == "a" && it.key == key } }
        if (holder != null) {
            holder.items.removeAll { it.kind == "a" && it.key == key }
            savePages()
            return true
        }
        val page = pages.getOrNull(currentPage) ?: return false
        val ok = place(page, "a", key, 1, 1)
        if (ok) savePages()
        return ok
    }

    /** Drops an app on a cell: moves it if the cell is free, swaps with another app, ignores widgets. */
    fun moveApp(pageIndex: Int, key: String, col: Int, row: Int) {
        val page = pages.getOrNull(pageIndex) ?: return
        val me = page.items.firstOrNull { it.kind == "a" && it.key == key } ?: return
        val other = page.items.firstOrNull {
            it !== me && col >= it.col && col < it.col + it.w && row >= it.row && row < it.row + it.h
        }
        when {
            other == null -> {
                me.col = col
                me.row = row
            }
            other.kind == "a" -> {
                other.col = me.col
                other.row = me.row
                me.col = col
                me.row = row
            }
            else -> return
        }
        savePages()
    }

    // ---- widgets
    fun widgetItems(): List<Item> = pages.getOrNull(currentPage)?.items?.filter { it.kind == "w" } ?: emptyList()

    fun allWidgets(): List<Int> =
        pages.flatMap { p -> p.items.filter { it.kind == "w" }.mapNotNull { it.key.toIntOrNull() } }

    /** Returns false when the current page has no room for a widget of this size. */
    fun addWidget(id: Int, w: Int, h: Int): Boolean {
        val page = pages.getOrNull(currentPage) ?: return false
        if (page.items.any { it.kind == "w" && it.key == id.toString() }) return true
        val ok = place(page, "w", id.toString(), w, h)
        if (ok) savePages()
        return ok
    }

    fun removeWidget(id: Int) {
        pages.forEach { p -> p.items.removeAll { it.kind == "w" && it.key == id.toString() } }
        savePages()
    }

    fun nudgeWidget(key: String, dc: Int, dr: Int) {
        val p = pages.getOrNull(currentPage) ?: return
        val it = p.items.firstOrNull { x -> x.kind == "w" && x.key == key } ?: return
        if (fits(p, it.col + dc, it.row + dr, it.w, it.h, gridRows, it)) {
            it.col += dc
            it.row += dr
            savePages()
        }
    }

    fun resizeWidget(key: String, dw: Int, dh: Int) {
        val p = pages.getOrNull(currentPage) ?: return
        val it = p.items.firstOrNull { x -> x.kind == "w" && x.key == key } ?: return
        val w = (it.w + dw).coerceIn(1, GRID_COLS)
        val h = (it.h + dh).coerceIn(1, 4)
        if (fits(p, it.col, it.row, w, h, gridRows, it)) {
            it.w = w
            it.h = h
            savePages()
        }
    }

    // ---- pages
    fun addPage(index: Int) {
        pages.add(index.coerceIn(0, pages.size), PageData())
        savePages()
    }

    fun removePage(index: Int) {
        if (pages.size > 1 && index in pages.indices && pages[index].items.isEmpty()) {
            pages.removeAt(index)
            savePages()
        }
    }

    // ---- dock
    fun setDock(keys: List<String>) {
        dock.clear()
        dock.addAll(keys)
        dockCustom = true
        prefs.dock = keys
        prefs.dockCustom = true
    }

    // ---- hidden apps and categories
    fun hide(pkg: String) {
        if (pkg !in hidden) hidden.add(pkg)
        prefs.hidden = hidden.toSet()
    }

    fun showAllApps() {
        hidden.clear()
        prefs.hidden = emptySet()
    }

    fun setCategory(pkg: String, category: String) {
        overrides[pkg] = category
        prefs.overrides = overrides.toMap()
    }
}
