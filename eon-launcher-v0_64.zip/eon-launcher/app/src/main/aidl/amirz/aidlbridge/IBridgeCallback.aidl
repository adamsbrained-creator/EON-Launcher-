package amirz.aidlbridge;

import android.content.ComponentName;
import android.os.IBinder;

interface IBridgeCallback {
    oneway void onServiceConnected(in ComponentName name, in IBinder service);

    oneway void onServiceDisconnected(in ComponentName name);
}
