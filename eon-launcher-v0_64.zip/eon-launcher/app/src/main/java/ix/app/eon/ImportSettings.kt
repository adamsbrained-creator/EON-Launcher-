package ix.app.eon

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

private val PanelColor = Color(0xFF0D0D0F)
private val LineColor = Color(0xFF1E1E22)

@Composable
private fun Panel(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(PanelColor)
            .border(1.dp, LineColor, RoundedCornerShape(24.dp)).padding(16.dp),
        content = content,
    )
}

@Composable
private fun PillButton(text: String, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().height(48.dp).clip(CircleShape).background(Eon.Button).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(text, color = Eon.OnAccent, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold) }
}

@Composable
private fun OptionRow(title: String, detail: String, on: Boolean?, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text(detail, color = Eon.Muted, fontSize = 13.sp, lineHeight = 18.sp)
        }
        if (on != null) EonSwitch(on, onChange)
    }
}

/** Settings hub > Import from Smart Launcher. */
@Composable
fun SmartLauncherImportPage(state: EonState, onBack: () -> Unit) {
    BackHandler { onBack() }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var stage by remember { mutableStateOf("start") } // start, reading, ready, done or error
    var plan by remember { mutableStateOf<SlPlan?>(null) }
    var result by remember { mutableStateOf<SmartLauncherImport.Result?>(null) }
    var apps by remember { mutableStateOf<List<AppEntry>>(emptyList()) }
    var appsReady by remember { mutableStateOf(false) }
    var optHome by remember { mutableStateOf(true) }
    var optHidden by remember { mutableStateOf(true) }
    var optCats by remember { mutableStateOf(true) }
    var optLook by remember { mutableStateOf(true) }
    var optPack by remember { mutableStateOf(true) }
    var presetsSaved by remember { mutableIntStateOf(-1) }

    LaunchedEffect(Unit) {
        apps = AppRepo(ctx).load()
        appsReady = true
    }
    DisposableEffect(Unit) { onDispose { SmartLauncherImport.cleanUp(ctx) } }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            stage = "reading"
            scope.launch {
                val backup = SmartLauncherImport.read(ctx, uri)
                if (backup == null) {
                    stage = "error"
                } else {
                    while (!appsReady) delay(50)
                    plan = withContext(Dispatchers.Default) { SmartLauncherImport.plan(ctx, backup, apps) }
                    stage = "ready"
                }
            }
        }
    }

    Column(
        Modifier.fillMaxSize().background(Color(0xF7000000)).systemBarsPadding().padding(horizontal = 16.dp)
            .verticalScroll(rememberScrollState()),
    ) {
        Gap(12)
        PageHeader("Import from Smart Launcher", onBack)
        Gap(22)

        when (stage) {
            "start", "error" -> {
                Panel {
                    Text("Bring your layout over", color = Eon.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Gap(6)
                    Text(
                        "Choose a Smart Launcher backup (a .slbk file). Eon reads your home pages, folders, hidden apps, " +
                            "drawer categories, app names and the icons you picked.",
                        color = Eon.Muted, fontSize = 14.sp, lineHeight = 20.sp,
                    )
                    if (stage == "error") {
                        Gap(10)
                        Text("That file is not a Smart Launcher backup, or it could not be read.", color = Eon.Danger, fontSize = 14.sp)
                    }
                    Gap(16)
                    PillButton("Choose backup file") { pick.launch(arrayOf("*/*")) }
                }
            }
            "reading" -> Panel {
                Text("Reading the backup…", color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
            "ready" -> {
                val p = plan
                if (p != null) {
                    SettingsSectionLabel("WHAT TO IMPORT")
                    Panel {
                        OptionRow(
                            "Home screen",
                            "${p.pages.size} pages, ${p.homeApps} apps, ${p.folders} folders. This replaces your current home screen.",
                            optHome,
                        ) { optHome = it }
                        OptionRow("Hidden apps", "${p.hidden.size} apps hidden from the drawer", optHidden) { optHidden = it }
                        OptionRow(
                            "Drawer categories",
                            "${p.cats.size} categories: " + p.cats.joinToString(", ") { it.name },
                            optCats,
                        ) { optCats = it }
                        OptionRow(
                            "Names and icons",
                            "${p.labels.size} renamed apps, ${p.icons.size} icons you picked",
                            optLook,
                        ) { optLook = it }
                        if (p.pack.isNotEmpty()) {
                            if (p.packInstalled) {
                                OptionRow("Icon pack", p.packName, optPack) { optPack = it }
                            } else {
                                OptionRow("Icon pack", "${p.packName} is not installed here. Install it and choose it in Icon packs.", null) {}
                            }
                        }
                    }
                    if (p.missingApps > 0) {
                        Gap(8)
                        Text(
                            "${p.missingApps} apps in the backup are not installed on this phone and are skipped.",
                            color = Eon.Faint, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.padding(horizontal = 6.dp),
                        )
                    }
                    val topWidgets = p.widgets.count { it.parent == null }
                    if (topWidgets > 0) {
                        Gap(8)
                        Text(
                            "$topWidgets widgets cannot be moved over, because Android ties each widget to the launcher that added it. " +
                                "You will be able to save the Kustom widget presets after importing.",
                            color = Eon.Faint, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.padding(horizontal = 6.dp),
                        )
                    }
                    Gap(16)
                    PillButton("Import") {
                        val r = SmartLauncherImport.apply(ctx, state, p, ImportOptions(optHome, optHidden, optCats, optLook, optPack))
                        result = r
                        stage = "done"
                    }
                }
            }
            "done" -> {
                val r = result
                val p = plan
                if (r != null && p != null) {
                    SettingsSectionLabel("DONE")
                    Panel {
                        val lines = ArrayList<String>()
                        if (r.pages > 0) lines.add("${r.pages} home pages with ${r.homeApps} apps and ${r.folders} folders")
                        if (r.hidden > 0) lines.add("${r.hidden} hidden apps")
                        if (r.cats > 0) lines.add("${r.cats} drawer categories")
                        if (r.renamed > 0) lines.add("${r.renamed} apps renamed")
                        if (r.icons > 0) lines.add("${r.icons} custom icons")
                        if (r.packApplied) lines.add("Icon pack: ${p.packName}")
                        if (lines.isEmpty()) lines.add("Nothing was selected.")
                        lines.forEach { Text(it, color = Eon.Text, fontSize = 15.sp, modifier = Modifier.padding(vertical = 3.dp)) }
                    }

                    val top = p.widgets.filter { it.parent == null }
                    if (top.isNotEmpty()) {
                        Gap(22)
                        SettingsSectionLabel("WIDGETS TO ADD AGAIN")
                        Panel {
                            val pm = ctx.packageManager
                            top.forEach { w ->
                                val pkg = w.provider.substringBefore('/')
                                val name = try {
                                    pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
                                } catch (_: Exception) {
                                    pkg
                                }
                                val where = "Page ${w.screen + 1}, ${w.w.roundToInt()}×${w.h.roundToInt()}"
                                val detail = if (w.isStack) {
                                    val n = p.widgets.count { it.parent == w.id }
                                    "$where, a stack of $n widgets"
                                } else {
                                    where
                                }
                                Column(Modifier.padding(vertical = 6.dp)) {
                                    Text(if (w.isStack) "Widget stack" else name, color = Eon.Text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                    Text(detail, color = Eon.Muted, fontSize = 13.sp)
                                }
                            }
                            val kustom = p.widgets.count { it.preset != null }
                            if (kustom > 0) {
                                Gap(10)
                                Text(
                                    "$kustom of these are Kustom (KWGT) widgets. Their full designs are in the backup, and Eon can save each one as a .kwgt file for KWGT to load.",
                                    color = Eon.Faint, fontSize = 12.sp, lineHeight = 17.sp,
                                )
                                Gap(12)
                                if (presetsSaved < 0) {
                                    PillButton("Save Kustom presets to Downloads") {
                                        presetsSaved = SmartLauncherImport.savePresets(ctx, p.widgets)
                                        Toast.makeText(ctx, "Saved $presetsSaved presets", Toast.LENGTH_SHORT).show()
                                    }
                                } else {
                                    Text(
                                        "Saved $presetsSaved presets in Downloads > Eon widgets.",
                                        color = Eon.Text, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                                    )
                                }
                            }
                        }
                    }
                    Gap(16)
                    PillButton("Done") { onBack() }
                }
            }
        }
        Gap(28)
    }
}
