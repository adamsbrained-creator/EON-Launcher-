package ix.app.eon

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.os.Build

/** The names of the icon styles, in the order of [IconStyle.mode]. */
val ICON_STYLES = listOf("Original", "Themed", "Themed dark", "Dark", "Tinted")

/** Colours offered for themed and tinted icons. The first entry (0) means "take it from the wallpaper". */
val ICON_TINTS = listOf(
    0, 0xFF35D6F0.toInt(), 0xFF4F8CFF.toInt(), 0xFF9B7BFF.toInt(), 0xFFF25CCB.toInt(), 0xFFFF7A66.toInt(),
    0xFFFFA63D.toInt(), 0xFF4CD98A.toInt(), 0xFF9AA0A6.toInt(),
)

/**
 * How every app icon is coloured, like Android's themed icons and iOS dark and tinted icons.
 * - Themed / Themed dark: the app's one-colour layer on a plate in your colour (apps without one are recoloured).
 * - Dark: the normal icon, dimmed.
 * - Tinted: the icon turned into shades of your colour.
 * Applied to icons Eon draws itself. Icons from an icon pack, or ones you chose yourself, stay as they are.
 */
object IconStyle {
    @Volatile var mode: Int = 0
    @Volatile var tint: Int = 0
    private var appContext: Context? = null

    fun load(ctx: Context, p: Prefs) {
        appContext = ctx.applicationContext
        mode = p.getInt("iconStyle", 0).coerceIn(0, ICON_STYLES.size - 1)
        tint = p.getInt("iconTint", 0)
    }

    fun save(p: Prefs) {
        p.putInt("iconStyle", mode)
        p.putInt("iconTint", tint)
    }

    /** The colour in use: the one you picked, else the wallpaper's main colour, else cyan. */
    fun resolved(): Int {
        if (tint != 0) return tint
        try {
            val c = appContext?.let { WallpaperManager.getInstance(it).getWallpaperColors(WallpaperManager.FLAG_SYSTEM) }
            if (c != null) return c.primaryColor.toArgb()
        } catch (_: Exception) {
        }
        return 0xFF35D6F0.toInt()
    }

    /** Goes into the icon cache key, so icons are rebuilt when the style or the colour changes. */
    fun signature(): String = if (mode == 0) "s0" else "s$mode:${Integer.toHexString(resolved())}"

    private fun hsv(base: Int, sat: Float, value: Float): Int {
        val h = FloatArray(3)
        Color.colorToHSV(base, h)
        // A grey base (very low saturation) stays grey.
        val s = if (h[1] < 0.08f) 0f else (h[1] * sat).coerceIn(0f, 1f)
        return Color.HSVToColor(floatArrayOf(h[0], s, value))
    }

    /** Recolours [content], the icon already drawn at full size, according to the style. Returns [content] itself for Original. */
    fun restyle(src: Drawable, content: Bitmap, px: Int): Bitmap {
        if (mode == 0) return content
        val base = resolved()
        val out = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        when (mode) {
            3 -> {
                val cm = ColorMatrix().apply { setSaturation(0.85f) }
                cm.postConcat(ColorMatrix().apply { setScale(0.6f, 0.6f, 0.6f, 1f) })
                c.drawBitmap(content, 0f, 0f, Paint().apply { colorFilter = ColorMatrixColorFilter(cm) })
            }
            1, 2 -> {
                val dark = mode == 2
                val plate = if (dark) hsv(base, 0.45f, 0.22f) else hsv(base, 0.22f, 0.96f)
                val glyph = if (dark) hsv(base, 0.25f, 0.93f) else hsv(base, 0.9f, 0.34f)
                val mono: Drawable? = if (Build.VERSION.SDK_INT >= 33 && src is AdaptiveIconDrawable) src.monochrome else null
                if (mono != null) {
                    c.drawColor(plate)
                    val d = mono.mutate()
                    val inset = (px * 0.25f).toInt()
                    d.setBounds(-inset, -inset, px + inset, px + inset)
                    d.setTint(glyph)
                    d.draw(c)
                } else {
                    // No one-colour layer: dark parts of the icon take the glyph colour, light parts the plate colour.
                    c.drawBitmap(content, 0f, 0f, Paint().apply { colorFilter = duotone(glyph, plate) })
                }
            }
            else -> {
                // Tinted: dark parts stay near black, light parts take the colour.
                c.drawBitmap(content, 0f, 0f, Paint().apply { colorFilter = duotone(hsv(base, 0.6f, 0.12f), hsv(base, 0.75f, 0.97f)) })
            }
        }
        content.recycle()
        return out
    }

    /** Maps brightness to a colour between [dark] and [light], keeping transparency. */
    private fun duotone(dark: Int, light: Int): ColorMatrixColorFilter {
        fun row(a: Int, b: Int): FloatArray {
            val d = (b - a).toFloat()
            return floatArrayOf(d * 0.299f, d * 0.587f, d * 0.114f, 0f, a.toFloat())
        }
        val r = row(Color.red(dark), Color.red(light))
        val g = row(Color.green(dark), Color.green(light))
        val b = row(Color.blue(dark), Color.blue(light))
        return ColorMatrixColorFilter(ColorMatrix(r + g + b + floatArrayOf(0f, 0f, 0f, 1f, 0f)))
    }
}
