package ix.app.eon

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountBalance
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.Bolt
import androidx.compose.material.icons.outlined.Bookmark
import androidx.compose.material.icons.outlined.Brush
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.Call
import androidx.compose.material.icons.outlined.Cloud
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.Computer
import androidx.compose.material.icons.outlined.DirectionsCar
import androidx.compose.material.icons.outlined.Event
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.FitnessCenter
import androidx.compose.material.icons.outlined.Flight
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Headphones
import androidx.compose.material.icons.outlined.Healing
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Lightbulb
import androidx.compose.material.icons.outlined.LocalBar
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Mail
import androidx.compose.material.icons.outlined.Map
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.MoreHoriz
import androidx.compose.material.icons.outlined.MusicNote
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.People
import androidx.compose.material.icons.outlined.Pets
import androidx.compose.material.icons.outlined.PhotoCamera
import androidx.compose.material.icons.outlined.Place
import androidx.compose.material.icons.outlined.PlayCircle
import androidx.compose.material.icons.outlined.Payments
import androidx.compose.material.icons.outlined.Restaurant
import androidx.compose.material.icons.outlined.School
import androidx.compose.material.icons.outlined.Settings as SettingsIcon
import androidx.compose.material.icons.outlined.ShoppingBag
import androidx.compose.material.icons.outlined.ShoppingCart
import androidx.compose.material.icons.outlined.Sms
import androidx.compose.material.icons.outlined.Smartphone
import androidx.compose.material.icons.outlined.SportsEsports
import androidx.compose.material.icons.outlined.SportsSoccer
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material.icons.outlined.TaskAlt
import androidx.compose.material.icons.outlined.TheaterComedy
import androidx.compose.material.icons.outlined.Tv
import androidx.compose.material.icons.outlined.Videocam
import androidx.compose.material.icons.outlined.WbSunny
import androidx.compose.material.icons.outlined.Work
import androidx.compose.material.icons.outlined.Public
import androidx.compose.ui.graphics.vector.ImageVector

/** Id of the first, fixed category that lists every app. */
const val CAT_ALL = "all"

/** A category in the drawer's bottom bar. [id] never changes; [name] and [icon] can be edited. */
data class DrawerCat(val id: String, val name: String, val icon: String)

/** A ready-made category. Eon fills it by itself from each app's type and name (Favorites you fill by hand). */
class CatDef(val id: String, val name: String, val icon: String)

/** The list on the "Add category" screen. */
val CATALOG: List<CatDef> = listOf(
    CatDef("contacts", "Contacts", "chat"),
    CatDef("education", "Education", "school"),
    CatDef("entertainment", "Entertainment", "masks"),
    CatDef("favorites", "Favorites", "star"),
    CatDef("finance", "Finance", "money"),
    CatDef("fitness", "Fitness", "heart"),
    CatDef("games", "Games", "game"),
    CatDef("internet", "Internet", "globe"),
    CatDef("lifestyle", "Lifestyle", "cocktail"),
    CatDef("media", "Media", "play"),
    CatDef("medical", "Medical", "bandage"),
    CatDef("music", "Music", "music"),
    CatDef("navigation", "Navigation", "compass"),
    CatDef("other", "Other", "more"),
    CatDef("personalization", "Personalization", "palette"),
    CatDef("photography", "Photography", "camera"),
    CatDef("productivity", "Productivity", "check"),
    CatDef("reading", "Reading", "book"),
    CatDef("shopping", "Shopping", "bag"),
    CatDef("social", "Social", "people"),
    CatDef("tools", "Tools", "tools"),
    CatDef("travel", "Travel", "plane"),
    CatDef("weather", "Weather", "sun"),
)

/** What a new install shows in the bottom bar, left to right. */
fun defaultCategories(): List<DrawerCat> {
    val first = DrawerCat(CAT_ALL, "All apps", "apps")
    val rest = listOf("social", "media", "games", "productivity", "tools").mapNotNull { id ->
        CATALOG.firstOrNull { it.id == id }?.let { DrawerCat(it.id, it.name, it.icon) }
    }
    return listOf(first) + rest
}

/** Before v0.13 an app's manual category was stored by its display name. */
private val LEGACY = mapOf(
    "Social" to "social", "Media" to "media", "Games" to "games", "Work" to "productivity",
    "Reading" to "reading", "Maps" to "navigation", "Tools" to "tools", "Other" to "other",
)

fun legacyCategory(value: String): String = LEGACY[value] ?: value

/** Every icon a category can use ("Edit icon" shows them in this order). */
val CAT_ICONS: Map<String, ImageVector> by lazy {
    linkedMapOf(
        "apps" to Icons.Outlined.Apps,
        "folder" to Icons.Outlined.Folder,
        "star" to Icons.Outlined.Star,
        "heart" to Icons.Outlined.FavoriteBorder,
        "chat" to Icons.Outlined.Sms,
        "call" to Icons.Outlined.Call,
        "mail" to Icons.Outlined.Mail,
        "people" to Icons.Outlined.People,
        "school" to Icons.Outlined.School,
        "masks" to Icons.Outlined.TheaterComedy,
        "money" to Icons.Outlined.Payments,
        "bank" to Icons.Outlined.AccountBalance,
        "game" to Icons.Outlined.SportsEsports,
        "soccer" to Icons.Outlined.SportsSoccer,
        "gym" to Icons.Outlined.FitnessCenter,
        "globe" to Icons.Outlined.Public,
        "cloud" to Icons.Outlined.Cloud,
        "cocktail" to Icons.Outlined.LocalBar,
        "food" to Icons.Outlined.Restaurant,
        "play" to Icons.Outlined.PlayCircle,
        "video" to Icons.Outlined.Videocam,
        "tv" to Icons.Outlined.Tv,
        "music" to Icons.Outlined.MusicNote,
        "headphones" to Icons.Outlined.Headphones,
        "bandage" to Icons.Outlined.Healing,
        "compass" to Icons.Outlined.Explore,
        "map" to Icons.Outlined.Map,
        "pin" to Icons.Outlined.Place,
        "car" to Icons.Outlined.DirectionsCar,
        "plane" to Icons.Outlined.Flight,
        "palette" to Icons.Outlined.Palette,
        "brush" to Icons.Outlined.Brush,
        "image" to Icons.Outlined.Image,
        "camera" to Icons.Outlined.PhotoCamera,
        "check" to Icons.Outlined.TaskAlt,
        "work" to Icons.Outlined.Work,
        "computer" to Icons.Outlined.Computer,
        "phone" to Icons.Outlined.Smartphone,
        "code" to Icons.Outlined.Code,
        "book" to Icons.Outlined.MenuBook,
        "bookmark" to Icons.Outlined.Bookmark,
        "event" to Icons.Outlined.Event,
        "bag" to Icons.Outlined.ShoppingBag,
        "cart" to Icons.Outlined.ShoppingCart,
        "tools" to Icons.Outlined.Build,
        "settings" to Icons.Outlined.SettingsIcon,
        "lock" to Icons.Outlined.Lock,
        "bulb" to Icons.Outlined.Lightbulb,
        "bolt" to Icons.Outlined.Bolt,
        "sun" to Icons.Outlined.WbSunny,
        "pets" to Icons.Outlined.Pets,
        "home" to Icons.Outlined.Home,
        "more" to Icons.Outlined.MoreHoriz,
    )
}

fun catIcon(key: String): ImageVector = CAT_ICONS[key] ?: Icons.Outlined.Folder
