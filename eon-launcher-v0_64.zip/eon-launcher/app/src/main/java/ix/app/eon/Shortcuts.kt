package ix.app.eon

import android.content.Context
import android.content.pm.LauncherApps
import android.content.pm.ShortcutInfo
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** One of an app's own shortcuts, such as Camera > Selfie. */
class AppShortcut(val info: ShortcutInfo, val label: String, val icon: ImageBitmap?)

/**
 * The shortcuts an app offers (up to [limit]). Android only lets the current home app read them, so this
 * is empty until Eon is the default home app.
 */
suspend fun loadShortcuts(ctx: Context, app: AppEntry, limit: Int = 4): List<AppShortcut> =
    withContext(Dispatchers.IO) {
        try {
            val launcherApps = ctx.getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps
            if (!launcherApps.hasShortcutHostPermission()) return@withContext emptyList()
            val query = LauncherApps.ShortcutQuery()
                .setPackage(app.packageName)
                .setQueryFlags(LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST)
            val found = launcherApps.getShortcuts(query, app.user).orEmpty()
            found
                .filter { it.isEnabled && (it.activity == null || it.activity == app.component) }
                .sortedBy { it.rank }
                .take(limit)
                .map { info ->
                    val label = (info.shortLabel ?: info.longLabel)?.toString().orEmpty().ifBlank { app.label }
                    val icon = try {
                        launcherApps.getShortcutIconDrawable(info, ctx.resources.displayMetrics.densityDpi)
                            ?.let { IconShaper.shape(it, 96).asImageBitmap() }
                    } catch (_: Exception) {
                        null
                    }
                    AppShortcut(info, label, icon)
                }
        } catch (_: Exception) {
            emptyList()
        }
    }

fun startShortcut(ctx: Context, shortcut: AppShortcut) {
    try {
        val launcherApps = ctx.getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps
        launcherApps.startShortcut(shortcut.info, null, null)
    } catch (_: Exception) {
    }
}

@Composable
fun ShortcutRow(shortcut: AppShortcut, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        if (shortcut.icon != null) Image(shortcut.icon, null, Modifier.size(28.dp))
        Text(
            shortcut.label, color = Eon.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium,
            maxLines = 1, overflow = TextOverflow.Ellipsis,
        )
    }
}
