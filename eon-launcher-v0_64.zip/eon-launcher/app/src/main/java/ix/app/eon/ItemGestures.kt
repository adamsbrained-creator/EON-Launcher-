package ix.app.eon

import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.AwaitPointerEventScope
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerInputChange
import androidx.compose.ui.unit.dp
import org.json.JSONObject
import kotlin.math.abs

const val G_UP = "up"
const val G_DOWN = "down"
const val G_LEFT = "left"
const val G_RIGHT = "right"
const val G_DOUBLE = "double"

/** The gestures an app, folder or widget can have, in the order they are listed. */
val ITEM_GESTURES = listOf(
    G_UP to "Swipe up", G_DOWN to "Swipe down", G_LEFT to "Swipe left", G_RIGHT to "Swipe right", G_DOUBLE to "Double tap",
)

/** What a request to edit the gestures of one thing refers to. [kind] is "a" (app), "f" (folder) or "w" (widget). */
class GestureTarget(val kind: String, val key: String, val title: String) {
    val id: String get() = "$kind:$key"
}

/** Gestures you gave to single apps, folders and widgets. Saved as one piece of JSON. */
object ItemGestures {
    private val map = mutableStateMapOf<String, Map<String, String>>()
    private var prefs: Prefs? = null

    fun load(p: Prefs) {
        prefs = p
        map.clear()
        try {
            val root = JSONObject(p.getString("itemGestures").ifEmpty { "{}" })
            root.keys().forEach { target ->
                val o = root.getJSONObject(target)
                val m = HashMap<String, String>()
                o.keys().forEach { g -> m[g] = o.getString(g) }
                if (m.isNotEmpty()) map[target] = m
            }
        } catch (_: Exception) {
        }
    }

    private fun save() {
        val root = JSONObject()
        map.forEach { (t, m) ->
            val o = JSONObject()
            m.forEach { (g, a) -> o.put(g, a) }
            root.put(t, o)
        }
        prefs?.putString("itemGestures", root.toString())
    }

    fun get(target: String, gesture: String): String? = map[target]?.get(gesture)

    fun count(target: String): Int = map[target]?.size ?: 0

    /** Gives [gesture] an action, or removes it when [action] is null or "none". */
    fun set(target: String, gesture: String, action: String?) {
        val m = HashMap(map[target] ?: emptyMap())
        if (action == null || action == Act.NONE) m.remove(gesture) else m[gesture] = action
        if (m.isEmpty()) map.remove(target) else map[target] = m
        save()
    }

    fun clear(target: String) {
        if (map.remove(target) != null) save()
    }

    /** Forget everything for a thing that no longer exists. */
    fun forget(target: String) = clear(target)
}

fun swipeName(d: Offset): String =
    if (abs(d.x) > abs(d.y)) (if (d.x > 0f) G_RIGHT else G_LEFT) else (if (d.y > 0f) G_DOWN else G_UP)

/**
 * Called when a press on an icon moved past the touch slop before it could become a long press. If the thing has an
 * action for the way the finger is going, this takes the rest of the touch (so the pages do not scroll), lets the icon
 * follow the finger a little through [onNudge] and runs the action when the finger is let go far enough.
 * With no action for that direction it does nothing, so the pages scroll as before.
 */
suspend fun AwaitPointerEventScope.trackSwipe(
    down: PointerInputChange, target: String, pass: PointerEventPass,
    onNudge: (Offset) -> Unit, onFire: (String) -> Unit,
) {
    val now = currentEvent.changes.firstOrNull { it.id == down.id } ?: return
    if (!now.pressed) return
    val first = now.position - down.position
    if (ItemGestures.get(target, swipeName(first)) == null) return
    currentEvent.changes.forEach { it.consume() }
    val threshold = 40.dp.toPx()
    var cur = first
    onNudge(cur * 0.3f)
    while (true) {
        val ev = awaitPointerEvent(pass)
        val c = ev.changes.firstOrNull { it.id == down.id } ?: break
        c.consume()
        cur = c.position - down.position
        onNudge(cur * 0.3f)
        if (!c.pressed) break
    }
    onNudge(Offset.Zero)
    val g = swipeName(cur)
    val action = ItemGestures.get(target, g) ?: return
    val along = if (g == G_UP || g == G_DOWN) abs(cur.y) else abs(cur.x)
    if (along >= threshold) onFire(action)
}

/**
 * After a tap on something that has a double-tap action: waits a moment for a second tap. Returns true (and has used
 * the second tap) when it came, false when it did not and the tap should go ahead as a single tap.
 */
suspend fun AwaitPointerEventScope.secondTap(): Boolean {
    val second = withTimeoutOrNull(viewConfiguration.doubleTapTimeoutMillis) {
        awaitFirstDownIn()
    } ?: return false
    second.consume()
    waitForUpOrCancellation()
    return true
}

private suspend fun AwaitPointerEventScope.awaitFirstDownIn(): PointerInputChange {
    while (true) {
        val ev = awaitPointerEvent()
        val c = ev.changes.firstOrNull { it.pressed && it.previousPressed.not() }
        if (c != null) return c
    }
}
