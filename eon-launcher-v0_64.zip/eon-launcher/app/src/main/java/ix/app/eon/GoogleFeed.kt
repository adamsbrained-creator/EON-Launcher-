package ix.app.eon

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Process
import android.os.RemoteException
import android.view.WindowManager
import amirz.aidlbridge.IBridge
import amirz.aidlbridge.IBridgeCallback
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.google.android.libraries.launcherclient.ILauncherOverlay
import com.google.android.libraries.launcherclient.ILauncherOverlayCallback

/**
 * Google's feed (Discover) as the page left of Home. EXPERIMENTAL.
 *
 * The Google app draws the feed in its own window and slides it in as you swipe. Launchers talk to it through a small
 * "bridge" app (Smart Launcher's Bridge, Lawnfeed, AIDL Bridge), which you install yourself. The speaking part follows
 * the open protocol used by Lawnchair and Google's own launcher client (Apache 2.0). Eon only ever connects to the one
 * bridge you choose in Settings > Feed.
 */
object GoogleFeed {
    const val ACTION = "com.android.launcher3.WINDOW_OVERLAY"
    private const val BRIDGE_DESCRIPTOR = "amirz.aidlbridge.IBridge"

    /** On when you switched it on; [provider] is the package of the bridge you chose. */
    var enabled by mutableStateOf(false)
        private set
    var provider by mutableStateOf("")
        private set

    /** True once the bridge has accepted Eon and the feed is ready to be swiped in. */
    var connected by mutableStateOf(false)
        private set

    /** How far the feed has slid in, 0 (closed) to 1 (open). Home slides away by the same amount. */
    var progress by mutableFloatStateOf(0f)
        private set

    val active: Boolean get() = enabled && connected

    /** What happened while connecting, newest last. Shown in Settings > Feed so a failure can be understood. */
    val log = mutableStateListOf<String>()

    fun note(text: String) {
        val line = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date()) + "  " + text
        main.post {
            log.add(line)
            while (log.size > 40) log.removeAt(0)
        }
    }

    /** Disconnects and connects again, as if Eon had just started. */
    fun reconnect() {
        note("Reconnecting")
        restart()
        client?.pushState()
    }

    private var activity: Activity? = null
    private var client: Client? = null
    private var activityState = 0
    private val main = Handler(Looper.getMainLooper())

    fun load(p: Prefs) {
        enabled = p.getBool("gFeedOn", false)
        provider = p.getString("gFeedPkg")
    }

    private fun save(ctx: Context) {
        val p = Prefs(ctx)
        p.putBool("gFeedOn", enabled)
        p.putString("gFeedPkg", provider)
    }

    /** Apps on this phone that offer a feed over the launcher protocol, as (package, name). */
    fun providers(ctx: Context): List<Pair<String, String>> = try {
        val pm = ctx.packageManager
        pm.queryIntentServices(Intent(ACTION).setData(Uri.parse("app://${ctx.packageName}")), 0)
            .map { it.serviceInfo.applicationInfo }
            .distinctBy { it.packageName }
            .filter { it.packageName != "com.google.android.googlequicksearchbox" }
            .map { it.packageName to it.loadLabel(pm).toString() }
    } catch (_: Exception) {
        emptyList()
    }

    fun setEnabled(ctx: Context, on: Boolean) {
        enabled = on
        save(ctx)
        restart()
    }

    fun choose(ctx: Context, pkg: String) {
        provider = pkg
        save(ctx)
        restart()
    }

    fun status(ctx: Context): String = when {
        !enabled -> "Off"
        provider.isEmpty() -> "Pick a bridge app below"
        connected -> "Connected"
        providers(ctx).none { it.first == provider } -> "That bridge app is not installed"
        else -> "Not connected. Open the Google app once, then press Home."
    }

    // ---- hooks from MainActivity

    fun create(a: Activity) {
        activity = a
        restart()
    }

    fun onAttached() { client?.setLayoutParams(activity?.window?.attributes) }
    fun onDetached() { client?.setLayoutParams(null) }
    fun onStart() { activityState = activityState or 1; client?.connect(); client?.pushState() }
    fun onResume() { activityState = activityState or 2; client?.pushState() }
    fun onPause() { activityState = activityState and 2.inv(); client?.pushState() }
    fun onStop() { activityState = activityState and 1.inv(); client?.pushState() }
    fun destroy() { client?.destroy(); client = null; activity = null }

    private fun restart() {
        client?.destroy()
        client = null
        connected = false
        progress = 0f
        val a = activity ?: return
        if (!enabled || provider.isEmpty()) return
        note("Connecting to $provider")
        client = Client(a, provider).also {
            it.connect()
            if (a.window?.peekDecorView()?.isAttachedToWindow == true) it.setLayoutParams(a.window.attributes)
        }
    }

    // ---- what Home calls while you drag

    fun startScroll() { client?.run { overlay?.let { try { it.startScroll() } catch (_: RemoteException) {} } } }
    fun scroll(f: Float) { client?.run { overlay?.let { try { it.onScroll(f.coerceIn(0f, 1f)) } catch (_: RemoteException) {} } } }
    fun endScroll() { client?.run { overlay?.let { try { it.endScroll() } catch (_: RemoteException) {} } } }
    fun open() { client?.run { overlay?.let { try { it.openOverlay(1) } catch (_: RemoteException) {} } } }
    fun close() { client?.run { overlay?.let { try { it.closeOverlay(1) } catch (_: RemoteException) {} } } }

    private class Client(val act: Activity, val pkg: String) {
        var overlay: ILauncherOverlay? = null
        private var layoutParams: WindowManager.LayoutParams? = null
        private var serviceState = 0
        private var destroyed = false
        private var sawScroll = false
        // The version the Google app speaks, read from the Google app itself (the bridge does not say). Newer is 7.
        private val apiVersion: Int = try {
            val gsa = Intent(ACTION).setPackage("com.google.android.googlequicksearchbox").setData(intent().data)
            act.packageManager.resolveService(gsa, PackageManager.GET_META_DATA)
                ?.serviceInfo?.metaData?.getInt("service.api.version", 1) ?: 7
        } catch (_: Exception) {
            7
        }
        private val callback = object : ILauncherOverlayCallback.Stub() {
            override fun overlayScrollChanged(progress: Float) {
                if (!sawScroll) { sawScroll = true; note("Feed is moving (first scroll update)") }
                main.post { if (!destroyed && serviceState and 1 != 0) GoogleFeed.progress = progress.coerceIn(0f, 1f) }
            }

            override fun overlayStatusChanged(status: Int) {
                note("Feed status changed: $status (feed ready: ${status and 1 != 0})")
                main.post { if (!destroyed) setServiceState(status) }
            }
        }
        // The first connection only keeps the Google app alive; the second one receives the overlay.
        private val keepAlive = Conn(Context.BIND_AUTO_CREATE or Context.BIND_IMPORTANT, false)
        private val receiver = Conn(Context.BIND_AUTO_CREATE or Context.BIND_WAIVE_PRIORITY, true)

        fun intent(): Intent = Intent(ACTION).setPackage(pkg).setData(
            Uri.parse("app://${act.packageName}:${Process.myUid()}").buildUpon()
                .appendQueryParameter("v", "7").appendQueryParameter("cv", "9").build(),
        )

        fun connect() {
            if (destroyed) return
            val r = receiver.bind()
            val k = keepAlive.bind()
            note("Bind: feed connection $r, keep-alive $k, api version $apiVersion")
            if (!(r && k)) main.post { setServiceState(0) }
        }

        fun destroy() {
            destroyed = true
            try { overlay?.windowDetached(false) } catch (_: Exception) {}
            keepAlive.unbind()
            receiver.unbind()
            overlay = null
            GoogleFeed.connected = false
            GoogleFeed.progress = 0f
        }

        fun setLayoutParams(lp: WindowManager.LayoutParams?) {
            if (layoutParams === lp) return
            layoutParams = lp
            if (lp != null) {
                exchangeConfig()
            } else {
                try { overlay?.windowDetached(act.isChangingConfigurations) } catch (_: RemoteException) {}
            }
        }

        fun pushState() {
            val o = overlay ?: return
            if (layoutParams == null) return
            try { o.setActivityState(activityState) } catch (_: RemoteException) {}
        }

        private fun exchangeConfig() {
            val o = overlay ?: return
            val lp = layoutParams ?: return
            note("Sending window to the feed (api $apiVersion, state $activityState)")
            try {
                if (apiVersion < 3) {
                    o.windowAttached(lp, callback, FLAGS)
                } else {
                    val b = Bundle()
                    b.putParcelable("layout_params", lp)
                    b.putParcelable("configuration", act.resources.configuration)
                    b.putInt("client_options", FLAGS)
                    o.windowAttached2(b, callback)
                }
                if (apiVersion >= 4) o.setActivityState(activityState)
                else if (activityState and 2 != 0) o.onResume() else o.onPause()
            } catch (e: Exception) {
                note("Could not send window: ${e.javaClass.simpleName} ${e.message}")
            }
        }

        fun attachOverlay(o: ILauncherOverlay?) {
            overlay = o
            note(if (o == null) "Feed service lost" else "Feed service received")
            if (o == null) setServiceState(0) else if (layoutParams != null) exchangeConfig()
        }

        private fun setServiceState(s: Int) {
            if (serviceState == s) return
            serviceState = s
            GoogleFeed.connected = s and 1 != 0
            if (!GoogleFeed.connected) GoogleFeed.progress = 0f
        }

        private inner class Conn(val flags: Int, val receives: Boolean) : ServiceConnection {
            private var bound = false
            private var bridged = false

            fun bind(): Boolean {
                if (!bound) {
                    bound = try {
                        act.applicationContext.bindService(intent(), this, flags)
                    } catch (t: Throwable) {
                        note("Bind refused: ${t.javaClass.simpleName} ${t.message}")
                        false
                    }
                }
                return bound
            }

            fun unbind() {
                if (bound) {
                    try { act.applicationContext.unbindService(this) } catch (_: Exception) {}
                    bound = false
                }
            }

            private fun deliver(s: IBinder?) {
                if (receives) main.post { if (!destroyed) attachOverlay(s?.let { ILauncherOverlay.Stub.asInterface(it) }) }
            }

            override fun onNullBinding(name: ComponentName) {
                note("The service gave nothing back (${if (receives) "feed" else "keep-alive"} connection)")
            }

            override fun onBindingDied(name: ComponentName) {
                note("The service died (${if (receives) "feed" else "keep-alive"} connection)")
            }

            override fun onServiceConnected(name: ComponentName, service: IBinder) {
                val d = try { service.interfaceDescriptor } catch (_: Exception) { "?" }
                note("Service connected (${if (receives) "feed" else "keep-alive"}): ${name.className.substringAfterLast('.')} / $d")
                try {
                    if (BRIDGE_DESCRIPTOR == service.interfaceDescriptor) {
                        IBridge.Stub.asInterface(service).bindService(object : IBridgeCallback.Stub() {
                            override fun onServiceConnected(name: ComponentName, service: IBinder) {
                                bridged = true
                                note("Bridge passed on the feed service")
                                deliver(service)
                            }

                            override fun onServiceDisconnected(name: ComponentName) {
                                if (bridged) {
                                    bridged = false
                                    deliver(null)
                                }
                            }
                        }, flags)
                    } else {
                        deliver(service)
                    }
                } catch (e: Exception) {
                    note("Error talking to the bridge: ${e.javaClass.simpleName} ${e.message}")
                }
            }

            override fun onServiceDisconnected(name: ComponentName) {
                note("Service disconnected")
                if (!bridged) deliver(null)
            }
        }

        companion object {
            /** Feed on, plus the options Lawnchair sends (2, 4 and 8). */
            const val FLAGS = 1 or 2 or 4 or 8
        }
    }
}
