package ix.app.eon

import android.content.ComponentName
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipInputStream
import kotlin.math.roundToInt

// ---- what is read from a Smart Launcher backup (a .slbk file)

class SlApp(val component: String, val label: String, val customIcon: File?)

/** Something on a Smart Launcher home page: an app ("a") or a folder ("f"), on a cell. */
class SlItem(val kind: String, val col: Int, val row: Int, val app: SlApp?, val name: String, val members: List<SlApp>)

class SlWidget(
    val id: Int, val provider: String, val screen: Int, val col: Float, val row: Float, val w: Float, val h: Float,
    val isStack: Boolean, val parent: Int?, val preset: File?,
)

class SlDrawerApp(
    val pkg: String, val activity: String, val label: String, val category: String, val hidden: Boolean, val customIcon: File?,
)

class SlCategory(val id: String, val label: String?)

class SlBackup(
    val pages: List<List<SlItem>>,
    val widgets: List<SlWidget>,
    val drawer: List<SlDrawerApp>,
    val categories: List<SlCategory>,
    val iconPack: String,
)

// ---- what will be done in Eon

/** One thing to put on an Eon page. */
class ImportItem(val kind: String, val key: String, val name: String, val members: List<String>, val col: Int, val row: Int)

class SlPlan(
    val pages: List<List<ImportItem>>,
    val rowsNeeded: Int,
    val homeApps: Int,
    val folders: Int,
    val missingApps: Int,
    val hidden: Set<String>,
    val cats: List<DrawerCat>,
    val overrides: Map<String, String>,
    val labels: Map<String, String>,
    val icons: Map<String, File>,
    val pack: String,
    val packName: String,
    val packInstalled: Boolean,
    val widgets: List<SlWidget>,
)

class ImportOptions(
    val home: Boolean = true,
    val hidden: Boolean = true,
    val categories: Boolean = true,
    val namesAndIcons: Boolean = true,
    val iconPack: Boolean = true,
)

object SmartLauncherImport {
    private val COMPONENT = Regex("component=([^;]+);")

    /** Opens the backup (the .slbk file, or a zip that holds it) and reads the layout. Null if it is not one. */
    suspend fun read(ctx: Context, uri: Uri): SlBackup? = withContext(Dispatchers.IO) {
        try {
            val root = File(ctx.cacheDir, "slimport")
            root.deleteRecursively()
            root.mkdirs()
            val tmp = File(root, "in.zip")
            val input = ctx.contentResolver.openInputStream(uri) ?: return@withContext null
            input.use { src -> tmp.outputStream().use { dst -> src.copyTo(dst) } }
            val out = File(root, "x")
            out.mkdirs()
            unzip(tmp, out)
            var base = out
            if (!File(out, "databases/ginlemon.flower.db").exists()) {
                // A zip that only wraps the .slbk file.
                val inner = out.walkTopDown().firstOrNull { it.isFile && it.extension.equals("slbk", true) }
                    ?: return@withContext null
                val out2 = File(root, "y")
                out2.mkdirs()
                unzip(inner, out2)
                base = out2
            }
            tmp.delete()
            parse(base)
        } catch (_: Exception) {
            null
        }
    }

    /** Clears what was unpacked. */
    fun cleanUp(ctx: Context) {
        File(ctx.cacheDir, "slimport").deleteRecursively()
    }

    private fun unzip(zip: File, dest: File) {
        val canon = dest.canonicalPath + File.separator
        ZipInputStream(zip.inputStream().buffered()).use { zin ->
            var e = zin.nextEntry
            while (e != null) {
                val f = File(dest, e.name)
                if (f.canonicalPath.startsWith(canon)) {
                    if (e.isDirectory) {
                        f.mkdirs()
                    } else {
                        f.parentFile?.mkdirs()
                        f.outputStream().use { zin.copyTo(it) }
                    }
                }
                e = zin.nextEntry
            }
        }
    }

    private class Act(val id: Int, val type: Int, val component: String?, val label: String)

    private fun componentOf(intent: String?): String? {
        if (intent == null) return null
        val m = COMPONENT.find(intent) ?: return null
        return Uri.decode(m.groupValues[1])
    }

    private fun parse(base: File): SlBackup? {
        val dbFile = File(base, "databases/ginlemon.flower.db")
        if (!dbFile.exists()) return null
        val db = SQLiteDatabase.openDatabase(dbFile.path, null, SQLiteDatabase.OPEN_READONLY)
        try {
            // Every launchable's actions: action 1 is what a tap does (an app, or a folder).
            val actions = HashMap<Int, MutableList<Act>>()
            db.rawQuery("select idLaunchable, actionId, type, intentUri, label from Action", null).use { c ->
                while (c.moveToNext()) {
                    actions.getOrPut(c.getInt(0)) { ArrayList() }
                        .add(Act(c.getInt(1), c.getInt(2), componentOf(c.getString(3)), c.getString(4) ?: ""))
                }
            }
            val children = HashMap<Int, MutableList<Pair<Int, Int>>>() // folder id -> (position, child id)
            db.rawQuery("select id, idParentFolderLaunchable, position from Launchable where idParentFolderLaunchable is not null", null).use { c ->
                while (c.moveToNext()) children.getOrPut(c.getInt(1)) { ArrayList() }.add(c.getInt(2) to c.getInt(0))
            }
            val homeIcons = File(base, "files/icons/home/custom")
            val drawerIcons = File(base, "files/icons/drawer/custom")

            fun appOf(lid: Int): SlApp? {
                val list = actions[lid] ?: return null
                val a = list.filter { it.type == 7 && it.component != null }.minByOrNull { it.id } ?: return null
                val icon = File(homeIcons, "ic_${lid}_${a.id}.png").takeIf { it.exists() }
                return SlApp(a.component!!, a.label, icon)
            }

            val pageMap = sortedMapOf<Int, MutableList<SlItem>>()
            val widgetPlace = ArrayList<List<Any>>() // widget id, screen, col, row, w, h
            db.rawQuery(
                "select idLaunchable, idWidget, screen, cellX, cellY, spanX, spanY from HomeItem order by screen, cellY, cellX", null,
            ).use { c ->
                while (c.moveToNext()) {
                    val screen = c.getInt(2)
                    val list = pageMap.getOrPut(screen) { ArrayList() }
                    if (!c.isNull(1)) {
                        widgetPlace.add(listOf(c.getInt(1), screen, c.getFloat(3), c.getFloat(4), c.getFloat(5), c.getFloat(6)))
                        continue
                    }
                    if (c.isNull(0)) continue
                    val lid = c.getInt(0)
                    val col = c.getFloat(3).roundToInt()
                    val row = c.getFloat(4).roundToInt()
                    val acts = actions[lid] ?: continue
                    val folderAct = acts.firstOrNull { it.type == 9 }
                    if (folderAct != null) {
                        val members = (children[lid] ?: emptyList<Pair<Int, Int>>()).sortedBy { it.first }.mapNotNull { appOf(it.second) }
                        list.add(SlItem("f", col, row, null, folderAct.label.trim(), members))
                    } else {
                        val app = appOf(lid) ?: continue
                        list.add(SlItem("a", col, row, app, "", emptyList()))
                    }
                }
            }

            // Widgets, and the children of widget stacks.
            val widgetRows = HashMap<Int, List<Any?>>() // id -> type, parent, provider
            db.rawQuery("select id, type, parentId, provider from Widget", null).use { c ->
                while (c.moveToNext()) widgetRows[c.getInt(0)] = listOf(c.getInt(1), if (c.isNull(2)) null else c.getInt(2), c.getString(3) ?: "")
            }
            fun presetOf(id: Int) = File(base, "files/metadata/widget_backups/org.kustom.widget-$id").takeIf { it.exists() }
            val widgets = ArrayList<SlWidget>()
            for (p in widgetPlace) {
                val id = p[0] as Int
                val row = widgetRows[id] ?: continue
                val isStack = row[0] == 4
                widgets.add(
                    SlWidget(id, row[2] as String, p[1] as Int, p[2] as Float, p[3] as Float, p[4] as Float, p[5] as Float, isStack, null, presetOf(id)),
                )
                if (isStack) {
                    widgetRows.filter { it.value[1] == id }.toSortedMap().forEach { (cid, v) ->
                        widgets.add(SlWidget(cid, v[2] as String, p[1] as Int, 0f, 0f, 0f, 0f, false, id, presetOf(cid)))
                    }
                }
            }

            val drawer = ArrayList<SlDrawerApp>()
            db.rawQuery("select id, label, categoryId, hidden, packageName, activityName from DrawerItem where packageName is not null", null).use { c ->
                while (c.moveToNext()) {
                    val icon = File(drawerIcons, "ic_${c.getInt(0)}.png").takeIf { it.exists() }
                    drawer.add(SlDrawerApp(c.getString(4), c.getString(5) ?: "", c.getString(1) ?: "", c.getString(2) ?: "", c.getInt(3) != 0, icon))
                }
            }
            val cats = ArrayList<SlCategory>()
            db.rawQuery("select id, customLabel from Category where enabled = 1 order by position", null).use { c ->
                while (c.moveToNext()) cats.add(SlCategory(c.getString(0), c.getString(1)?.trim()?.ifEmpty { null }))
            }
            var pack = ""
            try {
                val info = JSONObject(File(base, "files/metadata/info").readText())
                val comp = info.optJSONObject("components")
                pack = comp?.optString("flowerIconPack").orEmpty().ifEmpty { comp?.optString("drawerIconPack").orEmpty() }
            } catch (_: Exception) {
            }
            return SlBackup(pageMap.values.toList(), widgets, drawer, cats, pack)
        } finally {
            db.close()
        }
    }

    private class Matcher(apps: List<AppEntry>) {
        private val byKey = apps.associateBy { it.key }
        private val byPkg = apps.groupBy { it.packageName }

        fun find(component: String): AppEntry? {
            val cn = ComponentName.unflattenFromString(component) ?: return null
            return byKey[cn.flattenToString()] ?: byPkg[cn.packageName]?.firstOrNull()
        }

        fun exact(pkg: String, activity: String): AppEntry? = byKey["$pkg/$activity"]
    }

    /** Works out what the backup means for this phone: which apps are installed, and what goes where. */
    fun plan(ctx: Context, b: SlBackup, apps: List<AppEntry>): SlPlan {
        val m = Matcher(apps)
        val used = HashSet<String>()
        val icons = HashMap<String, File>()
        var homeApps = 0
        var folders = 0
        var missing = 0
        var rowsNeeded = 0
        val stamp = java.lang.Long.toString(System.currentTimeMillis(), 36)
        var folderNo = 0

        val pages = b.pages.map { items ->
            val out = ArrayList<ImportItem>()
            for (it in items) {
                rowsNeeded = maxOf(rowsNeeded, it.row + 1)
                if (it.kind == "a") {
                    val app = m.find(it.app!!.component)
                    if (app == null) {
                        missing++
                    } else if (used.add(app.key)) {
                        out.add(ImportItem("a", app.key, "", emptyList(), it.col, it.row))
                        homeApps++
                        it.app.customIcon?.let { f -> icons[app.key] = f }
                    }
                } else {
                    val keys = ArrayList<String>()
                    for (member in it.members) {
                        val app = m.find(member.component)
                        if (app == null) {
                            missing++
                        } else if (used.add(app.key)) {
                            keys.add(app.key)
                            homeApps++
                            member.customIcon?.let { f -> icons[app.key] = f }
                        }
                    }
                    when {
                        keys.size >= 2 -> {
                            out.add(ImportItem("f", "folder:$stamp${folderNo++}", it.name, keys, it.col, it.row))
                            folders++
                        }
                        keys.size == 1 -> out.add(ImportItem("a", keys[0], "", emptyList(), it.col, it.row))
                    }
                }
            }
            out as List<ImportItem>
        }

        // Pictures you picked in the drawer fill in the apps that did not get one on the home screen.
        val labels = HashMap<String, String>()
        val pm = ctx.packageManager
        for (d in b.drawer) {
            val app = m.exact(d.pkg, d.activity) ?: continue
            d.customIcon?.let { f -> if (app.key !in icons) icons[app.key] = f }
            val original = try {
                pm.getActivityInfo(app.component, 0).loadLabel(pm).toString().trim()
            } catch (_: Exception) {
                continue
            }
            val label = d.label.trim()
            if (label.isNotEmpty() && label != original) labels[app.key] = label
        }

        val hidden = b.drawer.filter { it.hidden }.map { it.pkg }.toSet()

        // The drawer's category bar, in the same order. Categories Eon has keep their id; the rest become your own.
        val cats = ArrayList<DrawerCat>()
        val idFor = HashMap<String, String>()
        b.categories.forEachIndexed { i, c ->
            val def = CATALOG.firstOrNull { it.id == c.id }
            val id = def?.id ?: ("c" + System.currentTimeMillis() + i)
            val name = c.label ?: def?.name ?: c.id.removePrefix("custom-").substringBeforeLast('-').replaceFirstChar { it.uppercase() }
            val icon = def?.icon ?: if (c.id == "settings") "tools" else if (c.id == "business") "more" else "folder"
            idFor[c.id] = id
            cats.add(DrawerCat(id, name, icon))
        }
        val overrides = HashMap<String, String>()
        for (d in b.drawer) idFor[d.category]?.let { overrides[d.pkg] = it }

        val installedPacks = IconPacks.installed(ctx)
        val packInfo = installedPacks.firstOrNull { it.pkg == b.iconPack }
        val packName = packInfo?.label ?: try {
            pm.getApplicationLabel(pm.getApplicationInfo(b.iconPack, 0)).toString()
        } catch (_: Exception) {
            b.iconPack
        }
        return SlPlan(
            pages, rowsNeeded, homeApps, folders, missing, hidden, cats, overrides, labels, icons,
            b.iconPack, packName, packInfo != null, b.widgets,
        )
    }

    class Result(
        val homeApps: Int, val folders: Int, val pages: Int, val hidden: Int, val cats: Int, val renamed: Int, val icons: Int,
        val packApplied: Boolean,
    )

    /** Puts the plan into Eon. This replaces the parts you leave ticked. */
    fun apply(ctx: Context, state: EonState, plan: SlPlan, o: ImportOptions): Result {
        var pages = 0
        if (o.home) {
            if (plan.rowsNeeded > state.gridRows) state.chooseRows(plan.rowsNeeded.coerceAtMost(12))
            state.importHome(plan.pages)
            pages = plan.pages.size
        }
        if (o.hidden) state.setHiddenPackages(plan.hidden)
        if (o.categories) {
            state.replaceCategories(plan.cats)
            state.setOverrides(plan.overrides)
        }
        var renamed = 0
        var icons = 0
        if (o.namesAndIcons) {
            for ((key, label) in plan.labels) {
                IconCustom.setLabel(key, label)
                renamed++
            }
            for ((key, file) in plan.icons) {
                val name = IconCustom.importFile(file) ?: continue
                IconCustom.setIcon(key, "img:$name")
                icons++
            }
        }
        var packApplied = false
        if (o.iconPack && plan.packInstalled && plan.pack.isNotEmpty()) {
            state.chooseIconPack(plan.pack)
            packApplied = true
        }
        state.applyImportedAppLook()
        return Result(plan.homeApps, plan.folders, pages, if (o.hidden) plan.hidden.size else 0, if (o.categories) plan.cats.size else 0, renamed, icons, packApplied)
    }

    /**
     * Saves each Kustom (KWGT) widget's preset from the backup as a .kwgt file in Downloads/Eon widgets, so KWGT can
     * load it again. Returns how many were saved.
     */
    fun savePresets(ctx: Context, widgets: List<SlWidget>): Int {
        var saved = 0
        for (w in widgets) {
            val src = w.preset ?: continue
            val where = if (w.parent != null) "stack on page ${w.screen + 1}" else "page ${w.screen + 1} ${w.w.roundToInt()}x${w.h.roundToInt()}"
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, "Kustom widget ${w.id} ($where).kwgt")
                put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Eon widgets")
            }
            try {
                val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: continue
                ctx.contentResolver.openOutputStream(uri)?.use { out -> src.inputStream().use { it.copyTo(out) } }
                saved++
            } catch (_: Exception) {
            }
        }
        return saved
    }
}
