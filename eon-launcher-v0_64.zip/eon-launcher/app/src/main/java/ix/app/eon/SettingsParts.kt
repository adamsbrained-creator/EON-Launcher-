package ix.app.eon

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs

// Pieces shared by the settings pages (Grid, Dock, Wallpaper), in the style of the settings hub.

private val SECTION_COLORS = listOf(
    Color(0xFF35D6F0), Color(0xFF4F8CFF), Color(0xFF9B7BFF),
    Color(0xFFF25CCB), Color(0xFFFF7A66), Color(0xFFFFA63D),
)

/** A section title: a short coloured line and spaced capitals. The colour comes from the rainbow, by the title. */
@Composable
fun SettingsSectionLabel(text: String) {
    val color = SECTION_COLORS[abs(text.hashCode()) % SECTION_COLORS.size]
    Row(
        Modifier.padding(start = 2.dp, bottom = 10.dp, top = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Box(Modifier.size(width = 22.dp, height = 3.dp).clip(CircleShape).background(color))
        Text(text, color = color, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.6.sp)
    }
}

/** Round back button and a bold title. */
@Composable
fun PageHeader(title: String, onBack: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        Box(
            Modifier.size(44.dp).clip(CircleShape).background(Color(0xFF161618)).border(1.dp, Color(0xFF28282C), CircleShape)
                .clickable(onClick = onBack),
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Outlined.ArrowBack, "Back", tint = Eon.Text, modifier = Modifier.size(22.dp)) }
        Text(title, color = Eon.Text, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
    }
}

/** The rainbow switch. */
@Composable
fun EonSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    Box(
        Modifier.size(width = 52.dp, height = 32.dp).clip(CircleShape)
            .background(if (checked) Eon.Button else SolidColor(Color(0xFF2A2A2E)))
            .clickable { onChange(!checked) }.padding(4.dp),
        contentAlignment = if (checked) Alignment.CenterEnd else Alignment.CenterStart,
    ) {
        Box(Modifier.size(24.dp).clip(CircleShape).background(if (checked) Color.White else Color(0xFF8A8C93)))
    }
}
