package ix.app.eon

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntRect
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupPositionProvider
import androidx.compose.ui.window.PopupProperties
import kotlinx.coroutines.delay

private val PopupColor = Color(0xFF1B1B1D)
private val CARD_WIDTH = 240.dp
private val ARROW_WIDTH = 20.dp

/** An extra row at the bottom of the category menu (for example "Drawer settings"). */
class PopupAction(val icon: ImageVector, val label: String, val onClick: () -> Unit)

/**
 * The small menu that opens above a category icon: Add category, Edit icon, Rename and (except for
 * All apps) Remove. [anchor] is where the icon is on screen; the arrow points at it.
 */
@Composable
fun CategoryPopup(
    title: String, anchor: Rect?, canRemove: Boolean,
    onAdd: () -> Unit, onEditIcon: () -> Unit, onRename: () -> Unit, onRemove: () -> Unit,
    onDismiss: () -> Unit,
    extras: List<PopupAction> = emptyList(),
) {
    val density = LocalDensity.current
    val screenW = with(density) { LocalConfiguration.current.screenWidthDp.dp.roundToPx() }
    val cardW = with(density) { CARD_WIDTH.roundToPx() }
    val margin = with(density) { 12.dp.roundToPx() }
    val gap = with(density) { 6.dp.roundToPx() }

    val centerX = anchor?.center?.x?.toInt() ?: (screenW / 2)
    val left = (centerX - cardW / 2).coerceIn(margin, maxOf(margin, screenW - cardW - margin))
    val arrowStart: Dp = with(density) { (centerX - left).toDp() } - ARROW_WIDTH / 2

    val provider = remember(anchor, left) {
        object : PopupPositionProvider {
            override fun calculatePosition(
                anchorBounds: IntRect, windowSize: IntSize,
                layoutDirection: LayoutDirection, popupContentSize: IntSize,
            ): IntOffset {
                val iconTop = anchor?.top?.toInt() ?: (windowSize.height - margin * 8)
                return IntOffset(left, maxOf(margin, iconTop - popupContentSize.height - gap))
            }
        }
    }

    Popup(
        popupPositionProvider = provider,
        onDismissRequest = onDismiss,
        properties = PopupProperties(focusable = true),
    ) {
        Column(Modifier.width(CARD_WIDTH)) {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(PopupColor)
                    .padding(vertical = 8.dp),
            ) {
                Text(
                    title, color = Eon.Muted, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(start = 22.dp, end = 22.dp, top = 12.dp, bottom = 6.dp),
                )
                PopupRow(Icons.Outlined.Add, "Add category", Eon.Text, onAdd)
                PopupRow(Icons.Outlined.Image, "Edit icon", Eon.Text, onEditIcon)
                PopupRow(Icons.Outlined.Edit, "Rename", Eon.Text, onRename)
                extras.forEach { PopupRow(it.icon, it.label, Eon.Text, it.onClick) }
                if (canRemove) {
                    Box(
                        Modifier.fillMaxWidth().padding(vertical = 6.dp).height(1.dp)
                            .background(Color(0x1FFFFFFF)),
                    )
                    PopupRow(Icons.Outlined.Delete, "Remove", Eon.Danger, onRemove)
                }
            }
            Canvas(Modifier.padding(start = arrowStart.coerceIn(16.dp, CARD_WIDTH - ARROW_WIDTH - 16.dp)).size(ARROW_WIDTH, 10.dp)) {
                val tip = Path().apply {
                    moveTo(0f, 0f)
                    lineTo(size.width, 0f)
                    lineTo(size.width / 2f, size.height)
                    close()
                }
                drawPath(tip, PopupColor)
            }
        }
    }
}

@Composable
private fun PopupRow(icon: ImageVector, text: String, color: Color, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 22.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        Icon(icon, null, tint = color, modifier = Modifier.size(24.dp))
        Text(text, color = color, fontSize = 16.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun DialogButton(label: String, primary: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.clip(CircleShape).clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label, color = if (primary) Eon.Accent else Eon.Soft, fontSize = 15.sp,
            fontWeight = if (primary) FontWeight.Bold else FontWeight.Medium,
        )
    }
}

/** A small dialog with one line of text, used to rename a category. */
@Composable
fun NameDialog(title: String, initial: String, onDone: (String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(TextFieldValue(initial, TextRange(0, initial.length))) }
    val focus = remember { FocusRequester() }
    Dialog(onDismissRequest = onDismiss) {
        LaunchedEffect(Unit) {
            delay(80)
            try {
                focus.requestFocus()
            } catch (_: Exception) {
            }
        }
        Column(Modifier.width(300.dp).glass(RoundedCornerShape(26.dp)).padding(20.dp)) {
            Text(title, color = Eon.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Gap(14)
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0x1FFFFFFF))
                    .padding(horizontal = 14.dp, vertical = 12.dp),
            ) {
                BasicTextField(
                    value = text,
                    onValueChange = { text = it },
                    singleLine = true,
                    textStyle = TextStyle(color = Eon.Text, fontSize = 16.sp),
                    cursorBrush = SolidColor(Eon.Accent),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = {
                        if (text.text.isNotBlank()) onDone(text.text.trim())
                    }),
                    modifier = Modifier.fillMaxWidth().focusRequester(focus),
                )
            }
            Gap(12)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                DialogButton("Cancel", false, onDismiss)
                DialogButton("Save", true) { if (text.text.isNotBlank()) onDone(text.text.trim()) }
            }
        }
    }
}

/** Every icon a category can use, in a grid. The one in use is highlighted. */
@Composable
fun IconPickerDialog(current: String, onPick: (String) -> Unit, onDismiss: () -> Unit) {
    val keys = remember { CAT_ICONS.keys.toList() }
    Dialog(onDismissRequest = onDismiss) {
        Column(Modifier.width(320.dp).glass(RoundedCornerShape(26.dp)).padding(horizontal = 16.dp, vertical = 20.dp)) {
            Text(
                "Choose an icon", color = Eon.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 4.dp),
            )
            Gap(14)
            LazyVerticalGrid(
                columns = GridCells.Fixed(5),
                modifier = Modifier.heightIn(max = 340.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(keys, key = { it }) { key ->
                    val on = key == current
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Box(
                            Modifier.size(50.dp).clip(CircleShape)
                                .accentFill(on, Color(0x1FFFFFFF))
                                .clickable { onPick(key) },
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                catIcon(key), null,
                                tint = if (on) Eon.OnAccent else Eon.Text,
                                modifier = Modifier.size(24.dp),
                            )
                        }
                    }
                }
            }
        }
    }
}
