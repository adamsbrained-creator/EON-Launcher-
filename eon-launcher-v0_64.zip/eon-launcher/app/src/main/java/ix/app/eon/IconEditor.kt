package ix.app.eon

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material.icons.outlined.Replay
import androidx.compose.material.icons.outlined.Restore
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

private val PanelColor = Color(0xFF0D0D0F)
private val LineColor = Color(0xFF1E1E22)

@Composable
private fun EditorDivider() {
    Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp).height(1.dp).background(Color(0x24FFFFFF)))
}

@Composable
private fun EditorRow(icon: ImageVector, text: String, color: Color = Eon.Text, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Icon(icon, null, tint = if (color == Eon.Text) Eon.Soft else color, modifier = Modifier.size(20.dp))
        Text(text, color = color, fontSize = 15.sp, fontWeight = FontWeight.Medium)
    }
}

/** Long-press menu > Rename: a small box to type the app's new name. Empty or the original name puts it back. */
@Composable
fun RenameAppDialog(app: AppEntry, state: EonState, onBack: () -> Unit, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val original = remember(app.key) {
        try {
            ctx.packageManager.getActivityInfo(app.component, 0).loadLabel(ctx.packageManager).toString()
        } catch (_: Exception) {
            app.label
        }
    }
    val renamed = IconCustom.labelFor(app.key) != null
    var text by remember { mutableStateOf(TextFieldValue(app.label, TextRange(0, app.label.length))) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { focus.requestFocus() }

    fun save() {
        val t = text.text.trim()
        state.renameApp(app.key, if (t.isEmpty() || t == original) null else t)
        onDone()
    }

    Dialog(onDismissRequest = onBack) {
        Column(Modifier.width(300.dp).glass(RoundedCornerShape(26.dp)).padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Image(app.icon, null, Modifier.size(44.dp))
                Column {
                    Text("Rename app", color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text(original, color = Eon.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            Gap(16)
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0xFF111113))
                    .border(1.dp, Color(0xFF232327), RoundedCornerShape(16.dp)).padding(horizontal = 16.dp, vertical = 14.dp),
            ) {
                BasicTextField(
                    value = text, onValueChange = { text = it }, singleLine = true,
                    textStyle = TextStyle(color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
                    cursorBrush = SolidColor(Eon.Accent),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { save() }),
                    modifier = Modifier.fillMaxWidth().focusRequester(focus),
                )
            }
            Gap(16)
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "Cancel", color = Eon.Muted, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.clip(CircleShape).clickable(onClick = onBack).padding(horizontal = 12.dp, vertical = 10.dp),
                )
                if (renamed) {
                    Text(
                        "Reset", color = Eon.Danger, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.clip(CircleShape).clickable { state.renameApp(app.key, null); onDone() }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                    )
                }
                Spacer(Modifier.weight(1f))
                Box(
                    Modifier.height(40.dp).clip(CircleShape).background(Eon.Button).clickable { save() }.padding(horizontal = 22.dp),
                    contentAlignment = Alignment.Center,
                ) { Text("Save", color = Eon.OnAccent, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold) }
            }
        }
    }
}

/** Long-press menu > Change icon: a picture from the gallery, an icon from an icon pack, or back to the default. */
@Composable
fun ChangeIconDialog(app: AppEntry, state: EonState, onBack: () -> Unit, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val packs = remember { IconPacks.installed(ctx) }
    var stage by remember { mutableStateOf("main") } // main, packs or grid
    var chosen by remember { mutableStateOf<PackInfo?>(null) }
    val hasCustom = IconCustom.iconSpec(app.key) != null
    var scale by remember(app.key) { mutableFloatStateOf(IconCustom.scaleFor(app.key)) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                val name = IconCustom.importImage(uri)
                if (name != null) {
                    state.setAppIcon(app.key, "img:$name")
                    onDone()
                } else {
                    Toast.makeText(ctx, "Could not read that picture", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    when (stage) {
        "grid" -> {
            val info = chosen
            if (info != null) {
                IconPackPicker(
                    info, suggest = { it.nameFor(app.component) },
                    onPick = { name -> state.setAppIcon(app.key, "pack:${info.pkg}|$name"); onDone() },
                    onBack = { stage = if (packs.size > 1) "packs" else "main" },
                )
            }
        }
        else -> Dialog(onDismissRequest = { if (stage == "packs") stage = "main" else onBack() }) {
            Column(Modifier.width(300.dp).glass(RoundedCornerShape(26.dp)).padding(vertical = 8.dp)) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    Image(app.icon, null, Modifier.size(44.dp))
                    Column {
                        Text(
                            if (stage == "packs") "Icon packs" else "Change icon",
                            color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold,
                        )
                        Text(app.label, color = Eon.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                EditorDivider()
                if (stage == "main") {
                    EditorRow(Icons.Outlined.PhotoLibrary, "Choose from gallery") {
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }
                    if (packs.isNotEmpty()) {
                        EditorRow(Icons.Outlined.Palette, "Choose from an icon pack") {
                            if (packs.size == 1) {
                                chosen = packs[0]
                                stage = "grid"
                            } else {
                                stage = "packs"
                            }
                        }
                    }
                    if (hasCustom) {
                        EditorRow(Icons.Outlined.Restore, "Use the normal icon", Eon.Danger) {
                            state.setAppIcon(app.key, null)
                            onDone()
                        }
                    }
                    if (packs.isEmpty()) {
                        Text(
                            "No icon packs are installed. Install one from the Play Store and it will show up here.",
                            color = Eon.Faint, fontSize = 12.sp, lineHeight = 17.sp,
                            modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp),
                        )
                    }
                    EditorDivider()
                    IconSizeControl(scale, onScale = { scale = it }, onCommit = { state.setAppScale(app.key, it) }) { s ->
                        Image(app.icon, null, Modifier.size(44.dp).scaledIcon(s))
                    }
                } else {
                    Column(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState())) {
                        packs.forEach { p ->
                            val bmp = remember(p.pkg) {
                                runCatching { ctx.packageManager.getApplicationIcon(p.pkg).toBitmap(96, 96).asImageBitmap() }.getOrNull()
                            }
                            Row(
                                Modifier.fillMaxWidth().clickable { chosen = p; stage = "grid" }
                                    .padding(horizontal = 20.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(14.dp),
                            ) {
                                if (bmp != null) Image(bmp, null, Modifier.size(32.dp)) else Spacer(Modifier.size(32.dp))
                                Text(p.label, color = Eon.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Change icon > Icon size, for an app or a folder: draws the icon bigger or smaller, from 0.60 to 1.50. The thin square is
 * the normal size, so you can see how far the icon has moved from it. The change is saved when you let go of the slider.
 * [preview] draws the icon at the size it is given (a 44 dp icon, before scaling).
 */
@Composable
internal fun IconSizeControl(
    scale: Float, onScale: (Float) -> Unit, onCommit: (Float) -> Unit,
    horizontal: androidx.compose.ui.unit.Dp = 20.dp, preview: @Composable (Float) -> Unit,
) {
    fun round2(v: Float) = (v.coerceIn(MIN_ICON_SCALE, MAX_ICON_SCALE) * 100f).roundToInt() / 100f
    fun nudge(d: Float) {
        val v = round2(scale + d)
        onScale(v)
        onCommit(v)
    }
    Column(Modifier.fillMaxWidth().padding(horizontal = horizontal, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Box(Modifier.size(68.dp), contentAlignment = Alignment.Center) {
                Box(Modifier.size(44.dp).border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(12.dp)))
                preview(scale)
            }
            Column(Modifier.weight(1f)) {
                Text("Icon size", color = Eon.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                Text(
                    String.format(java.util.Locale.US, "%.2fx", scale),
                    color = if (scale == 1f) Eon.Muted else Eon.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                )
            }
            if (scale != 1f) {
                Box(
                    Modifier.size(36.dp).clip(CircleShape).background(Color(0xFF18181B)).clickable { onScale(1f); onCommit(1f) },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Outlined.Replay, "Reset size", tint = Eon.Soft, modifier = Modifier.size(18.dp)) }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(32.dp).clip(CircleShape).clickable { nudge(-0.01f) },
                contentAlignment = Alignment.Center,
            ) { Text("\u2212", color = Eon.Soft, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
            Slider(
                value = scale.coerceIn(MIN_ICON_SCALE, MAX_ICON_SCALE),
                onValueChange = { onScale(round2(it)) },
                onValueChangeFinished = { onCommit(scale) },
                valueRange = MIN_ICON_SCALE..MAX_ICON_SCALE,
                colors = SliderDefaults.colors(
                    thumbColor = Color.White, activeTrackColor = Eon.Accent, inactiveTrackColor = Color(0x33FFFFFF),
                ),
                modifier = Modifier.weight(1f),
            )
            Box(
                Modifier.size(32.dp).clip(CircleShape).clickable { nudge(0.01f) },
                contentAlignment = Alignment.Center,
            ) { Text("+", color = Eon.Soft, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        }
    }
}

/** Every icon in one pack, with a search box. The icon [suggest] returns for the pack (if any) comes first. */
@Composable
fun IconPackPicker(info: PackInfo, suggest: (IconPack) -> String?, onPick: (String) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val result by produceState<Pair<Boolean, IconPack?>>(false to null, info.pkg) {
        value = true to withContext(Dispatchers.Default) { IconPacks.get(ctx, info.pkg) }
    }
    val loading = !result.first
    val pack: IconPack? = result.second
    var query by remember { mutableStateOf("") }
    val names = remember(pack, query) {
        if (pack == null) {
            emptyList()
        } else {
            val q = query.trim().lowercase()
            val all = if (q.isEmpty()) pack.names else pack.names.filter { it.lowercase().contains(q) }
            val mine = suggest(pack)
            if (mine != null && q.isEmpty()) listOf(mine) + all.filter { it != mine } else all
        }
    }

    Dialog(onDismissRequest = onBack, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().background(Color(0xF2000000)).systemBarsPadding().padding(horizontal = 16.dp)) {
            Gap(12)
            PageHeader(info.label, onBack)
            Gap(14)
            Row(
                Modifier.fillMaxWidth().height(48.dp).clip(CircleShape).background(Color(0xFF111113))
                    .border(1.dp, Color(0xFF232327), CircleShape).padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Icon(Icons.Outlined.Search, null, tint = Eon.Muted, modifier = Modifier.size(20.dp))
                BasicTextField(
                    value = query, onValueChange = { query = it }, singleLine = true,
                    textStyle = TextStyle(color = Eon.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold),
                    cursorBrush = SolidColor(Eon.Accent),
                    modifier = Modifier.weight(1f),
                    decorationBox = { inner ->
                        Box(contentAlignment = Alignment.CenterStart) {
                            if (query.isEmpty()) Text("Search icons", color = Eon.Muted, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                            inner()
                        }
                    },
                )
            }
            Gap(12)
            when {
                pack == null -> Text(
                    if (loading) "Loading icons…" else "This icon pack could not be read.",
                    color = Eon.Muted, fontSize = 14.sp, modifier = Modifier.padding(4.dp),
                )
                names.isEmpty() -> Text(
                    if (query.isEmpty()) "This icon pack has no icons Eon can list." else "Nothing matches \"$query\".",
                    color = Eon.Muted, fontSize = 14.sp, modifier = Modifier.padding(4.dp),
                )
                else -> LazyVerticalGrid(
                    columns = GridCells.Adaptive(68.dp),
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 24.dp),
                ) {
                    items(names, key = { it }) { n -> PackCell(pack!!, n) { onPick(n) } }
                }
            }
        }
    }
}

@Composable
private fun PackCell(pack: IconPack, name: String, onClick: () -> Unit) {
    val bmp by produceState<ImageBitmap?>(null, name) {
        value = withContext(Dispatchers.Default) {
            try {
                pack.drawable(name)?.toBitmap(128, 128)?.asImageBitmap()
            } catch (_: Exception) {
                null
            }
        }
    }
    Box(
        Modifier.aspectRatio(1f).padding(4.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFF111113))
            .clickable(onClick = onClick).padding(10.dp),
        contentAlignment = Alignment.Center,
    ) {
        bmp?.let { Image(it, name, Modifier.fillMaxSize()) }
    }
}

/** Settings hub > Icon packs: pick the pack in use, and see or undo your own names and icons. */
@Composable
fun IconsPage(state: EonState, onBack: () -> Unit) {
    BackHandler { onBack() }
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    // Coming back from the Play Store: look for icon packs again.
    DisposableEffect(Unit) {
        val owner = (ctx as ComponentActivity).lifecycle
        val observer = LifecycleEventObserver { _, event -> if (event == Lifecycle.Event.ON_RESUME) tick++ }
        owner.addObserver(observer)
        onDispose { owner.removeObserver(observer) }
    }
    val packs = remember(tick) { IconPacks.installed(ctx) }
    val inUse = packs.firstOrNull { it.pkg == state.iconPack }?.pkg ?: ""
    state.customTick // read so the counts below refresh after a reset
    var confirm by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().background(Color(0xF7000000)).systemBarsPadding().padding(horizontal = 16.dp)
            .verticalScroll(rememberScrollState()),
    ) {
        Gap(12)
        PageHeader("Icon packs", onBack)
        Gap(22)

        SettingsSectionLabel("ICON PACK")
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(PanelColor).border(1.dp, LineColor, RoundedCornerShape(24.dp))) {
            PackChoiceRow("Eon icons", "Each app's own icon, cut to your icon shape", null, inUse == "") { state.chooseIconPack("") }
            packs.forEach { p ->
                Box(Modifier.padding(horizontal = 16.dp).fillMaxWidth().height(1.dp).background(Color(0xFF1A1A1E)))
                val bmp = remember(p.pkg) {
                    runCatching { ctx.packageManager.getApplicationIcon(p.pkg).toBitmap(96, 96).asImageBitmap() }.getOrNull()
                }
                PackChoiceRow(p.label, "Icon pack", bmp, inUse == p.pkg) { state.chooseIconPack(p.pkg) }
            }
        }
        Gap(8)
        if (packs.isEmpty()) {
            Text(
                "No icon packs found. Install one (Lawnicons, for example) and it will show up here.",
                color = Eon.Faint, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
            )
        }
        Row(
            Modifier.padding(top = 6.dp).clip(CircleShape).background(Color(0xFF161618)).border(1.dp, Color(0xFF28282C), CircleShape)
                .clickable {
                    try {
                        ctx.startActivity(
                            Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=icon%20pack&c=apps")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                        )
                    } catch (_: Exception) {
                        Toast.makeText(ctx, "No app store found", Toast.LENGTH_SHORT).show()
                    }
                }.padding(horizontal = 18.dp, vertical = 11.dp),
        ) { Text("Find icon packs", color = Eon.Text, fontSize = 14.sp, fontWeight = FontWeight.Bold) }

        Gap(22)
        SettingsSectionLabel("PACK OPTIONS")
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(PanelColor).border(1.dp, LineColor, RoundedCornerShape(24.dp))) {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f).padding(end = 12.dp)) {
                    Text("Reshape pack icons", color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text("Cut icons from a pack to your icon shape too", color = Eon.Muted, fontSize = 13.sp)
                }
                EonSwitch(state.reshapePack) { state.chooseReshapePack(it) }
            }
        }

        Gap(22)
        SettingsSectionLabel("YOUR CHANGES")
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(PanelColor).border(1.dp, LineColor, RoundedCornerShape(24.dp)).padding(16.dp)) {
            Text(
                "${IconCustom.renamedCount} renamed · ${IconCustom.customIconCount} with their own icon · ${IconCustom.resizedCount} resized",
                color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold,
            )
            Gap(6)
            Text(
                "Long-press an app, on the home screen or in the drawer, and choose Rename or Change icon. An icon you choose for one app wins over the icon pack. Icon size in Change icon makes one icon bigger or smaller, to match icons from different packs.",
                color = Eon.Faint, fontSize = 12.sp, lineHeight = 17.sp,
            )
            if (IconCustom.renamedCount + IconCustom.customIconCount + IconCustom.resizedCount > 0) {
                Gap(12)
                Box(
                    Modifier.clip(CircleShape).background(if (confirm) Eon.Danger else Color(0xFF161618))
                        .border(1.dp, Color(0xFF28282C), CircleShape)
                        .clickable {
                            if (confirm) {
                                state.resetCustomIcons()
                                confirm = false
                            } else {
                                confirm = true
                            }
                        }.padding(horizontal = 18.dp, vertical = 11.dp),
                ) {
                    Text(
                        if (confirm) "Tap again to reset everything" else "Reset all names, icons and sizes",
                        color = if (confirm) Eon.OnAccent else Eon.Danger, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                    )
                }
            }
        }
        Gap(28)
    }
}

@Composable
private fun PackChoiceRow(title: String, subtitle: String, icon: ImageBitmap?, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        if (icon != null) Image(icon, null, Modifier.size(36.dp)) else Spacer(Modifier.size(36.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(subtitle, color = Eon.Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Box(
            Modifier.size(24.dp).clip(CircleShape)
                .then(if (selected) Modifier.background(Eon.Button) else Modifier.border(2.dp, Color(0xFF3A3A40), CircleShape)),
            contentAlignment = Alignment.Center,
        ) {
            if (selected) Box(Modifier.size(8.dp).clip(CircleShape).background(Color.White))
        }
    }
}
