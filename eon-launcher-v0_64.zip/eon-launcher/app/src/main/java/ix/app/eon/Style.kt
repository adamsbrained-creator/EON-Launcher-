package ix.app.eon

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp

object Eon {
    val Ink = Color(0xFF0A0A0B)          // near-black base
    val Surface = Color(0xFF111214)      // solid dark card
    val Accent = Color(0xFF35D6F0)       // cyan: solid accent for text, borders, cursors, toggles
    val OnAccent = Color(0xFF0A0A0B)     // black text on the rainbow
    val Soft = Color(0xFFB8BCC4)         // neutral light grey for icons and glyphs
    val Text = Color(0xFFF5F5F6)
    val Muted = Color(0xFF9A9CA3)
    val Faint = Color(0xFF74767C)
    val Good = Color(0xFF7DE3F4)
    val Danger = Color(0xFFFF8E7E)
    /** The rainbow from the Eon icon: filled buttons, selected chips, badges, step bars. */
    val Button = Brush.horizontalGradient(
        listOf(Color(0xFF35D6F0), Color(0xFF5C9DFF), Color(0xFF9B7BFF), Color(0xFFF25CCB), Color(0xFFFFA63D)),
    )
    val Tile = Brush.verticalGradient(listOf(Color(0xFF34363A), Color(0xFF1B1C1F), Color(0xFF0E0F10)))
    val Sheen = Brush.verticalGradient(listOf(Color(0x1AFFFFFF), Color(0x05FFFFFF)))
}

/** Panel surface: smoked black glass, or solid black when the Flat look is chosen. */
@Composable
fun Modifier.glass(shape: Shape): Modifier =
    if (LocalLook.current == "black") {
        // AMOLED: true black, so those pixels are switched off.
        this.clip(shape).background(Color(0xFF000000)).border(1.dp, Color(0x26FFFFFF), shape)
    } else if (LocalLook.current == "flat") {
        this.clip(shape).background(Color(0xFF0B0B0C))
    } else {
        this.clip(shape)
            .background(Color(0xB8000000))
            .background(Eon.Sheen)
            .border(1.dp, Color(0x40FFFFFF), shape)
    }

/** Rainbow fill when [on], otherwise the plain [off] colour. */
fun Modifier.accentFill(on: Boolean, off: Color): Modifier =
    if (on) this.background(Eon.Button) else this.background(off)
