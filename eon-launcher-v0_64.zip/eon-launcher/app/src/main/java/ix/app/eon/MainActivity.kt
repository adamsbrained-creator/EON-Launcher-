package ix.app.eon

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue

class MainActivity : ComponentActivity() {
    private var homeTick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        val prefs = Prefs(this)
        IconCustom.init(this, prefs)
        AnimConfig.load(prefs)
        BlurConfig.load(prefs)
        val repo = AppRepo(this)
        IconStyle.load(applicationContext, prefs)
        val state = EonState(prefs)
        val widgets = WidgetHolder(this)
        GoogleFeed.load(prefs)
        setContent { EonApp(prefs, state, widgets, repo, homeTick) }
        GoogleFeed.create(this)
    }

    // The Google feed (if switched on) follows the activity's life.
    override fun onAttachedToWindow() { super.onAttachedToWindow(); GoogleFeed.onAttached() }
    override fun onDetachedFromWindow() { super.onDetachedFromWindow(); GoogleFeed.onDetached() }
    override fun onStart() { super.onStart(); GoogleFeed.onStart() }
    override fun onResume() { super.onResume(); GoogleFeed.onResume() }
    override fun onPause() { GoogleFeed.onPause(); super.onPause() }
    override fun onStop() { GoogleFeed.onStop(); super.onStop() }
    override fun onDestroy() { GoogleFeed.destroy(); super.onDestroy() }

    // Pressing Home while Eon is already open comes back here: close the drawer.
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN && intent.hasCategory(Intent.CATEGORY_HOME)) {
            homeTick++
            if (GoogleFeed.progress > 0f) GoogleFeed.close()
        }
    }
}

@Composable
fun EonApp(prefs: Prefs, state: EonState, widgets: WidgetHolder, repo: AppRepo, homeTick: Int) {
    var onboarded by remember { mutableStateOf(prefs.onboarded) }
    var apps by remember { mutableStateOf(AppRepo.last) }
    var reload by remember { mutableIntStateOf(0) }

    LaunchedEffect(reload, state.iconReload) { apps = repo.load() }
    DisposableEffect(Unit) {
        val stop = repo.watch { reload++ }
        onDispose { stop() }
    }

    // Immersive mode: hide the system bars. They come back whenever Eon is shown again, so apply it on every resume.
    val view = androidx.compose.ui.platform.LocalView.current
    DisposableEffect(state.immersive) {
        val apply = {
            val window = (view.context as? android.app.Activity)?.window
            if (window != null) {
                val controller = androidx.core.view.WindowCompat.getInsetsController(window, view)
                controller.systemBarsBehavior =
                    androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                if (state.immersive) {
                    controller.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
                } else {
                    controller.show(androidx.core.view.WindowInsetsCompat.Type.systemBars())
                }
            }
        }
        apply()
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) apply()
        }
        val lifecycle = (view.context as ComponentActivity).lifecycle
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer) }
    }
    CompositionLocalProvider(LocalLook provides state.look) {
        MaterialTheme(colorScheme = darkColorScheme()) {
            if (onboarded) {
                Home(repo, state, widgets, apps, homeTick) {
                    prefs.onboarded = false
                    onboarded = false
                }
            } else {
                Onboarding(prefs) {
                    state.chooseLook(prefs.look)
                    onboarded = true
                }
            }
        }
    }
}
