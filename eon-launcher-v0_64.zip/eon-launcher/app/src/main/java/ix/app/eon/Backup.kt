package ix.app.eon

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Backups of everything Eon remembers: the home pages, folders, widget stacks, gestures, drawer boxes and every setting.
 * One a day is kept for a week (when the switch is on). Pictures you picked yourself and widgets are not inside:
 * Android ties each widget to the launcher that added it, so widgets have to be added again after a restore.
 */
object Backup {
    private const val KEEP = 7

    private fun dir(ctx: Context): File = File(ctx.filesDir, "backups").apply { mkdirs() }

    fun snapshot(ctx: Context): String {
        val all = ctx.getSharedPreferences("eon", Context.MODE_PRIVATE).all
        val root = JSONObject()
        all.forEach { (k, v) ->
            val o = JSONObject()
            when (v) {
                is String -> o.put("t", "s").put("v", v)
                is Int -> o.put("t", "i").put("v", v)
                is Long -> o.put("t", "l").put("v", v)
                is Float -> o.put("t", "f").put("v", v.toDouble())
                is Boolean -> o.put("t", "b").put("v", v)
                is Set<*> -> o.put("t", "set").put("v", org.json.JSONArray(v.map { it.toString() }))
                else -> return@forEach
            }
            root.put(k, o)
        }
        return JSONObject().put("eon", 1).put("saved", System.currentTimeMillis()).put("prefs", root).toString()
    }

    /** Puts a backup back and restarts Eon. Returns false (and changes nothing) when the text is not an Eon backup. */
    fun restore(ctx: Context, json: String): Boolean {
        val root = try {
            JSONObject(json).getJSONObject("prefs")
        } catch (_: Exception) {
            return false
        }
        val edit = ctx.getSharedPreferences("eon", Context.MODE_PRIVATE).edit()
        edit.clear()
        root.keys().forEach { k ->
            val o = root.getJSONObject(k)
            when (o.getString("t")) {
                "s" -> edit.putString(k, o.getString("v"))
                "i" -> edit.putInt(k, o.getInt("v"))
                "l" -> edit.putLong(k, o.getLong("v"))
                "f" -> edit.putFloat(k, o.getDouble("v").toFloat())
                "b" -> edit.putBoolean(k, o.getBoolean("v"))
                "set" -> {
                    val a = o.getJSONArray("v")
                    edit.putStringSet(k, (0 until a.length()).map { a.getString(it) }.toSet())
                }
            }
        }
        edit.commit()
        // Everything is read once at start-up, so start over.
        val launch = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName)
        if (launch != null) {
            ctx.startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
        }
        android.os.Process.killProcess(android.os.Process.myPid())
        return true
    }

    fun files(ctx: Context): List<File> =
        dir(ctx).listFiles { f -> f.name.startsWith("eon-") && f.name.endsWith(".json") }?.sortedByDescending { it.name } ?: emptyList()

    fun backUpNow(ctx: Context): File? {
        return try {
            val name = "eon-" + SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) + ".json"
            val f = File(dir(ctx), name)
            f.writeText(snapshot(ctx))
            files(ctx).drop(KEEP).forEach { it.delete() }
            Prefs(ctx).putString("backupLast", name.removePrefix("eon-").removeSuffix(".json"))
            f
        } catch (_: Exception) {
            null
        }
    }

    fun dailyOn(ctx: Context): Boolean = Prefs(ctx).getBool("backupDaily", true)

    fun setDaily(ctx: Context, on: Boolean) = Prefs(ctx).putBool("backupDaily", on)

    /** Makes today's backup when the switch is on and there is none yet. Call it off the main thread. */
    fun daily(ctx: Context) {
        val p = Prefs(ctx)
        if (!p.getBool("backupDaily", true) || !p.onboarded) return
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        if (p.getString("backupLast") != today) backUpNow(ctx)
    }
}

/** Settings hub > Backup. */
@Composable
fun BackupPage(onBack: () -> Unit) {
    val ctx = LocalContext.current
    BackHandler { onBack() }
    var refresh by remember { mutableIntStateOf(0) }
    var daily by remember { mutableStateOf(Backup.dailyOn(ctx)) }
    var armed by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    val files = remember(refresh) { Backup.files(ctx) }
    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        if (uri != null) {
            note = try {
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(Backup.snapshot(ctx).toByteArray()) }
                "Saved a copy."
            } catch (_: Exception) {
                "Could not save there."
            }
        }
    }
    val open = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            val text = try {
                ctx.contentResolver.openInputStream(uri)?.use { String(it.readBytes()) }
            } catch (_: Exception) {
                null
            }
            if (text == null || !Backup.restore(ctx, text)) note = "That is not an Eon backup."
        }
    }
    Column(
        Modifier.fillMaxSize().background(Color(0xF7000000)).systemBarsPadding().padding(horizontal = 16.dp)
            .verticalScroll(rememberScrollState()),
    ) {
        Gap(12)
        PageHeader("Backup", onBack)
        Gap(18)
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Color(0xFF0D0D0F))
                .border(1.dp, Color(0xFF1E1E22), RoundedCornerShape(24.dp)).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f).padding(end = 12.dp)) {
                Text("Daily backup", color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text("Keeps the last 7 days on this phone", color = Eon.Muted, fontSize = 13.sp)
            }
            EonSwitch(daily) { daily = it; Backup.setDaily(ctx, it) }
        }
        Gap(14)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            PillButton("Back up now", Modifier.weight(1f)) {
                note = if (Backup.backUpNow(ctx) != null) "Backed up." else "Backup failed."
                refresh++
            }
            PillButton("Save a copy", Modifier.weight(1f)) {
                save.launch("eon-backup-" + SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) + ".json")
            }
        }
        Gap(10)
        PillButton("Restore from a file", Modifier.fillMaxWidth()) { open.launch(arrayOf("application/json", "application/octet-stream", "text/plain")) }
        if (note.isNotEmpty()) Text(note, color = Eon.Accent, fontSize = 13.sp, modifier = Modifier.padding(start = 6.dp, top = 10.dp))
        Gap(18)
        SettingsSectionLabel("ON THIS PHONE")
        if (files.isEmpty()) {
            Text("No backups yet.", color = Eon.Muted, fontSize = 14.sp, modifier = Modifier.padding(start = 6.dp))
        }
        files.forEach { f ->
            val date = f.name.removePrefix("eon-").removeSuffix(".json")
            Row(
                Modifier.fillMaxWidth().padding(bottom = 8.dp).clip(RoundedCornerShape(18.dp)).background(Color(0xFF111113))
                    .border(1.dp, Color(0xFF232327), RoundedCornerShape(18.dp)).padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(date, color = Eon.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    Text("${f.length() / 1024 + 1} KB", color = Eon.Faint, fontSize = 12.sp)
                }
                Text(
                    if (armed == f.name) "Tap again" else "Restore",
                    color = if (armed == f.name) Eon.Danger else Eon.Accent, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.clip(CircleShape).clickable {
                        if (armed == f.name) {
                            if (!Backup.restore(ctx, f.readText())) note = "That backup could not be read."
                        } else {
                            armed = f.name
                        }
                    }.padding(horizontal = 12.dp, vertical = 8.dp),
                )
            }
        }
        Gap(8)
        Text(
            "Restoring puts back your home pages, folders, gestures, drawer boxes and settings, then restarts Eon. " +
                "Widgets cannot be saved (Android ties each one to the launcher that added it), so add them again. " +
                "Pictures you picked for folders or icons are not in the backup either.",
            color = Eon.Muted, fontSize = 13.sp, lineHeight = 18.sp, modifier = Modifier.padding(horizontal = 6.dp),
        )
        Gap(28)
    }
}

@Composable
private fun PillButton(label: String, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.clip(CircleShape).background(Color(0xFF18181B)).border(1.dp, Color(0xFF2A2A2E), CircleShape)
            .clickable(onClick = onClick).padding(vertical = 13.dp),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = Eon.Text, fontSize = 14.sp, fontWeight = FontWeight.Bold) }
}
