package ix.app.eon

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver

@Composable
fun Gap(h: Int) = Spacer(Modifier.height(h.dp))

@Composable
fun Onboarding(prefs: Prefs, onDone: () -> Unit) {
    var step by rememberSaveable { mutableIntStateOf(0) }
    var look by rememberSaveable { mutableStateOf("glassy") }
    var theme by rememberSaveable { mutableStateOf("dark") }
    BackHandler(enabled = step > 0) { step -= 1 }

    Box(
        Modifier
            .fillMaxSize()
            .background(Eon.Ink)
            .drawBehind {
                drawRect(
                    Brush.radialGradient(
                        listOf(Color(0x409B7BFF), Color.Transparent),
                        center = Offset(size.width / 2f, size.height * 1.05f),
                        radius = size.width * 1.1f,
                    ),
                )
                drawRect(
                    Brush.radialGradient(
                        listOf(Color(0x3035D6F0), Color.Transparent),
                        center = Offset(0f, size.height),
                        radius = size.width * 0.9f,
                    ),
                )
                drawRect(
                    Brush.radialGradient(
                        listOf(Color(0x30FFA63D), Color.Transparent),
                        center = Offset(size.width, size.height),
                        radius = size.width * 0.9f,
                    ),
                )
                drawRect(
                    Brush.radialGradient(
                        listOf(Color(0x1AFFFFFF), Color.Transparent),
                        center = Offset(size.width / 2f, 0f),
                        radius = size.width * 0.8f,
                    ),
                )
            },
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .padding(horizontal = 24.dp, vertical = 16.dp),
        ) {
            when (step) {
                0 -> Welcome { step = 1 }
                1 -> HomeApp { step = 2 }
                2 -> Permissions { step = 3 }
                else -> Look(
                    look = look, theme = theme,
                    setLook = { look = it }, setTheme = { theme = it },
                ) {
                    prefs.look = look
                    prefs.theme = theme
                    prefs.onboarded = true
                    onDone()
                }
            }
        }
    }
}

// ---------------------------------------------------------------- steps

@Composable
private fun ColumnScope.Welcome(next: () -> Unit) {
    Spacer(Modifier.weight(1f))
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        AnimatedLogo(120.dp)
        Gap(16)
        Text(
            "Eon", color = Eon.Text, fontSize = 46.sp, fontWeight = FontWeight.Light,
            letterSpacing = 8.sp, modifier = Modifier.padding(start = 8.dp),
        )
        Gap(12)
        Text("A calm home for your phone.", color = Eon.Muted, fontSize = 16.sp)
    }
    Spacer(Modifier.weight(1f))
    StepBars(0)
    Gap(18)
    PrimaryButton("Get started", next)
    Gap(14)
    Text(
        "Open source · Private by design", color = Eon.Faint, fontSize = 12.sp,
        modifier = Modifier.align(Alignment.CenterHorizontally),
    )
}

@Composable
private fun ColumnScope.HomeApp(next: () -> Unit) {
    val ctx = LocalContext.current
    val request = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { next() }
    StepBars(1)
    Header("Make Eon your home", "Android will ask which home app to use. Choose Eon, then confirm.")
    Gap(28)
    Column(
        Modifier.fillMaxWidth().glass(RoundedCornerShape(26.dp)).padding(vertical = 14.dp, horizontal = 10.dp),
    ) {
        Text(
            "CHOOSE A HOME APP", color = Eon.Faint, fontSize = 13.sp, fontWeight = FontWeight.Bold,
            letterSpacing = 1.4.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
        )
        HomeRow("Eon", "Recommended", true) { EonTile(44.dp) }
        HomeRow("Your current launcher", "Stays installed", false) {
            Box(Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(Color(0x24FFFFFF)))
        }
    }
    Spacer(Modifier.weight(1f))
    PrimaryButton("Set as home app") {
        val rm = ctx.getSystemService(RoleManager::class.java)
        if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME) && !rm.isRoleHeld(RoleManager.ROLE_HOME)) {
            request.launch(rm.createRequestRoleIntent(RoleManager.ROLE_HOME))
        } else {
            next()
        }
    }
    Gap(6)
    GhostButton("Not now", next)
}

@Composable
private fun ColumnScope.Permissions(next: () -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val askCalendar = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }
    val askLocation = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }
    DisposableEffect(Unit) {
        val owner = (ctx as ComponentActivity).lifecycle
        val observer = LifecycleEventObserver { _, event -> if (event == Lifecycle.Event.ON_RESUME) tick++ }
        owner.addObserver(observer)
        onDispose { owner.removeObserver(observer) }
    }
    val notifications = remember(tick) {
        NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    }
    val calendar = remember(tick) {
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED
    }
    val location = remember(tick) {
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    }

    StepBars(2)
    Header("A few optional permissions", "Eon works without any of these. Turn on only what you want.")
    Gap(24)
    Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(26.dp))) {
        PermRow(Icons.Outlined.Notifications, "Notifications", "Dots and counts on app icons", notifications) {
            ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        Divider()
        PermRow(Icons.Outlined.CalendarMonth, "Calendar", "Events in the week widget", calendar) {
            askCalendar.launch(Manifest.permission.READ_CALENDAR)
        }
        Divider()
        PermRow(Icons.Outlined.LocationOn, "Location", "Local weather on the home screen", location) {
            askLocation.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
        }
        Divider()
        PermRow(Icons.Outlined.FavoriteBorder, "Health Connect", "Push-ups and reading widgets", false, soon = true) {}
    }
    Gap(14)
    Text(
        "You can change these anytime in Eon settings.", color = Eon.Faint, fontSize = 12.sp,
        modifier = Modifier.align(Alignment.CenterHorizontally),
    )
    Spacer(Modifier.weight(1f))
    PrimaryButton("Continue", next)
}

@Composable
private fun ColumnScope.Look(
    look: String, theme: String,
    setLook: (String) -> Unit, setTheme: (String) -> Unit,
    done: () -> Unit,
) {
    StepBars(3)
    Header("Pick your look", "You can switch styles later in Eon settings.")
    Gap(26)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        LookCard("Glassy", look == "glassy", Modifier.weight(1f), { setLook("glassy") }) { EonTile(76.dp) }
        LookCard("Flat", look == "flat", Modifier.weight(1f), { setLook("flat") }) {
            Box(
                Modifier.size(76.dp).clip(RoundedCornerShape(18.dp)).background(Eon.Surface),
                contentAlignment = Alignment.Center,
            ) { EonMark(Modifier.fillMaxSize(0.82f), brush = SolidColor(Color.White)) }
        }
    }
    Gap(26)
    Text("THEME", color = Eon.Faint, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
    Gap(10)
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        listOf("dark" to "Dark", "light" to "Light", "auto" to "Auto").forEach { (key, label) ->
            Chip(label, theme == key) { setTheme(key) }
        }
    }
    Spacer(Modifier.weight(1f))
    PrimaryButton("Open Eon", done)
}

// ---------------------------------------------------------------- pieces

@Composable
fun StepBars(active: Int) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
    ) {
        repeat(4) { i ->
            val c = Color(0x4DFFFFFF)
            val on = i == active
            Canvas(Modifier.size(26.dp, 4.dp)) {
                val skew = 4.dp.toPx()
                val p = Path().apply {
                    moveTo(skew, 0f)
                    lineTo(size.width, 0f)
                    lineTo(size.width - skew, size.height)
                    lineTo(0f, size.height)
                    close()
                }
                if (on) drawPath(p, Eon.Button) else drawPath(p, c)
            }
        }
    }
}

@Composable
fun PrimaryButton(text: String, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().height(54.dp).clip(CircleShape).background(Eon.Button).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(text, color = Eon.OnAccent, fontWeight = FontWeight.Bold, fontSize = 16.sp) }
}

@Composable
fun GhostButton(text: String, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().height(46.dp).clip(CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(text, color = Color(0xFFC8CAD0), fontWeight = FontWeight.Medium, fontSize = 15.sp) }
}

@Composable
fun Header(title: String, sub: String) {
    Gap(28)
    Text(title, color = Eon.Text, fontSize = 30.sp, fontWeight = FontWeight.Bold, lineHeight = 34.sp)
    Gap(10)
    Text(sub, color = Eon.Muted, fontSize = 15.sp, lineHeight = 22.sp)
}

@Composable
private fun Divider() {
    Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(1.dp).background(Color(0x24FFFFFF)))
}

@Composable
private fun Radio(on: Boolean) {
    val look = if (on) Modifier.background(Eon.Button) else Modifier.border(2.dp, Color(0x40FFFFFF), CircleShape)
    Box(Modifier.size(22.dp).clip(CircleShape).then(look), contentAlignment = Alignment.Center) {
        if (on) Box(Modifier.size(8.dp).clip(CircleShape).background(Eon.OnAccent))
    }
}

@Composable
private fun HomeRow(name: String, sub: String, on: Boolean, tile: @Composable () -> Unit) {
    val bg = if (on) Modifier.clip(RoundedCornerShape(18.dp)).background(Color(0x1FFFFFFF)) else Modifier
    Row(
        Modifier.fillMaxWidth().then(bg).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        tile()
        Column(Modifier.weight(1f)) {
            Text(name, color = Eon.Text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(sub, color = Eon.Muted, fontSize = 12.sp)
        }
        Radio(on)
    }
}

@Composable
private fun PermRow(
    icon: ImageVector, title: String, desc: String, granted: Boolean,
    soon: Boolean = false, onAllow: () -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Box(
            Modifier.size(42.dp).clip(CircleShape).background(Color(0x24FFFFFF)).border(1.dp, Color(0x40FFFFFF), CircleShape),
            contentAlignment = Alignment.Center,
        ) { Icon(icon, null, tint = Color(0xFFC8CAD0), modifier = Modifier.size(20.dp)) }
        Column(Modifier.weight(1f)) {
            Text(title, color = Eon.Text, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text(desc, color = Eon.Muted, fontSize = 12.sp, lineHeight = 17.sp)
        }
        when {
            granted -> Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Icon(Icons.Outlined.Check, null, tint = Eon.Good, modifier = Modifier.size(16.dp))
                Text("Granted", color = Eon.Good, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            soon -> Text("Soon", color = Eon.Faint, fontSize = 13.sp)
            else -> Box(
                Modifier.height(34.dp).clip(CircleShape).background(Eon.Button).clickable(onClick = onAllow)
                    .padding(horizontal = 16.dp),
                contentAlignment = Alignment.Center,
            ) { Text("Allow", color = Eon.OnAccent, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
        }
    }
}

@Composable
private fun LookCard(
    name: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit,
    tile: @Composable () -> Unit,
) {
    val shape = RoundedCornerShape(26.dp)
    val ring = if (selected) Modifier.border(2.dp, Eon.Button, shape) else Modifier
    Column(
        modifier.glass(shape).then(ring).clickable(onClick = onClick).padding(vertical = 18.dp, horizontal = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        tile()
        Gap(12)
        Text(name, color = Eon.Text, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Gap(12)
        Radio(selected)
    }
}

@Composable
private fun Chip(label: String, on: Boolean, onClick: () -> Unit) {
    val look = if (on) Modifier.background(Eon.Button)
    else Modifier.background(Color(0x1FFFFFFF)).border(1.dp, Color(0x33FFFFFF), CircleShape)
    Box(
        Modifier.height(36.dp).clip(CircleShape).then(look).clickable(onClick = onClick).padding(horizontal = 18.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label, color = if (on) Eon.OnAccent else Color(0xFFC8CAD0), fontSize = 14.sp,
            fontWeight = if (on) FontWeight.Bold else FontWeight.Medium,
        )
    }
}
