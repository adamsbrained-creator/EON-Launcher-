package ix.app.eon

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.compose.ui.layout.onSizeChanged
import kotlin.math.roundToInt

/**
 * The "Search apps" pill, floating over the home grid. It can sit anywhere: long-press it to move it
 * (drag, or use the arrows), hide it, or send it back to the bottom. Its spot is saved as a share of the
 * grid's width and height.
 */
@Composable
fun SearchLayer(state: EonState, onOpen: () -> Unit) {
    val density = LocalDensity.current
    val haptic = LocalHapticFeedback.current
    var pill by remember { mutableStateOf(IntSize.Zero) }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val w = constraints.maxWidth.toFloat()
        val h = constraints.maxHeight.toFloat()
        val cellW = w / GRID_COLS
        val cellH = state.cellHeightPx
        val defaultY = (h - with(density) { 32.dp.toPx() }) / h
        val editing = state.editing == "search"
        val fy = if (state.searchY < 0f) defaultY else state.searchY

        // Puts the middle of the pill at (cx, cy) in pixels, snapping to half cells across and row middles down.
        fun moveTo(cx: Float, cy: Float) {
            val pw = pill.width.toFloat()
            val ph = pill.height.toFloat()
            var x = cx.coerceIn(pw / 2f, maxOf(w - pw / 2f, pw / 2f))
            var y = cy.coerceIn(ph / 2f, maxOf(h - ph / 2f, ph / 2f))
            if (state.snapToGrid) {
                val half = cellW / 2f
                x = (x / half).roundToInt() * half
                y = ((y / cellH - 0.5f).roundToInt() + 0.5f) * cellH
            }
            state.setSearchPos(x / w, y / h)
        }

        if (editing) {
            GridOverlay(cellW, cellH, state.gridRows, 1f)
            // Tapping outside finishes editing.
            Box(Modifier.fillMaxSize().zIndex(1900f).pointerInput(Unit) { detectTapGestures { state.editing = null } })
        }

        Box(
            Modifier
                .zIndex(if (editing) 2000f else 100f)
                .layout { measurable, c ->
                    val p = measurable.measure(Constraints(0, c.maxWidth, 0, c.maxHeight))
                    layout(c.maxWidth, c.maxHeight) {
                        val aw = c.maxWidth.toFloat()
                        val ah = c.maxHeight.toFloat()
                        val y0 = if (state.searchY < 0f) (ah - with(density) { 32.dp.toPx() }) / ah else state.searchY
                        val x = (state.searchX * aw - p.width / 2f).coerceIn(0f, maxOf(aw - p.width, 0f))
                        val y = (y0 * ah - p.height / 2f).coerceIn(0f, maxOf(ah - p.height, 0f))
                        p.place(x.roundToInt(), y.roundToInt())
                    }
                }
                .onSizeChanged { pill = it }
                .pointerInput(editing, w, h) {
                    if (editing) {
                        var cx = 0f
                        var cy = 0f
                        detectDragGestures(
                            onDragStart = {
                                cx = state.searchX * w
                                cy = (if (state.searchY < 0f) defaultY else state.searchY) * h
                            },
                            onDragEnd = { state.commitSearch() },
                            onDragCancel = { state.commitSearch() },
                        ) { change, d ->
                            change.consume()
                            cx += d.x
                            cy += d.y
                            moveTo(cx, cy)
                        }
                    } else {
                        detectTapGestures(
                            onTap = { onOpen() },
                            onLongPress = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                state.editing = "search"
                            },
                        )
                    }
                },
        ) {
            Row(
                Modifier
                    .glass(CircleShape)
                    .then(if (editing) Modifier.border(1.5.dp, Color(0xCCFFFFFF), CircleShape) else Modifier)
                    .padding(horizontal = 20.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                EonMark(Modifier.size(16.dp), brush = SolidColor(Eon.Soft))
                Spacer(Modifier.width(10.dp))
                Text("Search apps", color = Color(0xFFC8CAD0), fontSize = 14.sp)
            }
        }

        if (editing) {
            fun nudge(dx: Int, dy: Int) {
                val stepX = if (state.snapToGrid) cellW / 2f else cellW * 0.05f
                val stepY = if (state.snapToGrid) cellH else cellH * 0.05f
                val curY = (if (state.searchY < 0f) defaultY else state.searchY) * h
                moveTo(state.searchX * w + dx * stepX, curY + dy * stepY)
                state.commitSearch()
            }
            SearchEditPanel(
                state, ::nudge,
                Modifier.align(if (fy > 0.5f) Alignment.TopCenter else Alignment.BottomCenter).padding(vertical = 12.dp),
            )
        }
    }
}

@Composable
private fun SearchEditPanel(state: EonState, onNudge: (Int, Int) -> Unit, modifier: Modifier) {
    Column(
        modifier
            .zIndex(2200f)
            .width(260.dp)
            .glass(RoundedCornerShape(24.dp))
            .pointerInput(Unit) { detectTapGestures { } }
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            PanelLabel("SEARCH PILL", Eon.Text, Modifier.weight(1f))
            Text(
                "DONE", color = Eon.Good, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp,
                modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { state.editing = null }.padding(6.dp),
            )
        }
        NudgeRow(
            "X", cellText(state.searchX * GRID_COLS),
            { onNudge(-1, 0) }, { onNudge(1, 0) }, {},
        )
        NudgeRow(
            "Y", if (state.searchY < 0f) "auto" else cellText(state.searchY * state.gridRows),
            { onNudge(0, -1) }, { onNudge(0, 1) }, {},
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            PanelLabel("SNAP TO GRID", Eon.Text, Modifier.weight(1f))
            EonSwitch(state.snapToGrid) { state.chooseSnap(it) }
        }
        PanelRow("RESET POSITION") { state.resetSearch() }
        PanelRow("HIDE", Eon.Danger) {
            state.editing = null
            state.chooseSearchHidden(true)
        }
    }
}
