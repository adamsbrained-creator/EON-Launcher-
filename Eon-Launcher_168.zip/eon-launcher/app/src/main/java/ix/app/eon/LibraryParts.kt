package ix.app.eon

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Process
import android.provider.Settings
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import android.graphics.Bitmap
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntSize
import kotlin.math.max
import kotlin.math.roundToInt
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar
import kotlin.math.abs

/** The cyan to blue fill of the selected tab and other small buttons in the App Library. */
internal fun libGrad2(): Brush = Eon.dynamic?.let { Brush.linearGradient(listOf(it.primary, it.tertiary)) }
    ?: Brush.linearGradient(listOf(Color(0xFF35D6F0), Color(0xFF5C9DFF)))

/** The cyan, blue and violet fill of the selected sort chip and of Done. */
internal fun libGrad3(): Brush = Eon.dynamic?.let { Brush.horizontalGradient(listOf(it.primary, it.secondary, it.tertiary)) }
    ?: Brush.horizontalGradient(listOf(Color(0xFF35D6F0), Color(0xFF5C9DFF), Color(0xFF9B7BFF)))

internal val LibPink = Color(0xFFF25CCB)

/** A coloured fill with the colour of the glyph that sits on it. */
internal class LibTint(val a: Color, val b: Color, val ink: Color)

private val TintCyan = LibTint(Color(0xFF6BEAFC), Color(0xFF1F9DC4), Color(0xFF0A0A0B))
private val TintBlue = LibTint(Color(0xFF7BAEFF), Color(0xFF3566E0), Color(0xFFFFFFFF))
private val TintViolet = LibTint(Color(0xFFB195FF), Color(0xFF6A47E0), Color(0xFFFFFFFF))
private val TintPink = LibTint(Color(0xFFFF86DA), Color(0xFFC93A9E), Color(0xFF0A0A0B))
private val TintOrange = LibTint(Color(0xFFFFC066), Color(0xFFE8801A), Color(0xFF0A0A0B))
private val TintDark = LibTint(Color(0xFF41444C), Color(0xFF16171A), Color(0xFFF5F5F6))
private val TintAll = listOf(TintCyan, TintBlue, TintViolet, TintPink, TintOrange)

/** The colour of a box's round badge in its sheet. The usual boxes always get the same one. */
internal fun libTintFor(id: String): LibTint {
    val chosen = LibraryConfig.boxColors[id] ?: return libTintBase(id)
    val c = Color(chosen)
    return LibTint(androidx.compose.ui.graphics.lerp(c, Color.White, 0.35f), androidx.compose.ui.graphics.lerp(c, Color.Black, 0.35f), Color.White)
}

private fun libTintBase(id: String): LibTint = when (id) {
    "social", "contacts" -> TintViolet
    "media", "music", "entertainment" -> TintPink
    "productivity", "reading", "~recent" -> TintOrange
    "games" -> TintBlue
    "tools", "internet", "~suggest" -> TintCyan
    "~other", "other" -> TintDark
    else -> TintAll[abs(id.hashCode()) % TintAll.size]
}

/**
 * How long each app has been on screen today, for the "1h 12m today" pill and the box sheets. Android only shares this
 * with an app the user has switched on in Settings > Usage access, so until then [granted] is false and the Library
 * shows a pill that opens that page. Kept in memory only and never sent anywhere.
 */
object ScreenTime {
    var granted by mutableStateOf(false)
        private set

    /** Milliseconds on screen today per package. */
    val today = mutableStateMapOf<String, Long>()

    /** Everything today except Eon itself. */
    var total by mutableLongStateOf(0L)
        private set

    fun hasAccess(ctx: Context): Boolean = try {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        } else {
            @Suppress("DEPRECATION")
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        }
        mode == AppOpsManager.MODE_ALLOWED
    } catch (_: Exception) {
        false
    }

    /** Looks again: whether access is on, and if so how long each app has been open since midnight. */
    suspend fun refresh(ctx: Context) {
        if (!hasAccess(ctx)) {
            granted = false
            today.clear()
            total = 0L
            return
        }
        val sums = withContext(Dispatchers.Default) { read(ctx) }
        granted = true
        today.clear()
        today.putAll(sums)
        total = sums.entries.filter { it.key != ctx.packageName }.sumOf { it.value }
    }

    private fun read(ctx: Context): Map<String, Long> {
        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager ?: return emptyMap()
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val now = System.currentTimeMillis()
        val sums = HashMap<String, Long>()
        try {
            val events = usm.queryEvents(cal.timeInMillis, now)
            val e = UsageEvents.Event()
            val open = HashMap<String, Long>()
            while (events.hasNextEvent()) {
                events.getNextEvent(e)
                val pkg = e.packageName ?: continue
                when (e.eventType) {
                    // 1 is "activity resumed" (an app comes to the front), 2 is "activity paused" (it leaves).
                    1 -> open[pkg] = e.timeStamp
                    2 -> open.remove(pkg)?.let { sums[pkg] = (sums[pkg] ?: 0L) + (e.timeStamp - it).coerceAtLeast(0L) }
                }
            }
            // Whatever is open right now has been open since it came to the front.
            open.forEach { (p, t) -> sums[p] = (sums[p] ?: 0L) + (now - t).coerceAtLeast(0L) }
        } catch (_: Exception) {
        }
        return sums
    }

    /** "1h 12m", or "12m" under an hour. */
    fun format(ms: Long): String {
        val m = ms / 60_000L
        val h = m / 60L
        return if (h > 0) "${h}h ${m % 60L}m" else "${m}m"
    }

    /** Opens Android's Usage access page, where Eon can be switched on. */
    fun openSettings(ctx: Context) {
        try {
            ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
        }
    }
}

private val LibSaturate = ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(1.35f) })

/**
 * The blurred wallpaper that shows through the boxes, like iOS. When Eon draws the wallpaper itself (the picture from
 * Settings > Wallpaper), a small blurred copy of that picture is made once and each box draws the part of it that is
 * behind it. With the plain system wallpaper Eon cannot read the picture, so there is no copy and the boxes are only
 * tinted glass over the window blur.
 */
internal object LibBackdrop {
    var image by mutableStateOf<ImageBitmap?>(null)
        private set
    private var key = ""

    /** Brightness of the last copy made, 0 to 1. Written on the worker thread, read once that work has finished. */
    @Volatile
    private var madeLum = -1f

    suspend fun refresh(ctx: Context) {
        if (!WallpaperConfig.active) {
            image = null
            key = ""
            LibFrost.lum = -1f
            return
        }
        val name = WallpaperConfig.current
        val dm = ctx.resources.displayMetrics
        val k = "$name|${dm.widthPixels}x${dm.heightPixels}"
        if (k == key && image != null) return
        val made = withContext(Dispatchers.Default) { make(ctx, name, dm.widthPixels, dm.heightPixels) }
        if (made != null) {
            image = made
            key = k
            LibFrost.lum = madeLum
        }
    }

    /** The picture cropped to the screen, shrunk to an eighth and blurred, so it costs almost nothing to keep. */
    private fun make(ctx: Context, name: String, sw: Int, sh: Int): ImageBitmap? {
        val tw = (sw / 8).coerceAtLeast(16)
        val th = (sh / 8).coerceAtLeast(16)
        val full = WallpaperStore.load(ctx, name, sw / 4, sh / 4, WallpaperConfig.QUALITY_STANDARD, software = true) ?: return null
        val out = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888)
        val scale = max(tw.toFloat() / full.width, th.toFloat() / full.height)
        val srcW = tw / scale
        val srcH = th / scale
        val l = ((full.width - srcW) / 2f).coerceAtLeast(0f)
        val t = ((full.height - srcH) / 2f).coerceAtLeast(0f)
        val src = android.graphics.Rect(
            l.roundToInt(), t.roundToInt(),
            (l + srcW).roundToInt().coerceAtMost(full.width), (t + srcH).roundToInt().coerceAtMost(full.height),
        )
        android.graphics.Canvas(out).drawBitmap(full, src, android.graphics.Rect(0, 0, tw, th), android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG))
        full.recycle()
        val px = IntArray(tw * th)
        out.getPixels(px, 0, tw, 0, 0, tw, th)
        val tmp = IntArray(px.size)
        repeat(3) {
            for (y in 0 until th) blurLine(px, tmp, y * tw, 1, tw, 4)
            for (x in 0 until tw) blurLine(tmp, px, x, tw, th, 4)
        }
        out.setPixels(px, 0, tw, 0, 0, tw, th)
        // How bright the wallpaper is overall: Auto frost uses it to choose light or dark cards and names.
        var sum = 0.0
        for (c in px) sum += 0.2126 * ((c shr 16) and 255) + 0.7152 * ((c shr 8) and 255) + 0.0722 * (c and 255)
        madeLum = (sum / px.size / 255.0).toFloat().coerceIn(0f, 1f)
        return out.asImageBitmap()
    }

    /** One pass of a box blur along a row or a column; the edges repeat their last pixel. */
    private fun blurLine(src: IntArray, dst: IntArray, start: Int, stride: Int, count: Int, r: Int) {
        val div = 2 * r + 1
        var rr = 0
        var g = 0
        var b = 0
        for (i in -r..r) {
            val c = src[start + i.coerceIn(0, count - 1) * stride]
            rr += (c shr 16) and 255
            g += (c shr 8) and 255
            b += c and 255
        }
        for (i in 0 until count) {
            dst[start + i * stride] = (0xFF shl 24) or ((rr / div) shl 16) or ((g / div) shl 8) or (b / div)
            val add = src[start + (i + r + 1).coerceAtMost(count - 1) * stride]
            val rem = src[start + (i - r).coerceAtLeast(0) * stride]
            rr += ((add shr 16) and 255) - ((rem shr 16) and 255)
            g += ((add shr 8) and 255) - ((rem shr 8) and 255)
            b += (add and 255) - (rem and 255)
        }
    }
}

/**
 * A frosted-glass card for a box. Behind the fill, when the blurred wallpaper copy exists ([LibBackdrop]), the part of
 * it that lies behind the box is drawn (a little more colourful, under the same dim layer as the rest of the drawer).
 * The fill is lighter at the top and fades down, and the hairline edge catches the light along the top. [selected]
 * lifts the fill a little and brightens the edge (no coloured outline).
 */
@Composable
internal fun Modifier.libTileGlass(shape: Shape, selected: Boolean = false, tint: Color? = null): Modifier {
    var origin by remember { mutableStateOf(Offset.Zero) }
    val flat = LibraryConfig.isFlat
    val lite = libLiteFx()
    // Flat boxes are solid and draw no wallpaper. With the home screen blurred behind the Library, each box need not draw its own copy of the wallpaper on every scroll frame.
    val backdrop = if (flat || (LibraryConfig.homeBlur && android.os.Build.VERSION.SDK_INT >= 31)) null else LibBackdrop.image
    val dm = LocalContext.current.resources.displayMetrics
    // The soft shadow goes first, outside the clip, so it can fall around the card.
    var m = (if (flat) this else this.libSoftShadow(shape)).clip(shape)
    if (backdrop != null) {
        m = m.onGloballyPositioned { origin = it.positionInWindow() }.drawBehind {
            // The wallpaper does not move with the box, so draw it shifted back by where the box is on the screen.
            translate(-origin.x, -origin.y) {
                drawImage(backdrop, dstSize = IntSize(dm.widthPixels, dm.heightPixels), filterQuality = FilterQuality.Medium, colorFilter = LibSaturate)
                drawRect(DrawerConfig.scrim(), size = Size(dm.widthPixels.toFloat(), dm.heightPixels.toFloat()))
            }
        }
    }
    if (flat) {
        val line = LibraryConfig.flatBorderColor.copy(alpha = LibraryConfig.flatBorderOpacity)
        val w = LibraryConfig.flatBorderWidth
        m = m.background(LibraryConfig.flatColor.copy(alpha = LibraryConfig.flatOpacity))
        if (LibraryConfig.flatTint) {
            // The same soft wash of the box's own colour as Glass, and a light edge along the top, so Flat boxes are not all one slab.
            if (tint != null) m = m.background(Brush.verticalGradient(listOf(tint.copy(alpha = 0.16f), tint.copy(alpha = 0.04f))))
            m = m.background(Brush.verticalGradient(0f to Color.White.copy(alpha = 0.07f), 0.35f to Color.Transparent, 1f to Color.Transparent))
        }
        return if (selected) m.border(1.dp, Color.White.copy(alpha = 0.40f), shape)
        else if (w > 0f && line.alpha > 0f) m.border(w.dp, line, shape)
        else m
    }
    val dark = LibFrost.darkCards
    // Edge: with the bright top edge on it is strongest along the top and fades to almost nothing down the sides; off, the old even hairline.
    val edge = when {
        selected -> Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.70f), Color.White.copy(alpha = 0.22f)))
        LibraryConfig.glassTop -> Brush.verticalGradient(
            0f to Color.White.copy(alpha = if (dark) 0.40f else 0.65f), 0.4f to Color.White.copy(alpha = 0.12f), 1f to Color.White.copy(alpha = 0.03f),
        )
        else -> Brush.verticalGradient(
            listOf(Color.White.copy(alpha = if (DrawerConfig.tileBorder) 0.55f else 0.30f), Color.White.copy(alpha = 0.08f)),
        )
    }
    var out = m.background(libFrostFill(lift = if (selected) 0.07f else 0f))
    // A soft wash of the box's own colour, strongest at the top (only with Tinted, or for a colour you picked) ...
    if (tint != null) out = out.background(Brush.verticalGradient(listOf(tint.copy(alpha = 0.20f), tint.copy(alpha = 0.05f))))
    // ... a light sheen over the top half, like glass catching the light ...
    out = out.background(Brush.verticalGradient(0f to Color.White.copy(alpha = 0.13f), 0.5f to Color.Transparent, 1f to Color.Transparent))
    // ... a faint darker band along the bottom, so the card has a lower edge ...
    if (LibraryConfig.glassShade) out = out.background(Brush.verticalGradient(0f to Color.Transparent, 0.6f to Color.Transparent, 1f to Color.Black.copy(alpha = 0.07f)))
    // ... and a little grain so the gradients do not band.
    if (LibraryConfig.grain && !lite) out = out.drawBehind { drawRect(LibGrain.brush, alpha = 0.03f) }
    return out.border(1.dp, edge, shape)
}

/** The two looks of the Library (Settings > Drawer, or Customize Library > Style): what the chips, search pill and boxes are made of. */
internal object LibStyle {
    private val flat: Boolean get() = LibraryConfig.isFlat
    val ink: Color get() = Eon.DText
    val soft: Color get() = Eon.DSoft
    fun field(): Shape = RoundedCornerShape(if (flat) LibraryConfig.flatRadius.coerceAtMost(24).dp else 24.dp)
    fun chip(): Shape = RoundedCornerShape(if (flat) (LibraryConfig.flatRadius * 0.65f).coerceAtLeast(4f).dp else 17.dp)
    /** Box corners: the drawer's own radius for Glass, the Flat roundness slider for Flat. */
    fun tile(base: Int): Dp = if (flat) LibraryConfig.flatRadius.dp else base.dp
}

/** Fades the last stretch of a sideways-scrolling row to nothing, so a chip cut off at the edge looks intended. */
internal fun Modifier.libFadeEnd(width: Dp = 28.dp): Modifier =
    this.graphicsLayer(compositingStrategy = androidx.compose.ui.graphics.CompositingStrategy.Offscreen).drawWithContent {
        drawContent()
        drawRect(
            Brush.horizontalGradient(listOf(Color.Black, Color.Transparent), startX = size.width - width.toPx(), endX = size.width),
            blendMode = androidx.compose.ui.graphics.BlendMode.DstIn,
        )
    }

/**
 * The fourth slot of a box with more than four apps: the next four apps as small icons. By default they sit straight on the
 * card, as on iOS; "Plate under +N" (Customize Library) puts them on a small glass tile again.
 */
@Composable
internal fun LibMiniCluster(rest: List<AppEntry>, size: Dp, modifier: Modifier = Modifier, onClick: (() -> Unit)? = null) {
    val plate = LibraryConfig.clusterPlate == 1
    val tidy = LibraryConfig.tidyCluster
    val chip = RoundedCornerShape(size * (if (tidy) 0.24f else if (LibraryConfig.isFlat) 0.2f else 0.28f))
    val inner = if (plate) size * (if (tidy) 0.12f else 0.1f) else 0.dp
    val gap = size * (if (plate) 0.06f else 0.08f)
    val mini = (size - inner * 2 - gap) / 2
    Box(
        modifier.size(size).clip(chip)
            .then(if (plate) Modifier.background(if (tidy) Color(0x1FFFFFFF) else if (LibraryConfig.isFlat) Color(0x1AFFFFFF) else Color(0x26FFFFFF)) else Modifier)
            .then(if (plate && !tidy) Modifier.border(1.dp, if (LibraryConfig.isFlat) Color(0x29FFFFFF) else Color(0x33FFFFFF), chip) else Modifier)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(inner),
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(gap)) {
            rest.take(4).chunked(2).forEach { pair ->
                Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                    pair.forEach { a -> Image(bitmap = a.icon, contentDescription = null, modifier = Modifier.size(mini).scaledIcon(a.iconScale)) }
                }
            }
        }
    }
}

/** One easing for every Library movement (sheet, Arrange, popups), so nothing feels like its own canned animation: fast start, long soft landing, no bounce. */
internal val LibEase = androidx.compose.animation.core.CubicBezierEasing(0.2f, 0f, 0f, 1f)

/** The Library comes in and goes out quickly, so it never holds you up. */
internal val LibEnter: androidx.compose.animation.EnterTransition =
    androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(130, easing = LibEase)) +
        androidx.compose.animation.slideInVertically(androidx.compose.animation.core.tween(190, easing = LibEase)) { it / 16 }
internal val LibExit: androidx.compose.animation.ExitTransition =
    androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(100))

/** How far the Library sheet is from fully open, 0 (not at all) to 1 (gone). The home screen's blur eases off with it. */
/**
 * An upward swipe on the home screen drives the Library while the finger is still down: Home starts it, the Library follows
 * [dy], and when the finger lifts the release velocity decides how the sheet settles.
 */
internal object LibHandoff {
    private val a = androidx.compose.runtime.mutableStateOf(false)
    private val d = androidx.compose.runtime.mutableFloatStateOf(0f)
    private val r = androidx.compose.runtime.mutableStateOf<Float?>(null)
    var active: Boolean
        get() = a.value
        set(v) { a.value = v }
    /** How far the finger has pulled the sheet up from the bottom, in px. */
    var dy: Float
        get() = d.floatValue
        set(v) { d.floatValue = v }
    /** Set when the finger lifts: the vertical velocity in px/s (down is positive). Taken by the Library. */
    var release: Float?
        get() = r.value
        set(v) { r.value = v }
}

internal object LibPull {
    private val state = androidx.compose.runtime.mutableFloatStateOf(0f)
    var p: Float
        get() = state.floatValue
        set(v) { state.floatValue = v }

    private val closingState = androidx.compose.runtime.mutableStateOf(false)

    /** True from the moment the sheet is let go towards closed, until it is grabbed or opened again. */
    var closing: Boolean
        get() = closingState.value
        set(v) { closingState.value = v }

    /** Home's blur is dropped while the sheet is still on its way out, so it is already sharp when the sheet is gone. */
    val blurOff: Boolean get() = closing && state.floatValue > 0.4f
}

/**
 * The Library as a sheet with one continuous position, the way Launcher3 and Lawnchair move their app drawer.
 *
 * [offset] is how far the sheet is pushed down from fully open, in pixels. Everything moves it directly:
 *  - your finger, one to one, pulling it down from the top of the list and pushing it back up (the list and the sheet
 *    share the same touch, so a quick down-and-up just works);
 *  - the settle after you let go, which starts at the speed your finger had and carries on from there. A flick closes
 *    it, a flick back up keeps it open, a slow release goes to whichever end is nearer. There are no fixed stops.
 *  - opening, which is the same spring from fully closed up to open.
 */
internal class LibDrawer(
    private val scope: kotlinx.coroutines.CoroutineScope,
    private val range: Float,
    private val flingPxPerSec: Float,
    private val dpPx: Float,
    private val nearTop: () -> Boolean,
    private val enabled: () -> Boolean,
    private val onClosed: () -> Unit,
) {
    var offset by androidx.compose.runtime.mutableFloatStateOf(range)
        private set
    private var job: kotlinx.coroutines.Job? = null
    private var fresh = true
    private var fromTop = false

    private var down = false

    init {
        // Starts fully closed, so the home screen is in front until the sheet has risen.
        LibPull.p = 1f
        LibPull.closing = false
    }

    fun touch(isDown: Boolean) { down = isDown }

    /**
     * Called once every finger is up. Normally the settle is already running; if for any reason it is not (a cancelled
     * touch, an interrupted animation) the sheet is never left hanging half way: it finishes the way it was heading.
     */
    fun released() {
        scope.launch {
            kotlinx.coroutines.delay(48)
            if (down || job?.isActive == true) return@launch
            if (offset >= range - 1f) onClosed() else if (offset > 0f) settle(0f)
        }
    }

    private fun set(v: Float) {
        offset = v.coerceIn(0f, range)
        LibPull.p = offset / range
    }

    /** Slides up from fully closed with the same spring the settle uses. */
    fun open() {
        job?.cancel()
        LibPull.closing = false
        job = scope.launch {
            androidx.compose.animation.core.animate(
                offset, 0f, 0f, androidx.compose.animation.core.spring(1f, 520f, 1f),
            ) { v, _ -> set(v) }
        }
    }

    /** The sheet follows a finger that is pulling it up from the bottom of the screen. */
    fun follow(dy: Float) {
        job?.cancel()
        LibPull.closing = false
        set(range - dy)
    }

    /** The finger that was pulling the sheet up has lifted. */
    fun fling(velocity: Float) {
        job?.cancel()
        // Opening: a quick swipe up opens it even if short, but a small pull or a touch that drifted does not (that used to
        // open it and blur home from a slight touch). Otherwise it goes by how far it was pulled.
        val pulled = range - offset
        val close = when {
            velocity < -LibraryConfig.flickSpeedDp() * dpPx && pulled > LibraryConfig.flickPullDp() * dpPx -> false
            velocity > 120f * dpPx -> true
            else -> pulled < range * LibraryConfig.settleFraction()
        }
        run(close, velocity)
    }

    /** Where the sheet is drawn: under the finger directly while a swipe from home is still going, so it does not trail it. */
    val shown: Float
        get() = if (LibHandoff.active || LibHandoff.release != null) (range - LibHandoff.dy).coerceIn(0f, range) else offset

    private fun settle(velocity: Float) {
        job?.cancel()
        // Whichever way the finger was heading when it lifted decides, however small the pull; only a finger that was
        // hardly moving goes by position. (Needing a long pull, or a hard flick, is what made it feel like it resisted.)
        val dir = 120f * dpPx
        val close = when {
            velocity > dir && offset > 40f * dpPx -> true
            velocity < -dir -> false
            else -> offset > range * 0.3f
        }
        run(close, velocity)
    }

    private fun run(close: Boolean, velocity: Float) {
        LibPull.closing = close
        job = scope.launch {
            var told = false
            // A faster flick settles faster (stiffer spring) instead of always taking the same time.
            val stiff = 600f + (kotlin.math.abs(velocity) / dpPx).coerceAtMost(3000f) * 0.4f
            androidx.compose.animation.core.animate(
                offset, if (close) range else 0f, velocity, androidx.compose.animation.core.spring(1f, stiff, 1f),
            ) { v, _ ->
                set(v)
                // A spring only ever creeps up on its target, so waiting for it to finish kept the (invisible) Library on
                // screen for most of a second, still taking touches, with home blurred behind it. Hand over once it is
                // practically gone.
                if (close && !told && v >= range - 16f * dpPx) {
                    told = true
                    onClosed()
                }
            }
            if (close && !told) onClosed()
        }
    }

    val connection = object : androidx.compose.ui.input.nestedscroll.NestedScrollConnection {
        override fun onPreScroll(
            available: androidx.compose.ui.geometry.Offset, source: androidx.compose.ui.input.nestedscroll.NestedScrollSource,
        ): androidx.compose.ui.geometry.Offset {
            if (source != androidx.compose.ui.input.nestedscroll.NestedScrollSource.UserInput) return androidx.compose.ui.geometry.Offset.Zero
            if (fresh) {
                // A new touch: catch the sheet if it is still moving, and remember whether the list was at its top.
                fresh = false
                job?.cancel()
                LibPull.closing = false
                fromTop = offset > 0f || nearTop()
            }
            if (enabled() && offset > 0f && available.y < 0f) {
                // Finger going back up: the sheet comes back first, then the list scrolls.
                val d = kotlin.math.max(available.y, -offset)
                set(offset + d)
                return androidx.compose.ui.geometry.Offset(0f, d)
            }
            return androidx.compose.ui.geometry.Offset.Zero
        }

        override fun onPostScroll(
            consumed: androidx.compose.ui.geometry.Offset, available: androidx.compose.ui.geometry.Offset,
            source: androidx.compose.ui.input.nestedscroll.NestedScrollSource,
        ): androidx.compose.ui.geometry.Offset {
            if (source == androidx.compose.ui.input.nestedscroll.NestedScrollSource.UserInput && enabled() && fromTop && available.y > 0f) {
                // The list is at its top and the finger keeps going down: the sheet follows it, one to one.
                set(offset + available.y)
                return androidx.compose.ui.geometry.Offset(0f, available.y)
            }
            return androidx.compose.ui.geometry.Offset.Zero
        }

        override suspend fun onPreFling(available: androidx.compose.ui.unit.Velocity): androidx.compose.ui.unit.Velocity {
            fresh = true
            if (offset > 0f) {
                settle(available.y)
                return available
            }
            return androidx.compose.ui.unit.Velocity.Zero
        }
    }
}
