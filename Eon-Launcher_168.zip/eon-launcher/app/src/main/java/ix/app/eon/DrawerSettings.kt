package ix.app.eon

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Replay
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.BlurOn
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.SwapVert
import androidx.compose.material.icons.outlined.TouchApp
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material.icons.outlined.ViewModule
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asComposePath
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

/**
 * Settings > Drawer. A live preview stays at the top while you change things below it.
 * The bar style and the App Library each get their own section, shown for the style you use.
 */
@Composable
fun DrawerSettingsScreen(state: EonState, onBack: () -> Unit) {
    BackHandler { onBack() }
    val cfg = DrawerConfig
    val library = state.drawerStyle == "library"
    val grid = state.drawerStyle == "shelves" || state.drawerStyle == "chips"
    fun changed() = state.saveDrawer()

    Column(
        Modifier.fillMaxSize().background(Eon.Page).systemBarsPadding().padding(horizontal = 20.dp),
    ) {
        Gap(12)
        PageHeader("Drawer", onBack)
        Gap(14)
        DrawerLivePreview(state)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            Gap(16)
            // Which drawer you use, and its ready-made looks. The groups below belong to the drawer chosen here.
            SettingsSectionLabel("DRAWER STYLE")
            val styles = listOf("bar", "library", "shelves", "chips")
            DsChips(listOf("Bar", "Library", "Shelves", "Chips"), styles.indexOf(state.drawerStyle).coerceAtLeast(0)) {
                state.chooseDrawerStyle(styles[it])
            }
            Gap(12)
            Text("Presets", color = Eon.Muted, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
            DsChips(DRAWER_PRESETS.map { it.name }, -1) {
                cfg.applyPreset(DRAWER_PRESETS[it])
                changed()
            }


            Gap(18)
            val styleTitle = when (state.drawerStyle) { "library" -> "Library"; "shelves" -> "Shelves"; "chips" -> "Chips"; else -> "Bar" }
            Text(
                "$styleTitle settings", color = Eon.Text, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.padding(start = 4.dp),
            )
            Text(
                "Tap a group to open it. Only the groups that belong to this drawer are listed.",
                color = Eon.Muted, fontSize = 12.sp, modifier = Modifier.padding(start = 4.dp, bottom = 12.dp),
            )
            var open by rememberSaveable { mutableStateOf("") }
            val toggle: (String) -> Unit = { open = if (open == it) "" else it }
            val tint = { n: Int -> DS_GROUP_COLORS[n % DS_GROUP_COLORS.size] }

            DsGroup(
                "bg", "Background", "${(cfg.bgOpacity * 100).roundToInt()}% dim · blur ${if (BlurConfig.amount == 0) "off" else "${BlurConfig.amount}%"}" +
                    (if (library || grid) " · home blur ${if (LibraryConfig.homeBlur) "on" else "off"}" else ""),
                Icons.Outlined.BlurOn, tint(0), open, toggle,
            ) {
            DsColor("Colour", cfg.bgColor, Color.Black) { cfg.bgColor = it; changed() }
            DsSlider("Opacity", "${(cfg.bgOpacity * 100).roundToInt()}%", cfg.bgOpacity, 0f..1f, {
                cfg.bgOpacity = (it * 100).roundToInt() / 100f
                changed()
            }) { cfg.bgOpacity = 0.65f; changed() }
            DsSlider("Blur", if (BlurConfig.amount == 0) "Off" else "${BlurConfig.amount}%", BlurConfig.amount.toFloat(), 0f..100f, {
                BlurConfig.set(it.roundToInt())
            }) { BlurConfig.set(0) }
            Text(
                "Blurs your wallpaper behind the drawer and settings. Some phones turn this off in battery saver.",
                color = Eon.Faint, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
            )
            LibBlurNote(Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
            DsToggle("Fade from top to bottom", "Lighter at the top, stronger behind the apps", cfg.bgGradient) {
                cfg.bgGradient = it
                changed()
            }
            if (library || grid) {
                DsToggle("Blur the home screen", "Blurs the icons and widgets behind the drawer, not only the wallpaper (Android 12 and newer)", LibraryConfig.homeBlur) {
                    LibraryConfig.chooseHomeBlur(it)
                }
            }

            }

            DsGroup(
                "apps", "Apps and labels",
                "${cfg.iconDp} dp icons · " + (if (cfg.autoFit) "auto grid" else "${cfg.columns} columns") + " · labels ${if (cfg.showLabels) "on" else "off"}",
                Icons.Outlined.Apps, tint(1), open, toggle,
            ) {
            DsColor("Text colour", cfg.textColor, Color(0xFFF5F5F6)) { cfg.textColor = it; changed() }
            DsSlider("Icon size", "${cfg.iconDp} dp", cfg.iconDp.toFloat(), 44f..88f, {
                cfg.iconDp = it.roundToInt()
                changed()
            }) { cfg.iconDp = 68; changed() }
            DsToggle("Fit the grid to the apps", "Few apps get bigger icons, many apps get more columns, so they all fit", cfg.autoFit) {
                cfg.autoFit = it
                changed()
            }
            if (!cfg.autoFit) {
                DsStepper(
                    "Columns", "${cfg.columns}",
                    { cfg.columns = (cfg.columns - 1).coerceAtLeast(3); changed() },
                    { cfg.columns = (cfg.columns + 1).coerceAtMost(6); changed() },
                )
            }
            DsSlider("Row spacing", "${cfg.rowGap} dp", cfg.rowGap.toFloat(), 0f..32f, {
                cfg.rowGap = it.roundToInt()
                changed()
            }) { cfg.rowGap = 14; changed() }
            DsToggle("Show labels", "The app's name under its icon", cfg.showLabels) { cfg.showLabels = it; changed() }
            DsToggle("Custom padding", "Set the space around the apps yourself", cfg.customPadding) {
                cfg.customPadding = it
                changed()
            }
            if (cfg.customPadding) {
                DsSlider("Side padding", "${cfg.padSide} dp", cfg.padSide.toFloat(), 0f..40f, {
                    cfg.padSide = it.roundToInt(); changed()
                }) { cfg.padSide = 14; changed() }
                DsSlider("Top padding", "${cfg.padTop} dp", cfg.padTop.toFloat(), 0f..60f, {
                    cfg.padTop = it.roundToInt(); changed()
                }) { cfg.padTop = 12; changed() }
                DsSlider("Bottom padding", "${cfg.padBottom} dp", cfg.padBottom.toFloat(), 0f..60f, {
                    cfg.padBottom = it.roundToInt(); changed()
                }) { cfg.padBottom = 20; changed() }
            }
            if (cfg.showLabels) {
                DsSlider("Label size", "${cfg.labelSp.roundToInt()} pt", cfg.labelSp, 9f..16f, {
                    cfg.labelSp = it.roundToInt().toFloat()
                    changed()
                }) { cfg.labelSp = 12f; changed() }
                DsToggle("Allow two-line labels", "Let long names use two lines", cfg.twoLine) { cfg.twoLine = it; changed() }
            }
            }

            if (grid) {
                DsGroup(
                    "grid", if (state.drawerStyle == "shelves") "Shelves" else "Chips",
                    if (state.drawerStyle == "shelves") "${(cfg.tileOpacity * 100).roundToInt()}% fill · ${cfg.tileRadius} dp corners" else "Follows the Library look",
                    Icons.Outlined.ViewModule, tint(2), open, toggle,
                ) {
                val shelves = state.drawerStyle == "shelves"
                Text(
                    "Uses the columns, icon size and labels above. The chips, search pill and shelves follow the Library look (Glass or Flat, set under LOOK below).",
                    color = Eon.Muted, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 4.dp),
                )
                if (shelves) {
                    // The same dials as the Library's folders: a shelf is drawn like a Library box.
                    DsColor("Shelf colour", cfg.tileColor, Color.White) { cfg.tileColor = it; changed() }
                    DsSlider("Shelf opacity", "${(cfg.tileOpacity * 100).roundToInt()}%", cfg.tileOpacity, 0f..0.8f, {
                        cfg.tileOpacity = (it * 100).roundToInt() / 100f
                        changed()
                    }) { cfg.tileOpacity = 0.10f; changed() }
                    DsSlider("Shelf corners", "${cfg.tileRadius} dp", cfg.tileRadius.toFloat(), 8f..40f, {
                        cfg.tileRadius = it.roundToInt()
                        changed()
                    }) { cfg.tileRadius = 28; changed() }
                    DsToggle("Shelf outline", "A thin line around each shelf", cfg.tileBorder) { cfg.tileBorder = it; changed() }
                }
                DsToggle("Recently added", "The newest apps, first in the list", cfg.showRecent) { cfg.showRecent = it; changed() }
                DsToggle("Other apps", "Apps that none of your categories hold", cfg.showOther) { cfg.showOther = it; changed() }
                }
            } else if (!library) {
                DsGroup(
                    "bar", "Category bar", (if (cfg.showBar) "On" else "Off") + " · " + DRAWER_TRANSITIONS[cfg.transition] + " transition",
                    Icons.Outlined.ViewModule, tint(2), open, toggle,
                ) {
                DsToggle("Show the category bar", "Turn it off for a plain list of apps", cfg.showBar) { cfg.showBar = it; changed() }
                Text("Category transition", color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp, top = 6.dp, bottom = 8.dp))
                DsChips(DRAWER_TRANSITIONS, cfg.transition) { cfg.transition = it; changed() }
                Gap(6)
                DsSlider("Height of the apps", "${cfg.panelPct}%", cfg.panelPct.toFloat(), 30f..75f, {
                    cfg.panelPct = it.roundToInt()
                    changed()
                }) { cfg.panelPct = 50; changed() }
                DsToggle("Show category title", null, cfg.showTitle) { cfg.showTitle = it; changed() }
                if (cfg.showTitle) {
                    DsSlider("Title size", "${cfg.titleSp} sp", cfg.titleSp.toFloat(), 18f..40f, {
                        cfg.titleSp = it.roundToInt()
                        changed()
                    }) { cfg.titleSp = 28; changed() }
                    DsToggle("Centre the title", null, cfg.titleCenter) { cfg.titleCenter = it; changed() }
                }
                DsSlider("Bar icon size", "${cfg.barIconDp} dp", cfg.barIconDp.toFloat(), 18f..32f, {
                    cfg.barIconDp = it.roundToInt()
                    changed()
                }) { cfg.barIconDp = 24; changed() }
                DsToggle("Pill background", "Put the category icons in a rounded glass bar", cfg.barPill) {
                    cfg.barPill = it
                    changed()
                }
                DsColor("Selected icon colour", cfg.accentColor, Color.White) { cfg.accentColor = it; changed() }
                DsToggle("Selected marker", "The small bar under the icon you are on", cfg.barIndicator) {
                    cfg.barIndicator = it
                    changed()
                }
                DsToggle("Swipe between categories", "Swipe the apps sideways to change category", cfg.swipeCategories) {
                    cfg.swipeCategories = it
                    changed()
                }
                }
            } else {
                DsGroup(
                    "lib", "App Library folders", "${cfg.libColumns} per row · ${(cfg.tileOpacity * 100).roundToInt()}% fill · ${cfg.tileRadius} dp corners",
                    Icons.Outlined.Folder, tint(2), open, toggle,
                ) {
                DsStepper(
                    "Folders per row", "${cfg.libColumns}",
                    { cfg.libColumns = (cfg.libColumns - 1).coerceAtLeast(2); changed() },
                    { cfg.libColumns = (cfg.libColumns + 1).coerceAtMost(3); changed() },
                )
                DsColor("Folder colour", cfg.tileColor, Color.White) { cfg.tileColor = it; changed() }
                DsSlider("Folder opacity", "${(cfg.tileOpacity * 100).roundToInt()}%", cfg.tileOpacity, 0f..0.8f, {
                    cfg.tileOpacity = (it * 100).roundToInt() / 100f
                    changed()
                }) { cfg.tileOpacity = 0.10f; changed() }
                DsSlider("Folder corners", "${cfg.tileRadius} dp", cfg.tileRadius.toFloat(), 8f..40f, {
                    cfg.tileRadius = it.roundToInt()
                    changed()
                }) { cfg.tileRadius = 28; changed() }
                DsToggle("Folder outline", "A thin line around each folder", cfg.tileBorder) { cfg.tileBorder = it; changed() }
                DsToggle("Recently added folder", "The newest apps, first in the list", cfg.showRecent) { cfg.showRecent = it; changed() }
                DsToggle("Other apps folder", "Apps that none of your categories hold", cfg.showOther) { cfg.showOther = it; changed() }
                DsToggle(
                    "Open apps from a folder", "Tap a big icon on a folder to launch the app. Off: a tap opens the folder, so a slip while scrolling never starts an app",
                    cfg.libDirectLaunch,
                ) { cfg.libDirectLaunch = it; changed() }
                }
            }

            if (library || grid) {
                DsGroup("look", "Look", LibraryConfig.styleName + if (LibraryConfig.isFlat) " · ${(LibraryConfig.flatOpacity * 100).roundToInt()}% fill" else "",
                    Icons.Outlined.Palette, tint(3), open, toggle) { LibraryLookControls() }
            }

            DsGroup("sort", "Sort and search", DRAWER_SORTS.getOrElse(cfg.sort) { "" } + if (cfg.autoKeyboard) " · keyboard opens" else "",
                Icons.Outlined.SwapVert, tint(4), open, toggle) {
            Text("Order of apps", color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
            DsChips(DRAWER_SORTS, cfg.sort) { cfg.sort = it; changed() }
            Gap(6)
            DsToggle("Open the keyboard with the drawer", "Start typing to search straight away", cfg.autoKeyboard) {
                cfg.autoKeyboard = it
                changed()
            }
            }

            DsGroup("swipes", "Swipes", listOfNotNull("swipe up" .takeIf { cfg.swipeUpHome }, "pull down".takeIf { cfg.pullDownHome }).joinToString(" · ").ifEmpty { "Off" },
                Icons.Outlined.TouchApp, tint(5), open, toggle) {
            DsToggle(
                "Swipe up goes home", "Swipe up in the drawer to close it, and swipe down on the home screen to open it. Replaces the home swipe-down gesture while on",
                cfg.swipeUpHome,
            ) { cfg.swipeUpHome = it; changed() }
            DsToggle(
                "Pull down at the top goes home", "When a list is already at its top, pull down a little more and the drawer closes",
                cfg.pullDownHome,
            ) { cfg.pullDownHome = it; changed() }
            }

            DsGroup("icons", "Icons", "${ICON_STYLES.getOrElse(state.iconStyle) { "" }} · auto size ${AUTO_MODES.getOrElse(state.autoSize) { "" }.lowercase()}",
                Icons.Outlined.Palette, tint(0), open, toggle) {
                SettingsSectionLabel("ICON SHAPE")
            ShapeGrid(state.iconShape) { state.chooseIconShape(it) }
                Gap(16)
                SettingsSectionLabel("ICON STYLE")
            DsChips(ICON_STYLES, state.iconStyle) { state.chooseIconStyle(it, state.iconTint) }
            if (state.iconStyle != 0 && state.iconStyle != 3) {
                Gap(10)
                Text("Colour", color = Eon.Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    ICON_TINTS.forEach { c ->
                        val on = state.iconTint == c
                        Box(
                            Modifier.size(28.dp).clip(CircleShape)
                                .background(if (c == 0) Eon.Button else androidx.compose.ui.graphics.SolidColor(Color(c)))
                                .border(if (on) 2.dp else 0.dp, if (on) Eon.Text else Color.Transparent, CircleShape)
                                .clickable { state.chooseIconStyle(state.iconStyle, c) },
                            contentAlignment = Alignment.Center,
                        ) { if (c == 0) Text("W", color = Eon.OnAccent, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold) }
                    }
                }
                Text(
                    "The first circle takes the colour from your wallpaper. Icons from an icon pack, or ones you chose yourself, are left as they are.",
                    color = Eon.Faint, fontSize = 12.sp, modifier = Modifier.padding(start = 4.dp, top = 8.dp),
                )
            }
                Gap(16)
                SettingsSectionLabel("AUTOMATIC ICON SIZE")
            DsChips(AUTO_MODES, state.autoSize) { state.chooseAutoSize(it, state.autoFill) }
            Text(
                when (state.autoSize) {
                    1 -> "Every icon is scaled so its visible part is the same size, and moved to the middle. Fixes icons that look small or off-centre, whatever icon pack they come from."
                    2 -> "Like Match size, but it also looks at how much of the frame is filled, so round and square icons look equally big."
                    else -> "Icons are drawn as their app or icon pack made them. Your own per-icon sizes apply."
                },
                color = Eon.Faint, fontSize = 12.sp, modifier = Modifier.padding(start = 4.dp, top = 8.dp),
            )
            if (state.autoSize != 0) {
                Gap(10)
                Text("Fill", color = Eon.Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                DsChips(AUTO_FILLS, state.autoFill) { state.chooseAutoSize(state.autoSize, it) }
            }
            }

            DsGroup("folders", "Home screen folders", FOLDER_STYLES.getOrElse(FolderStyle.mode) { "" } + " · " + (if (FolderStyle.columns == 0) "auto" else "${FolderStyle.columns}") + " columns",
                Icons.Outlined.Folder, tint(1), open, toggle) {
            DsChips(FOLDER_STYLES, FolderStyle.mode) { FolderStyle.mode = it; state.saveFolderStyle() }
            Text(
                when (FolderStyle.mode) {
                    1 -> "No card: the home screen fades away and the apps sit in the lower half, near your thumb. + adds apps, ··· has the rest. Hold an app and drag to put them in order."
                    2 -> "A sheet rises from the bottom while the home screen stays visible. Drag the handle down to close it."
                    else -> "The original: a card in the middle of the screen."
                },
                color = Eon.Faint, fontSize = 12.sp, modifier = Modifier.padding(start = 4.dp, top = 8.dp),
            )
            Gap(10)
            Text("Folder menu", color = Eon.Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
            DsChips(FOLDER_MENUS, FolderStyle.menuMode) { FolderStyle.menuMode = it; state.saveFolderStyle() }
            Text(
                when (FolderStyle.menuMode) {
                    1 -> "Only the + button. Tap it to add apps, hold it to open the folder's menu."
                    else -> "A ··· button next to + opens the menu."
                },
                color = Eon.Faint, fontSize = 12.sp, modifier = Modifier.padding(start = 4.dp, top = 8.dp),
            )
            DsToggle("See-through folders", "A lighter shade over the wallpaper and a see-through card, instead of solid black", FolderStyle.translucent) {
                FolderStyle.translucent = it
                state.saveFolderStyle()
            }
            DsSlider("Icon size in folders", "${FolderStyle.iconDp} dp", FolderStyle.iconDp.toFloat(), 44f..84f, {
                FolderStyle.iconDp = it.roundToInt()
                state.saveFolderStyle()
            }) { FolderStyle.iconDp = 60; state.saveFolderStyle() }
            Gap(10)
            Text("Columns", color = Eon.Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
            DsChips(listOf("Auto", "3", "4", "5", "6"), FolderStyle.columns.let { if (it == 0) 0 else it - 2 }) {
                FolderStyle.columns = if (it == 0) 0 else it + 2
                state.saveFolderStyle()
            }
            DsSlider("Space between icons", if (FolderStyle.hGap == 0) "Even" else "${FolderStyle.hGap} dp", FolderStyle.hGap.toFloat(), 0f..32f, {
                FolderStyle.hGap = it.roundToInt()
                state.saveFolderStyle()
            }) { FolderStyle.hGap = 0; state.saveFolderStyle() }
            DsSlider("Space between rows", "${FolderStyle.vGap} dp", FolderStyle.vGap.toFloat(), 8f..56f, {
                FolderStyle.vGap = it.roundToInt()
                state.saveFolderStyle()
            }) { FolderStyle.vGap = 30; state.saveFolderStyle() }
            DsToggle("Names under icons", "Turn off for a clean grid of icons", FolderStyle.labels) {
                FolderStyle.labels = it
                state.saveFolderStyle()
            }
            DsSlider("Height of new widgets in folders", "${FolderStyle.widgetDp} dp", FolderStyle.widgetDp.toFloat(), 100f..300f, {
                FolderStyle.widgetDp = it.roundToInt()
                state.saveFolderStyle()
            }) { FolderStyle.widgetDp = 150; state.saveFolderStyle() }
            Text(
                "To put a widget in a folder, open the folder and choose Widgets in its menu. Then hold the widget to move it anywhere and resize it, just like on the home screen.",
                color = Eon.Faint, fontSize = 12.sp, modifier = Modifier.padding(start = 4.dp, top = 4.dp),
            )
            }

            DsGroup("adv", "Advanced",
                listOf(cfg.searchIndex, cfg.hidePlayStore, cfg.hideIconPacks, cfg.moveDown, cfg.stackBottom).count { it }.let { if (it == 0) "Nothing changed" else "$it on" },
                Icons.Outlined.Tune, tint(2), open, toggle) {
                DsToggle("Search apps by index", "A to Z strip at the edge (name order only)", cfg.searchIndex) { cfg.searchIndex = it; changed() }
                DsToggle("Hide Play Store icon", null, cfg.hidePlayStore) { cfg.hidePlayStore = it; changed() }
                DsToggle("Hide icon packs", "Apps that only hold icons or themes", cfg.hideIconPacks) { cfg.hideIconPacks = it; changed() }
                DsToggle("Move icons down", "Short lists sit at the bottom, near your thumb", cfg.moveDown) { cfg.moveDown = it; changed() }
                DsToggle("Stack apps from the bottom", "The list starts at the bottom edge", cfg.stackBottom) { cfg.stackBottom = it; changed() }
                DsToggle("Close the drawer after launching", null, cfg.closeAfterLaunch) { cfg.closeAfterLaunch = it; changed() }
            }

            Gap(20)
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Eon.P1)
                    .border(1.dp, Eon.P2, RoundedCornerShape(16.dp))
                    .clickable { cfg.reset(); changed() }.padding(vertical = 14.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text("Reset drawer settings", color = Eon.Danger, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
            Gap(28)
        }
    }
}

// ---- groups

private val DS_GROUP_COLORS = listOf(
    Color(0xFF35D6F0), Color(0xFF4F8CFF), Color(0xFF9B7BFF), Color(0xFFF25CCB), Color(0xFFFF7A66), Color(0xFFFFA63D),
)

/**
 * A folder of settings: one tidy card with an icon, its name and a line that shows what it is set to now. Tap to open it;
 * only one group is open at a time, so the page stays short.
 */
@Composable
private fun DsGroup(
    id: String, title: String, summary: String, icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color,
    open: String, onToggle: (String) -> Unit, content: @Composable ColumnScope.() -> Unit,
) {
    val isOpen = open == id
    val turn by androidx.compose.animation.core.animateFloatAsState(if (isOpen) 180f else 0f, androidx.compose.animation.core.tween(200), label = "dsGroupTurn")
    val shape = RoundedCornerShape(20.dp)
    Column(
        Modifier.fillMaxWidth().padding(bottom = 10.dp).clip(shape).background(Eon.P0)
            .border(1.dp, if (isOpen) color.copy(alpha = 0.55f) else Eon.P2, shape),
    ) {
        Row(
            Modifier.fillMaxWidth().clickable { onToggle(id) }.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Box(
                Modifier.size(40.dp).clip(RoundedCornerShape(13.dp)).background(color.copy(alpha = 0.18f)),
                contentAlignment = Alignment.Center,
            ) { Icon(icon, null, tint = color, modifier = Modifier.size(22.dp)) }
            Column(Modifier.weight(1f)) {
                Text(title, color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                Text(summary, color = Eon.Muted, fontSize = 12.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
            }
            Icon(
                Icons.Outlined.ExpandMore, null, tint = Eon.Soft,
                modifier = Modifier.size(24.dp).graphicsLayer { rotationZ = turn },
            )
        }
        androidx.compose.animation.AnimatedVisibility(visible = isOpen) {
            Column(Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, bottom = 12.dp), content = content)
        }
    }
}

// ---- icon shapes

private class IconPathShape(val index: Int) : androidx.compose.ui.graphics.Shape {
    override fun createOutline(
        size: androidx.compose.ui.geometry.Size,
        layoutDirection: androidx.compose.ui.unit.LayoutDirection,
        density: androidx.compose.ui.unit.Density,
    ): androidx.compose.ui.graphics.Outline =
        androidx.compose.ui.graphics.Outline.Generic(iconShapePath(index, size.width).asComposePath())
}

@Composable
private fun ShapeGrid(selected: Int, onPick: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ICON_SHAPES.chunked(4).forEachIndexed { r, row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEachIndexed { c, name ->
                    val i = r * 4 + c
                    val on = i == selected
                    Column(
                        Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).clickable { onPick(i) }.padding(vertical = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Box(
                            Modifier.size(52.dp).clip(IconPathShape(i))
                                .background(if (on) Eon.Button else androidx.compose.ui.graphics.SolidColor(Eon.P2)),
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(name, color = if (on) Eon.Text else Eon.Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
                repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

// ---- rows

@Composable
private fun DsToggle(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(horizontal = 4.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            if (subtitle != null) Text(subtitle, color = Eon.Muted, fontSize = 12.sp, lineHeight = 16.sp)
        }
        EonSwitch(checked, onChange)
    }
}

@Composable
private fun DsStepper(title: String, value: String, onMinus: () -> Unit, onPlus: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        DsStepButton("−", onMinus)
        Text(value, color = Eon.Text, fontSize = 16.sp, modifier = Modifier.width(56.dp), textAlign = TextAlign.Center)
        DsStepButton("+", onPlus)
    }
}

@Composable
private fun DsStepButton(label: String, onClick: () -> Unit) {
    Box(
        Modifier.size(width = 52.dp, height = 44.dp).clip(RoundedCornerShape(14.dp)).background(Eon.P1).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = Eon.Text, fontSize = 22.sp) }
}

@Composable
private fun DsSlider(
    title: String, valueText: String, value: Float, range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit, onReset: () -> Unit,
) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text(valueText, color = Eon.Muted, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(12.dp))
            Box(
                Modifier.size(36.dp).clip(RoundedCornerShape(12.dp)).background(Eon.P1).clickable(onClick = onReset),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Outlined.Replay, "Reset", tint = Eon.Soft, modifier = Modifier.size(18.dp)) }
        }
        DsSliderBar(value, range, onChange)
    }
}

@Composable
private fun DsSliderBar(value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Slider(
        value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange, valueRange = range,
        colors = SliderDefaults.colors(
            thumbColor = Color.White, activeTrackColor = Eon.Accent, inactiveTrackColor = Eon.ov(0x33),
        ),
    )
}

/** A row of pills; the chosen one is filled with the rainbow. Pass -1 when none is "chosen" (presets). */
@Composable
private fun DsChips(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        options.forEachIndexed { i, label ->
            val on = i == selected
            Box(
                Modifier.height(40.dp).clip(CircleShape).accentFill(on, Eon.P1)
                    .clickable { onSelect(i) }.padding(horizontal = 20.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(label, color = if (on) Eon.OnAccent else Eon.Text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

private val SWATCHES = listOf(
    Color.White, Color(0xFFF5F5F6), Color(0xFF8A8C93), Color.Black, Color(0xFF070B1F),
    Color(0xFF35D6F0), Color(0xFF4F8CFF), Color(0xFF9B7BFF), Color(0xFFF25CCB),
    Color(0xFFFF7A66), Color(0xFFFFA63D), Color(0xFFFFD23D), Color(0xFF4ADE80),
)

/** A colour: a row of swatches, and Custom for hue, saturation and brightness. */
@Composable
private fun DsColor(title: String, value: Color, default: Color, onChange: (Color) -> Unit) {
    var custom by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Box(Modifier.size(22.dp).clip(CircleShape).background(value).border(1.dp, Color(0x55FFFFFF), CircleShape))
            Spacer(Modifier.width(12.dp))
            Box(
                Modifier.size(36.dp).clip(RoundedCornerShape(12.dp)).background(Eon.P1).clickable { onChange(default) },
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Outlined.Replay, "Reset", tint = Eon.Soft, modifier = Modifier.size(18.dp)) }
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            SWATCHES.forEach { c ->
                val on = c == value
                Box(
                    Modifier.size(34.dp).clip(CircleShape).background(c)
                        .border(if (on) 2.dp else 1.dp, if (on) Eon.Accent else Eon.ov(0x33), CircleShape)
                        .clickable { onChange(c) },
                )
            }
            Box(
                Modifier.height(34.dp).clip(CircleShape).accentFill(custom, Eon.P1)
                    .clickable { custom = !custom }.padding(horizontal = 14.dp),
                contentAlignment = Alignment.Center,
            ) { Text("Custom", color = if (custom) Eon.OnAccent else Eon.Text, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
        }
        if (custom) {
            val start = remember { FloatArray(3).also { android.graphics.Color.colorToHSV(value.toArgb(), it) } }
            var h by remember { mutableFloatStateOf(start[0]) }
            var s by remember { mutableFloatStateOf(start[1]) }
            var v by remember { mutableFloatStateOf(start[2]) }
            fun push() = onChange(Color(android.graphics.Color.HSVToColor(floatArrayOf(h, s, v))))
            Text("Hue", color = Eon.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
            DsSliderBar(h, 0f..360f) { h = it; push() }
            Text("Saturation", color = Eon.Muted, fontSize = 12.sp)
            DsSliderBar(s, 0f..1f) { s = it; push() }
            Text("Brightness", color = Eon.Muted, fontSize = 12.sp)
            DsSliderBar(v, 0f..1f) { v = it; push() }
        }
    }
}

/** Glass or Flat for the Library and the grid drawers, and every dial of the Flat look. */
@Composable
private fun LibraryLookControls() {
    val cfg = LibraryConfig
    DsChips(cfg.styleNames, cfg.style) { cfg.chooseStyle(it) }
    if (cfg.isFlat) {
        Gap(8)
        DsColor("Fill colour", cfg.flatColor, Color(0xFF1A1C20)) { cfg.flatColor = it; cfg.save() }
        DsSlider("Fill opacity", "${(cfg.flatOpacity * 100).roundToInt()}%", cfg.flatOpacity, 0f..1f, {
            cfg.flatOpacity = (it * 100).roundToInt() / 100f
            cfg.save()
        }) { cfg.flatOpacity = 0.96f; cfg.save() }
        DsColor("Border colour", cfg.flatBorderColor, Color(0xFF2A2D33)) { cfg.flatBorderColor = it; cfg.save() }
        DsSlider("Border opacity", "${(cfg.flatBorderOpacity * 100).roundToInt()}%", cfg.flatBorderOpacity, 0f..1f, {
            cfg.flatBorderOpacity = (it * 100).roundToInt() / 100f
            cfg.save()
        }) { cfg.flatBorderOpacity = 1f; cfg.save() }
        DsSlider("Border width", "${"%.1f".format(cfg.flatBorderWidth)} dp", cfg.flatBorderWidth, 0f..4f, {
            cfg.flatBorderWidth = (it * 2).roundToInt() / 2f
            cfg.save()
        }) { cfg.flatBorderWidth = 1f; cfg.save() }
        DsSlider("Corner roundness", "${cfg.flatRadius} dp", cfg.flatRadius.toFloat(), 0f..40f, {
            cfg.flatRadius = it.roundToInt()
            cfg.save()
        }) { cfg.flatRadius = 14; cfg.save() }
    }
}
