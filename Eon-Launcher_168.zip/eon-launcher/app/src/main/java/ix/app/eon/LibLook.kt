package ix.app.eon

import org.json.JSONObject

/**
 * The calmer, iOS-style Library look (0.80.1): one light dim instead of two, a blurred wallpaper, one neutral card material,
 * quieter extras. It is switched on once, the first time this version starts, because the old values are saved on the
 * phone and new defaults alone would change nothing. The values you had are kept so the "Classic" preset can bring them back.
 */
internal object LibLook {
    private const val VERSION = 1

    /** Runs after every config has been loaded. Does nothing after the first time. */
    fun migrate(p: Prefs) {
        if (p.getInt("libLookV", 0) >= VERSION) return
        val old = JSONObject()
            .put("bgOpacity", DrawerConfig.bgOpacity.toDouble())
            .put("blur", BlurConfig.amount)
            .put("countChip", LibraryConfig.countChip)
            .put("bottomBar", LibraryConfig.bottomBar)
            .put("pills", LibraryConfig.cardOn("pills"))
        p.putString("libClassic", old.toString())
        applyNew(p)
        p.putInt("libLookV", VERSION)
    }

    /** The new look: light dim, strong wallpaper blur, no count chip, no bottom bar, no quick-facts row, neutral cards. */
    private fun applyNew(p: Prefs) {
        DrawerConfig.bgOpacity = 0.30f
        DrawerConfig.save(p)
        if (BlurConfig.amount < 60) BlurConfig.set(60)
        LibraryConfig.countChip = false
        LibraryConfig.bottomBar = false
        LibraryConfig.tintCards = false
        LibraryConfig.classicDim = false
        LibraryConfig.setCard("pills", false)
        // Coming back from Classic: the glass layers and the capsule pill are part of the calmer look.
        LibraryConfig.frost = 0
        LibraryConfig.glassTop = true
        LibraryConfig.glassShade = true
        LibraryConfig.glassShadow = true
        LibraryConfig.clusterPlate = 0
        LibraryConfig.iosPill = true
        LibraryConfig.save()
    }

    /** "Classic": the dim, blur, tint, chips and bar you had before this look. Margins and label style stay as they are now. */
    fun restoreClassic(p: Prefs) {
        val o = try {
            JSONObject(p.getString("libClassic").ifEmpty { "{}" })
        } catch (_: Exception) {
            JSONObject()
        }
        DrawerConfig.bgOpacity = o.optDouble("bgOpacity", 0.65).toFloat().coerceIn(0f, 1f)
        DrawerConfig.save(p)
        BlurConfig.set(o.optInt("blur", 0))
        LibraryConfig.countChip = o.optBoolean("countChip", true)
        LibraryConfig.bottomBar = o.optBoolean("bottomBar", true)
        LibraryConfig.tintCards = true
        LibraryConfig.classicDim = true
        // The glass layers added in 0.80.2 were not part of the old look.
        LibraryConfig.clearGlass = false
        LibraryConfig.frost = 1
        LibraryConfig.glassTop = false
        LibraryConfig.glassShade = false
        LibraryConfig.glassShadow = false
        LibraryConfig.grain = false
        LibraryConfig.clusterPlate = 1
        LibraryConfig.iosPill = false
        LibraryConfig.setCard("pills", o.optBoolean("pills", true))
        LibraryConfig.save()
    }

    /**
     * The "iOS" preset: frosted cards in one material, 25% dim, blur 60, frost chosen from the wallpaper, the glass layers
     * on, no plate under the +N icons, the search pill as a capsule, and none of the extras (count chip, bottom bar, quick
     * facts, "New box" tile). The launcher sets the icon shape to Squircle when this preset is chosen.
     */
    fun applyIos(p: Prefs) {
        applyNew(p)
        DrawerConfig.bgOpacity = 0.25f
        DrawerConfig.save(p)
        BlurConfig.set(60)
        LibraryConfig.style = 0
        LibraryConfig.tintCards = false
        LibraryConfig.clearGlass = false
        LibraryConfig.frost = 0
        LibraryConfig.glassTop = true
        LibraryConfig.glassShade = true
        LibraryConfig.glassShadow = true
        LibraryConfig.grain = false
        LibraryConfig.clusterPlate = 0
        LibraryConfig.iosPill = true
        LibraryConfig.tidyCluster = true
        LibraryConfig.edgeFade = true
        LibraryConfig.badgeDots = true
        LibraryConfig.quickRows = false
        LibraryConfig.fillGap = false
        LibraryConfig.save()
    }

    /** Back to the new look from Classic or any other preset. */
    fun restoreNew(p: Prefs) = applyNew(p)
}
