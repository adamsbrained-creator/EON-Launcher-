package ix.app.eon

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** What a folder looks like on the home screen: a rounded square with the first four apps inside, and its name. */
@Composable
fun FolderIconBody(
    folder: Item, apps: List<AppEntry>, iconSize: Dp, showLabel: Boolean,
    labelSp: Float = 12f, twoLine: Boolean = false, labelColor: Color = Eon.DText,
    scale: Float = folder.iconScale,
) {
    val preview = folder.members.mapNotNull { k -> apps.firstOrNull { it.key == k } }.take(4)
    val shape = RoundedCornerShape(iconSize * 0.28f)
    val mini = iconSize * 0.36f
    // A folder can wear one icon from an icon pack. It is drawn off the main thread, and kept ready afterwards.
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val packPx = with(androidx.compose.ui.platform.LocalDensity.current) { iconSize.roundToPx() }.coerceAtLeast(64)
    val packBmp by androidx.compose.runtime.produceState<androidx.compose.ui.graphics.ImageBitmap?>(
        if (folder.iconKind == "pack") FolderPackIcons.peek(folder.iconValue, packPx) else null,
        folder.iconKind, folder.iconValue, packPx, IconCustom.reshapePack,
    ) {
        value = if (folder.iconKind == "pack") {
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {
                try {
                    FolderPackIcons.load(ctx, folder.iconValue, packPx)
                } catch (_: Exception) {
                    null
                }
            }
        } else {
            null
        }
    }
    // If the pack or its icon is gone, the folder goes back to the preview of its apps.
    val kind = if (folder.iconKind == "pack" && packBmp == null) "" else folder.iconKind
    val bare = kind == "pack" && folder.iconColor == 0
    // Folders shrink a little under a finger too, like app icons.
    var pressed by remember { mutableStateOf(false) }
    val pressScale by androidx.compose.animation.core.animateFloatAsState(
        if (pressed && AnimConfig.press) 0.9f else 1f, Motion.snappy(), label = "folderPress",
    )
    Column(
        Modifier.pressFeedback { pressed = it }
            .graphicsLayer { scaleX = pressScale; scaleY = pressScale }
            .padding(vertical = 2.dp, horizontal = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        val bg = if (folder.iconColor != 0) Color(folder.iconColor) else Color(0x40FFFFFF)
        val picture = kind == "image" || kind == "pack"
        Box(
            Modifier.size(iconSize).scaledIcon(scale).then(
                if (bare) {
                    Modifier
                } else {
                    Modifier.clip(shape).background(bg)
                        .border(if (picture) 1.dp else 1.5.dp, if (picture) SolidColor(Color(0x44FFFFFF)) else Eon.Button, shape)
                },
            ),
            contentAlignment = Alignment.Center,
        ) {
            when (kind) {
                "pack" -> packBmp?.let { Image(bitmap = it, contentDescription = null, modifier = Modifier.fillMaxSize()) }
                "glyph" -> Icon(catIcon(folder.iconValue), null, tint = Color.White, modifier = Modifier.size(iconSize * 0.52f))
                "emoji" -> Text(folder.iconValue, fontSize = (iconSize.value * 0.5f).sp, textAlign = TextAlign.Center)
                "image" -> {
                    val bmp = remember(folder.iconValue) {
                        try {
                            android.graphics.BitmapFactory.decodeFile(folder.iconValue)?.asImageBitmap()
                        } catch (_: Exception) {
                            null
                        }
                    }
                    if (bmp != null) {
                        Image(bitmap = bmp, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                    }
                }
                else -> Column(verticalArrangement = Arrangement.spacedBy(iconSize * 0.06f)) {
                    preview.chunked(2).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(iconSize * 0.06f)) {
                            row.forEach { app -> Image(bitmap = app.icon, contentDescription = null, modifier = Modifier.size(mini)) }
                        }
                    }
                }
            }
        }
        if (showLabel) {
            Gap(4)
            Text(
                folder.name.ifBlank { "Folder" }, color = labelColor, fontSize = labelSp.sp,
                maxLines = if (twoLine) 2 else 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                style = LabelTextStyle(labelSp),
                modifier = Modifier.wrapContentHeight(align = Alignment.Top, unbounded = true),
            )
        }
    }
}

/**
 * An open folder as a card (the original look): its name (tap to rename) and its apps. Tap an app to open it,
 * long-press for its menu (which has Take out of folder). Tapping outside closes it.
 */
@Composable
fun FolderCard(
    state: EonState, folder: Item, apps: List<AppEntry>, holder: WidgetHolder,
    onLaunch: (AppEntry) -> Unit, onMenu: (AppEntry) -> Unit, onClose: () -> Unit,
) {
    val members = folder.members.mapNotNull { k -> apps.firstOrNull { it.key == k } }
    var name by remember(folder.key) { mutableStateOf(folder.name) }
    var pickingIcon by remember(folder.key) { mutableStateOf(false) }
    // Save the name however the popup closes.
    DisposableEffect(folder.key) { onDispose { state.commitLayout() } }
    Box(
        Modifier.fillMaxSize().background(Color(0x99000000))
            .pointerInput(Unit) { detectTapGestures(onTap = { onClose() }) },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier.padding(horizontal = 24.dp).fillMaxWidth()
                .folderCardBg()
                .pointerInput(Unit) { detectTapGestures(onTap = { }) }
                .padding(horizontal = 18.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            BasicTextField(
                value = name,
                onValueChange = { name = it.take(24); folder.name = name },
                singleLine = true,
                textStyle = TextStyle(color = Eon.Text, fontSize = 22.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center),
                cursorBrush = SolidColor(Eon.Accent),
                modifier = Modifier.fillMaxWidth(),
                decorationBox = { inner ->
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        if (name.isEmpty()) Text("Folder", color = Eon.Faint, fontSize = 22.sp)
                        inner()
                    }
                },
            )
            Gap(16)
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                modifier = Modifier.heightIn(max = 380.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(members, key = { it.key }) { app ->
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        AppIcon(app, 52.dp, true, { onLaunch(app) }, { onMenu(app) })
                    }
                }
            }
            Gap(14)
            if (folder.members.size == 2) {
                Box(
                    Modifier.clip(CircleShape).clickable { folder.pair = !folder.pair; state.commitLayout() }
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                ) {
                    Text(
                        if (folder.pair) "Tap opens the folder (turn off app pair)" else "Tap opens both apps side by side (app pair)",
                        color = Eon.Accent, fontSize = 14.sp, fontWeight = FontWeight.Medium,
                    )
                }
            }
            Box(
                Modifier.clip(CircleShape).clickable { state.openFolderWidgets(folder.key) }
                    .padding(horizontal = 12.dp, vertical = 8.dp),
            ) {
                val n = state.stacks[folderStackId(folder.key)]?.members?.size ?: 0
                Text(if (n > 0) "Widgets ($n)" else "Add widgets", color = Eon.Accent, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            }
            if ((state.stacks[folderStackId(folder.key)]?.members?.size ?: 0) > 0) {
                Box(
                    Modifier.clip(CircleShape)
                        .clickable { FolderWidgetLayout.editing = state.stacks[folderStackId(folder.key)]?.members?.firstOrNull() }
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                ) { Text("Move and resize widgets", color = Eon.Accent, fontSize = 14.sp, fontWeight = FontWeight.Medium) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                Box(
                    Modifier.clip(CircleShape).clickable {
                        state.gestureEditor = GestureTarget("f", folder.key, folder.name.ifBlank { "Folder" })
                        onClose()
                    }.padding(horizontal = 10.dp, vertical = 8.dp),
                ) { Text("Gestures", color = Eon.Accent, fontSize = 14.sp, fontWeight = FontWeight.Medium) }
                Box(
                    Modifier.clip(CircleShape).clickable { pickingIcon = true }
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                ) { Text("Change icon", color = Eon.Accent, fontSize = 14.sp, fontWeight = FontWeight.Medium) }
                Box(
                    Modifier.clip(CircleShape).clickable { state.disbandFolder(folder.key) }
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                ) { Text("Remove folder", color = Eon.Muted, fontSize = 14.sp, fontWeight = FontWeight.Medium) }
            }
        }
        // The widgets float over the card, wherever you put them.
        FolderWidgetLayer(state, holder, folder)
        if (pickingIcon) FolderIconDialog(state, folder, apps) { pickingIcon = false }
    }
}
