package ix.app.eon

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.ViewModule
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** One folder tile in the App Library. [manage] is true for your own categories (long-press for Rename and so on). */
private data class LibTile(
    val id: String, val name: String, val icon: String?, val apps: List<AppEntry>, val manage: Boolean,
)

private fun buildTiles(apps: List<AppEntry>, state: EonState): List<LibTile> {
    val out = ArrayList<LibTile>()
    val recent = apps.sortedByDescending { it.firstInstall }.take(8)
    if (DrawerConfig.showRecent && recent.isNotEmpty()) out.add(LibTile("~recent", "Recently added", null, recent, false))
    val cats = state.categories.filter { it.id != CAT_ALL }
    cats.forEach { c -> out.add(LibTile(c.id, c.name, c.icon, apps.filter { state.inCategory(it, c.id) }, true)) }
    // Apps that no folder above holds, so every app can be reached without searching.
    val rest = apps.filter { a -> cats.none { state.inCategory(a, it.id) } }
    if (DrawerConfig.showOther && rest.isNotEmpty()) out.add(LibTile("~other", "Other apps", null, rest, false))
    return out
}

private fun initial(label: String): String {
    val c = label.trim().firstOrNull()?.uppercaseChar()
    return if (c != null && c.isLetter()) c.toString() else "#"
}

/**
 * The iOS-style drawer: a search pill and a two-column grid of folders. Each folder shows the first
 * apps of a category as big icons and, when there are more, a small cluster of the next ones; tap the
 * folder (or the cluster) to open all of them. Tap the search pill for an A to Z list. Long-press one
 * of your folders for Add category, Edit icon, Rename and Remove. Fling down at the top to close.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppLibrary(
    apps: List<AppEntry>, state: EonState, focusSearch: Boolean,
    onLaunch: (AppEntry) -> Unit, onMenu: (AppEntry) -> Unit, onClose: () -> Unit,
    drag: DragState, onDrop: (AppEntry, Offset) -> Unit,
    onSettings: () -> Unit = {},
) {
    val focus = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    var searching by remember { mutableStateOf(focusSearch || DrawerConfig.autoKeyboard) }
    var query by remember { mutableStateOf("") }
    var openId by remember { mutableStateOf<String?>(null) }
    var adding by remember { mutableStateOf(false) }
    var menuFor by remember { mutableStateOf<String?>(null) }
    var renaming by remember { mutableStateOf<String?>(null) }
    var picking by remember { mutableStateOf<String?>(null) }
    val bounds = remember { HashMap<String, Rect>() }
    val tiles by remember(apps) { derivedStateOf { buildTiles(apps, state) } }
    val close by rememberUpdatedState(onClose)
    val pull = remember {
        object : NestedScrollConnection {
            override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
                if (available.y > 1500f) close()
                return Velocity.Zero
            }
        }
    }

    LaunchedEffect(searching) {
        if (searching) {
            try {
                focus.requestFocus()
            } catch (_: Exception) {
            }
        }
    }
    BackHandler(enabled = openId != null) { openId = null }
    BackHandler(enabled = searching) {
        searching = false
        query = ""
        focusManager.clearFocus()
    }

    val q = query.trim()

    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize()
                .background(DrawerConfig.scrim())
                .pointerInput(Unit) { detectTapGestures(onTap = { }) }
                .systemBarsPadding().imePadding(),
        ) {
            Gap(8)
            // The search pill. Tapping it turns it into a field with an A to Z list below.
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
                    .glass(RoundedCornerShape(16.dp))
                    .then(if (!searching) Modifier.clickable { searching = true } else Modifier)
                    .padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Outlined.Search, null, tint = Eon.Muted, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(10.dp))
                Box(Modifier.weight(1f).padding(vertical = 14.dp)) {
                    if (!searching) {
                        Text("App Library", color = Eon.Muted, fontSize = 16.sp)
                    } else {
                        if (query.isEmpty()) Text("Search", color = Eon.Faint, fontSize = 16.sp)
                        BasicTextField(
                            value = query,
                            onValueChange = { query = it },
                            singleLine = true,
                            textStyle = TextStyle(color = Eon.Text, fontSize = 16.sp),
                            cursorBrush = SolidColor(Eon.Accent),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                            modifier = Modifier.fillMaxWidth().focusRequester(focus),
                        )
                    }
                }
                if (searching) {
                    Text(
                        "Cancel", color = Eon.Accent, fontSize = 15.sp, fontWeight = FontWeight.Medium,
                        modifier = Modifier.clickable {
                            searching = false
                            query = ""
                            focusManager.clearFocus()
                        }.padding(start = 10.dp, top = 8.dp, bottom = 8.dp),
                    )
                }
            }

            if (searching) {
                val list = remember(apps, q) {
                    if (q.isEmpty()) apps else apps.filter { it.label.contains(q, ignoreCase = true) }
                }
                val groups = remember(list) {
                    list.groupBy { initial(it.label) }.toList().sortedBy { if (it.first == "#") "~" else it.first }
                }
                LazyColumn(
                    Modifier.weight(1f).fillMaxWidth(),
                    contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 24.dp),
                ) {
                    if (groups.isEmpty()) {
                        item(key = "none") {
                            Text(
                                "No apps match", color = Eon.Muted, fontSize = 14.sp,
                                modifier = Modifier.fillMaxWidth().padding(top = 40.dp), textAlign = TextAlign.Center,
                            )
                        }
                    }
                    groups.forEach { (letter, group) ->
                        item(key = "h$letter") {
                            Text(
                                letter, color = Eon.Muted, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(start = 4.dp, top = 14.dp, bottom = 4.dp),
                            )
                        }
                        items(group, key = { it.key }) { app -> ListRow(app, onLaunch, onMenu) }
                    }
                }
            } else {
                val perRow = DrawerConfig.libColumns
                val rows = remember(tiles, perRow) { tiles.chunked(perRow) }
                LazyColumn(
                    Modifier.weight(1f).fillMaxWidth().nestedScroll(pull),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 28.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    items(rows, key = { r -> r.joinToString("|") { it.id } }) { row ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(if (perRow == 3) 12.dp else 16.dp)) {
                            row.forEach { t ->
                                Box(Modifier.weight(1f)) {
                                    FolderTile(
                                        tile = t, drag = drag, onLaunch = onLaunch, onMenu = onMenu, onDrop = onDrop,
                                        onOpen = { openId = t.id },
                                        onLongPress = { if (t.manage) menuFor = t.id },
                                        onBounds = { r -> bounds[t.id] = r },
                                    )
                                }
                            }
                            repeat(perRow - row.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                    item(key = "add") {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            LibButton(Icons.Outlined.Add, "Add category", Modifier.weight(1f)) { adding = true }
                            LibButton(Icons.Outlined.Tune, "Drawer settings", Modifier.weight(1f), onSettings)
                        }
                    }
                }
            }
        }

        openId?.let { id ->
            tiles.firstOrNull { it.id == id }?.let { t ->
                FolderSheet(t.name, t.apps, onLaunch, onMenu, drag, onDrop) { openId = null }
            }
        }
        if (adding) {
            AddCategoryScreen(
                existing = state.categories.map { it.id }.toSet(),
                onPick = { def -> state.addCategory(def); adding = false },
                onCustom = {
                    val id = state.addCustomCategory()
                    adding = false
                    renaming = id
                },
                onBack = { adding = false },
            )
        }
    }

    menuFor?.let { id ->
        val cat = state.categories.firstOrNull { it.id == id }
        if (cat != null) {
            CategoryPopup(
                title = cat.name, anchor = bounds[id], canRemove = id != CAT_ALL,
                onAdd = { menuFor = null; adding = true },
                onEditIcon = { menuFor = null; picking = id },
                onRename = { menuFor = null; renaming = id },
                onRemove = { menuFor = null; state.removeCategory(id) },
                onDismiss = { menuFor = null },
                extras = listOf(
                    PopupAction(Icons.Outlined.ViewModule, "Switch to Bar") {
                        menuFor = null
                        state.chooseDrawerStyle("bar")
                    },
                    PopupAction(Icons.Outlined.Tune, "Drawer settings") {
                        menuFor = null
                        onSettings()
                    },
                ),
            )
        }
    }
    renaming?.let { id ->
        val cat = state.categories.firstOrNull { it.id == id }
        if (cat != null) {
            NameDialog(
                title = "Rename category", initial = cat.name,
                onDone = { state.renameCategory(id, it); renaming = null },
                onDismiss = { renaming = null },
            )
        }
    }
    picking?.let { id ->
        val cat = state.categories.firstOrNull { it.id == id }
        if (cat != null) {
            IconPickerDialog(
                current = cat.icon,
                onPick = { state.setCategoryIcon(id, it); picking = null },
                onDismiss = { picking = null },
            )
        }
    }
}

/** A row in the A to Z list. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ListRow(app: AppEntry, onLaunch: (AppEntry) -> Unit, onMenu: (AppEntry) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
            .combinedClickable(onClick = { onLaunch(app) }, onLongClick = { onMenu(app) })
            .padding(horizontal = 4.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Image(bitmap = app.icon, contentDescription = null, modifier = Modifier.size(46.dp))
        Spacer(Modifier.width(16.dp))
        Text(app.label, color = DrawerConfig.textColor, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/**
 * One folder: a rounded, see-through square with four slots. Up to four apps are shown as icons;
 * with more, the last slot holds a small 2 x 2 cluster of the next apps. Icons can be launched, opened
 * for their menu or dragged out to the home screen like in the other drawer.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FolderTile(
    tile: LibTile, drag: DragState,
    onLaunch: (AppEntry) -> Unit, onMenu: (AppEntry) -> Unit, onDrop: (AppEntry, Offset) -> Unit,
    onOpen: () -> Unit, onLongPress: () -> Unit, onBounds: (Rect) -> Unit,
) {
    val haptic = LocalHapticFeedback.current
    val shape = RoundedCornerShape(DrawerConfig.tileRadius.dp)
    val fill = DrawerConfig.tileColor.copy(alpha = DrawerConfig.tileOpacity)
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        BoxWithConstraints(
            Modifier.fillMaxWidth().aspectRatio(1f).clip(shape)
                .background(fill)
                .then(
                    if (DrawerConfig.tileBorder) Modifier.border(1.dp, DrawerConfig.tileColor.copy(alpha = DrawerConfig.tileOpacity * 0.55f), shape)
                    else Modifier,
                )
                .onGloballyPositioned { onBounds(it.boundsInWindow()) },
        ) {
            // Behind the icons: a tap on an icon launches it, a tap anywhere else on the folder opens it.
            Box(
                Modifier.matchParentSize().combinedClickable(
                    onClick = onOpen,
                    onLongClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        onLongPress()
                    },
                ),
            )
            val w = maxWidth
            val pad = w * 0.075f
            val gap = w * 0.08f
            val icon = (w - pad * 2 - gap) / 2
            val apps = tile.apps
            if (apps.isEmpty()) {
                Icon(
                    catIcon(tile.icon ?: "folder"), null, tint = Color(0x66FFFFFF),
                    modifier = Modifier.align(Alignment.Center).size(w * 0.3f),
                )
            } else {
                val overflow = apps.size > 4
                val big = if (overflow) apps.take(3) else apps
                val rest = if (overflow) apps.drop(3).take(4) else emptyList()
                val miniGap = icon * 0.1f
                val mini = (icon - miniGap) / 2
                Column(Modifier.padding(pad), verticalArrangement = Arrangement.spacedBy(gap)) {
                    for (r in 0..1) {
                        Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                            for (c in 0..1) {
                                val i = r * 2 + c
                                Box(Modifier.size(icon), contentAlignment = Alignment.Center) {
                                    if (i < big.size) {
                                        val app = big[i]
                                        // The icon body has a few dp of padding of its own.
                                        DragAppIcon(
                                            app, icon - 8.dp, drag,
                                            { onLaunch(app) }, { onMenu(app) }, onDrop,
                                            showLabel = false,
                                        )
                                    } else if (i == 3 && overflow) {
                                        Column(verticalArrangement = Arrangement.spacedBy(miniGap)) {
                                            for (mr in 0..1) {
                                                Row(horizontalArrangement = Arrangement.spacedBy(miniGap)) {
                                                    for (mc in 0..1) {
                                                        val a = rest.getOrNull(mr * 2 + mc)
                                                        if (a != null) {
                                                            Image(bitmap = a.icon, contentDescription = null, modifier = Modifier.size(mini))
                                                        } else {
                                                            Spacer(Modifier.size(mini))
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        Text(
            tile.name, color = DrawerConfig.textColor.copy(alpha = 0.85f), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center, modifier = Modifier.padding(top = 6.dp),
        )
    }
}

/** A folder opened: its apps in a rounded panel over the dimmed library. Tap outside to close. */
@Composable
private fun FolderSheet(
    title: String, apps: List<AppEntry>,
    onLaunch: (AppEntry) -> Unit, onMenu: (AppEntry) -> Unit,
    drag: DragState, onDrop: (AppEntry, Offset) -> Unit, onClose: () -> Unit,
) {
    val cols = DrawerConfig.columns
    val rows = (apps.size + cols - 1) / cols
    val rowHeight = DrawerConfig.iconDp + (if (DrawerConfig.showLabels) 34 else 10) + DrawerConfig.rowGap
    val gridHeight = (rows * rowHeight + 32).dp.coerceAtMost(460.dp)
    Box(
        Modifier.fillMaxSize().background(Color(0x99000000))
            .pointerInput(Unit) { detectTapGestures(onTap = { onClose() }) }
            .systemBarsPadding(),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier.padding(horizontal = 16.dp).fillMaxWidth()
                .clip(RoundedCornerShape(32.dp)).background(Color(0xF01A1A1C))
                .pointerInput(Unit) { detectTapGestures(onTap = { }) }
                .padding(top = 20.dp),
        ) {
            Text(
                title, color = Eon.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 24.dp),
            )
            Box(Modifier.fillMaxWidth().height(gridHeight)) {
                AppGrid(apps, "No apps here yet.\nLong-press an app and choose Change category.", onLaunch, onMenu, drag, onDrop, Eon.Text)
            }
        }
    }
}

/** A pill button under the folders. */
@Composable
private fun LibButton(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, modifier: Modifier, onClick: () -> Unit) {
    Row(
        modifier.clip(RoundedCornerShape(18.dp)).background(Color(0x22FFFFFF))
            .clickable(onClick = onClick).padding(vertical = 14.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = Eon.Soft, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Text(label, color = Eon.Soft, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}
