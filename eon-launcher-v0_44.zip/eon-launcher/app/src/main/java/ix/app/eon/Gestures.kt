package ix.app.eon

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue

const val ACTION_NONE = 0
const val ACTION_LOCK = 1
const val ACTION_DRAWER = 2
const val ACTION_SEARCH = 3
const val ACTION_NOTIFICATIONS = 4
const val ACTION_SETTINGS = 5

/** The things a gesture can do, in the order of the action numbers above. */
val GESTURE_ACTIONS = listOf("None", "Lock screen", "Open drawer", "Search", "Notifications", "Settings")

/** What the double tap and the swipe down on the home screen do. Swipe up always opens the drawer. */
object GestureConfig {
    var doubleTap by mutableIntStateOf(ACTION_NONE)
    var swipeDown by mutableIntStateOf(ACTION_NOTIFICATIONS)

    fun load(p: Prefs) {
        doubleTap = p.getInt("gestureDouble", ACTION_NONE).coerceIn(0, GESTURE_ACTIONS.size - 1)
        swipeDown = p.getInt("gestureDown", ACTION_NOTIFICATIONS).coerceIn(0, GESTURE_ACTIONS.size - 1)
    }

    fun save(p: Prefs) {
        p.putInt("gestureDouble", doubleTap)
        p.putInt("gestureDown", swipeDown)
    }
}

/** Needed so Eon can lock the screen. Android asks the user to turn it on the first time. */
class EonAdminReceiver : DeviceAdminReceiver()

/** Locks the screen. The first time, opens Android's screen to make Eon a device administrator. */
fun lockScreen(ctx: Context) {
    try {
        val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val admin = ComponentName(ctx, EonAdminReceiver::class.java)
        if (dpm.isAdminActive(admin)) {
            dpm.lockNow()
        } else {
            ctx.startActivity(
                Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
                    .putExtra(
                        DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                        "Eon only uses this to lock the screen when you use the lock gesture.",
                    )
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
        }
    } catch (_: Exception) {
    }
}
