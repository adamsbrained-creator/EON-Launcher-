package ix.app.eon

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/** The four edges of a widget. */
enum class Side(val label: String) { Left("LEFT"), Right("RIGHT"), Top("TOP"), Bottom("BOTTOM") }

private val BarBg = Color(0xFF0D0D0F)
private val BarLine = Color(0xFF26272B)
private val ChipBg = Color(0xFF18181B)

/** Moves one edge of a widget to [pos] (in cells), keeping the opposite edge where it is. */
fun moveEdge(state: EonState, item: Item, side: Side, pos: Float) {
    val right = item.col + item.w
    val bottom = item.row + item.h
    when (side) {
        Side.Left -> {
            val l = pos.coerceIn(0f, right - MIN_SIZE)
            state.setRect(item, l, item.row, right - l, item.h)
        }
        Side.Right -> {
            val r = pos.coerceIn(item.col + MIN_SIZE, GRID_COLS.toFloat())
            state.setRect(item, item.col, item.row, r - item.col, item.h)
        }
        Side.Top -> {
            val t = pos.coerceIn(0f, bottom - MIN_SIZE)
            state.setRect(item, item.col, t, item.w, bottom - t)
        }
        Side.Bottom -> {
            val hi = maxOf(state.gridRows.toFloat(), item.row + MIN_SIZE)
            val b = pos.coerceIn(item.row + MIN_SIZE, hi)
            state.setRect(item, item.col, item.row, item.w, b - item.row)
        }
    }
}

/** Faint cell lines, shown while moving things around so you can see where they will land. */
@Composable
fun GridOverlay(cellW: Float, cellH: Float, rows: Int, alpha: Float = 1f) {
    Canvas(Modifier.fillMaxSize().zIndex(500f)) {
        val line = Color.White.copy(alpha = 0.2f * alpha)
        val stroke = 1.dp.toPx()
        for (c in 0..GRID_COLS) {
            drawLine(line, Offset(c * cellW, 0f), Offset(c * cellW, rows * cellH), strokeWidth = stroke)
        }
        for (r in 0..rows) {
            drawLine(line, Offset(0f, r * cellH), Offset(GRID_COLS * cellW, r * cellH), strokeWidth = stroke)
        }
    }
}

/**
 * Edit mode for one widget. Drag the widget to move it; drag the dots on its edges to resize it. Both follow your
 * finger exactly, to any size. With Snap to grid on, the widget eases onto the nearest cell lines when you let go.
 * Tap anywhere else to finish.
 */
@Composable
fun BoxScope.WidgetEditLayer(
    state: EonState,
    widgets: WidgetHolder,
    item: Item,
    cellW: Float,
    cellH: Float,
    rows: Int,
) {
    val density = LocalDensity.current
    val pad = with(density) { 4.dp.toPx() }
    val edge = with(density) { 36.dp.toPx() }
    val raw = remember { FloatArray(1) }
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()

    fun settle() {
        if (state.snapToGrid) {
            scope.launch {
                state.glideToCells(item)
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            }
        } else {
            state.commitLayout()
        }
    }

    // Tapping outside finishes editing.
    Box(Modifier.fillMaxSize().zIndex(1900f).pointerInput(Unit) { detectTapGestures { state.editing = null } })

    // The widget itself: drag to move.
    Box(
        Modifier
            .offset { IntOffset((item.col * cellW).roundToInt(), (item.row * cellH).roundToInt()) }
            .size(with(density) { DpSize((item.w * cellW).toDp(), (item.h * cellH).toDp()) })
            .zIndex(2000f)
            .padding(4.dp)
            .border(1.5.dp, Eon.Button, RoundedCornerShape(24.dp))
            .pointerInput(item) { detectTapGestures { } }
            .pointerInput(item, cellW, cellH) {
                var rc = 0f
                var rr = 0f
                detectDragGestures(
                    onDragStart = { rc = item.col; rr = item.row },
                    onDragEnd = { state.dragEdge = 0; settle() },
                    onDragCancel = { state.dragEdge = 0; settle() },
                ) { change, drag ->
                    change.consume()
                    rc += drag.x / cellW
                    rr += drag.y / cellH
                    state.setRect(item, rc, rr, item.w, item.h)
                    // Rest the finger at the left or right edge of the screen to carry the widget to the next page.
                    val fingerX = item.col * cellW + pad + change.position.x
                    state.dragEdge = when {
                        fingerX < edge -> -1
                        fingerX > cellW * GRID_COLS - edge -> 1
                        else -> 0
                    }
                }
            },
    )

    // Handles on the four edges.
    val left = item.col * cellW + pad
    val right = (item.col + item.w) * cellW - pad
    val top = item.row * cellH + pad
    val bottom = (item.row + item.h) * cellH - pad
    val midX = (left + right) / 2f
    val midY = (top + bottom) / 2f
    EdgeHandle(left, midY, { raw[0] = item.col }, { dx, _ ->
        raw[0] += dx / cellW
        moveEdge(state, item, Side.Left, raw[0])
    }, { settle() })
    EdgeHandle(right, midY, { raw[0] = item.col + item.w }, { dx, _ ->
        raw[0] += dx / cellW
        moveEdge(state, item, Side.Right, raw[0])
    }, { settle() })
    EdgeHandle(midX, top, { raw[0] = item.row }, { _, dy ->
        raw[0] += dy / cellH
        moveEdge(state, item, Side.Top, raw[0])
    }, { settle() })
    EdgeHandle(midX, bottom, { raw[0] = item.row + item.h }, { _, dy ->
        raw[0] += dy / cellH
        moveEdge(state, item, Side.Bottom, raw[0])
    }, { settle() })

    // The bar sits on the opposite half of the screen so it never covers the widget.
    val widgetLow = item.row + item.h / 2f > rows / 2f
    EditPanel(
        state, widgets, item,
        Modifier.align(if (widgetLow) Alignment.TopCenter else Alignment.BottomCenter).padding(vertical = 12.dp),
    )
}

@Composable
private fun EdgeHandle(
    x: Float,
    y: Float,
    onStart: () -> Unit,
    onDrag: (Float, Float) -> Unit,
    onEnd: () -> Unit,
) {
    val half = with(LocalDensity.current) { 24.dp.toPx() }
    val start by rememberUpdatedState(onStart)
    val drag by rememberUpdatedState(onDrag)
    val end by rememberUpdatedState(onEnd)
    Box(
        Modifier
            .offset { IntOffset((x - half).roundToInt(), (y - half).roundToInt()) }
            .size(48.dp)
            .zIndex(2100f)
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { start() },
                    onDragEnd = { end() },
                    onDragCancel = { end() },
                ) { change, d ->
                    change.consume()
                    drag(d.x, d.y)
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.size(22.dp).clip(CircleShape).background(Color.White).border(3.dp, Eon.Accent, CircleShape))
    }
}

/** The editing bar: position and size always showing, Done, and Move, Resize and Layer with exact steppers. */
@Composable
private fun EditPanel(state: EonState, widgets: WidgetHolder, item: Item, modifier: Modifier) {
    // 0 = move, 1 = resize, 2 = layer, 3 = stack (stacks only)
    val stackId = item.key.toIntOrNull()?.takeIf { isStackId(it) }
    var tab by remember { mutableStateOf(if (stackId != null) 3 else 0) }
    var fromCenter by remember { mutableStateOf(false) }
    var stepIdx by remember { mutableStateOf(1) }
    val steps = remember { listOf(0.01f, 0.1f, 1f) }
    val step = steps[stepIdx]

    fun r3(v: Float) = (v * 1000f).roundToInt() / 1000f
    fun place(c: Float, r: Float) = state.setRect(item, r3(c), r3(r), item.w, item.h)
    fun resize(w: Float, h: Float) {
        val nw = w.coerceIn(MIN_SIZE, GRID_COLS.toFloat())
        val nh = h.coerceIn(MIN_SIZE, maxOf(state.gridRows, 1).toFloat())
        if (fromCenter) {
            state.setRect(item, r3(item.col + (item.w - nw) / 2f), r3(item.row + (item.h - nh) / 2f), r3(nw), r3(nh))
        } else {
            state.setRect(item, item.col, item.row, r3(nw), r3(nh))
        }
    }
    val end: () -> Unit = { state.commitLayout() }

    val bar = RoundedCornerShape(26.dp)
    Column(
        modifier
            .zIndex(2200f)
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .clip(bar)
            .background(BarBg)
            .border(1.5.dp, Eon.Button, bar)
            .pointerInput(Unit) { detectTapGestures { } },
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "X ${cellText(item.col)} · Y ${cellText(item.row)} · ${cellText(item.w)} × ${cellText(item.h)}",
                    color = Eon.Muted, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.6.sp,
                    modifier = Modifier.weight(1f),
                )
                Box(
                    Modifier.height(36.dp).clip(CircleShape).background(Eon.Button).clickable { state.editing = null }
                        .padding(horizontal = 20.dp),
                    contentAlignment = Alignment.Center,
                ) { Text("Done", color = Eon.OnAccent, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold) }
            }
            Row(Modifier.fillMaxWidth().height(44.dp).clip(RoundedCornerShape(14.dp)).background(ChipBg).padding(3.dp)) {
                (if (stackId != null) listOf("Move", "Resize", "Layer", "Stack") else listOf("Move", "Resize", "Layer")).forEachIndexed { i, label ->
                    Box(
                        Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(11.dp))
                            .accentFill(tab == i, Color.Transparent).clickable { tab = i },
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            label, color = if (tab == i) Eon.OnAccent else Eon.Soft, fontSize = 14.sp,
                            fontWeight = if (tab == i) FontWeight.ExtraBold else FontWeight.Medium,
                        )
                    }
                }
            }
            when (tab) {
                0 -> Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    NudgeRow("X", cellText(item.col), { place(item.col - step, item.row) }, { place(item.col + step, item.row) }, end)
                    NudgeRow("Y", cellText(item.row), { place(item.col, item.row - step) }, { place(item.col, item.row + step) }, end)
                }
                1 -> Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    NudgeRow("Width", cellText(item.w), { resize(item.w - step, item.h) }, { resize(item.w + step, item.h) }, end)
                    NudgeRow("Height", cellText(item.h), { resize(item.w, item.h - step) }, { resize(item.w, item.h + step) }, end)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TinyChip("From corner", !fromCenter) { fromCenter = false }
                        TinyChip("From center", fromCenter) { fromCenter = true }
                    }
                }
                3 -> if (stackId != null) {
                    val st = state.stacks[stackId]
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            "${st?.members?.size ?: 0} widgets in this stack", color = Eon.Muted, fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                        )
                        PanelButton("Configure") { state.stackConfig = stackId }
                        PanelButton("Add widget") { state.stackPicker = stackId }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("SCROLL", color = Eon.Faint, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.2.sp)
                            TinyChip("Vertical", st?.vertical == true) { state.setStackVertical(stackId, true) }
                            TinyChip("Horizontal", st?.vertical == false) { state.setStackVertical(stackId, false) }
                        }
                    }
                }
                else -> Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    NudgeRow("Layer", "${item.z}", { state.raise(item, -1) }, { state.raise(item, 1) }, {})
                    Box(
                        Modifier.fillMaxWidth().height(44.dp).clip(RoundedCornerShape(14.dp))
                            .border(1.dp, Eon.Danger.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                            .clickable {
                                val id = item.key.toIntOrNull()
                                if (id != null) {
                                    state.editing = null
                                    state.removeWidget(id) { widgets.host.deleteAppWidgetId(it) }
                                }
                            },
                        contentAlignment = Alignment.Center,
                    ) { Text("Remove widget", color = Eon.Danger, fontSize = 14.sp, fontWeight = FontWeight.Bold) }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (tab < 2) {
                    Text("STEP", color = Eon.Faint, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.2.sp)
                    Spacer(Modifier.width(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("0.01", "0.1", "1").forEachIndexed { i, l -> TinyChip(l, stepIdx == i) { stepIdx = i } }
                    }
                }
                Spacer(Modifier.weight(1f))
                Text("Snap to grid", color = Eon.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.width(10.dp))
                EonSwitch(state.snapToGrid) { state.chooseSnap(it) }
            }
        }
    }
}

/** A label, a minus, the value and a plus. Hold a button to keep stepping. */
@Composable
internal fun NudgeRow(label: String, value: String, onMinus: () -> Unit, onPlus: () -> Unit, onEnd: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Eon.Muted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        NudgeButton("−", onMinus, onEnd)
        Text(
            value, color = Eon.Text, fontSize = 17.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
            modifier = Modifier.width(76.dp),
        )
        NudgeButton("+", onPlus, onEnd)
    }
}

@Composable
private fun NudgeButton(label: String, onStep: () -> Unit, onEnd: () -> Unit) {
    val scope = rememberCoroutineScope()
    val step by rememberUpdatedState(onStep)
    val done by rememberUpdatedState(onEnd)
    Box(
        Modifier.size(46.dp).clip(CircleShape).background(ChipBg).border(1.dp, BarLine, CircleShape)
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown()
                    val job = scope.launch {
                        step()
                        delay(380)
                        while (true) {
                            step()
                            delay(60)
                        }
                    }
                    waitForUpOrCancellation()
                    job.cancel()
                    done()
                }
            },
        contentAlignment = Alignment.Center,
    ) { Text(label, color = Eon.Text, fontSize = 22.sp, fontWeight = FontWeight.Medium) }
}

@Composable
private fun PanelButton(label: String, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().height(44.dp).clip(RoundedCornerShape(14.dp))
            .border(1.dp, Eon.Accent.copy(alpha = 0.5f), RoundedCornerShape(14.dp)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = Eon.Text, fontSize = 14.sp, fontWeight = FontWeight.Bold) }
}

@Composable
private fun TinyChip(label: String, on: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.height(32.dp).clip(CircleShape).accentFill(on, ChipBg).clickable(onClick = onClick).padding(horizontal = 12.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label, color = if (on) Eon.OnAccent else Eon.Soft, fontSize = 12.sp,
            fontWeight = if (on) FontWeight.ExtraBold else FontWeight.Medium,
        )
    }
}

@Composable
internal fun PanelLabel(text: String, color: Color, modifier: Modifier) {
    Text(text, color = color, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp, modifier = modifier)
}

@Composable
internal fun PanelRow(text: String, color: Color = Eon.Text, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable { onClick() }.padding(vertical = 8.dp),
    ) { PanelLabel(text, color, Modifier) }
}
