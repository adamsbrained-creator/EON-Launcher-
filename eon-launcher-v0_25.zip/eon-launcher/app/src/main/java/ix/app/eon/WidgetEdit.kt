package ix.app.eon

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import kotlin.math.roundToInt

/** The four edges of a widget. */
enum class Side(val label: String) { Left("LEFT"), Right("RIGHT"), Top("TOP"), Bottom("BOTTOM") }

/** Moves one edge of a widget to [pos] (in cells), keeping the opposite edge where it is. */
fun moveEdge(state: EonState, item: Item, side: Side, pos: Float) {
    val right = item.col + item.w
    val bottom = item.row + item.h
    when (side) {
        Side.Left -> {
            val l = pos.coerceIn(0f, right - MIN_SIZE)
            state.setRect(item, l, item.row, right - l, item.h)
        }
        Side.Right -> {
            val r = pos.coerceIn(item.col + MIN_SIZE, GRID_COLS.toFloat())
            state.setRect(item, item.col, item.row, r - item.col, item.h)
        }
        Side.Top -> {
            val t = pos.coerceIn(0f, bottom - MIN_SIZE)
            state.setRect(item, item.col, t, item.w, bottom - t)
        }
        Side.Bottom -> {
            val hi = maxOf(state.gridRows.toFloat(), item.row + MIN_SIZE)
            val b = pos.coerceIn(item.row + MIN_SIZE, hi)
            state.setRect(item, item.col, item.row, item.w, b - item.row)
        }
    }
}

/** Faint cell lines, shown while moving things around so you can see where they will land. */
@Composable
fun GridOverlay(cellW: Float, cellH: Float, rows: Int, alpha: Float = 1f) {
    Canvas(Modifier.fillMaxSize().zIndex(500f)) {
        val line = Color.White.copy(alpha = 0.2f * alpha)
        val stroke = 1.dp.toPx()
        for (c in 0..GRID_COLS) {
            drawLine(line, Offset(c * cellW, 0f), Offset(c * cellW, rows * cellH), strokeWidth = stroke)
        }
        for (r in 0..rows) {
            drawLine(line, Offset(0f, r * cellH), Offset(GRID_COLS * cellW, r * cellH), strokeWidth = stroke)
        }
    }
}

/**
 * Edit mode for one widget: drag the widget to move it, drag the dots on its edges to resize it,
 * and use the panel for exact steps, stacking order and removing it. Tap anywhere else to finish.
 */
@Composable
fun BoxScope.WidgetEditLayer(
    state: EonState,
    widgets: WidgetHolder,
    item: Item,
    cellW: Float,
    cellH: Float,
    rows: Int,
) {
    val density = LocalDensity.current
    val pad = with(density) { 4.dp.toPx() }
    val raw = remember { FloatArray(1) }
    val haptic = LocalHapticFeedback.current

    // Tapping outside finishes editing.
    Box(Modifier.fillMaxSize().zIndex(1900f).pointerInput(Unit) { detectTapGestures { state.editing = null } })

    // The widget itself: drag to move.
    Box(
        Modifier
            .offset { IntOffset((item.col * cellW).roundToInt(), (item.row * cellH).roundToInt()) }
            .size(with(density) { DpSize((item.w * cellW).toDp(), (item.h * cellH).toDp()) })
            .zIndex(2000f)
            .padding(4.dp)
            .border(1.5.dp, Color(0xCCFFFFFF), RoundedCornerShape(24.dp))
            .pointerInput(item) { detectTapGestures { } }
            .pointerInput(item, cellW, cellH) {
                var rc = 0f
                var rr = 0f
                var lastC = -1f
                var lastR = -1f
                detectDragGestures(
                    onDragStart = { rc = item.col; rr = item.row; lastC = item.col; lastR = item.row },
                    onDragEnd = { state.commitLayout() },
                    onDragCancel = { state.commitLayout() },
                ) { change, drag ->
                    change.consume()
                    rc += drag.x / cellW
                    rr += drag.y / cellH
                    val s = state.snapToGrid
                    state.setRect(item, snapValue(rc, s), snapValue(rr, s), item.w, item.h)
                    // A small tick each time it lands exactly on a cell, so you can feel the alignment.
                    val onCell = item.col == item.col.roundToInt().toFloat() && item.row == item.row.roundToInt().toFloat()
                    if (onCell && (item.col != lastC || item.row != lastR)) {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    }
                    lastC = item.col
                    lastR = item.row
                }
            },
    )

    // Handles on the four edges.
    val left = item.col * cellW + pad
    val right = (item.col + item.w) * cellW - pad
    val top = item.row * cellH + pad
    val bottom = (item.row + item.h) * cellH - pad
    val midX = (left + right) / 2f
    val midY = (top + bottom) / 2f
    EdgeHandle(left, midY, { raw[0] = item.col }, { dx, _ ->
        raw[0] += dx / cellW
        moveEdge(state, item, Side.Left, snapValue(raw[0], state.snapToGrid))
    }, { state.commitLayout() })
    EdgeHandle(right, midY, { raw[0] = item.col + item.w }, { dx, _ ->
        raw[0] += dx / cellW
        moveEdge(state, item, Side.Right, snapValue(raw[0], state.snapToGrid))
    }, { state.commitLayout() })
    EdgeHandle(midX, top, { raw[0] = item.row }, { _, dy ->
        raw[0] += dy / cellH
        moveEdge(state, item, Side.Top, snapValue(raw[0], state.snapToGrid))
    }, { state.commitLayout() })
    EdgeHandle(midX, bottom, { raw[0] = item.row + item.h }, { _, dy ->
        raw[0] += dy / cellH
        moveEdge(state, item, Side.Bottom, snapValue(raw[0], state.snapToGrid))
    }, { state.commitLayout() })

    // The panel sits on the opposite half of the screen so it never covers the widget.
    val widgetLow = item.row + item.h / 2f > rows / 2f
    EditPanel(
        state, widgets, item,
        Modifier.align(if (widgetLow) Alignment.TopCenter else Alignment.BottomCenter).padding(vertical = 12.dp),
    )
}

@Composable
private fun EdgeHandle(
    x: Float,
    y: Float,
    onStart: () -> Unit,
    onDrag: (Float, Float) -> Unit,
    onEnd: () -> Unit,
) {
    val half = with(LocalDensity.current) { 22.dp.toPx() }
    val start by rememberUpdatedState(onStart)
    val drag by rememberUpdatedState(onDrag)
    val end by rememberUpdatedState(onEnd)
    Box(
        Modifier
            .offset { IntOffset((x - half).roundToInt(), (y - half).roundToInt()) }
            .size(44.dp)
            .zIndex(2100f)
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { start() },
                    onDragEnd = { end() },
                    onDragCancel = { end() },
                ) { change, d ->
                    change.consume()
                    drag(d.x, d.y)
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.size(20.dp).clip(CircleShape).background(Color(0xFFE6E6E8)))
    }
}

@Composable
private fun EditPanel(state: EonState, widgets: WidgetHolder, item: Item, modifier: Modifier) {
    // 0 = move, 1 = resize, 2 = layer
    var tab by remember { mutableStateOf(0) }
    var side by remember { mutableStateOf(Side.Left) }
    val snap = state.snapToGrid
    val step = if (snap) 1f else 0.05f

    fun nudge(dx: Int, dy: Int) {
        state.setRect(item, snapValue(item.col + dx * step, snap), snapValue(item.row + dy * step, snap), item.w, item.h)
        state.commitLayout()
    }

    fun pushEdge(dir: Int) {
        val pos = when (side) {
            Side.Left -> item.col
            Side.Right -> item.col + item.w
            Side.Top -> item.row
            Side.Bottom -> item.row + item.h
        }
        moveEdge(state, item, side, snapValue(pos + dir * step, snap))
        state.commitLayout()
    }

    val bar = RoundedCornerShape(26.dp)
    Column(
        modifier
            .zIndex(2200f)
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .clip(bar)
            .background(Color(0xFF121214))
            .border(1.dp, Color(0xFF26272B), bar)
            .pointerInput(Unit) { detectTapGestures { } }
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            PanelLabel(
                "X ${cellText(item.col)} · Y ${cellText(item.row)} · ${cellText(item.w)} × ${cellText(item.h)}",
                Eon.Muted, Modifier.weight(1f),
            )
            Box(
                Modifier.height(36.dp).clip(CircleShape).background(Eon.Accent).clickable { state.editing = null }
                    .padding(horizontal = 20.dp),
                contentAlignment = Alignment.Center,
            ) { Text("Done", color = Eon.OnAccent, fontSize = 14.sp, fontWeight = FontWeight.Bold) }
        }
        Row(Modifier.fillMaxWidth().height(44.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFF1E1F22)).padding(3.dp)) {
            listOf("Move", "Resize", "Layer").forEachIndexed { i, label ->
                Box(
                    Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(11.dp))
                        .background(if (tab == i) Eon.Accent else Color.Transparent).clickable { tab = i },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        label, color = if (tab == i) Eon.OnAccent else Color(0xFFC9CBD1), fontSize = 14.sp,
                        fontWeight = if (tab == i) FontWeight.Bold else FontWeight.Normal,
                    )
                }
            }
        }
        when (tab) {
            0 -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PadButton("←", Modifier.weight(1f)) { nudge(-1, 0) }
                PadButton("↑", Modifier.weight(1f)) { nudge(0, -1) }
                PadButton("↓", Modifier.weight(1f)) { nudge(0, 1) }
                PadButton("→", Modifier.weight(1f)) { nudge(1, 0) }
            }
            1 -> {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Side.entries.forEach { sd ->
                        Box(
                            Modifier.weight(1f).height(34.dp).clip(CircleShape)
                                .background(if (side == sd) Color(0xFF34D17E).copy(alpha = 0.2f) else Color(0xFF1E1F22))
                                .border(1.dp, if (side == sd) Eon.Accent else Color.Transparent, CircleShape)
                                .clickable { side = sd },
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                sd.label, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp,
                                color = if (side == sd) Eon.Accent else Color(0xFFC9CBD1),
                            )
                        }
                    }
                }
                val horizontal = side == Side.Left || side == Side.Right
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PadButton(if (horizontal) "←" else "↑", Modifier.weight(1f)) { pushEdge(-1) }
                    PadButton(if (horizontal) "→" else "↓", Modifier.weight(1f)) { pushEdge(1) }
                }
            }
            else -> {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    PanelLabel("LAYER ${item.z}", Eon.Muted, Modifier.weight(1f))
                    PadButton("↑", Modifier.width(72.dp)) { state.raise(item, 1) }
                    PadButton("↓", Modifier.width(72.dp)) { state.raise(item, -1) }
                }
                PanelRow("REMOVE WIDGET", Eon.Danger) {
                    val id = item.key.toIntOrNull()
                    if (id != null) {
                        if (id > 0) widgets.host.deleteAppWidgetId(id)
                        state.editing = null
                        state.removeWidget(id)
                    }
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Snap to grid", color = Eon.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            Switch(
                checked = snap,
                onCheckedChange = { state.chooseSnap(it) },
                colors = SwitchDefaults.colors(checkedTrackColor = Eon.Accent, checkedThumbColor = Color.White),
            )
        }
    }
}

@Composable
internal fun PanelLabel(text: String, color: Color, modifier: Modifier) {
    Text(text, color = color, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp, modifier = modifier)
}

@Composable
internal fun PanelRow(text: String, color: Color = Eon.Text, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable { onClick() }.padding(vertical = 8.dp),
    ) { PanelLabel(text, color, Modifier) }
}

@Composable
internal fun PadButton(label: String, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.height(48.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFF26272B)).clickable { onClick() },
        contentAlignment = Alignment.Center,
    ) { Text(label, color = Eon.Text, fontSize = 18.sp, fontWeight = FontWeight.Medium) }
}
