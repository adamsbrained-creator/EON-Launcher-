package ix.app.eon

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.animateIntOffsetAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.SortByAlpha
import androidx.compose.material.icons.outlined.TouchApp
import androidx.compose.material.icons.outlined.Widgets
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntRect
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupPositionProvider
import androidx.compose.ui.window.PopupProperties
import androidx.compose.ui.zIndex
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.math.roundToInt

/** The ways an open folder can look, in the order of [FolderStyle.mode]. */
val FOLDER_STYLES = listOf("Card", "Full page", "Bottom sheet")

/**
 * The widget stack that holds the widgets placed in a folder. Folders have no stack until they get a widget. The id is
 * worked out from the folder's key, so nothing more has to be saved; it stays below the ids of the stacks on home pages.
 */
fun folderStackId(folderKey: String): Int = -60000 - ((folderKey.hashCode() and 0x7fffffff) % 900000)

/** How the folder menu opens, in the order of [FolderStyle.menuMode]. */
val FOLDER_MENUS = listOf("Button", "Hold +")

/** The black card the Card folder style sits on (see-through when [FolderStyle.translucent] is on). */
fun Modifier.folderCardBg(): Modifier {
    val shape = RoundedCornerShape(30.dp)
    return this.clip(shape)
        .background(Color.Black.copy(alpha = if (FolderStyle.translucent) 0.62f else 1f))
        .border(1.dp, Color(0x26FFFFFF), shape)
}

/** Which look an open home screen folder has. Card is the original; Full page is the default. */
object FolderStyle {
    var mode by mutableIntStateOf(1)

    /** The size of the app icons inside an open folder, in dp. */
    var iconDp by mutableIntStateOf(60)

    /** How many columns the apps in a folder have: 0 picks the number that fits the icon size. */
    var columns by mutableIntStateOf(0)

    /** Space between icons side by side, in dp. 0 spreads them evenly across the width. */
    var hGap by mutableIntStateOf(0)

    /** Space between rows of icons, in dp. */
    var vGap by mutableIntStateOf(30)

    /** Show the app names under the icons. */
    var labels by mutableStateOf(true)

    /** The height of each widget placed in a folder, in dp. */
    var widgetDp by mutableIntStateOf(150)

    /** How the folder's menu opens: 0 a ··· button next to +, 1 hold the + button. */
    var menuMode by mutableIntStateOf(0)

    /** See-through folders: a lighter shade over the wallpaper and a see-through card, instead of solid black. */
    var translucent by mutableStateOf(false)

    fun load(p: Prefs) {
        mode = p.getInt("folderStyle", 1).coerceIn(0, FOLDER_STYLES.size - 1)
        iconDp = p.getInt("folderIconDp", 60).coerceIn(44, 84)
        // An older "both" choice (2) becomes the button.
        menuMode = p.getInt("folderMenuMode", 0).let { if (it == 1) 1 else 0 }
        translucent = p.getBool("folderTranslucent", false)
        columns = p.getInt("folderCols", 0).coerceIn(0, 6)
        hGap = p.getInt("folderHGap", 0).coerceIn(0, 32)
        vGap = p.getInt("folderVGap", 30).coerceIn(8, 56)
        labels = p.getBool("folderLabels", true)
        widgetDp = p.getInt("folderWidgetDp", 150).coerceIn(100, 300)
    }

    fun save(p: Prefs) {
        p.putInt("folderStyle", mode)
        p.putInt("folderIconDp", iconDp)
        p.putInt("folderMenuMode", menuMode)
        p.putBool("folderTranslucent", translucent)
        p.putInt("folderCols", columns)
        p.putInt("folderHGap", hGap)
        p.putInt("folderVGap", vGap)
        p.putBool("folderLabels", labels)
        p.putInt("folderWidgetDp", widgetDp)
    }
}

/** Plays the opening animation that goes with the folder style. */
@Composable
fun FolderEnter(content: @Composable () -> Unit) {
    if (FolderStyle.mode == 2) {
        val shown = remember { MutableTransitionState(false).apply { targetState = true } }
        AnimatedVisibility(
            visibleState = shown,
            enter = slideInVertically(tween(340, easing = Motion.Decel)) { it / 2 } + fadeIn(tween(220)),
        ) { content() }
    } else {
        PopAnim(content)
    }
}

/** An open folder, drawn in the style chosen in Settings > Drawer > Folders. */
@Composable
fun FolderPopup(
    state: EonState, folder: Item, apps: List<AppEntry>, holder: WidgetHolder,
    onLaunch: (AppEntry) -> Unit, onMenu: (AppEntry) -> Unit, onClose: () -> Unit,
) {
    when (FolderStyle.mode) {
        1 -> FolderPage(state, folder, apps, holder, onLaunch, onMenu, onClose, sheet = false)
        2 -> FolderPage(state, folder, apps, holder, onLaunch, onMenu, onClose, sheet = true)
        else -> FolderCard(state, folder, apps, holder, onLaunch, onMenu, onClose)
    }
}

/**
 * The calm folder: no card. As a full page the home screen fades away and the apps sit in the lower half, near your
 * thumb. As a bottom sheet the home screen stays visible above and the handle drags it away.
 * + adds apps, ··· has the rest. Hold an app and drag it to put the folder in the order you like.
 */
@Composable
private fun FolderPage(
    state: EonState, folder: Item, apps: List<AppEntry>, holder: WidgetHolder,
    onLaunch: (AppEntry) -> Unit, onMenu: (AppEntry) -> Unit, onClose: () -> Unit, sheet: Boolean,
) {
    var rev by remember(folder.key) { mutableIntStateOf(0) }
    val members = rev.let { folder.members.mapNotNull { k -> apps.firstOrNull { it.key == k } } }
    var pickingIcon by remember(folder.key) { mutableStateOf(false) }
    var adding by remember(folder.key) { mutableStateOf(false) }
    var menu by remember(folder.key) { mutableStateOf(false) }
    var dragY by remember { mutableFloatStateOf(0f) }
    // Save the name and the order however the folder closes.
    DisposableEffect(folder.key) { onDispose { state.commitLayout() } }

    val header: @Composable (Modifier) -> Unit = { mod ->
        Row(mod.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                FolderNameField(folder, if (sheet) 26.sp else 30.sp)
                if (sheet) Text("${members.size} apps", color = Eon.DMuted, fontSize = 13.sp)
            }
            val menuPanel: @Composable () -> Unit = {
                if (menu) {
                    FolderMenu(
                        state = state, folder = folder, apps = apps, onDismiss = { menu = false },
                        onGestures = {
                            state.gestureEditor = GestureTarget("f", folder.key, folder.name.ifBlank { "Folder" })
                            onClose()
                        },
                        onChangeIcon = { pickingIcon = true },
                        onSorted = { rev++ },
                    )
                }
            }
            // Tap + to add apps. With the Hold + choice, holding it opens the menu, and there is no ··· button.
            Box {
                IconAction(Icons.Outlined.Add, "Add apps", onLongClick = if (FolderStyle.menuMode == 1) ({ menu = true }) else null) { adding = true }
                if (FolderStyle.menuMode == 1) menuPanel()
            }
            if (FolderStyle.menuMode == 0) {
                Box {
                    IconAction(Icons.Outlined.MoreVert, "Folder options") { menu = true }
                    menuPanel()
                }
            }
        }
    }

    // With widgets in the folder, the apps get less height so everything still fits on the screen.
    val hasWidgets = (state.stacks[folderStackId(folder.key)]?.members?.isNotEmpty() == true)
    val grid: @Composable () -> Unit = {
        FolderGrid(
            state, folder, members,
            if (hasWidgets) (if (sheet) 240.dp else 300.dp) else (if (sheet) 400.dp else 470.dp), onLaunch, onMenu,
        )
    }

    Box(
        Modifier.fillMaxSize()
            .background(
                if (sheet) SolidColor(Color(if (FolderStyle.translucent) 0x55000000 else 0x88000000))
                else if (FolderStyle.translucent) Brush.verticalGradient(listOf(Color(0x33000000), Color(0x66000000), Color(0x99000000)))
                else Brush.verticalGradient(listOf(Color(0x66000000), Color(0xB3000000), Color(0xD9000000))),
            )
            .pointerInput(Unit) { detectTapGestures(onTap = { onClose() }) },
    ) {
        if (sheet) {
            Column(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                    .graphicsLayer { translationY = dragY.coerceAtLeast(0f) }
                    .clip(RoundedCornerShape(topStart = 34.dp, topEnd = 34.dp))
                    .background(Color.Black.copy(alpha = if (FolderStyle.translucent) 0.72f else 1f))
                    .pointerInput(Unit) { detectTapGestures(onTap = { }) }
                    .navigationBarsPadding().padding(start = 18.dp, end = 18.dp, bottom = 28.dp),
            ) {
                Box(
                    Modifier.fillMaxWidth().pointerInput(Unit) {
                        detectVerticalDragGestures(
                            onDragEnd = { if (dragY > 140f) onClose() else dragY = 0f },
                            onDragCancel = { dragY = 0f },
                        ) { _, d -> dragY = (dragY + d).coerceAtLeast(0f) }
                    }.padding(top = 12.dp, bottom = 14.dp),
                    contentAlignment = Alignment.Center,
                ) { Box(Modifier.size(width = 40.dp, height = 5.dp).clip(CircleShape).background(Color(0xFF3A3D49))) }
                header(Modifier.padding(start = 6.dp))
                Spacer(Modifier.size(18.dp))
                FolderWidgets(state, holder, folder, 200.dp)
                grid()
            }
        } else {
            Column(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                    .pointerInput(Unit) { detectTapGestures(onTap = { }) }
                    .navigationBarsPadding().padding(start = 20.dp, end = 14.dp, bottom = 84.dp),
            ) {
                header(Modifier.padding(start = 4.dp))
                Spacer(Modifier.size(22.dp))
                Box(Modifier.padding(end = 6.dp)) { FolderWidgets(state, holder, folder, 260.dp) }
                Box(Modifier.padding(end = 6.dp)) { grid() }
            }
        }
        if (pickingIcon) FolderIconDialog(state, folder, apps) { pickingIcon = false }
        if (adding) AddAppsDialog(state, folder, apps) { adding = false; rev++ }
    }
}

/**
 * The apps of a folder in a grid of cells. Tap opens an app. Hold one and it lifts: lift and let go for its menu, or
 * drag it and the others make room, which sets the folder's order. How many columns fit follows the icon size.
 */
@Composable
private fun FolderGrid(
    state: EonState, folder: Item, members: List<AppEntry>, maxHeight: androidx.compose.ui.unit.Dp,
    onLaunch: (AppEntry) -> Unit, onMenu: (AppEntry) -> Unit,
) {
    val density = LocalDensity.current
    val haptic = LocalHapticFeedback.current
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val iconDp = FolderStyle.iconDp
        val hGap = FolderStyle.hGap
        // Gap 0 spreads the icons evenly across the width. A gap makes every cell icon-wide plus that gap, centred.
        val natural = (maxOf(iconDp, 64) + hGap).dp
        val cols = when {
            FolderStyle.columns > 0 -> FolderStyle.columns
            hGap == 0 -> (maxWidth.value / (iconDp + 18)).toInt().coerceIn(3, 5)
            else -> (maxWidth / natural).toInt().coerceIn(2, 6)
        }
        val cellW = if (hGap == 0) maxWidth / cols else minOf(natural, maxWidth / cols)
        val cellH = (iconDp + (if (FolderStyle.labels) 24 else 0) + FolderStyle.vGap).dp
        val rows = ((members.size + cols - 1) / cols).coerceAtLeast(1)
        val wPx = with(density) { cellW.toPx() }
        val hPx = with(density) { cellH.toPx() }
        val xPad = with(density) { ((maxWidth - cellW * cols) / 2).toPx() }
        var dragKey by remember { mutableStateOf<String?>(null) }
        var dragPos by remember { mutableStateOf(Offset.Zero) }
        Box(Modifier.heightIn(max = maxHeight).verticalScroll(rememberScrollState())) {
            Box(Modifier.fillMaxWidth().height(cellH * rows)) {
                members.forEachIndexed { i, app ->
                    key(app.key) {
                        val slot = IntOffset((xPad + (i % cols) * wPx).roundToInt(), ((i / cols) * hPx).roundToInt())
                        val settled by animateIntOffsetAsState(slot, spring(dampingRatio = 0.8f, stiffness = 520f), label = "slot")
                        val lifted = dragKey == app.key
                        Box(
                            Modifier
                                .offset { if (lifted) IntOffset(dragPos.x.roundToInt(), dragPos.y.roundToInt()) else settled }
                                .size(cellW, cellH)
                                .zIndex(if (lifted) 1f else 0f)
                                .graphicsLayer {
                                    val s = if (lifted) 1.1f else 1f
                                    scaleX = s
                                    scaleY = s
                                    alpha = if (lifted) 0.94f else 1f
                                }
                                .pointerInput(app.key, cols, wPx, hPx, xPad) {
                                    awaitEachGesture {
                                        val down = awaitFirstDown(requireUnconsumed = false)
                                        val slop = viewConfiguration.touchSlop
                                        // A quick lift is a tap, a swipe is a scroll, and holding still is a long press.
                                        var tap = false
                                        val still = withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
                                            while (true) {
                                                val ev = awaitPointerEvent()
                                                val ch = ev.changes.firstOrNull { it.id == down.id }
                                                if (ch == null || ch.isConsumed) return@withTimeoutOrNull false
                                                if (!ch.pressed) { tap = true; return@withTimeoutOrNull false }
                                                if ((ch.position - down.position).getDistance() > slop) return@withTimeoutOrNull false
                                            }
                                        }
                                        if (still != null) {
                                            if (tap) onLaunch(app)
                                            return@awaitEachGesture
                                        }
                                        // Long press: the app lifts.
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        val start = folder.members.indexOf(app.key).coerceAtLeast(0)
                                        dragPos = Offset(xPad + (start % cols) * wPx, (start / cols) * hPx)
                                        dragKey = app.key
                                        var total = Offset.Zero
                                        var moved = false
                                        while (true) {
                                            val ev = awaitPointerEvent()
                                            val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                                            ch.consume()
                                            if (!ch.pressed) break
                                            val d = ch.positionChange()
                                            total += d
                                            if (!moved && total.getDistance() > slop) moved = true
                                            if (moved) {
                                                dragPos += d
                                                val cx = (dragPos.x - xPad + wPx / 2f) / wPx
                                                val cy = (dragPos.y + hPx / 2f) / hPx
                                                val n = folder.members.size
                                                val target = (cy.toInt().coerceAtLeast(0) * cols + cx.toInt().coerceIn(0, cols - 1))
                                                    .coerceIn(0, n - 1)
                                                val cur = folder.members.indexOf(app.key)
                                                if (cur >= 0 && target != cur) {
                                                    folder.members.add(target, folder.members.removeAt(cur))
                                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                                }
                                            }
                                        }
                                        dragKey = null
                                        if (moved) state.commitLayout() else onMenu(app)
                                    }
                                },
                            contentAlignment = Alignment.TopCenter,
                        ) {
                            AppIconBody(app, iconDp.dp, FolderStyle.labels, labelSp = 13f)
                        }
                    }
                }
            }
        }
    }
}

/** The widgets placed in a folder, one under another above the apps. They are chosen in the folder's ··· menu. */
@Composable
private fun FolderWidgets(state: EonState, holder: WidgetHolder, folder: Item, maxHeight: androidx.compose.ui.unit.Dp) {
    val stack = state.stacks[folderStackId(folder.key)] ?: return
    if (stack.members.isEmpty()) return
    Column(
        Modifier.fillMaxWidth().padding(bottom = 18.dp).heightIn(max = maxHeight).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        stack.members.toList().forEach { id ->
            BoxWithConstraints(Modifier.fillMaxWidth().height(FolderStyle.widgetDp.dp).clip(RoundedCornerShape(22.dp))) {
                WidgetView(holder, id, maxWidth.value.toInt(), FolderStyle.widgetDp)
            }
        }
    }
}

/** A plain icon button in the folder's header, with a comfortable touch area. */
@Composable
private fun IconAction(icon: ImageVector, description: String, onLongClick: (() -> Unit)? = null, onClick: () -> Unit) {
    val haptic = LocalHapticFeedback.current
    Box(
        Modifier.size(40.dp).clip(CircleShape).pointerInput(onLongClick) {
            detectTapGestures(
                onTap = { onClick() },
                onLongPress = onLongClick?.let { go -> { haptic.performHapticFeedback(HapticFeedbackType.LongPress); go() } },
            )
        },
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, description, tint = Color(0xCCF0F2F8), modifier = Modifier.size(22.dp))
    }
}

/** The folder's name, editable in place. */
@Composable
private fun FolderNameField(folder: Item, size: TextUnit) {
    var name by remember(folder.key) { mutableStateOf(folder.name) }
    BasicTextField(
        value = name,
        onValueChange = { name = it.take(24); folder.name = name },
        singleLine = true,
        textStyle = TextStyle(color = Color.White, fontSize = size, fontWeight = FontWeight.Medium, textAlign = TextAlign.Start),
        cursorBrush = SolidColor(Eon.Accent),
        modifier = Modifier.fillMaxWidth(),
        decorationBox = { inner ->
            Box(Modifier.fillMaxWidth()) {
                if (name.isEmpty()) Text("Folder", color = Eon.DFaint, fontSize = size, fontWeight = FontWeight.Medium)
                inner()
            }
        },
    )
}

/** Puts a popup above its button, lined up with the button's right edge; below it if there is no room above. */
private val ABOVE_END = object : PopupPositionProvider {
    override fun calculatePosition(
        anchorBounds: IntRect, windowSize: IntSize, layoutDirection: LayoutDirection, popupContentSize: IntSize,
    ): IntOffset {
        val x = (anchorBounds.right - popupContentSize.width).coerceIn(0, (windowSize.width - popupContentSize.width).coerceAtLeast(0))
        val above = anchorBounds.top - popupContentSize.height - 12
        val y = if (above >= 0) above else anchorBounds.bottom + 12
        return IntOffset(x, y)
    }
}

/** The ··· menu: a dark rounded panel with an icon for each action and the icon size right inside it. */
@Composable
private fun FolderMenu(
    state: EonState, folder: Item, apps: List<AppEntry>, onDismiss: () -> Unit,
    onGestures: () -> Unit, onChangeIcon: () -> Unit, onSorted: () -> Unit,
) {
    val shape = RoundedCornerShape(26.dp)
    Popup(popupPositionProvider = ABOVE_END, onDismissRequest = onDismiss, properties = PopupProperties(focusable = true)) {
        Column(
            Modifier.width(280.dp).shadow(18.dp, shape).clip(shape)
                .background(Color(0xFF0A0A0C)).border(1.dp, Color(0x22FFFFFF), shape)
                .padding(vertical = 8.dp),
        ) {
            MenuRow(Icons.Outlined.TouchApp, "Gestures") { onDismiss(); onGestures() }
            MenuRow(Icons.Outlined.Palette, "Change icon") { onDismiss(); onChangeIcon() }
            val widgetCount = state.stacks[folderStackId(folder.key)]?.members?.size ?: 0
            MenuRow(Icons.Outlined.Widgets, if (widgetCount > 0) "Widgets ($widgetCount)" else "Add widgets") {
                onDismiss()
                state.openFolderWidgets(folder.key)
            }
            MenuRow(Icons.Outlined.SortByAlpha, "Sort A to Z") {
                val sorted = folder.members.sortedBy { k -> apps.firstOrNull { it.key == k }?.label?.lowercase() ?: k }
                folder.members.clear()
                folder.members.addAll(sorted)
                state.commitLayout()
                onSorted()
                onDismiss()
            }
            if (folder.members.size == 2) {
                MenuRow(Icons.Outlined.Apps, if (folder.pair) "Turn off app pair" else "Open both apps side by side") {
                    folder.pair = !folder.pair
                    state.commitLayout()
                    onDismiss()
                }
            }
            Column(Modifier.padding(horizontal = 20.dp, vertical = 6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Tune, null, tint = Color(0xB3FFFFFF), modifier = Modifier.size(22.dp))
                    Spacer(Modifier.width(16.dp))
                    Text("Icon size", color = Color(0xFFF0F2F8), fontSize = 16.sp, modifier = Modifier.weight(1f))
                    Text("${FolderStyle.iconDp}", color = Color(0xB3FFFFFF), fontSize = 14.sp)
                }
                Slider(
                    value = FolderStyle.iconDp.toFloat(),
                    onValueChange = { FolderStyle.iconDp = it.roundToInt().coerceIn(44, 84) },
                    onValueChangeFinished = { state.saveFolderStyle() },
                    valueRange = 44f..84f,
                    colors = SliderDefaults.colors(
                        thumbColor = Color.White, activeTrackColor = Eon.Accent, inactiveTrackColor = Color(0x33FFFFFF),
                    ),
                )
            }
            Box(Modifier.fillMaxWidth().padding(vertical = 4.dp, horizontal = 16.dp).height(1.dp).background(Color(0x1FFFFFFF)))
            MenuRow(Icons.Outlined.Delete, "Remove folder", Color(0xFFFF8A80)) { onDismiss(); state.disbandFolder(folder.key) }
        }
    }
}

@Composable
private fun MenuRow(icon: ImageVector, label: String, color: Color = Color(0xFFF0F2F8), onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = if (color == Color(0xFFF0F2F8)) Color(0xB3FFFFFF) else color, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(16.dp))
        Text(label, color = color, fontSize = 16.sp)
    }
}

/** Pick apps from the whole list to put in the folder. They are taken from wherever they are on the home screen. */
@Composable
private fun AddAppsDialog(state: EonState, folder: Item, apps: List<AppEntry>, onDone: () -> Unit) {
    var picked by remember { mutableStateOf(setOf<String>()) }
    val candidates = remember { apps.filter { it.key !in folder.members }.sortedBy { it.label.lowercase() } }
    Dialog(onDismissRequest = onDone) {
        Column(Modifier.width(320.dp).heightIn(max = 560.dp).glass(RoundedCornerShape(26.dp)).padding(top = 18.dp, bottom = 10.dp)) {
            Text("Add apps", color = Eon.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp))
            Spacer(Modifier.size(8.dp))
            LazyColumn(Modifier.weight(1f, fill = false)) {
                items(candidates, key = { it.key }) { app ->
                    val on = app.key in picked
                    Row(
                        Modifier.fillMaxWidth().clickable { picked = if (on) picked - app.key else picked + app.key }
                            .padding(horizontal = 20.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        Image(app.icon, null, Modifier.size(38.dp))
                        Text(app.label, color = Eon.Text, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        Box(
                            Modifier.size(22.dp).clip(CircleShape)
                                .then(if (on) Modifier.background(Eon.Button) else Modifier.border(2.dp, Eon.Muted, CircleShape)),
                        )
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.End) {
                Box(Modifier.clip(CircleShape).clickable(onClick = onDone).padding(horizontal = 16.dp, vertical = 10.dp)) {
                    Text("Cancel", color = Eon.Muted, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                }
                Box(
                    Modifier.clip(CircleShape).clickable(enabled = picked.isNotEmpty()) {
                        state.addAppsToFolder(folder.key, picked.toList())
                        onDone()
                    }.padding(horizontal = 16.dp, vertical = 10.dp),
                ) {
                    Text(
                        if (picked.isEmpty()) "Add" else "Add ${picked.size}",
                        color = if (picked.isEmpty()) Eon.Faint else Eon.Accent, fontSize = 15.sp, fontWeight = FontWeight.Bold,
                    )
                }
            }
        }
    }
}
