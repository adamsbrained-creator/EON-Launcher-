# Eon: what's new

## 0.55.0

- Widgets in folders. Open a folder, ··· (or hold +) > Widgets: it opens the Widget Stack page, where you add, reorder and remove the widgets of that folder. They show above the apps in all three folder styles. A folder with widgets gives the apps a little less height so everything fits. Removing a folder (or its last apps going away) lets go of its widgets.
- Folder grid, in Settings > Drawer > Folders: Columns (Auto, 3, 4, 5, 6), Space between icons (0 spreads them evenly across the width, any other value sets the gap and centres the grid), Space between rows, Names under icons (off for a clean grid) and Widget height. They apply to every folder.
- Not compiled or tested on a phone where it was written. Please send the build log or what you see.

## 0.54.1

- Folder menu, as meant: Settings > Drawer > Folders > Folder menu is now Button or Hold +. With Hold +, the folder shows only the + button: tap it to add apps, hold it to open the menu, and there is no ··· button. Holding empty space no longer does anything.

## 0.54.0

- Folder menu your way. Settings > Drawer > Folders > Folder menu: Button (the ··· button), Hold (hold empty space in an open folder, no button) or Both.
- The ··· and + buttons are smaller and lighter, and the menu panel is black with tighter rows.
- See-through folders: a switch for a lighter shade over the wallpaper and a see-through card or sheet. Off is solid black.
- The Card folder is black now, like the rest of Eon, instead of grey glass.
- Not compiled or tested on a phone where it was written. Please send the build log or what you see.

## 0.53.1

- Fixes the build of 0.53.0 (a missing import in the folder drag code).

## 0.53.0

- Folder polish. Arrange: hold an app inside a folder and it lifts; drag it and the others make room, and the order is saved. Lift and let go without moving and you get its menu, as before.
- A new ··· menu: a dark rounded panel with an icon for each action: Gestures, Change icon, Sort A to Z, the app-pair switch (for two-app folders), an Icon size slider, and Remove folder. The icon size also lives in Settings > Drawer > Folders.
- More like Smart Launcher: with the Full page folder the home screen fades away and only the wallpaper stays, so nothing shows through behind the apps. The name is lighter and larger, + and ··· are plain icons, labels are a little bigger, and the number of columns follows the icon size (bigger icons, fewer columns).
- Not compiled or tested on a phone where it was written. Please send the build log or what you see.

## 0.52.0

- Smart widgets, drawn by Eon itself so they match its look. Long-press empty space > Add widget, under Eon: Agenda (4x2: your next events over the next day and a half, with the calendar's colour dot, "Now" for one that is running, "All day" first; it asks for the calendar permission when you tap it, and refreshes every minute), Battery (2x1: percentage, charging or not, a rainbow bar; tap opens Android's battery page), Next alarm (2x1: time and weekday, updates the moment an alarm changes; tap opens your alarms) and Storage (2x1: free space of the total with a bar; tap opens Android's storage page).
- They work everywhere the other Eon widgets do: on a home page, inside a Widget Stack (the Smart Stack counts Agenda as a morning widget and the alarm as a night one), on the feed page and as a popup widget.
- Not compiled or tested on a phone where it was written. Please send the build log or what you see.

## 0.51.0

- Desk mode, like iOS StandBy. Settings > Quick settings > Desk mode: Off, Charging, or Landscape. While the phone charges (Landscape: and lies on its side) Eon shows a dark screen with a big clock, the date, the next alarm and the battery level. Swipe sideways for the weather, the music that is playing (with its cover) and your photos. In Landscape the app turns sideways while desk mode shows and back to portrait when it goes.
- Photos: Desk mode > Desk mode photos > Choose picks up to 12 pictures with Android's photo picker (no permission needed). Eon keeps scaled copies in its own storage, shows them one after another with a slow fade, and the originals are not touched. Clear removes the copies.
- Made to sit on a desk overnight: the screen stays on while it shows, the clock drifts a few pixels every minute so it cannot burn in, and between 22:00 and 06:00 it turns dim red. Double tap or go back to leave; it stays away until the charger is pulled and plugged in again.
- The weather page uses the last weather Eon loaded, so add the Weather widget once (or open its page) for it to fill in.
- The app now handles screen rotation itself (a manifest change), so turning the phone no longer restarts it.
- Not compiled or tested on a phone where it was written. Please send the build log or what you see.

## 0.50.0

- Wi-Fi and Bluetooth triggers for automations. New "Wi-Fi joined", "Wi-Fi left", "Bluetooth connects" and "Bluetooth disconnects": pick any network or device, or one by name (the network you are on now, or any device you have paired). Eon asks for the location permission (Android requires it to read a Wi-Fi name) and the Bluetooth permission (to read device names) from the editor, only when you choose such a trigger. Without them "any network" and "any device" still work.
- Phone controls as actions, usable from any gesture and any automation (a new PHONE CONTROLS list in the action picker): flashlight on/off, Do Not Disturb on/off/switch, ringer sound/vibrate/silent, auto-rotate on/off, brightness low/medium/full/automatic. Do Not Disturb and silent need Do Not Disturb access, and rotate and brightness need "modify system settings", each allowed once; Eon opens the right Android page when it is missing and tells you to try again.
- Wi-Fi, Bluetooth, NFC and volume cannot be switched by an app since Android 10, so those four open Android's own small panel (one more tap). Airplane mode and mobile data cannot be switched at all by a normal app.
- New permissions in the manifest: network and Wi-Fi state, fine location, Bluetooth connect, write settings, notification policy.
- Not done, and a decision for you: switching Wi-Fi, Bluetooth, hotspot and the like straight from Eon is possible by letting the accessibility helper press the Quick Settings tiles for you. That needs the helper to read what is on screen, which it deliberately does not do now, and it depends on the phone's language and layout, so I left it off.
- Not compiled or tested on a phone where it was written. Please send the build log or what you see.

## 0.49.0

- Automations. Settings > Automations: "when this happens, do that". Triggers: headphones connect or disconnect, the charger is connected or disconnected, or a time of day on the days you pick. The action is anything the gesture action list offers: open an app, turn a Focus mode on or off, open a popup widget, open the drawer and so on. Each automation has its own on/off switch and can be deleted.
- They run while Eon is running, which as your home app is nearly always. Android does not let an app open other apps from the background, so an "open an app" action only works while Eon is on screen; Focus modes, popups and Eon's own actions work anywhere.
- Not done: Wi-Fi network and Bluetooth device triggers, because both need extra permissions (location, nearby devices) that I did not want to ask for without you saying so.
- Not compiled or tested on a phone where it was written. Please send the build log or what you see.

## 0.48.0

- New folder pages. Settings > Drawer > Folders: Full page (the new default), Bottom sheet, or Card (the original). Full page has no card: the home screen sinks into darkness, the name sits on the left with + and ··· on the right, and the apps sit in the lower half near your thumb. Bottom sheet rises from the bottom while the home screen stays visible; drag its handle down to close. In both, + adds apps (taken from wherever they are on your home screen or dock) and ··· holds Gestures, Change icon, app pair and Remove folder.

## 0.47.1

- Automatic icon size fix. Sizes you had set by hand for single icons were being added on top of the automatic size, so some icons stayed bigger than others. While Match size or Optical is on, those hand-set sizes are now ignored. Soft shadows and glows around an icon no longer count when measuring it.
- The notification dot is a perfect circle for one digit; two or more digits make a pill of the same height. The number is centred.

## 0.47.0

- Haptic feedback. Settings > Animations > Haptic feedback: Off, Subtle (long presses and dragging, as before) or Full. Full adds a crisp tap when an app opens, a tick for every page you swipe to, for the drawer and folders opening and closing, and for every switch you flip. Off also silences the existing long-press and drag ticks.
- Switches are livelier: the knob slides across with a small spring.
- Settings tiles shrink under your finger and spring back, and build up one after another when the page opens.

## 0.46.0

- Automatic icon size. Settings > Drawer > Automatic icon size: Match size scales every icon so its visible part is the same size and moves it to the middle of its frame, whatever the app or icon pack drew (small logos, icons with big margins, off-centre ones). Optical also looks at how much of the frame is filled, so round and square icons look equally big. Fill (Compact, Standard, Full) sets how much of the frame icons use. It is done once per icon and cached; your own per-icon sizes still apply on top.

## 0.45.0

- Notification markers. Settings > Notifications now has a Marker choice: Rainbow dot (the default, redrawn as a rainbow ring around a red centre so it is calmer and sits in the icon's corner), Glow (the icon breathes softly in its own colour), Label dot (a dot and the name in the icon's colour), Count in label ("Chat · 2") and Off. Styles that need a label fall back to the rainbow dot when labels are hidden.
- Peek at the latest notification: hold an icon and its newest notification shows at the top of the menu. It can be switched off on the same page. The text is kept in memory only.
- The Notifications tile opens this page; Notification access is on it too.

## 0.44.0

- Page manager redesign. The cross now sizes itself to the screen, so every card shows in full. Each card draws what it opens (a G with a search bar for Google's feed, a story card for Eon's feed, a grid for the app page, a search bar for the search page) and has a short name. Home shows a little home screen with dots for your pages. The arrows turn to your accent colour for sides that have a page. New "Swap left and right" button, and an empty side shows a + to add a page.
- The page manager and the action list are now fully solid, so the page behind no longer shows through.

## 0.43.2

- Fixed the build error in the Page manager (a missing import). Nothing else changed.

## 0.43.1

- Page manager polish: tall page-shaped cards with an icon for what each direction opens (a G for Google's feed), arrows from Home to each side, Home highlighted with dots for your pages, and a Change label on every card.

## 0.43.0

- Page manager (Settings > Page manager, also a button in Settings > Feed). Home sits in the middle, and each direction shows the page it leads to; tap a card to choose. By default a swipe right on the first home page opens Google's feed (as before) and a swipe left on the last page opens Eon's own feed, which comes in from the right. Swipe up and swipe down are the same gestures as in Settings > Gestures. Any side can be given any action: the app page, the search page, a Focus mode, Google feed, News feed, or None.
- With the right-hand feed open, swipe right (or press back) to go back. The left-hand one closes with a swipe left as before. The G button on Eon's feed still jumps to Google's.
- Not compiled or tested on a phone where it was written. Please send the build log or what you see.

## 0.42.2

- Fixed the build errors in Predicted apps and Material You (two setter names clashed with their own settings). Nothing else changed.

## 0.42.1

- Fixed the two build errors that came with 0.39 to 0.41: the popup action was declared twice, and the Widget Stack size page used a variable it does not have. Nothing else changed from 0.42.0.

## 0.42.0

- Both feeds. Settings > Feed > Google feed now has "Swipe right opens": Google feed or Eon feed. The other one stays one step away: new gesture action "Google feed" (and "News feed (Eon)"), and a G button at the top of Eon's feed that jumps to Google's.
- Google feed polish. What the feed uncovers while it slides in is now black instead of the wallpaper. Home moves a little slower than the feed and dims as it comes, so the feed seems to lie on top. A small tick when the feed has come far enough to stay open, and when it falls back.
- Not possible: the grey of Google's feed itself. Google's app draws it in its own window and decides its colours, so Eon cannot recolour it. Eon's own feed is black.
- Not compiled or tested on a phone where it was written. Please send the build log or what you see.

## 0.41.0

- Universal search, in both drawers. Under the app results, search now also shows: hidden apps that match (marked "Hidden from the drawer", tap to open), contacts with Call and Message buttons (it asks for contacts permission the first time, from a row in the results), phone settings and Eon's own settings pages, and ways to carry on the search on Google, the Google Play Store, YouTube and Maps. While the box is empty your last eight searches show as chips.
- Better matching for apps. A search now looks at the app's own name as well as the name you gave it, and from four letters on at its package name; several words must all match; and the first letters work too (gm finds Google Maps). Accents and capitals are ignored.
- When nothing matches, the list says how many apps Android gave Eon a launcher icon for and how many you hid, so a missing app can be understood.
- Why Gemini might not show: Eon, like every launcher, can only list apps that have a launcher icon. If Gemini on the phone is part of the Google app (no icon of its own), no launcher can list it. If it is installed as its own app but hidden (by you, or by the "hide Play Store" rule), search now finds it under Hidden apps. If it still does not appear, tell me what the no-results line says.
- Not compiled or tested on a phone where it was written. Please send the build log or what you see.

## 0.40.0

- App pairs. Make a folder with exactly two apps, open it and tap "Tap opens both apps side by side (app pair)". From then on tapping that folder icon opens both apps in split screen; long-press it to open the folder again and turn the pair off. It is best effort: Android has no plain call for split screen, so Eon opens the first app, asks the Eon gesture helper (Settings > Gestures) to start split screen, then opens the second beside it. Without the helper you get a reminder. The pair can also be a gesture action ("Open app pair").
- Predictive back. On Android 14 and up, dragging the back gesture now shrinks, rounds and fades the Settings page and the app drawer, and they close when you let go; cancel the gesture and they spring back. Sub-pages of Settings keep the normal back.
- Per-page parallax was already in: the gyro wallpaper and the live wallpaper both shift as you swipe pages, so nothing was added for it. The iOS-style depth effect (subject over the clock) needs a subject mask and is not built.
- Still not compiled or tested on a phone where it was written. Please send the build log or what you see.

## 0.39.0

- Predicted apps. Settings > Quick settings > Predicted apps > On puts a row of four apps above the dock, chosen from the launch log Eon already keeps: launches around the same time of day over the last month count most, and apps already in the dock are left out. It updates every five minutes and after each launch. Tap to open, long-press for the app menu. Nothing leaves the phone.
- Popup widgets. Settings > Gestures > Popup widgets > Manage: add the widgets you want. Then give any icon, folder or widget a gesture (for example double tap) with the new action Popup widget (a POPUP WIDGET section appears in the action list). The widget opens in a small window over the home screen; tap outside or go back to close it.
- Material You colours. Settings > Quick settings > Colours > Wallpaper: Eon's buttons, chips, switches and accent take their colours from your wallpaper (Android's dynamic colours) and follow dark or light. "Eon" keeps the rainbow.
- Still not compiled or tested on a phone where it was written. Please send the build log or what you see.

## 0.38.0

- Focus modes. Settings > Focus: make a mode such as Work or Sleep. Each mode has its own home pages, so while it is on you see only those pages and the apps on them; your normal home comes back when you turn it off. New modes can start with the apps from the home you are on. Turn one on from that page, from any gesture (new FOCUS section in the action list, including shake and knock), or give it a schedule (hours and days) and it switches itself on and off.
- Widgets on the feed page. Settings > Feed > Widgets on the feed page: add widgets (calendar, weather, anything from the widget list) and they show one under another above the news stories, so a swipe right gives a Today page. They hide while you search or filter.
- Light theme fixes: the action list and several full-screen pages (Home, Drawer and Widgets settings, the icon editor, the widget picker) still had a hard-coded black backdrop and now follow the theme.
- Still not compiled or tested on a phone where it was written. Please send the build log or what you see.

## 0.37.0

- Search answers sums and units. Type 12*8, (3+4)^2, sqrt(81), 20% of 150 or 5 km in miles (also kg, lb, litres, mph, GB, hours, and Celsius, Fahrenheit and Kelvin) in either drawer's search and the answer appears above the apps. Tap it to copy the number.
- Shake and double knock. Settings > Gestures has two new actions: shake the phone three times, or knock twice on it, and Eon runs any action you choose. They work while Eon is on screen and use only the motion sensor. The knock is experimental and may need a firm tap.
- Smart Stack. Open a Widget Stack's page and turn on Smart rotate: the stack turns itself to calendar or news in the morning, weather at midday, music in the evening and a clock at night, and to music whenever headphones connect or something is playing. It checks every half minute, and a swipe of your own pauses it for ten minutes (headphones still win).
- Lock an app. Long-press an app > Organize > Lock app. Opening it from Eon then asks for your fingerprint, face or screen lock. It only guards opening from Eon: another launcher, a notification or a shortcut can still start the app.
- Not compiled or tested on a phone where it was written, so please send the build log or what you see.

## 0.36.0

- Light theme, and Auto. Settings > Quick settings > Theme: Dark, Light or Auto. Auto follows the phone's own dark mode, or switch "Auto follows" to Schedule and pick the hour the light theme starts and the hour dark returns (07:00 and 19:00 to begin with; it can wrap past midnight). The choice you made in the greeting now takes effect too, where before it was only saved.
- Light shows on the settings pages, menus and pop-ups, folder windows, the feed and the greeting. Text, panels, dividers, chips and the frosted glass all swap to light versions, and the cyan accent is a deeper cyan so it stays readable on white.
- Left dark on purpose: the home screen, dock, search pill and the two app drawers, because they sit on your wallpaper or on the drawer colours you chose yourself in Settings > Drawer.
- Not tested on a phone yet (this build could not be compiled where it was written), so please report any screen that still shows light text on a light page or dark text on a dark one.

## 0.35.3

- Google feed: Eon now reads the protocol version from the Google app instead of the bridge. The bridges do not state one, so Eon spoke the oldest version and the feed never answered.

## 0.35.2

- Google feed: a Connection log in Settings > Feed shows each step of connecting to the bridge (bind, service, window, status), with Reconnect and Copy buttons, so a failed connection can be understood.

## 0.35.1

- Fixed the build error in the Google feed code (a name clash). Nothing else changed from 0.35.0.

## 0.35.0

- Experimental: Google's own feed (Discover) as the page left of Home. Settings > Feed > Google feed. It needs a bridge app that you install yourself (Smart Launcher's Bridge, Lawnfeed or AIDL Bridge) and the Google app. Pick the bridge, switch it on, open the Google app once, then press Home. Swiping right on the first page then pulls Google's feed in under your finger, and Home slides away with it. Back or Home closes it. While it is connected, the News feed gesture action opens it; Eon's own feed is used when it is off.
- This uses the open launcher protocol that Lawnchair uses. It cannot be tested without a phone, the Google app and a bridge, so please report what you see.

## 0.34.1

- Feed: Your interests. In Settings > Feed add words you like to read about (football, Beatles, anything) or tap a suggestion. Eon searches the news for each word and mixes those stories into the feed. Each interest also gets its own chip on the feed page to filter by. Stories with pictures are preferred.

## 0.34.0

- New: Icon style (Settings > Drawer > Icon style). Original, Themed, Themed dark, Dark and Tinted. Themed uses each app's one-colour icon layer on a plate in your colour, like Android's themed icons; apps without one are recoloured to match. Dark dims the normal icons. Tinted turns icons into shades of your colour. Pick the colour from the wallpaper (first circle) or from the row. Icons from an icon pack or ones you chose yourself are left alone.

## 0.33.0

- New: a news feed page. Swipe right on the first home page (or give any gesture the "News feed" action) and it slides in from the left. It has a search bar (type to narrow the stories, press search to search the web), source chips to filter by, and cards with picture, headline, source and how long ago. Tap a card to read it, tap the share icon to send it. Swipe left or press back to return home.
- Settings > Feed: switch the page on or off, pick sources (BBC, The Guardian, NPR, Ars Technica, Hacker News, Google News topics) and add any RSS or Atom address of your own.
- This is Eon's own feed, built from those sources. It is not Google's Discover, which a launcher cannot show without a Google-approved bridge. Stories are saved so the page opens at once, and refresh after 15 minutes. Needs the internet.

## 0.32.1

- The long-press menu on an app is shorter. The things you do most stay on top (pin or remove from home, move to the dock or home, App info, Uninstall), and the rest moved into two smaller menus: Organize (add to a folder, change category, hide from the drawer) and Customize (rename, change icon and its size, gestures). Tap the title of a smaller menu to go back. Nothing was removed. Change category also has a back row now.

## 0.32.0

- Pulling a drawer closed now follows your finger, like turning a page. Past the top or the end of the list the drawer moves with you (a little heavier than your finger) and fades. Let go and it decides by how far you took it and how fast you were going: far enough, or a quick flick, and it carries on out at the speed you left it; otherwise it springs back. Catch it in the middle and you are holding it again, so you can pull it back. A light touch moves nothing.
- Closing is no longer started the moment a short pull passes a line, which is what made it close so fast and completely. The older close-on-a-short-pull methods are gone from both drawers.
- A flick closes the drawer from the moment you let go, so the home screen is already coming back while the drawer goes out, with no pause.
- A strong fling that runs into the top of the Library now needs to be much stronger to close it.

## 0.31.3

- Pulling past the top (or the end) of a drawer now reliably closes it, in both the App Library and the bar drawer. Eon watches your finger directly and checks whether the list is at its edge, instead of waiting for the list to pass the pull on, which the list's stretch effect could swallow. Scrolling up to the top and carrying on in the same swipe closes it too. About 32 dp of pull is enough.
- A swipe that began in the drawer no longer also counts as a swipe on the home screen, so closing the drawer by pulling can never open it again or start the swipe-down gesture.

## 0.31.2

- Fixed icon labels being cut off at the bottom (the tails of g, p, y and the bottoms of letters in the dock and in tight grids). Labels now have a line height that fits the text, a little less spacing around the icon, and are never clipped by their cell.

## 0.31.1

- Pull down at the top goes home (Settings > Drawer > Swipes, on by default): when a list in either drawer is already at its top, pull down a little more and the drawer closes. Swipe up goes home still works as before.
- Closing by swipe is quicker: it needs a shorter pull (about 30 dp instead of 70), and a quick flick closes it at once.
- The drawer no longer seems to hang before it leaves: it moves from the first frame and is gone sooner, and the home screen and the blur come back faster.

## 0.31.0

- Folder icon size: open a folder, Change icon, and use Icon size (0.60 to 1.50) to make a folder's icon bigger or smaller, the same slider as for apps. Works for folders on the home screen and in the app page. The dialog now scrolls on small screens.
- Swipe up goes home (Settings > Drawer > Swipes): swipe up in either drawer to close it, and swipe down on the home screen to open it. In a list, the swipe closes the drawer once there is nothing left to scroll, so scrolling to the end of a long list never closes it by accident. While on, it replaces the home swipe-down gesture, and swiping up on the home screen no longer opens the drawer.
- Open apps from a folder (Settings > Drawer, App Library): turn it off and a tap on the big icons of a folder opens the folder instead of launching the app. Long-press and drag still work on those icons.

## 0.30.0

- Icon size: long-press an app, choose Change icon, and set Icon size from 0.60 to 1.50 with the slider or the minus and plus buttons (1.00 is normal). Use it to match icons from different icon packs. It applies on the home screen, the dock, both drawers and the App Library cards. The thin square in the preview marks the normal size.
- Folders can now use an icon from an icon pack: open a folder, Change icon, Pack tab. The icon is shown as it is; pick a colour to put it on a coloured tile instead.
- Settings > Icon packs counts resized icons, and Reset also puts every size back.

## 0.29.3

- Fixed the release build failing on App Library settings (Insights and Smart box order switches).

## 0.29.2

- Fixed the release build failing to compile (missing imports behind the folder wiggle in arrange mode and the drawer blur setting).

## 0.29.1

- Folders in the bar-style app page: long-press an app and choose Add to folder (or New folder). Folders show in the grid in place of their apps, open in a popup, and can be renamed, given an icon (symbol, emoji or photo), filled with more apps, or removed. Apps can be taken out again from their menu. Search still shows every app.

## 0.29.0

**Folders**
- Custom folder icons: a symbol, an emoji or your own photo, on a colour you pick (open a folder, Change icon).

**Gestures**
- Every app, folder and widget can have its own swipe up, down, left and right and a double tap (long-press an app and choose Gestures; folders: open and choose Gestures; widgets: edit and choose Gestures).
- New Smart Launcher-style action picker (Suggested and Apps tabs): open an app, open a web page, turn off the screen, notifications, recent apps, toggle panel, App page, Search, Preferences, next and previous home page.
- Home screen: swipe up, swipe down, double tap, and two-finger swipe up and down can all be set (Settings > Gestures).
- Optional Eon gesture helper (an accessibility service that reads nothing) for turning off the screen, recent apps and the toggle panel.

**Smoother**
- Apps open out of the icon you tapped.
- One shared set of curves and springs; screens, popups and settings pages now slide and fade in instead of appearing.
- The home screen sinks back a little behind the drawer and settings.
- Softer page snap, lift spring on dragged icons, press feedback on folders.
- Blur behind the drawer (Settings > Animations): frosted glass or strong blur.

**App Library**
- Insight cards: suggested for you (by time of day), your stats, recently added, not opened lately, waiting for you. Hide any card, reorder them, or turn insights off (Customize).
- Boxes: New box, Arrange (wiggle mode with move and remove), Add apps to a box, sort each box (default, A to Z, most used, recently used, newest, my order), smart box order, Organize boxes (adds boxes for kinds of apps you have).
- Eon keeps a private list of what you open, only on the phone, to power the suggestions. Clear it in Customize.

**More from Smart Launcher**
- AMOLED black look, immersive mode, daily backup with restore (Settings > Backup), Most used and Recently used sorting in the drawer.


## v0.28.0
- Import from Smart Launcher. New Settings > Import layout page. Choose a Smart Launcher backup (the .slbk file) and Eon brings over your home pages (apps and folders, on the same cells), hidden apps, drawer categories in the same order (with their names and which apps are in them), app names you changed, the icons you picked yourself, and the icon pack you used. Each part has its own switch, and apps from the backup that are not installed on this phone are skipped.
- If the layout needs more rows than your grid has, Eon raises the number of rows so nothing moves.
- Widgets cannot be moved over, because Android ties every widget to the launcher that added it. The page lists them (page, size) so you can add them again, and can save each Kustom (KWGT) widget's full design from the backup as a .kwgt file in Downloads > Eon widgets, for KWGT to load.

## v0.27.0
- Animations. New Settings > Animations page, with a small preview you can tap to replay.
- Home animation: what the icons do when you come back to the home screen (from an app, or after unlocking). None, Fade, Rise, Free fall (icons drop from the top and bounce into place) or Pop. Icons start one after another, top-left first, and the dock rises in last. Free fall is on by default; pick None to turn it off.
- Swiping between pages: Slide (as before), Fade, Zoom, or Depth, where the page you leave stays put and sinks behind the next one.
- App drawer: Slide up (as before), Zoom, Fade, or Sheet (slides all the way up from the bottom edge).
- Icon press effect: icons shrink a little under your finger, in the drawer, on the home screen and in the dock. It has its own switch.
- If you turn animations off in Android's developer options, all of these play instantly.

## v0.26.0
- Drag to the next page. Long-press an icon or a folder on the home screen, drag it to the left or right edge and hold: the pages turn, one every moment, and you can drop it on any of them. Past the last page a new page is made (and goes away again if nothing is dropped on it). The same works for widgets: while moving a widget (long-press it), hold your finger at the edge and it goes to the next page.
- Moving an icon on the home screen now works like dragging one out of the drawer: the lifted icon follows the finger over the whole screen, the target cell lights up, and you can also drop it on the dock. An icon dropped on another icon still makes a folder, and a folder dropped on an icon swaps places with it. Holding an icon without moving it and letting go still opens its menu.
- Moving a widget: the editing layer now sits above the pages instead of inside one, which is what lets a widget travel between pages.

## v0.25.3
- Same as v0.25.2, with the app list in the widget picker back to how it looked before. Only the Eon section is new.

## v0.25.2
- The widget editing card has the rainbow edge all the way round, like the widget being edited, instead of a line along the top.
- The widget picker looks different from before. Eon's own widgets sit together in a "Made by Eon" panel with a rainbow edge: each is a row with a bigger picture, its size and a round + button that adds it straight away (tap the row to see it first). The app list below, the A to Z strip, search, the filters and the app sheets are unchanged.

## v0.25.1
- Widget Stack scrolls forever. With two or more widgets, swiping past the last one brings the first back, and the other way round, so you can keep going in the same direction.
- Smoother flipping: the widget you swipe away shrinks and fades a little while the next one comes in. With three or more widgets the next ones are kept ready, so they are already drawn when they arrive. (With two, they are drawn as you swipe, because a widget can only be drawn in one place at a time.)
- The dots follow the widget you are on, and the stack keeps its place when you leave and come back.

## v0.25.0
- Widget Stack. One widget that holds several. Long-press empty space > Add widget > Widget Stack, swipe through the four sizes (Landscape 3×2, Square 3×3, Portrait 2×3, Square 2×2) and tap Add widget. Swipe the stack to flip between its widgets; small dots show where you are (down the right edge when it scrolls vertically, along the bottom when horizontally).
- The new Widget Stack page opens right after you add a stack, and from the stack's own editing bar (long-press the stack > Stack tab > Configure). It lists the widgets in the stack: drag the handle to reorder, tap the bin to remove, or Add widget to pick another one (any app widget, or Eon's Now playing, Weather and quote and Week). Scroll orientation switches between Vertical and Horizontal.
- The Stack tab of the editing bar also has Add widget and the Vertical / Horizontal choice. Move, Resize and Layer work on a stack like on any widget.
- Removing a stack (Layer tab > Remove widget, or On this page > Remove) removes everything inside it. A widget whose app was uninstalled leaves its stack by itself.
- Widget picker: a Widget Stack tile at the start of the Eon row. It is left out when you are adding into a stack, since a stack cannot hold a stack.
- Includes the v0.24.2 fix: icons now show the moment Eon opens.

## v0.24.2
- Icons now show the moment Eon opens. Before, the home screen and widgets appeared first and the app icons popped in about two seconds later, because Eon rebuilt every icon from scratch each time it started. Now it keeps the finished icons in memory and on the phone, and only redraws the ones that changed (a new shape, icon pack, custom icon or an app update). The icons it does have to draw are made several at a time.

## v0.24.1
- Fixes the build error in v0.24.0 (a name clash in the icon pack code). Rename, Change icon and Icon packs are the same as described in v0.24.0.

## v0.24.0
- Rename apps. Long-press an app (home screen, dock, drawer or Library) and tap Rename. Type the new name and Save. Reset, or saving the original name, puts it back. The drawer, search and sorting use the new name; categories still go by the real one.
- Custom icons. Long-press an app > Change icon: pick a picture from the gallery (it is cropped to a square and kept inside Eon), or pick one icon from an installed icon pack. "Use the normal icon" undoes it. A picture that fills its frame is cut to your icon shape; a logo with a transparent edge stays as it is.
- Icon packs. New Settings > Icon packs page lists the icon packs on the phone (ADW, Nova, Apex and GO style packs, such as Lawnicons). Choose one and every app it has an icon for changes at once. Apps the pack does not cover keep their own icon, or get the pack's background, mask and overlay if it has them.
- Reshape pack icons: a switch that cuts pack icons to your icon shape too (off by default, since packs bring their own shape).
- The picker for one app shows the pack's icon for that app first, then every icon, with a search box.
- Your changes: the Icon packs page shows how many apps you renamed or gave their own icon, and has Reset all names and icons.
- A custom icon you pick for one app always wins over the icon pack.

## v0.23.0
- Drawer: "Fit the grid to the apps". With few apps (a small category) the icons get bigger and use fewer columns; with many they get smaller and more columns, so everything fits without scrolling.
- Icon shape: eleven shapes (square, rounded, squircle, circle, hexagon, octagon, pentagon, diamond, teardrop, leaf, flower) in Settings > Drawer. Every icon follows the one you choose.
- Custom padding (sides, top, bottom), a switch for the category bar, and a category transition effect (Default, Fade, Zoom, Rotate).
- Advanced: A to Z index strip, hide the Play Store icon, hide icon packs, move icons down, stack apps from the bottom, and close the drawer after launching an app (on by default).

## v0.22.0
- New category bar in the drawer (Bar style). The icons now sit in a rounded glass pill and spread evenly across it, like the reference. The icon you are on grows a little and fades to the selected colour, a small marker slides in under it, and changing category gives a soft tick. It still scrolls sideways when there are more icons than fit.
- Settings > Drawer has a Pill background switch if you prefer the loose icons, and the live preview shows the pill. The pill takes its tint from your text colour, so it follows the presets.

## v0.21.0
- New Settings > Drawer page, with a live preview at the top that follows every change. It covers both drawers.
- Background: colour, opacity (0 to 100%) and whether it fades from lighter at the top to stronger at the bottom. Five presets (Smoke, Midnight, Frost, Amoled, Clear) set colours and opacity in one tap.
- Apps and labels: text colour (a swatch row, or Custom with hue, saturation and brightness), icon size, columns (3 to 6), row spacing, show or hide labels, label size and two-line labels.
- Category bar (the Bar style): how much of the screen the apps take, show or hide the category title, its size and centring, bar icon size, selected icon colour, the little marker under the selected icon, and whether swiping the apps changes category.
- App Library: folders per row (2 or 3), folder colour, opacity, corner roundness and outline, and whether the Recently added and Other apps folders show.
- Sort and search: order apps A to Z, Z to A or newest first, and open the keyboard together with the drawer.
- Reset drawer settings puts everything back.
- Menus: the category menu (the ⋮ button or long-press on a category icon in the Bar, long-press on one of your folders in the Library) now also has Switch to Library or Bar and Drawer settings. The Library has a Drawer settings button under the folders. Drawer settings opens straight on this page and Back returns you to where you were.
- Settings has a Drawer tile. Drawer style is also still in Quick settings.
- The dim background is a bit different from before: the new default is 65% opacity, fading from about 43% at the top to about 87% at the bottom.

## v0.20.0
- App Library, an iOS style drawer as a second choice. Settings > Quick settings > Drawer style: Bar (the Smart Launcher style drawer with the category bar, as before) or Library.
- The Library is a search pill and a two-column grid of folders. Each folder shows the first apps of a category as big icons and, with more than four, a small cluster of the next ones in the last slot. Tap the folder (or the cluster) to open all its apps in a panel; tap outside it to close.
- It uses the same categories as the bar. Recently added comes first, then your categories (an empty one shows its icon), then Other apps for anything no folder holds. Long-press one of your folders for Add category, Edit icon, Rename and Remove. Add category is also the last row.
- Tap the search pill for an A to Z list of every app; type to filter. Cancel goes back. Fling down at the top of the Library to close it.
- Big icons in a folder work like in the bar drawer: tap to open, long-press for the app menu and shortcuts, long-press and drag to drop it on the home screen or the dock.

## v0.19.1
- Smoother, exact resizing. Dragging a widget's edge dots, or the widget itself, now follows your finger to any size or position: no more steps or sticky spots. With Snap to grid on, the widget eases onto the nearest cell lines when you let go; with it off it stays exactly where you left it. Widgets can be made smaller (down to a quarter of a cell), and an app's widget is told its new size only when you pause, so nothing stutters.
- Holding a widget or one of its dots no longer also opens the home screen's long-press menu. While you edit, only the editing bar shows.
- The editing bar has a new look, with no arrow pad: Move has X and Y, Resize has Width and Height (grow from a corner or from the centre), Layer has the layer number and Remove. Each has a minus, the number and a plus; hold one to keep going. STEP sets how far a tap moves: 0.01, 0.1 or a whole cell. The search pill's bar uses the same steppers.
- The colours were not changed here: v0.15 already moved everything to the rainbow on black.

## v0.19.0
- Gestures. New Gestures tile in Settings. Pick what a double tap on empty space does, and what a swipe down does: None, Lock screen, Open drawer, Search, Notifications or Settings. Swipe down still opens the notification shade, and swipe up still opens the drawer.
- Lock screen: Eon locks the phone with Android's device administrator permission, which is asked for the first time you use it. Eon uses it for nothing else (it can only lock the screen). Turn it off under Settings > Security > Device admin apps.

## v0.18.0
- App shortcuts. Long-press an app, on the home screen or in the drawer, and the app's own shortcuts (Camera: Selfie, Messages: New chat and so on) show at the top of its menu, up to four. Tap one to open it. Android only shows them to the home app, so they appear once Eon is your default home app.

## v0.17.0
- The Grid, Dock and Wallpaper settings pages now match the settings hub: black panels with a thin outline, a coloured line before each section title, rainbow switches, bold row titles and darker chips and buttons. The home screen still shows above the panel so you see changes live.
- A page that was made by holding at the edge while dragging from the drawer is removed again if you drop somewhere else and it stays empty.
- Apps you uninstall are taken out of folders, and a folder left with one app turns back into that app.

## v0.16.0
- Folders. Drop an icon on another icon on the home screen and they become a folder, with a rainbow outline and the first four apps showing inside. Drop an icon on a folder to add it. Tap a folder to open it: tap its name to rename it, tap an app to open it, long-press an app for its menu (it has Take out of folder), and Remove folder sends the apps back to the home screen. A folder with one app left turns back into that app. Folders can be dragged around like apps and work in Free placement too.
- Drag from the drawer to the dock: drop an app on a dock cell (or any free dock cell if that one is taken). The dock lights up where it will land.
- Drag from the drawer past the last page: hold at the right edge and Eon adds a new page for you (when the last page has something on it).
- Dragging an icon from the drawer onto another icon outlines the target in rainbow, to show it will make or join a folder.
- Two icons on the home screen no longer swap when you drop one on the other (it makes a folder instead). Folders still swap with icons.

## v0.15.0
- New colours everywhere: the old green is gone. Eon now uses the rainbow from its icon (cyan, blue, violet, pink, orange) on black, the same as the settings page.
- Buttons, selected chips, the step bars in the welcome screens, notification badges, the Done button, picked tabs and the wallpaper and widget pickers are filled with the rainbow, with black text on top.
- Switches, cursors, selected borders and links use the cyan from the start of the rainbow, since they need one solid colour. The welcome screens glow violet, cyan and orange at the bottom instead of green, and the logo glows violet.
- Settings tiles: the first tile is blue now instead of green.

## v0.14.0
- Drag apps from the drawer onto the home screen. Long-press an icon in the drawer and move your finger: the drawer fades away, the icon follows your finger and the cell it will land on is outlined. Let go to drop it there. Hold at the left or right edge to go to the next page.
- If the spot is taken, the app goes to the nearest free cell. If the app is already on a page, it moves to where you drop it. Free placement drops it exactly where you let go.
- Long-press and let go without moving still opens the app menu (Add to home screen, Change category and so on). Dropping outside the grid brings the drawer back.

## v0.13.0
- New app drawer, modelled on Smart Launcher. The title of the category you are in sits above the apps in the lower half of the screen, with Search and a ⋮ menu on the right. The open wallpaper above is a tap target: tap it or pull it down to close.
- Category bar at the bottom: one icon per category. Tap an icon, or swipe the apps sideways, to change category. The little bar under an icon shows where you are. If there are more icons than fit, the bar scrolls. Eon remembers the category you were in.
- Long-press an icon (or use ⋮) for Add category, Edit icon, Rename and Remove. Remove is not offered for All apps. Removing a category never removes apps; they stay in All apps.
- Add category: a full-screen list (Contacts, Education, Entertainment, Favorites, Finance, Fitness, Internet, Lifestyle, Media, Medical, Music, Navigation, Personalization, Photography, Productivity and more). Ones already in the bar are left out. Custom category at the top makes an empty one you name yourself.
- Eon fills the ready-made categories from each app's type and name, so an app can show up in more than one (Spotify in Media and Music, say). Favorites and your own categories start empty: long-press an app and choose Change category. Change category now lists the categories in your bar, with Automatic to undo.
- Search is now the magnifier in the drawer's header, and looks through every app. Tapping the search pill on the home screen still opens the drawer with the keyboard up.
- New installs start with All apps, Social, Media, Games, Productivity and Tools. Categories you had set by hand in v0.12 carry over. Apps that were only in Reading, Maps or Other now show under All apps until you add those categories.

## v0.12.1
- New widget picker. Search at the top finds widgets by name, by app or by kind. Chips filter by what a widget is (Clock, Weather, Music, Calendar and so on). Eon's own widgets sit in a row of previews, and below them every app is listed A to Z with how many widgets it has; slide along the strip on the right to jump to a letter.
- Tap an app, or a widget in the results, to open a sheet with that app's widgets as previews and their sizes. Pick one, filter by size if you like, and press Add.
- After adding, the widget is already in edit mode on the home screen, so you can place it straight away. The widgets you already have are under "On this page".
- Widget edit panel redesigned into a bottom bar: the position and size always showing, Done, and Move, Resize and Layer tabs. Remove is under Layer.
- The kind of a widget is guessed from its name and its app's name, so a few will land under Other; they are always listed under their app too.

## v0.12.0
- New settings page: a hub of six coloured tiles, one for each colour in the Eon icon. Each tile shows its current state: Grid and icons, Dock, Wallpaper, Notifications, Hidden apps and About Eon. Tap one to open its page; Notifications opens Android's notification access screen.
- Quick settings under the tiles: Look (Glassy or Flat), Icon placement (Grid or Free) and Page indicator, changed right there with small switches.
- Search settings at the top filters the tiles and quick settings as you type.
- Grid properties and Dock now open straight from their tiles (the old Home screen list page is gone). Hidden apps and About Eon (version, show the greeting again) have their own pages.

## v0.11.0
- Live wallpaper: Eon is now also a real Android live wallpaper. In Settings > Wallpaper choose "Set as live wallpaper" and Android's own preview lets you pick home screen, lock screen or both. The picture moves as you tilt the phone on both, with your Range, Speed, Dim, Direction and effects settings. When it is active, the home screen shifts it as you swipe between pages and sends your touches to it (for Ripple), and Eon stops drawing its own copy.
- Still picture: "Home", "Lock" or "Both" under it set the picture as a normal system wallpaper, with no motion.
- Rain now has big glass drops: round drops that show the picture upside down, with a rim and a highlight. They slide down now and then. Settings: Glass drops on/off, Drop amount, Drop size, Drop slide speed, plus Rain streaks on/off and Lightning (the wallpaper flashes now and then; it does not change your screen brightness).
- Ripple has a Rain lines switch.
- Transition animation (Fade, Dissolve, Pixelate, Wipe, Blur, Zoom) for when you pick another picture, and Animation speed (0.25x to 4x) for the effects and the transition. Blur works only on the in-Eon wallpaper; the live wallpaper fades instead.
- Not yet: slideshow.

## v0.10.0
- New: gyro wallpaper. Pick a picture and Eon draws it behind the home screen and slides it as you tilt the phone (it reads the accelerometer, so no extra permission). Nothing changes until you turn it on: with it off Eon still shows your normal system wallpaper.
- Open it from Settings > Wallpaper, or long-press empty space on the home screen and choose Wallpaper. Add pictures with the + tile (they are copied into Eon, so they stay even if you delete them from the gallery), tap one to use it, long-press one to delete it.
- Wallpaper settings, with the wallpaper visible above the panel so you can tilt and watch: Direction (Horizontal, Vertical or Both), Range, Speed, Dim, Reverse direction, Wallpaper scrolling (the picture also shifts as you swipe between pages), Power saver mode (stop reading the sensor in battery saver) and Quality (High, Standard, Low = 16-bit colour).
- The centre follows where you hold the phone, so the picture settles back to the middle if you keep it at a new angle or put it down.
- Effects: an optional overlay of Rain, Ripple (starts where you touch, or also at random) or Snow, each with its own sliders.
- Not yet: slideshow, other transition animations, the lock screen.

## v0.9.13
- New: the Dock. A rounded, see-through bar at the bottom of the home screen, like iOS, that stays put while you swipe between pages. It is off until you turn it on in Settings > Home screen > Dock.
- Dock settings: Enable, Columns (1 to 6), Rows (1 to 3), Icon size, Pages (1 to 5, swipe the dock sideways) and Icon label visibility. The home screen stays visible below the panel, so you watch the dock change as you set it up.
- Add an app by long-pressing it and choosing Move to dock. In the dock, long-press and drag an icon to rearrange; long-press an icon without moving for Move to home or Remove from dock.
- The home grid gives up the space the dock uses. Icons that no longer fit are moved to the nearest free cell, nothing is deleted.

## v0.9.12
- New Settings > Home screen, with Grid properties and a Show indicator switch (hides the page dots).
- Grid properties, in Eon's own look. The home screen stays visible above the panel so you see every change live:
  - Presets 4x7, 5x8 and 6x10, plus Columns (3 to 8) and Rows (Auto or 3 to 14). With a chosen number of rows the grid stretches to fill the screen.
  - Icon size (40 to 84 dp), with a reset button.
  - Icon label visibility, Label size (8 to 16 pt) and Allow two-line labels.
  - Use custom padding: side, top and bottom space around the grid.
- When you change the grid, widgets are pulled back inside it and any icon that no longer fits moves to the nearest free cell. Nothing is deleted.
- The drawer keeps its own icon size, so changing the home screen does not change it.

## v0.9.11
- The Search apps pill now floats and can go anywhere. Long-press it to edit: drag it, nudge it with the arrows (half a cell with Snap to grid on, 0.05 cell with it off), reset it to the bottom, or hide it. Open it with a tap as before.
- The home grid now reaches all the way down to the page dots, so you can put icons where the search pill used to be (a dock-style row at the bottom, like in Smart Launcher). Icons you already placed stay where they are.
- If you hide the pill, long-press empty space on the home screen and choose "Show search pill" to bring it back.
- Page swiping is paused while you edit a widget or the pill.

## v0.9.10
- Smoother icons: an icon now settles from where you let go instead of jumping back first, lifts with a little spring when you pick it up, and swaps glide. The grid fades in and out instead of popping.
- More precise placing: while you drag, a ghost outline shows exactly where the icon will land (the cell in Grid mode, the exact spot in Free mode). In Free mode, and when moving or resizing widgets with Snap to grid off, positions click onto a whole cell when you are close.
- You feel it too: a small tick each time the icon moves into a new cell, and when a widget lands exactly on a cell.
- The edit panel now shows the widget's position and size all the time, and updates as you drag.

## v0.9.9
- Quick switch: long-press empty space on the home screen and choose "Place icons freely" or "Snap icons to grid". It is the same setting as in Eon settings.

## v0.9.8
- New setting, Icon placement: Grid (icons snap to cells, as before) or Free (drop an icon anywhere on the home screen; positions go in steps of 0.05 cell, and a drop that would land on top of another icon is ignored). Switching back to Grid moves each icon to the nearest free cell.
- Fixed three type errors in the app-drag code that came in with v0.9.7 and would have stopped the build.

## v0.9.7
- Edit widgets right on the home screen: long-press a widget. A faint grid appears, you drag the widget to move it and drag the dots on its edges to resize it. A small panel gives you exact steps (Resize, Move, Elevation), a Snap to grid switch and Remove. Tap anywhere else, press Done or go back to finish.
- Widgets can now sit anywhere, not just on whole cells. With Snap to grid off, moves and resizes go in steps of 0.05 cell; with it on they snap to whole cells (this is the default).
- Elevation: when widgets overlap, the one with the higher Z number is on top.
- The grid also shows while you drag an app, so you can see where it will land.
- While a widget is being edited, swiping between pages and swiping up for the drawer are paused.

## v0.9.6
- App icon: the glyph is back to its original size (it was too big in 0.9.5) and sits comfortably inside the black background. Same rainbow colours.

## v0.9.5
- New app icon: the Eon symbol in a rainbow gradient (green, cyan, violet, magenta, coral, orange) on a pure black background. The welcome screen logo matches it.
- Removed the built-in clock and date from the top of the home screen, since it could not be moved or removed like a widget. The home grid now starts at the top, so apps you placed earlier sit about two rows higher; drag them back if you want.

## v0.9.4
- New icon shape: every app icon is now the same rounded square (about 26% rounded corners, measured from Smart Launcher), in the drawer, on the home grid and in the app menu. Adaptive icons are cut to the shape; old icons with a transparent margin sit centred on a light or dark plate so the grid looks even.
- Icons are a little bigger (60 dp instead of 56 dp). The size and corner radius are two values at the top of IconShape.kt.

## v0.9.3
- New colours: Eon moves from blue to near-black with soft grey text and a green accent (selected chips, badges, toggles, the playing dot). Panels are smoked black glass instead of blue, the welcome screen and the app icon are charcoal, and the Week widget and cover art match.

## v0.9.2
- Removed the dock: the home screen is now just the clock, your pages and the search pill. "Add to dock" is gone from the app menu. The dark fade at the bottom is shorter now that there is no dock behind it.

## v0.9.1
- Fixed: the build failed on one line in the home menu that still used the old way of checking whether a page is empty. Nothing else changed, so v0.9.1 has everything from v0.9.

## v0.9.0
- Free home grid: apps and widgets now sit on a 4-column grid. Long-press an app and drag it to any empty spot (or onto another app to swap); a highlight shows where it will land. Your existing home screen is moved onto the grid automatically.
- Widgets on the grid: each widget takes a number of cells. In the Widgets screen, the "On this page" tab lets you nudge a widget left, right, up or down and make it taller, shorter, wider or narrower. If a page is full, Eon says there is no space.
- Fixed: weather said "Allow location" even when location was allowed. It now asks the phone for a fresh coarse location itself, and says "No location fix" if there is none. Now playing also shows how many players it can see, to help find out why it stays empty.
- Not yet: dragging widgets directly, moving apps between pages.

## v0.8.0
- Fixed: long-pressing empty space on the home screen did nothing since pages arrived in v0.5, because the page swiper was catching the touch; it now opens the home menu (widgets, pages, settings) again, and long-pressing an app no longer risks opening it twice.
- New: tapping the page marker at the bottom also opens the home menu, as a second way in.

## v0.7.1
- Fixed: the build failed because two functions in the settings state had the same internal name (a naming clash on the look setting). Nothing else changed, so v0.7.1 has everything from v0.5 to v0.7, including home pages, the Eon widgets and weather.

## v0.7.0
- Weather and quote: a new Eon widget with the local weather on the left (angular icon, temperature, feels like) and a daily quote on the right; tap the weather to refresh or to allow location, tap the quote for another one. Weather comes from Open-Meteo using your last known coarse location, so Eon now asks for internet access.
- Not yet: your own quotes, folders, dragging apps between pages.

## v0.6.0
- Eon widgets: two built-in widgets under "EON" in the widget picker. Now playing shows the track and artist as plain text with a round cover and a green dot while playing (tap to open the player; needs notification access), and Week shows seven days around today with the month and the time.
- Gesture: swipe down on the home screen to pull the notification shade.
- Not yet: weather, folders, dragging apps between pages.

## v0.5.0
- Home pages: swipe sideways between pages, each with its own pinned apps and widgets; the marker at the bottom shows where you are, with the Eon glyph always standing for page one.
- Page controls: long-press empty space to add a page to the left or right, or to remove an empty one; pressing Home takes you back to page one.
- Changed: pinning an app or adding a widget now goes to the page you are on, and the widget manager shows that page's widgets.
- Not yet: dragging apps between pages, resizing widgets, folders.

## v0.4.0
- Widgets: long-press empty space and choose Widgets to add any widget from any app, then move or remove them in the "On this page" tab; they sit above your pinned apps.

## v0.3.0
- Drag to rearrange: long-press a pinned app or a dock app and drag it to a new spot; long-press and release still opens the app menu, which can now add or remove dock apps.

## v0.2.0
- Every app now shows in the drawer, Eon appears in the notification access list, and icons get notification counts.
- The drawer has category chips with search across all apps; long-press an app to pin, recategorize, hide, open app info or uninstall.
- Eon settings (Glassy or Flat look, notification access, hidden apps) and a more solid drawer background.

## v0.1.0
- First build: greeting flow, home with clock and dock, app drawer with search.
