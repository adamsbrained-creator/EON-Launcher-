package ix.app.eon

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue

/** One set of curves and springs, so everything in Eon speeds up and slows down the same way. */
object Motion {
    /** Fast start, long soft landing: things arriving. */
    val Decel = CubicBezierEasing(0.2f, 0.9f, 0.25f, 1f)

    /** Slow start, quick end: things leaving. */
    val Accel = CubicBezierEasing(0.4f, 0f, 0.8f, 0.3f)

    /** A calm settle with a hint of overshoot, for things that move with a finger. */
    fun <T> settle() = spring<T>(dampingRatio = 0.82f, stiffness = Spring.StiffnessMediumLow)

    /** A quick, light spring for small things (selection, press, nudge). */
    fun <T> snappy() = spring<T>(dampingRatio = 0.72f, stiffness = Spring.StiffnessMedium)
}

/** A full screen that rises in and settles, and sinks away when [visible] turns false. */
@Composable
fun ScreenAnim(visible: Boolean, content: @Composable () -> Unit) {
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(240, easing = Motion.Decel)) + slideInVertically(tween(340, easing = Motion.Decel)) { it / 12 },
        exit = fadeOut(tween(170, easing = Motion.Accel)) + slideOutVertically(tween(230, easing = Motion.Accel)) { it / 16 },
    ) { content() }
}

/** Like [ScreenAnim] for something that is shown only while it exists: it animates in when it first appears. */
@Composable
fun EnterAnim(content: @Composable () -> Unit) {
    val shown = remember { MutableTransitionState(false).apply { targetState = true } }
    AnimatedVisibility(
        visibleState = shown,
        enter = fadeIn(tween(220, easing = Motion.Decel)) + slideInVertically(tween(320, easing = Motion.Decel)) { it / 14 },
        exit = ExitTransition.None,
    ) { content() }
}

/** A popup that grows from slightly smaller while it fades in. */
@Composable
fun PopAnim(content: @Composable () -> Unit) {
    val shown = remember { MutableTransitionState(false).apply { targetState = true } }
    AnimatedVisibility(
        visibleState = shown,
        enter = fadeIn(tween(200, easing = Motion.Decel)) + scaleIn(tween(300, easing = Motion.Decel), initialScale = 0.9f),
        exit = fadeOut(tween(120)) + scaleOut(tween(160), targetScale = 0.95f),
    ) { content() }
}

/** Blur of the wallpaper behind the drawer and settings: 0 none, 1 frosted, 2 strong. Needs Android's window blur. */
object BlurConfig {
    var level by androidx.compose.runtime.mutableIntStateOf(0)
        private set
    private var prefs: Prefs? = null

    fun load(p: Prefs) {
        prefs = p
        level = p.getInt("drawerBlur", 0).coerceIn(0, 2)
    }

    fun choose(v: Int) {
        level = v
        prefs?.putInt("drawerBlur", v)
    }

    /** Blur radius in pixels. */
    fun radius(): Int = when (level) {
        1 -> 60
        2 -> 140
        else -> 0
    }
}
