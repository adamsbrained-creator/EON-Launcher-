package ix.app.eon

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp

/** What the double tap and the swipes on empty space on the home screen do. Swipe up opens the drawer unless you change it. */
object GestureConfig {
    var doubleTap by mutableStateOf(Act.NONE)
    var swipeDown by mutableStateOf(Act.NOTIF)
    var swipeUp by mutableStateOf(Act.DRAWER)
    var twoUp by mutableStateOf(Act.NONE)
    var twoDown by mutableStateOf(Act.NONE)

    private fun read(p: Prefs, key: String, legacyKey: String, legacyDef: Int): String {
        val s = p.getString(key)
        return if (s.isNotEmpty()) s else Act.fromLegacy(p.getInt(legacyKey, legacyDef))
    }

    fun load(p: Prefs) {
        doubleTap = read(p, "gestureDoubleS", "gestureDouble", 0)
        swipeDown = read(p, "gestureDownS", "gestureDown", 4)
        swipeUp = p.getString("gestureUpS").ifEmpty { Act.DRAWER }
        twoUp = p.getString("gestureTwoUpS").ifEmpty { Act.NONE }
        twoDown = p.getString("gestureTwoDownS").ifEmpty { Act.NONE }
    }

    fun save(p: Prefs) {
        p.putString("gestureDoubleS", doubleTap)
        p.putString("gestureDownS", swipeDown)
        p.putString("gestureUpS", swipeUp)
        p.putString("gestureTwoUpS", twoUp)
        p.putString("gestureTwoDownS", twoDown)
    }
}

/**
 * Swipe up goes home (Settings > Drawer), for the parts of a drawer that do not scroll: the title, the bar and the
 * empty space. A swipe up of about 70 dp closes the drawer. [enabled] lets a drawer switch it off while it is busy
 * (searching, arranging).
 */
fun Modifier.swipeUpToClose(enabled: () -> Boolean, onClose: () -> Unit): Modifier = this.pointerInput(Unit) {
    var total = 0f
    val need = 70.dp.toPx()
    detectVerticalDragGestures(
        onDragStart = { total = 0f },
        onDragEnd = { if (DrawerConfig.swipeUpHome && enabled() && total < -need) onClose() },
        onDragCancel = { total = 0f },
        onVerticalDrag = { _, dy -> total += dy },
    )
}

/**
 * Swipe up goes home, for a list: once the list has nothing more to scroll (it is at its end, or too short to scroll at
 * all), keep pulling up and the drawer closes. A fast flick up from there closes it too. A fling that merely runs into the
 * end of a long list never does, so scrolling to the bottom is safe.
 */
@Composable
fun rememberSwipeUpToClose(enabled: () -> Boolean, onClose: () -> Unit): NestedScrollConnection {
    val close by rememberUpdatedState(onClose)
    val active by rememberUpdatedState(enabled)
    val density = LocalDensity.current.density
    return remember(density) {
        object : NestedScrollConnection {
            private var pulled = 0f

            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                if (!DrawerConfig.swipeUpHome || !active()) {
                    pulled = 0f
                    return Offset.Zero
                }
                if (consumed.y != 0f) {
                    // The list is still moving: this is scrolling, not a swipe home.
                    pulled = 0f
                } else if (source == NestedScrollSource.UserInput && available.y < 0f) {
                    pulled -= available.y
                    if (pulled > 70f * density) {
                        pulled = 0f
                        close()
                    }
                }
                return Offset.Zero
            }

            override suspend fun onPreFling(available: Velocity): Velocity {
                val flick = DrawerConfig.swipeUpHome && active() && pulled > 20f * density && available.y < -1500f
                pulled = 0f
                if (flick) close()
                return Velocity.Zero
            }
        }
    }
}

/** Needed so Eon can lock the screen. Android asks the user to turn it on the first time. */
class EonAdminReceiver : DeviceAdminReceiver()

/** Locks the screen. The first time, opens Android's screen to make Eon a device administrator. */
fun lockScreen(ctx: Context) {
    try {
        val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val admin = ComponentName(ctx, EonAdminReceiver::class.java)
        if (dpm.isAdminActive(admin)) {
            dpm.lockNow()
        } else {
            ctx.startActivity(
                Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
                    .putExtra(
                        DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                        "Eon only uses this to lock the screen when you use the lock gesture.",
                    )
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
        }
    } catch (_: Exception) {
    }
}
