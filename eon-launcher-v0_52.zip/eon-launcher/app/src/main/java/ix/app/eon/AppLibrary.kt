package ix.app.eon

import androidx.activity.compose.BackHandler
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.RepeatMode
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Remove
import androidx.compose.material.icons.outlined.ViewModule
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** One folder tile in the App Library. [manage] is true for your own categories (long-press for Rename and so on). */
private data class LibTile(
    val id: String, val name: String, val icon: String?, val apps: List<AppEntry>, val manage: Boolean,
)

private fun buildTiles(apps: List<AppEntry>, state: EonState): List<LibTile> {
    val out = ArrayList<LibTile>()
    val recent = apps.sortedByDescending { it.firstInstall }.take(8)
    if (DrawerConfig.showRecent && recent.isNotEmpty()) out.add(LibTile("~recent", "Recently added", null, recent, false))
    val cats = state.categories.filter { it.id != CAT_ALL }
    val contents = cats.map { c -> c to apps.filter { state.inCategory(it, c.id) } }
    // Smart order: boxes you open the most come first.
    val ordered = if (LibraryConfig.smartBoxes) {
        contents.sortedByDescending { (_, list) -> list.sumOf { Usage.count(it.key, 30) } }
    } else {
        contents
    }
    ordered.forEach { (c, list) -> out.add(LibTile(c.id, c.name, c.icon, LibraryConfig.sorted(c.id, list), true)) }
    // Apps that no folder above holds, so every app can be reached without searching.
    val rest = apps.filter { a -> cats.none { state.inCategory(a, it.id) } }
    if (DrawerConfig.showOther && rest.isNotEmpty()) out.add(LibTile("~other", "Other apps", null, LibraryConfig.sorted("~other", rest), false))
    return out
}

private fun initial(label: String): String {
    val c = label.trim().firstOrNull()?.uppercaseChar()
    return if (c != null && c.isLetter()) c.toString() else "#"
}

/**
 * The iOS-style drawer: a search pill and a two-column grid of folders. Each folder shows the first
 * apps of a category as big icons and, when there are more, a small cluster of the next ones; tap the
 * folder (or the cluster) to open all of them. Tap the search pill for an A to Z list. Long-press one
 * of your folders for Add category, Edit icon, Rename and Remove. Fling down at the top to close.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppLibrary(
    apps: List<AppEntry>, state: EonState, focusSearch: Boolean,
    onLaunch: (AppEntry) -> Unit, onMenu: (AppEntry) -> Unit, onClose: () -> Unit,
    drag: DragState, onDrop: (AppEntry, Offset) -> Unit,
    onSettings: () -> Unit = {},
) {
    val focus = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    var searching by remember { mutableStateOf(focusSearch || DrawerConfig.autoKeyboard) }
    var query by remember { mutableStateOf("") }
    var openId by remember { mutableStateOf<String?>(null) }
    var adding by remember { mutableStateOf(false) }
    var menuFor by remember { mutableStateOf<String?>(null) }
    var renaming by remember { mutableStateOf<String?>(null) }
    var picking by remember { mutableStateOf<String?>(null) }
    var editMode by remember { mutableStateOf(false) }
    var customizing by remember { mutableStateOf(false) }
    val bounds = remember { HashMap<String, Rect>() }
    val tiles by remember(apps) { derivedStateOf { buildTiles(apps, state) } }
    val close by rememberUpdatedState(onClose)
    val pull = remember {
        object : NestedScrollConnection {
            override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
                if (available.y > 1500f) close()
                return Velocity.Zero
            }
        }
    }

    // Swipe up goes home (Settings > Drawer). Not while searching or arranging.
    val upClose = rememberSwipeUpToClose({ !searching && !editMode }, onClose)

    LaunchedEffect(searching) {
        if (searching) {
            try {
                focus.requestFocus()
            } catch (_: Exception) {
            }
        }
    }
    BackHandler(enabled = openId != null) { openId = null }
    BackHandler(enabled = editMode && openId == null) { editMode = false }
    BackHandler(enabled = searching) {
        searching = false
        query = ""
        focusManager.clearFocus()
    }

    val q = query.trim()

    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize()
                .background(DrawerConfig.scrim())
                .pointerInput(Unit) { detectTapGestures(onTap = { }) }
                .swipeUpToClose({ !searching && !editMode }, onClose)
                .systemBarsPadding().imePadding(),
        ) {
            Gap(8)
            // The search pill. Tapping it turns it into a field with an A to Z list below.
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
                    .glass(RoundedCornerShape(16.dp))
                    .then(if (!searching) Modifier.clickable { searching = true } else Modifier)
                    .padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Outlined.Search, null, tint = Eon.Muted, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(10.dp))
                Box(Modifier.weight(1f).padding(vertical = 14.dp)) {
                    if (!searching) {
                        Text("App Library", color = Eon.Muted, fontSize = 16.sp)
                    } else {
                        if (query.isEmpty()) Text("Search", color = Eon.Faint, fontSize = 16.sp)
                        BasicTextField(
                            value = query,
                            onValueChange = { query = it },
                            singleLine = true,
                            textStyle = TextStyle(color = Eon.Text, fontSize = 16.sp),
                            cursorBrush = SolidColor(Eon.Accent),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                            modifier = Modifier.fillMaxWidth().focusRequester(focus),
                        )
                    }
                }
                if (searching) {
                    Text(
                        "Cancel", color = Eon.Accent, fontSize = 15.sp, fontWeight = FontWeight.Medium,
                        modifier = Modifier.clickable {
                            searching = false
                            query = ""
                            focusManager.clearFocus()
                        }.padding(start = 10.dp, top = 8.dp, bottom = 8.dp),
                    )
                }
            }

            if (searching) {
                val list = remember(apps, q) {
                    if (q.isEmpty()) apps else apps.filter { it.label.contains(q, ignoreCase = true) }
                }
                val groups = remember(list) {
                    list.groupBy { initial(it.label) }.toList().sortedBy { if (it.first == "#") "~" else it.first }
                }
                LazyColumn(
                    Modifier.weight(1f).fillMaxWidth(),
                    contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 24.dp),
                ) {
                    if (groups.isEmpty()) {
                        item(key = "none") {
                            Text(
                                "No apps match", color = Eon.Muted, fontSize = 14.sp,
                                modifier = Modifier.fillMaxWidth().padding(top = 40.dp), textAlign = TextAlign.Center,
                            )
                        }
                    }
                    groups.forEach { (letter, group) ->
                        item(key = "h$letter") {
                            Text(
                                letter, color = Eon.Muted, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(start = 4.dp, top = 14.dp, bottom = 4.dp),
                            )
                        }
                        items(group, key = { it.key }) { app -> ListRow(app, onLaunch, onMenu) }
                    }
                }
            } else {
                val perRow = DrawerConfig.libColumns
                val rows = remember(tiles, perRow) { tiles.chunked(perRow) }
                LazyColumn(
                    Modifier.weight(1f).fillMaxWidth().nestedScroll(pull).nestedScroll(upClose),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 28.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    if (LibraryConfig.showInsights && !editMode) {
                        item(key = "insights") {
                            InsightsPanel(apps, onLaunch, onMenu, onHideApp = { state.hide(it.packageName) })
                        }
                    }
                    items(rows, key = { r -> r.joinToString("|") { it.id } }) { row ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(if (perRow == 3) 12.dp else 16.dp)) {
                            row.forEach { t ->
                                val idx = state.categories.indexOfFirst { it.id == t.id }
                                val canOrder = t.manage && !LibraryConfig.smartBoxes
                                Box(Modifier.weight(1f)) {
                                    FolderTile(
                                        tile = t, drag = drag, onLaunch = onLaunch, onMenu = onMenu, onDrop = onDrop,
                                        onOpen = { openId = t.id },
                                        onLongPress = { if (t.manage) menuFor = t.id },
                                        onBounds = { r -> bounds[t.id] = r },
                                        edit = editMode,
                                        onDelete = if (t.manage) ({ state.removeCategory(t.id) }) else null,
                                        onMoveLeft = if (canOrder && idx > 1) ({ state.moveCategory(t.id, -1) }) else null,
                                        onMoveRight = if (canOrder && idx in 1 until state.categories.size - 1) ({ state.moveCategory(t.id, 1) }) else null,
                                    )
                                }
                            }
                            repeat(perRow - row.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                    item(key = "add") {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                LibButton(Icons.Outlined.Add, "New box", Modifier.weight(1f)) { adding = true }
                                LibButton(
                                    if (editMode) Icons.Outlined.Check else Icons.Outlined.Edit,
                                    if (editMode) "Done" else "Arrange", Modifier.weight(1f),
                                ) { editMode = !editMode }
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                LibButton(Icons.Outlined.AutoAwesome, "Customize", Modifier.weight(1f)) { customizing = true }
                                LibButton(Icons.Outlined.Tune, "Drawer settings", Modifier.weight(1f), onSettings)
                            }
                        }
                    }
                }
            }
        }

        openId?.let { id ->
            tiles.firstOrNull { it.id == id }?.let { t ->
                BoxSheet(t, state, apps, onLaunch, onMenu, drag, onDrop) { openId = null }
            }
        }
        if (adding) {
            AddCategoryScreen(
                existing = state.categories.map { it.id }.toSet(),
                onPick = { def -> state.addCategory(def); adding = false },
                onCustom = {
                    val id = state.addCustomCategory()
                    adding = false
                    renaming = id
                },
                onBack = { adding = false },
            )
        }
    }

    if (customizing) {
        LibraryCustomizeDialog(onOrganize = { state.organizeLibrary(apps) }, onDismiss = { customizing = false })
    }
    menuFor?.let { id ->
        val cat = state.categories.firstOrNull { it.id == id }
        if (cat != null) {
            CategoryPopup(
                title = cat.name, anchor = bounds[id], canRemove = id != CAT_ALL,
                onAdd = { menuFor = null; adding = true },
                onEditIcon = { menuFor = null; picking = id },
                onRename = { menuFor = null; renaming = id },
                onRemove = { menuFor = null; state.removeCategory(id) },
                onDismiss = { menuFor = null },
                extras = listOf(
                    PopupAction(Icons.Outlined.ViewModule, "Switch to Bar") {
                        menuFor = null
                        state.chooseDrawerStyle("bar")
                    },
                    PopupAction(Icons.Outlined.Tune, "Drawer settings") {
                        menuFor = null
                        onSettings()
                    },
                ),
            )
        }
    }
    renaming?.let { id ->
        val cat = state.categories.firstOrNull { it.id == id }
        if (cat != null) {
            NameDialog(
                title = "Rename category", initial = cat.name,
                onDone = { state.renameCategory(id, it); renaming = null },
                onDismiss = { renaming = null },
            )
        }
    }
    picking?.let { id ->
        val cat = state.categories.firstOrNull { it.id == id }
        if (cat != null) {
            IconPickerDialog(
                current = cat.icon,
                onPick = { state.setCategoryIcon(id, it); picking = null },
                onDismiss = { picking = null },
            )
        }
    }
}

/** A row in the A to Z list. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ListRow(app: AppEntry, onLaunch: (AppEntry) -> Unit, onMenu: (AppEntry) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
            .combinedClickable(onClick = { onLaunch(app) }, onLongClick = { onMenu(app) })
            .padding(horizontal = 4.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Image(bitmap = app.icon, contentDescription = null, modifier = Modifier.size(46.dp).scaledIcon(app.iconScale))
        Spacer(Modifier.width(16.dp))
        Text(app.label, color = DrawerConfig.textColor, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/**
 * One folder: a rounded, see-through square with four slots. Up to four apps are shown as icons;
 * with more, the last slot holds a small 2 x 2 cluster of the next apps. Icons can be launched, opened
 * for their menu or dragged out to the home screen like in the other drawer.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FolderTile(
    tile: LibTile, drag: DragState,
    onLaunch: (AppEntry) -> Unit, onMenu: (AppEntry) -> Unit, onDrop: (AppEntry, Offset) -> Unit,
    onOpen: () -> Unit, onLongPress: () -> Unit, onBounds: (Rect) -> Unit,
    edit: Boolean = false, onDelete: (() -> Unit)? = null,
    onMoveLeft: (() -> Unit)? = null, onMoveRight: (() -> Unit)? = null,
) {
    val haptic = LocalHapticFeedback.current
    val shape = RoundedCornerShape(DrawerConfig.tileRadius.dp)
    val fill = DrawerConfig.tileColor.copy(alpha = DrawerConfig.tileOpacity)
    // In arrange mode the boxes wiggle a little, like icons on iOS.
    val wob = if (edit) {
        rememberInfiniteTransition(label = "wob").animateFloat(
            -0.8f, 0.8f, infiniteRepeatable(tween(120 + (tile.id.hashCode() and 31) * 2), RepeatMode.Reverse), label = "wobv",
        ).value
    } else {
        0f
    }
    Column(Modifier.graphicsLayer { rotationZ = wob }, horizontalAlignment = Alignment.CenterHorizontally) {
        BoxWithConstraints(
            Modifier.fillMaxWidth().aspectRatio(1f).clip(shape)
                .background(fill)
                .then(
                    if (DrawerConfig.tileBorder) Modifier.border(1.dp, DrawerConfig.tileColor.copy(alpha = DrawerConfig.tileOpacity * 0.55f), shape)
                    else Modifier,
                )
                .onGloballyPositioned { onBounds(it.boundsInWindow()) },
        ) {
            // Behind the icons: a tap on an icon launches it (unless Settings > Drawer says to open the folder), a tap anywhere else opens the folder.
            Box(
                Modifier.matchParentSize().combinedClickable(
                    onClick = onOpen,
                    onLongClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        onLongPress()
                    },
                ),
            )
            val w = maxWidth
            val pad = w * 0.075f
            val gap = w * 0.08f
            val icon = (w - pad * 2 - gap) / 2
            val apps = tile.apps
            if (apps.isEmpty()) {
                Icon(
                    catIcon(tile.icon ?: "folder"), null, tint = Color(0x66FFFFFF),
                    modifier = Modifier.align(Alignment.Center).size(w * 0.3f),
                )
            } else {
                val overflow = apps.size > 4
                val big = if (overflow) apps.take(3) else apps
                val rest = if (overflow) apps.drop(3).take(4) else emptyList()
                val miniGap = icon * 0.1f
                val mini = (icon - miniGap) / 2
                Column(Modifier.padding(pad), verticalArrangement = Arrangement.spacedBy(gap)) {
                    for (r in 0..1) {
                        Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                            for (c in 0..1) {
                                val i = r * 2 + c
                                Box(Modifier.size(icon), contentAlignment = Alignment.Center) {
                                    if (i < big.size) {
                                        val app = big[i]
                                        // The icon body has a few dp of padding of its own.
                                        DragAppIcon(
                                            app, icon - 8.dp, drag,
                                            { if (DrawerConfig.libDirectLaunch) onLaunch(app) else onOpen() }, { onMenu(app) }, onDrop,
                                            showLabel = false,
                                        )
                                    } else if (i == 3 && overflow) {
                                        Column(verticalArrangement = Arrangement.spacedBy(miniGap)) {
                                            for (mr in 0..1) {
                                                Row(horizontalArrangement = Arrangement.spacedBy(miniGap)) {
                                                    for (mc in 0..1) {
                                                        val a = rest.getOrNull(mr * 2 + mc)
                                                        if (a != null) {
                                                            Image(bitmap = a.icon, contentDescription = null, modifier = Modifier.size(mini))
                                                        } else {
                                                            Spacer(Modifier.size(mini))
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if (edit) {
                if (onDelete != null) {
                    Box(Modifier.align(Alignment.TopStart).padding(6.dp)) { EditDot(Icons.Outlined.Close, onDelete) }
                }
                Row(Modifier.align(Alignment.BottomCenter).padding(bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (onMoveLeft != null) EditDot(Icons.Outlined.ChevronLeft, onMoveLeft)
                    if (onMoveRight != null) EditDot(Icons.Outlined.ChevronRight, onMoveRight)
                }
            }
        }
        Text(
            tile.name, color = DrawerConfig.textColor.copy(alpha = 0.85f), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center, modifier = Modifier.padding(top = 6.dp),
        )
    }
}

/** A small round button used while arranging. */
@Composable
private fun EditDot(icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Box(
        Modifier.size(30.dp).clip(androidx.compose.foundation.shape.CircleShape).background(Color(0xDD1C1C1F))
            .border(1.dp, Color(0x44FFFFFF), androidx.compose.foundation.shape.CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, null, tint = Eon.Text, modifier = Modifier.size(16.dp)) }
}

/**
 * A box opened: its apps in a rounded panel over the dimmed library. Choose how they sort (the chips), add apps
 * to a box of your own, and use Arrange to take apps out or move them earlier and later. Tap outside to close.
 */
@Composable
private fun BoxSheet(
    tile: LibTile, state: EonState, allApps: List<AppEntry>,
    onLaunch: (AppEntry) -> Unit, onMenu: (AppEntry) -> Unit,
    drag: DragState, onDrop: (AppEntry, Offset) -> Unit, onClose: () -> Unit,
) {
    var arranging by remember { mutableStateOf(false) }
    var adding by remember { mutableStateOf(false) }
    val apps = tile.apps
    val cols = DrawerConfig.columns
    val rows = (apps.size + cols - 1) / cols
    val rowHeight = DrawerConfig.iconDp + (if (DrawerConfig.showLabels) 34 else 10) + DrawerConfig.rowGap
    val gridHeight = (rows * rowHeight + 32).dp.coerceIn(160.dp, 460.dp)
    val canSort = tile.id != "~recent"
    BackHandler(enabled = arranging) { arranging = false }
    Box(
        Modifier.fillMaxSize().background(Color(0x99000000))
            .pointerInput(Unit) { detectTapGestures(onTap = { onClose() }) }
            .systemBarsPadding(),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier.padding(horizontal = 16.dp).fillMaxWidth()
                .clip(RoundedCornerShape(32.dp)).background(Color(0xF01A1A1C))
                .pointerInput(Unit) { detectTapGestures(onTap = { }) }
                .padding(top = 20.dp),
        ) {
            Row(Modifier.padding(horizontal = 24.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(tile.name, color = Eon.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${apps.size} apps", color = Eon.Muted, fontSize = 12.sp)
                }
                if (tile.manage && apps.isNotEmpty()) {
                    Text(
                        if (arranging) "Done" else "Arrange", color = Eon.Accent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable { arranging = !arranging }
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                    )
                }
            }
            if (canSort) {
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    BOX_SORTS.forEach { (key, label) ->
                        val on = LibraryConfig.sortOf(tile.id) == key
                        Box(
                            Modifier.clip(androidx.compose.foundation.shape.CircleShape).accentFill(on, Color(0x1FFFFFFF))
                                .clickable { LibraryConfig.setSort(tile.id, key) }.padding(horizontal = 14.dp, vertical = 7.dp),
                        ) {
                            Text(
                                label, color = if (on) Eon.OnAccent else Eon.Soft, fontSize = 12.sp,
                                fontWeight = if (on) FontWeight.ExtraBold else FontWeight.Medium,
                            )
                        }
                    }
                }
            }
            Box(Modifier.fillMaxWidth().height(gridHeight)) {
                if (arranging) {
                    LazyVerticalGrid(
                        columns = androidx.compose.foundation.lazy.grid.GridCells.Fixed(4),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        items(apps, key = { it.key }) { app ->
                            val i = apps.indexOf(app)
                            Box(Modifier.fillMaxWidth().animateItem(), contentAlignment = Alignment.Center) {
                                AppIconBody(app, 48.dp, true, 11f, false)
                                Box(Modifier.align(Alignment.TopStart).padding(start = 2.dp)) {
                                    EditDot(Icons.Outlined.Remove) { state.setCategory(app.packageName, "none") }
                                }
                                Row(Modifier.align(Alignment.BottomCenter), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    if (i > 0) EditDot(Icons.Outlined.ChevronLeft) {
                                        LibraryConfig.moveApp(tile.id, apps.map { it.key }, app.key, -1)
                                    }
                                    if (i < apps.size - 1) EditDot(Icons.Outlined.ChevronRight) {
                                        LibraryConfig.moveApp(tile.id, apps.map { it.key }, app.key, 1)
                                    }
                                }
                            }
                        }
                    }
                } else {
                    AppGrid(apps, "No apps here yet.\nTap Add apps to fill this box.", onLaunch, onMenu, drag, onDrop, Eon.Text)
                }
            }
            if (tile.manage) {
                Box(
                    Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp)
                        .clip(RoundedCornerShape(18.dp)).background(Color(0x22FFFFFF))
                        .clickable { adding = true }.padding(vertical = 13.dp),
                    contentAlignment = Alignment.Center,
                ) { Text("Add apps", color = Eon.Soft, fontSize = 14.sp, fontWeight = FontWeight.Medium) }
            } else {
                Spacer(Modifier.height(14.dp))
            }
        }
        if (adding) {
            AddAppsScreen(
                tile.name, allApps, tile.apps.map { it.key }.toSet(),
                onConfirm = { list -> list.forEach { state.setCategory(it.packageName, tile.id) } },
                onClose = { adding = false },
            )
        }
    }
}

/** Pick any apps to put in a box or folder called [name]. Apps already in it ([inBox]) are ticked and stay. */
@Composable
internal fun AddAppsScreen(
    name: String, allApps: List<AppEntry>, inBox: Set<String>,
    onConfirm: (List<AppEntry>) -> Unit, onClose: () -> Unit,
) {
    BackHandler { onClose() }
    var query by remember { mutableStateOf("") }
    val picked = remember { androidx.compose.runtime.mutableStateListOf<String>() }
    val list = remember(allApps, query) {
        allApps.filter { query.isBlank() || it.label.contains(query.trim(), ignoreCase = true) }.sortedBy { it.label.lowercase() }
    }
    Column(
        Modifier.fillMaxSize().background(Color(0xFA000000)).systemBarsPadding()
            .pointerInput(Unit) { detectTapGestures { } }.padding(horizontal = 16.dp),
    ) {
        Gap(12)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Add apps to", color = Eon.Faint, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text(name, color = Eon.Text, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            }
            Box(
                Modifier.clip(androidx.compose.foundation.shape.CircleShape).background(Eon.Button)
                    .clickable {
                        onConfirm(allApps.filter { it.key in picked })
                        onClose()
                    }.padding(horizontal = 20.dp, vertical = 10.dp),
            ) {
                Text(if (picked.isEmpty()) "Close" else "Add ${picked.size}", color = Eon.OnAccent, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
        Gap(12)
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0xFF151517)).padding(horizontal = 14.dp, vertical = 12.dp)) {
            if (query.isEmpty()) Text("Search apps", color = Eon.Faint, fontSize = 15.sp)
            BasicTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                textStyle = TextStyle(color = Eon.Text, fontSize = 15.sp), cursorBrush = SolidColor(Eon.Accent),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp)) {
            items(list, key = { it.key }) { app ->
                val already = app.key in inBox
                val on = already || app.key in picked
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                        .clickable(enabled = !already) { if (app.key in picked) picked.remove(app.key) else picked.add(app.key) }
                        .padding(horizontal = 8.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Image(bitmap = app.icon, contentDescription = null, modifier = Modifier.size(40.dp))
                    Text(
                        app.label, color = if (already) Eon.Faint else Eon.Text, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f).padding(start = 14.dp),
                    )
                    Box(
                        Modifier.size(24.dp).clip(androidx.compose.foundation.shape.CircleShape)
                            .accentFill(on && !already, if (already) Color(0xFF2A2A2E) else Color(0xFF1C1C1F)),
                        contentAlignment = Alignment.Center,
                    ) { if (on) Icon(Icons.Outlined.Check, null, tint = if (already) Eon.Faint else Eon.OnAccent, modifier = Modifier.size(16.dp)) }
                }
            }
        }
    }
}

/** A pill button under the folders. */
@Composable
private fun LibButton(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, modifier: Modifier, onClick: () -> Unit) {
    Row(
        modifier.clip(RoundedCornerShape(18.dp)).background(Color(0x22FFFFFF))
            .clickable(onClick = onClick).padding(vertical = 14.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = Eon.Soft, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Text(label, color = Eon.Soft, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}
