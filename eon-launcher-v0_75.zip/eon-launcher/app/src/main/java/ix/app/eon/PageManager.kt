package ix.app.eon

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Article
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * What lies beyond the home pages. Swiping right on the first page opens [left], swiping left on the last page opens
 * [right]. Each is an action, so it can be Google's feed, Eon's feed, the app page, the search page or anything else.
 */
object PageSlots {
    var left by mutableStateOf(Act.GOOGLE_FEED)
    var right by mutableStateOf(Act.FEED)

    fun load(p: Prefs) {
        // Older versions had one choice, which feed a swipe right opens.
        val googleFirst = p.getBool("gFeedFirst", true)
        left = p.getString("slotLeft").ifEmpty { if (googleFirst) Act.GOOGLE_FEED else Act.FEED }
        right = p.getString("slotRight").ifEmpty { if (googleFirst) Act.FEED else Act.GOOGLE_FEED }
    }

    fun save(p: Prefs) {
        p.putString("slotLeft", left)
        p.putString("slotRight", right)
    }
}

/** The picture for what a direction opens. Google's feed has no icon of its own, so it gets a letter. */
private fun slotIcon(spec: String): ImageVector? = when (spec) {
    Act.GOOGLE_FEED -> null
    Act.FEED -> Icons.Outlined.Article
    Act.DRAWER -> Icons.Outlined.GridView
    Act.SEARCH -> Icons.Outlined.Search
    Act.NOTIF -> Icons.Outlined.Notifications
    Act.NONE -> Icons.Outlined.Close
    else -> Icons.Outlined.Tune
}

/** Settings > Page manager: Home in the middle, and the page each direction leads to around it, like Smart Launcher. */
@Composable
fun PageManagerScreen(state: EonState, apps: List<AppEntry>, onBack: () -> Unit) {
    BackHandler { onBack() }
    Column(
        Modifier.fillMaxSize().background(Eon.Page).systemBarsPadding().padding(horizontal = 16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Gap(12)
        Box(Modifier.fillMaxWidth()) { PageHeader("Page manager", onBack) }
        Gap(8)
        Text(
            "Tap a card to choose what that direction opens.",
            color = Eon.Muted, fontSize = 14.sp, modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
        )
        Gap(24)
        SlotCard("Swipe up", GestureConfig.swipeUp, apps, state, "Swipe up") { GestureConfig.swipeUp = it; state.saveGestures() }
        Arrow(90f)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            SlotCard("Swipe right", PageSlots.left, apps, state, "Swipe right on the first page") {
                PageSlots.left = it; state.savePageSlots()
            }
            Arrow(0f)
            HomeCard(state.pages.size)
            Arrow(180f)
            SlotCard("Swipe left", PageSlots.right, apps, state, "Swipe left on the last page") {
                PageSlots.right = it; state.savePageSlots()
            }
        }
        Arrow(270f)
        SlotCard("Swipe down", GestureConfig.swipeDown, apps, state, "Swipe down") { GestureConfig.swipeDown = it; state.saveGestures() }
        Gap(24)
        Text(
            "Swipe right and swipe left happen past the first and last home page. Swipe up and down are the same gestures as in Settings > Gestures. " +
                "Choose Google feed for one side and News feed (Eon) for the other to have both.",
            color = Eon.Faint, fontSize = 12.sp, modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
        )
        Gap(30)
    }
}

/** A short arrow pointing from Home towards a card. [degrees] 0 points left, 180 right, 90 down, 270 up. */
@Composable
private fun Arrow(degrees: Float) {
    Box(Modifier.size(22.dp), contentAlignment = Alignment.Center) {
        Icon(Icons.Outlined.ArrowBack, null, tint = Eon.Faint, modifier = Modifier.size(16.dp).rotate(degrees))
    }
}

@Composable
private fun HomeCard(pages: Int) {
    Column(
        Modifier.width(88.dp).height(138.dp).clip(RoundedCornerShape(22.dp)).background(Eon.P2)
            .border(1.5.dp, Eon.Accent, RoundedCornerShape(22.dp)).padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(Icons.Outlined.Home, null, tint = Eon.Text, modifier = Modifier.size(26.dp))
        Gap(8)
        Text("Home", color = Eon.Text, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
        Gap(8)
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            repeat(pages.coerceIn(1, 6)) { i ->
                Box(Modifier.size(if (i == 0) 7.dp else 5.dp).clip(CircleShape).background(if (i == 0) Eon.Text else Eon.Faint))
            }
        }
        Gap(6)
        Text("$pages ${if (pages == 1) "page" else "pages"}", color = Eon.Muted, fontSize = 11.sp)
    }
}

@Composable
private fun SlotCard(
    direction: String, spec: String, apps: List<AppEntry>, state: EonState, pickerTitle: String, onPick: (String) -> Unit,
) {
    val icon = slotIcon(spec)
    Column(
        Modifier.width(88.dp).height(138.dp).clip(RoundedCornerShape(22.dp)).background(Eon.P0)
            .border(1.dp, Eon.Line, RoundedCornerShape(22.dp))
            .clickable { state.actionPicker = ActionRequest(pickerTitle, spec, onPick) }
            .padding(horizontal = 8.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(direction, color = Eon.Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(40.dp).clip(CircleShape).background(Eon.P2), contentAlignment = Alignment.Center) {
                if (icon == null) {
                    Text("G", color = Eon.Accent, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                } else {
                    Icon(icon, null, tint = Eon.Text, modifier = Modifier.size(22.dp))
                }
            }
            Gap(6)
            Text(
                Act.label(spec, apps), color = Eon.Text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis,
            )
        }
        Text("Change", color = Eon.Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}
