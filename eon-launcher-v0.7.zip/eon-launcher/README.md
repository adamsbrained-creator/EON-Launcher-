# Eon

A calm, quick Android launcher. Personal project, open source.

Package: `ix.app.eon` · Kotlin · Jetpack Compose · min Android 12 (API 31) · see CHANGELOG.md

## What works
See CHANGELOG.md.

## Build on GitHub
1. Create a new empty repo on GitHub.
2. Upload every file in this folder (keep the structure, including `.github/workflows/build.yml` and `app/eon.jks`).
3. Open the **Actions** tab. A build starts on every push to `main`. You can also run it by hand.
4. When it finishes, open the run and download the **eon-apk** artifact (a zip), unzip it and install the `.apk`. No GitHub release is created.
5. Open Eon, go through the greeting, and choose Eon as the home app.

Every build is signed with the same key (`app/eon.jks`), so a new build installs over the previous one.
The key and its password are public in this repo on purpose: this app is for personal sideloading only.

## Notes
- There is no Gradle wrapper; the workflow installs Gradle 8.10.2 itself.
- Versions: AGP 8.7.3, Kotlin 2.0.21, Compose BOM 2024.12.01. If a build fails, send the error log.
- Location, calendar and notification access are only requested if you tap Allow; nothing reads them yet.
