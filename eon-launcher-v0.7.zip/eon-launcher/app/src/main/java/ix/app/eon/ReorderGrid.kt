package ix.app.eon

import androidx.compose.animation.core.animateIntOffsetAsState
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitLongPressOrCancellation
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.zIndex
import kotlin.math.roundToInt

/**
 * A fixed grid whose items can be reordered by long-pressing and dragging.
 * Tap = [onTap]. Long-press and release without moving = [onMenu]. Long-press and drag = reorder.
 */
@Composable
fun <T> ReorderGrid(
    items: List<T>,
    idOf: (T) -> String,
    columns: Int,
    cellHeight: Dp,
    onMove: (from: Int, to: Int) -> Unit,
    onTap: (T) -> Unit,
    onMenu: (T) -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable (T) -> Unit,
) {
    val density = LocalDensity.current
    val haptic = LocalHapticFeedback.current
    val rows = ((items.size + columns - 1) / columns).coerceAtLeast(1)
    var dragId by remember { mutableStateOf<String?>(null) }
    var dragPos by remember { mutableStateOf(Offset.Zero) }
    var target by remember { mutableIntStateOf(0) }
    val latestItems by rememberUpdatedState(items)
    val latestTap by rememberUpdatedState(onTap)
    val latestMove by rememberUpdatedState(onMove)
    val latestMenu by rememberUpdatedState(onMenu)

    BoxWithConstraints(modifier.height(cellHeight * rows)) {
        val cellW = constraints.maxWidth.toFloat() / columns
        val cellH = with(density) { cellHeight.toPx() }
        val cellWDp = with(density) { cellW.toDp() }
        val dragged = dragId?.let { id -> items.firstOrNull { idOf(it) == id } }
        val visual = if (dragged == null) items else items.toMutableList().also {
            it.remove(dragged)
            it.add(target.coerceIn(0, it.size), dragged)
        }

        visual.forEachIndexed { slot, item ->
            val id = idOf(item)
            key(id) {
                val isDragged = id == dragId
                val slotOffset = IntOffset(
                    ((slot % columns) * cellW).roundToInt(),
                    ((slot / columns) * cellH).roundToInt(),
                )
                val animated by animateIntOffsetAsState(slotOffset, label = "slot")
                val pos = if (isDragged) IntOffset(dragPos.x.roundToInt(), dragPos.y.roundToInt()) else animated
                Box(
                    Modifier
                        .offset { pos }
                        .size(DpSize(cellWDp, cellHeight))
                        .zIndex(if (isDragged) 1f else 0f)
                        .graphicsLayer {
                            val s = if (isDragged) 1.12f else 1f
                            scaleX = s
                            scaleY = s
                            alpha = if (isDragged) 0.92f else 1f
                        }
                        .pointerInput(id) {
                            awaitEachGesture {
                                val down = awaitFirstDown(requireUnconsumed = false)
                                val press = awaitLongPressOrCancellation(down.id)
                                if (press == null) {
                                    // Released quickly without moving far: a tap.
                                    val ev = currentEvent.changes.firstOrNull { it.id == down.id }
                                    if (ev != null && !ev.pressed &&
                                        (ev.position - down.position).getDistance() < viewConfiguration.touchSlop * 2
                                    ) {
                                        latestItems.firstOrNull { idOf(it) == id }?.let { latestTap(it) }
                                    }
                                    return@awaitEachGesture
                                }
                                val startIndex = latestItems.indexOfFirst { idOf(it) == id }
                                if (startIndex < 0) return@awaitEachGesture
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                dragId = id
                                target = startIndex
                                dragPos = Offset((startIndex % columns) * cellW, (startIndex / columns) * cellH)
                                var travelled = 0f
                                drag(down.id) { change ->
                                    val d = change.positionChange()
                                    travelled += d.getDistance()
                                    dragPos += d
                                    change.consume()
                                    val cx = dragPos.x + cellW / 2f
                                    val cy = dragPos.y + cellH / 2f
                                    val col = (cx / cellW).toInt().coerceIn(0, columns - 1)
                                    val row = (cy / cellH).toInt().coerceIn(0, rows - 1)
                                    target = (row * columns + col).coerceAtMost(latestItems.size - 1)
                                }
                                val finalTarget = target
                                dragId = null
                                if (travelled > viewConfiguration.touchSlop * 2) {
                                    if (finalTarget != startIndex) latestMove(startIndex, finalTarget)
                                } else {
                                    latestItems.getOrNull(startIndex)?.let { latestMenu(it) }
                                }
                            }
                        },
                    contentAlignment = Alignment.Center,
                ) { content(item) }
            }
        }
    }
}
