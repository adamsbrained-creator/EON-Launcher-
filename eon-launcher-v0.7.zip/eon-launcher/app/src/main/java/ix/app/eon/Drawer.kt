package ix.app.eon

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun Drawer(
    apps: List<AppEntry>, state: EonState, focusSearch: Boolean,
    onLaunch: (AppEntry) -> Unit, onMenu: (AppEntry) -> Unit,
) {
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf("All") }
    val focus = remember { FocusRequester() }
    LaunchedEffect(focusSearch) { if (focusSearch) focus.requestFocus() }

    val groups = apps.groupBy { state.overrides[it.packageName] ?: it.autoCategory }
    val chips = listOf("All") + CATEGORIES.filter { it in groups }
    val tab = if (selected in chips) selected else "All"
    val q = query.trim()
    val list = when {
        q.isNotEmpty() -> apps.filter { it.label.contains(q, ignoreCase = true) }
        tab == "All" -> apps
        else -> groups[tab].orEmpty()
    }

    Column(
        Modifier.fillMaxSize().background(Color(0xF5070B24)).systemBarsPadding().imePadding()
            .padding(horizontal = 16.dp),
    ) {
        Gap(12)
        Box(Modifier.fillMaxWidth().glass(CircleShape).padding(horizontal = 20.dp, vertical = 14.dp)) {
            if (query.isEmpty()) Text("Search apps", color = Eon.Faint, fontSize = 16.sp)
            BasicTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                textStyle = TextStyle(color = Eon.Text, fontSize = 16.sp),
                cursorBrush = SolidColor(Eon.Periwinkle),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { list.firstOrNull()?.let(onLaunch) }),
                modifier = Modifier.fillMaxWidth().focusRequester(focus),
            )
        }
        Gap(12)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(chips) { name -> CatChip(name, name == tab && q.isEmpty()) { selected = name; query = "" } }
        }
        Gap(8)
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(list, key = { it.key }) { app ->
                AppIcon(app, 56.dp, true, { onLaunch(app) }, { onMenu(app) })
            }
        }
    }
}

@Composable
private fun CatChip(label: String, on: Boolean, onClick: () -> Unit) {
    val look = if (on) Modifier.background(Eon.Button)
    else Modifier.background(Color(0x1FFFFFFF)).border(1.dp, Color(0x4DBECDFF), CircleShape)
    Box(
        Modifier.height(34.dp).clip(CircleShape).then(look).clickable(onClick = onClick).padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label, color = if (on) Color.White else Color(0xFFC9D1F5), fontSize = 14.sp,
            fontWeight = if (on) FontWeight.Bold else FontWeight.Medium,
        )
    }
}
