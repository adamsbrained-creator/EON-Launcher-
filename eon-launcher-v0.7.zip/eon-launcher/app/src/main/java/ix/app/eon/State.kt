package ix.app.eon

import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

val LocalLook = compositionLocalOf { "glassy" }

/** One home page: its pinned apps and its widgets. */
class PageData(pinnedKeys: List<String> = emptyList(), widgetIds: List<Int> = emptyList()) {
    val pinned = mutableStateListOf<String>().also { it.addAll(pinnedKeys) }
    val widgets = mutableStateListOf<Int>().also { it.addAll(widgetIds) }
    val isEmpty: Boolean get() = pinned.isEmpty() && widgets.isEmpty()
}

private fun JSONArray.strings(): List<String> = (0 until length()).map { getString(it) }
private fun JSONArray.ints(): List<Int> = (0 until length()).map { getInt(it) }

/** Everything the user can change, kept in memory and saved to [Prefs]. */
class EonState(private val prefs: Prefs) {
    var look by mutableStateOf(prefs.look)
        private set
    val pages = mutableStateListOf<PageData>().also { it.addAll(loadPages()) }
    var currentPage by mutableIntStateOf(0)
    val dock = mutableStateListOf<String>().also { it.addAll(prefs.dock) }
    var dockCustom by mutableStateOf(prefs.dockCustom)
        private set
    val hidden = mutableStateListOf<String>().also { it.addAll(prefs.hidden) }
    val overrides = mutableStateMapOf<String, String>().also { it.putAll(prefs.overrides) }

    private fun loadPages(): List<PageData> {
        val raw = prefs.pagesJson
        // First run after an update from v0.4: everything becomes page one.
        if (raw.isBlank()) return listOf(PageData(prefs.pinned, prefs.widgets))
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                PageData(o.getJSONArray("pinned").strings(), o.getJSONArray("widgets").ints())
            }.ifEmpty { listOf(PageData()) }
        } catch (_: Exception) {
            listOf(PageData(prefs.pinned, prefs.widgets))
        }
    }

    private fun savePages() {
        val arr = JSONArray()
        pages.forEach { p ->
            arr.put(
                JSONObject()
                    .put("pinned", JSONArray(p.pinned.toList()))
                    .put("widgets", JSONArray(p.widgets.toList())),
            )
        }
        prefs.pagesJson = arr.toString()
    }

    fun setLook(value: String) {
        look = value
        prefs.look = value
    }

    // ---- apps on pages
    fun isPinned(key: String): Boolean = pages.any { key in it.pinned }

    fun togglePin(key: String) {
        val holder = pages.firstOrNull { key in it.pinned }
        if (holder != null) holder.pinned.remove(key) else pages.getOrNull(currentPage)?.pinned?.add(key)
        savePages()
    }

    fun moveHome(page: Int, from: Int, to: Int) {
        val list = pages.getOrNull(page)?.pinned ?: return
        if (from == to || from !in list.indices || to !in list.indices) return
        list.add(to, list.removeAt(from))
        savePages()
    }

    // ---- widgets
    val currentWidgets: List<Int> get() = pages.getOrNull(currentPage)?.widgets ?: emptyList()

    fun allWidgets(): List<Int> = pages.flatMap { it.widgets }

    fun addWidget(id: Int) {
        pages.getOrNull(currentPage)?.widgets?.let { if (id !in it) it.add(id) }
        savePages()
    }

    fun removeWidget(id: Int) {
        pages.forEach { it.widgets.remove(id) }
        savePages()
    }

    fun moveWidget(from: Int, to: Int) {
        val list = pages.getOrNull(currentPage)?.widgets ?: return
        if (from == to || from !in list.indices || to !in list.indices) return
        list.add(to, list.removeAt(from))
        savePages()
    }

    // ---- pages
    fun addPage(index: Int) {
        pages.add(index.coerceIn(0, pages.size), PageData())
        savePages()
    }

    fun removePage(index: Int) {
        if (pages.size > 1 && index in pages.indices && pages[index].isEmpty) {
            pages.removeAt(index)
            savePages()
        }
    }

    // ---- dock
    fun setDock(keys: List<String>) {
        dock.clear()
        dock.addAll(keys)
        dockCustom = true
        prefs.dock = keys
        prefs.dockCustom = true
    }

    // ---- hidden apps and categories
    fun hide(pkg: String) {
        if (pkg !in hidden) hidden.add(pkg)
        prefs.hidden = hidden.toSet()
    }

    fun showAllApps() {
        hidden.clear()
        prefs.hidden = emptySet()
    }

    fun setCategory(pkg: String, category: String) {
        overrides[pkg] = category
        prefs.overrides = overrides.toMap()
    }
}
