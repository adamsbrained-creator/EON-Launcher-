package ix.app.eon

import android.app.Notification
import android.content.ComponentName
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap

/** Number of visible notifications per package, read by the icons. */
object Badges {
    val counts = mutableStateMapOf<String, Int>()
}

/** What the music app is playing right now, read by the Now playing widget. */
object NowPlaying {
    var title by mutableStateOf("")
    var artist by mutableStateOf("")
    var playing by mutableStateOf(false)
    var art by mutableStateOf<ImageBitmap?>(null)
    var pkg by mutableStateOf("")
}

class EonNotificationListener : NotificationListenerService() {
    private val main = Handler(Looper.getMainLooper())
    private var controller: MediaController? = null

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = publishMedia()
        override fun onPlaybackStateChanged(state: PlaybackState?) = publishMedia()
    }
    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { list ->
        updateMedia(list ?: emptyList())
    }

    override fun onListenerConnected() {
        refresh()
        startMedia()
    }

    override fun onListenerDisconnected() {
        publish(emptyMap())
        stopMedia()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) = refresh()
    override fun onNotificationRemoved(sbn: StatusBarNotification?) = refresh()

    // ---- notification counts
    private fun refresh() {
        val active = try {
            activeNotifications
        } catch (_: Exception) {
            null
        } ?: return
        val next = HashMap<String, Int>()
        for (n in active) {
            if (n.isOngoing) continue
            if ((n.notification.flags and Notification.FLAG_GROUP_SUMMARY) != 0) continue
            next[n.packageName] = (next[n.packageName] ?: 0) + 1
        }
        publish(next)
    }

    private fun publish(next: Map<String, Int>) {
        main.post {
            Badges.counts.clear()
            Badges.counts.putAll(next)
        }
    }

    // ---- now playing
    private fun startMedia() {
        try {
            val msm = getSystemService(MediaSessionManager::class.java) ?: return
            val me = ComponentName(this, EonNotificationListener::class.java)
            msm.addOnActiveSessionsChangedListener(sessionsListener, me)
            updateMedia(msm.getActiveSessions(me))
        } catch (_: Exception) {
        }
    }

    private fun stopMedia() {
        try {
            getSystemService(MediaSessionManager::class.java)?.removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (_: Exception) {
        }
        controller?.unregisterCallback(callback)
        controller = null
        publishMedia()
    }

    private fun updateMedia(list: List<MediaController>) {
        controller?.unregisterCallback(callback)
        controller = list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list.firstOrNull()
        controller?.registerCallback(callback)
        publishMedia()
    }

    private fun publishMedia() {
        val c = controller
        val md = c?.metadata
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: ""
        val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
        val art = md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
        val playing = c?.playbackState?.state == PlaybackState.STATE_PLAYING
        val pkg = c?.packageName ?: ""
        main.post {
            NowPlaying.title = title
            NowPlaying.artist = artist
            NowPlaying.playing = playing
            NowPlaying.art = art?.asImageBitmap()
            NowPlaying.pkg = pkg
        }
    }
}
