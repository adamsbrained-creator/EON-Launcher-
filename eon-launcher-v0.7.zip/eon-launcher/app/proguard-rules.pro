# Eon: no special rules needed yet.
-dontwarn org.jetbrains.annotations.**
