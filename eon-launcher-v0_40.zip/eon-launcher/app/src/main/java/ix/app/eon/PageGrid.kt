package ix.app.eon

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.VectorConverter
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateIntOffsetAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitLongPressOrCancellation
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import kotlin.math.roundToInt

val CELL_HEIGHT: Dp = 92.dp

/**
 * One home page as a grid of 4 columns. Apps and widgets sit on cells.
 * Long-press an app and drag it to any free cell (or onto another app to swap).
 * Long-press and release without moving opens the app menu; long-press on empty space opens the home menu.
 */
@Composable
fun PageGrid(
    page: PageData,
    pageIndex: Int,
    state: EonState,
    apps: List<AppEntry>,
    widgets: WidgetHolder,
    onTap: (AppEntry) -> Unit,
    onMenu: (AppEntry) -> Unit,
    onEmptyLongPress: () -> Unit,
    modifier: Modifier = Modifier,
    onDoubleTap: () -> Unit = {},
) {
    val density = LocalDensity.current
    val haptic = LocalHapticFeedback.current
    var dragKey by remember { mutableStateOf<String?>(null) }
    var dragPos by remember { mutableStateOf(Offset.Zero) }
    var targetCol by remember { mutableIntStateOf(0) }
    var targetRow by remember { mutableIntStateOf(0) }
    val latestApps by rememberUpdatedState(apps)
    val latestTap by rememberUpdatedState(onTap)
    val latestMenu by rememberUpdatedState(onMenu)
    val latestEmpty by rememberUpdatedState(onEmptyLongPress)
    val latestDouble by rememberUpdatedState(onDoubleTap)

    BoxWithConstraints(
        modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures(
            onLongPress = { if (state.editing == null && !state.widgetTouch) latestEmpty() },
            onDoubleTap = { latestDouble() },
        ) },
    ) {
        val cellW = constraints.maxWidth.toFloat() / GRID_COLS
        val cellH = state.cellHeightPx
        val cellWDp = with(density) { cellW.toDp() }
        val cellHDp = with(density) { cellH.toDp() }
        val rows = state.gridRows
        val editItem = page.items.firstOrNull { it.kind == "w" && it.key == state.editing }

        val gridAlpha by animateFloatAsState(
            if (dragKey != null || editItem != null) 1f else 0f, tween(160), label = "grid",
        )
        if (gridAlpha > 0.01f) GridOverlay(cellW, cellH, rows, gridAlpha)

        if (dragKey != null) {
            // Where the icon will land: the cell in grid mode, the exact (magnetic) spot in free mode.
            val free = state.freeIcons
            val gx = if (free) snapValue(dragPos.x / cellW, false).coerceIn(0f, GRID_COLS - 1f) * cellW else targetCol * cellW
            val gy = if (free) snapValue(dragPos.y / cellH, false).coerceIn(0f, maxOf(rows, 1) - 1f) * cellH else targetRow * cellH
            val ghost by animateIntOffsetAsState(
                IntOffset(gx.roundToInt(), gy.roundToInt()),
                spring(stiffness = Spring.StiffnessMedium),
                label = "ghost",
            )
            val shape = RoundedCornerShape(20.dp)
            Box(
                Modifier
                    .offset { ghost }
                    .size(DpSize(cellWDp, cellHDp))
                    .padding(4.dp)
                    .clip(shape)
                    .background(Color(0x22FFFFFF))
                    .border(1.dp, Color(0x66FFFFFF), shape),
            )
        }

        page.items.toList().forEach { item ->
            key(item.kind + item.key) {
                if (item.kind == "w") {
                    val id = item.key.toIntOrNull()
                    if (id != null) {
                        Box(
                            Modifier
                                .offset { IntOffset((item.col * cellW).roundToInt(), (item.row * cellH).roundToInt()) }
                                .size(DpSize(cellWDp * item.w, cellHDp * item.h))
                                .zIndex(item.z.toFloat())
                                .padding(4.dp)
                                .pointerInput(item.key) {
                                    // Long-press a widget to edit it. Watching before the widget sees the touch
                                    // (Initial pass) means this works even over widgets that handle touches.
                                    awaitEachGesture {
                                        val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                                        // Tells the page this touch belongs to a widget, so it does not open the home menu too.
                                        state.widgetTouch = true
                                        try {
                                        if (state.editing == item.key) return@awaitEachGesture
                                        var cancelled = false
                                        withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
                                            while (!cancelled) {
                                                val ev = awaitPointerEvent(PointerEventPass.Initial)
                                                val c = ev.changes.firstOrNull { it.id == down.id }
                                                if (c == null || !c.pressed ||
                                                    (c.position - down.position).getDistance() > viewConfiguration.touchSlop
                                                ) {
                                                    cancelled = true
                                                }
                                            }
                                        }
                                        if (!cancelled) {
                                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                            state.editing = item.key
                                            // Take over the rest of the touch so the widget does not also react to it.
                                            while (true) {
                                                val ev = awaitPointerEvent(PointerEventPass.Initial)
                                                ev.changes.forEach { it.consume() }
                                                if (ev.changes.none { it.pressed }) break
                                            }
                                        }
                                        } finally {
                                            state.widgetTouch = false
                                        }
                                    }
                                },
                        ) {
                            val wDp = (cellWDp * item.w).value.toInt() - 8
                            val hDp = (cellHDp * item.h).value.toInt() - 8
                            if (isStackId(id)) StackView(widgets, state, id, wDp, hDp) else WidgetView(widgets, id, wDp, hDp)
                        }
                    }
                } else {
                    val app = if (item.kind == "a") apps.firstOrNull { it.key == item.key } else null
                    if (app != null || item.kind == "f") {
                        val isDragged = dragKey == item.key
                        val slot = Offset(item.col * cellW, item.row * cellH)
                        // The icon glides to its slot. When you let go it starts from where your finger left it,
                        // so it settles into place instead of jumping back first.
                        val glide = remember { Animatable(slot, Offset.VectorConverter) }
                        var wasDragged by remember { mutableStateOf(false) }
                        LaunchedEffect(isDragged, slot) {
                            if (isDragged) {
                                wasDragged = true
                            } else {
                                if (wasDragged) {
                                    glide.snapTo(dragPos)
                                    wasDragged = false
                                }
                                glide.animateTo(slot, spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMedium))
                            }
                        }
                        val lift by animateFloatAsState(
                            if (isDragged) 1.12f else 1f, spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMedium), label = "lift",
                        )
                        val pos = if (isDragged) dragPos else glide.value
                        Box(
                            Modifier
                                .offset { IntOffset(pos.x.roundToInt(), pos.y.roundToInt()) }
                                .size(DpSize(cellWDp, cellHDp))
                                .zIndex(if (isDragged) 1000f else item.z.toFloat())
                                .graphicsLayer {
                                    scaleX = lift
                                    scaleY = lift
                                    alpha = if (isDragged) 0.92f else 1f
                                }
                                .pointerInput(item.key) {
                                    awaitEachGesture {
                                        val down = awaitFirstDown(requireUnconsumed = false)
                                        down.consume()
                                        val press = awaitLongPressOrCancellation(down.id)
                                        if (press == null) {
                                            val ev = currentEvent.changes.firstOrNull { it.id == down.id }
                                            if (ev != null && !ev.pressed &&
                                                (ev.position - down.position).getDistance() < viewConfiguration.touchSlop * 2
                                            ) {
                                                if (item.kind == "f") state.openFolder = item.key
                                                else latestApps.firstOrNull { it.key == item.key }?.let { latestTap(it) }
                                            }
                                            return@awaitEachGesture
                                        }
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        dragKey = item.key
                                        dragPos = Offset(item.col * cellW, item.row * cellH)
                                        targetCol = item.col.roundToInt()
                                        targetRow = item.row.roundToInt()
                                        var travelled = 0f
                                        drag(down.id) { change ->
                                            val d = change.positionChange()
                                            travelled += d.getDistance()
                                            dragPos += d
                                            change.consume()
                                            val cx = dragPos.x + cellW / 2f
                                            val cy = dragPos.y + cellH / 2f
                                            val nc = (cx / cellW).toInt().coerceIn(0, GRID_COLS - 1)
                                            val nr = (cy / cellH).toInt().coerceIn(0, state.gridRows - 1)
                                            if (!state.freeIcons && (nc != targetCol || nr != targetRow)) {
                                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                            }
                                            targetCol = nc
                                            targetRow = nr
                                        }
                                        val tc = targetCol
                                        val tr = targetRow
                                        dragKey = null
                                        if (travelled > viewConfiguration.touchSlop * 2) {
                                            if (state.freeIcons) {
                                                state.dropApp(pageIndex, item.key, dragPos.x / cellW, dragPos.y / cellH)
                                            } else if (tc.toFloat() != item.col || tr.toFloat() != item.row) {
                                                state.moveApp(pageIndex, item.key, tc, tr)
                                            }
                                        } else {
                                            if (item.kind == "f") state.openFolder = item.key
                                            else latestApps.firstOrNull { it.key == item.key }?.let { latestMenu(it) }
                                        }
                                    }
                                },
                            contentAlignment = Alignment.Center,
                        ) {
                            if (app != null) {
                                AppIconBody(
                                    app, HomeConfig.iconDp.dp, HomeConfig.showLabels,
                                    HomeConfig.labelSp, HomeConfig.twoLine,
                                )
                            } else {
                                FolderIconBody(
                                    item, apps, HomeConfig.iconDp.dp, HomeConfig.showLabels,
                                    HomeConfig.labelSp, HomeConfig.twoLine,
                                )
                            }
                        }
                    }
                }
            }
        }

        if (editItem != null) WidgetEditLayer(state, widgets, editItem, cellW, cellH, rows)
    }
}
