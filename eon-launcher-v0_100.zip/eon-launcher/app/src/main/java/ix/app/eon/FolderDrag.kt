package ix.app.eon

import androidx.compose.animation.core.animateIntOffsetAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.*
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.math.roundToInt

/**
 * The apps of a folder in a grid you can rearrange: tap opens an app, hold one and it lifts (you feel a buzz), then
 * drag it and the others make room. Lift and let go without moving and you get its menu, as before.
 * [members] is the folder's own list of app keys, so the new order is the folder's order; [onCommit] saves it.
 */
@Composable
fun FolderDragGrid(
    members: SnapshotStateList<String>,
    apps: List<AppEntry>,
    maxHeight: Dp,
    onLaunch: (AppEntry) -> Unit,
    onMenu: (AppEntry) -> Unit,
    onCommit: () -> Unit,
    cols: Int = 4,
    iconDp: Dp = 52.dp,
    rowGap: Dp = 12.dp,
) {
    val density = LocalDensity.current
    val haptic = LocalHapticFeedback.current
    val ordered = members.mapNotNull { k -> apps.firstOrNull { it.key == k } }
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val cellW = maxWidth / cols
        val cellH = iconDp + 24.dp + rowGap
        val rows = ((ordered.size + cols - 1) / cols).coerceAtLeast(1)
        val wPx = with(density) { cellW.toPx() }
        val hPx = with(density) { cellH.toPx() }
        var dragKey by remember { mutableStateOf<String?>(null) }
        var dragPos by remember { mutableStateOf(Offset.Zero) }
        Box(Modifier.heightIn(max = maxHeight).verticalScroll(rememberScrollState())) {
            Box(Modifier.fillMaxWidth().height(cellH * rows)) {
                ordered.forEachIndexed { i, app ->
                    key(app.key) {
                        val slot = IntOffset(((i % cols) * wPx).roundToInt(), ((i / cols) * hPx).roundToInt())
                        val settled by animateIntOffsetAsState(slot, spring(dampingRatio = 0.8f, stiffness = 520f), label = "dslot")
                        val lifted = dragKey == app.key
                        Box(
                            Modifier
                                .offset { if (lifted) IntOffset(dragPos.x.roundToInt(), dragPos.y.roundToInt()) else settled }
                                .size(cellW, cellH)
                                .zIndex(if (lifted) 1f else 0f)
                                .graphicsLayer {
                                    val s = if (lifted) 1.1f else 1f
                                    scaleX = s
                                    scaleY = s
                                    alpha = if (lifted) 0.94f else 1f
                                }
                                .pointerInput(app.key, cols, wPx, hPx) {
                                    awaitEachGesture {
                                        val down = awaitFirstDown(requireUnconsumed = false)
                                        val slop = viewConfiguration.touchSlop
                                        // A quick lift is a tap, a swipe is a scroll, and holding still is a long press.
                                        var tap = false
                                        val still = withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
                                            while (true) {
                                                val ev = awaitPointerEvent()
                                                val ch = ev.changes.firstOrNull { it.id == down.id }
                                                if (ch == null || ch.isConsumed) return@withTimeoutOrNull false
                                                if (!ch.pressed) { tap = true; return@withTimeoutOrNull false }
                                                if ((ch.position - down.position).getDistance() > slop) return@withTimeoutOrNull false
                                            }
                                        }
                                        if (still != null) {
                                            if (tap) onLaunch(app)
                                            return@awaitEachGesture
                                        }
                                        // Long press: the app lifts.
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        val start = members.indexOf(app.key).coerceAtLeast(0)
                                        dragPos = Offset((start % cols) * wPx, (start / cols) * hPx)
                                        dragKey = app.key
                                        var total = Offset.Zero
                                        var moved = false
                                        while (true) {
                                            val ev = awaitPointerEvent()
                                            val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                                            ch.consume()
                                            if (!ch.pressed) break
                                            val d = ch.positionChange()
                                            total += d
                                            if (!moved && total.getDistance() > slop) moved = true
                                            if (moved) {
                                                dragPos += d
                                                val cx = (dragPos.x + wPx / 2f) / wPx
                                                val cy = (dragPos.y + hPx / 2f) / hPx
                                                val n = members.size
                                                val target = (cy.toInt().coerceAtLeast(0) * cols + cx.toInt().coerceIn(0, cols - 1))
                                                    .coerceIn(0, n - 1)
                                                val cur = members.indexOf(app.key)
                                                if (cur >= 0 && target != cur) {
                                                    members.add(target, members.removeAt(cur))
                                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                                }
                                            }
                                        }
                                        dragKey = null
                                        if (moved) onCommit() else onMenu(app)
                                    }
                                },
                            contentAlignment = Alignment.TopCenter,
                        ) {
                            AppIconBody(app, iconDp, true)
                        }
                    }
                }
            }
        }
    }
}
