package ix.app.eon

import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import kotlin.math.abs
import kotlin.math.roundToInt

val LocalLook = compositionLocalOf { "glassy" }

/** Columns in the home grid (set in Grid properties). */
val GRID_COLS: Int get() = HomeConfig.cols

/**
 * Something placed on a home page: an app ("a") or a widget ("w"). Position and size are in grid cells.
 * Apps always sit on whole cells; widgets can sit anywhere (steps of 0.05 cell) and overlap, in which
 * case the higher [z] is drawn on top.
 */
class Item(val kind: String, val key: String, col: Float, row: Float, w: Float, h: Float, z: Int = 0) {
    var col by mutableStateOf(col)
    var row by mutableStateOf(row)
    var w by mutableStateOf(w)
    var h by mutableStateOf(h)
    var z by mutableStateOf(z)
}

/** Smallest a widget can be made, in cells. */
const val MIN_SIZE = 0.5f

/** Rounds to a whole cell when snapping, otherwise to steps of 0.05 cell (with a pull towards whole cells). */
fun snapValue(v: Float, snap: Boolean): Float {
    val whole = v.roundToInt().toFloat()
    if (snap) return whole
    // Free: steps of 0.05, but it clicks onto a whole cell when you are close, which makes lining things up easy.
    return if (abs(v - whole) < 0.08f) whole else (v * 20f).roundToInt() / 20f
}

/** 2 -> "2", 1.5 -> "1.50" */
fun cellText(v: Float): String =
    if (v == v.toInt().toFloat()) v.toInt().toString() else String.format(java.util.Locale.US, "%.2f", v)

/** One home page. The legacy lists only hold data from versions before v0.9 until it is migrated. */
class PageData(
    var legacyPinned: List<String> = emptyList(),
    var legacyWidgets: List<Int> = emptyList(),
) {
    val items = mutableStateListOf<Item>()
}

private fun JSONArray.strings(): List<String> = (0 until length()).map { getString(it) }
private fun JSONArray.ints(): List<Int> = (0 until length()).map { getInt(it) }

/** Everything the user can change, kept in memory and saved to [Prefs]. */
class EonState(private val prefs: Prefs) {
    // Must come first: loading the pages below needs the grid size.
    init {
        HomeConfig.load(prefs)
        WallpaperConfig.load(prefs)
    }

    var look by mutableStateOf(prefs.look)
        private set
    val pages = mutableStateListOf<PageData>().also { it.addAll(loadPages()) }

    /** The dock's pages. Apps here sit on whole cells of the dock's own grid (columns and rows from the Dock settings). */
    val dock = mutableStateListOf<PageData>().also { it.addAll(loadDock()) }

    init {
        refitDock()
    }
    var currentPage by mutableIntStateOf(0)
    /** Size of the area the grid fills, and the height of one row when rows are automatic. */
    private var areaHeightPx by mutableStateOf(1500f)
    private var autoCellPx by mutableStateOf(250f)

    /** Rows in the grid: the chosen number, or as many as fit when set to automatic. */
    val gridRows: Int
        get() = if (HomeConfig.rowsSetting > 0) HomeConfig.rowsSetting else maxOf(1, (areaHeightPx / autoCellPx).toInt())

    /** Height of one grid row in pixels. With a chosen number of rows the grid stretches to fill the area. */
    val cellHeightPx: Float
        get() = if (HomeConfig.rowsSetting > 0) areaHeightPx / HomeConfig.rowsSetting else autoCellPx

    /** Set when a setting that changes the grid's room was changed; the items are re-fitted once the new size is known. */
    private var pendingRefit = false

    fun setArea(heightPx: Float, autoCell: Float) {
        areaHeightPx = heightPx
        autoCellPx = autoCell
        if (pendingRefit && heightPx > autoCell * 2f) {
            pendingRefit = false
            refitItems()
        }
    }

    fun saveHome() {
        HomeConfig.save(prefs)
        pendingRefit = true
    }

    /** Call after changing any wallpaper setting. */
    fun saveWallpaper() {
        WallpaperConfig.save(prefs)
    }

    /** Call after changing a Dock setting. */
    fun dockChanged() {
        saveHome()
        refitDock()
    }

    // ---- dock
    private fun loadDock(): List<PageData> {
        val raw = prefs.getString("dockJson")
        if (raw.isBlank()) return listOf(PageData())
        return try {
            val arr = JSONObject(raw).getJSONArray("pages")
            (0 until arr.length()).map { i ->
                val page = PageData()
                val items = arr.getJSONObject(i).getJSONArray("items")
                for (j in 0 until items.length()) {
                    val o = items.getJSONObject(j)
                    page.items.add(Item("a", o.getString("k"), o.getInt("c").toFloat(), o.getInt("r").toFloat(), 1f, 1f))
                }
                page
            }.ifEmpty { listOf(PageData()) }
        } catch (_: Exception) {
            listOf(PageData())
        }
    }

    private fun saveDock() {
        val pagesArr = JSONArray()
        dock.forEach { p ->
            val items = JSONArray()
            p.items.forEach { i ->
                items.put(JSONObject().put("k", i.key).put("c", i.col.roundToInt()).put("r", i.row.roundToInt()))
            }
            pagesArr.put(JSONObject().put("items", items))
        }
        prefs.putString("dockJson", JSONObject().put("pages", pagesArr).toString())
    }

    fun isInDock(key: String): Boolean = dock.any { p -> p.items.any { it.key == key } }

    /** First empty dock cell as (page, column, row), or null when the dock is full. */
    private fun dockFreeSpot(): Triple<Int, Int, Int>? {
        for (pi in dock.indices) {
            for (r in 0 until HomeConfig.dockRows) {
                for (c in 0 until HomeConfig.dockCols) {
                    if (dock[pi].items.none { it.col.roundToInt() == c && it.row.roundToInt() == r }) return Triple(pi, c, r)
                }
            }
        }
        return null
    }

    /** Takes an app off the home pages and puts it in the dock. Returns false (and changes nothing) if the dock is full. */
    fun moveToDock(key: String): Boolean {
        if (isInDock(key)) return true
        val spot = dockFreeSpot() ?: return false
        var changedHome = false
        pages.forEach { p -> if (p.items.removeAll { it.kind == "a" && it.key == key }) changedHome = true }
        dock[spot.first].items.add(Item("a", key, spot.second.toFloat(), spot.third.toFloat(), 1f, 1f))
        if (changedHome) savePages()
        saveDock()
        return true
    }

    fun removeFromDock(key: String) {
        dock.forEach { p -> p.items.removeAll { it.key == key } }
        saveDock()
    }

    /** Takes an app out of the dock and onto the current home page. Returns false if that page has no free cell. */
    fun dockToHome(key: String): Boolean {
        val page = pages.getOrNull(currentPage) ?: return false
        if (!place(page, "a", key, 1, 1)) return false
        removeFromDock(key)
        savePages()
        return true
    }

    /** Dragging inside the dock: moves to the cell if it is free, otherwise swaps with the icon there. */
    fun moveDockApp(pageIndex: Int, key: String, col: Int, row: Int) {
        val page = dock.getOrNull(pageIndex) ?: return
        val me = page.items.firstOrNull { it.key == key } ?: return
        val c = col.coerceIn(0, HomeConfig.dockCols - 1)
        val r = row.coerceIn(0, HomeConfig.dockRows - 1)
        val other = page.items.firstOrNull { it !== me && it.col.roundToInt() == c && it.row.roundToInt() == r }
        if (other != null) {
            other.col = me.col
            other.row = me.row
        }
        me.col = c.toFloat()
        me.row = r.toFloat()
        saveDock()
    }

    /** After the Dock settings change: matches the number of pages and moves icons that no longer fit into free cells. */
    fun refitDock() {
        val cols = HomeConfig.dockCols
        val rows = HomeConfig.dockRows
        val n = maxOf(1, HomeConfig.dockPages)
        val loose = mutableListOf<String>()
        while (dock.size > n) dock.removeAt(dock.size - 1).items.forEach { loose.add(it.key) }
        while (dock.size < n) dock.add(PageData())
        dock.forEach { p ->
            val out = p.items.filter { it.col.roundToInt() >= cols || it.row.roundToInt() >= rows }
            if (out.isNotEmpty()) {
                out.forEach { loose.add(it.key) }
                p.items.removeAll(out)
            }
        }
        loose.forEach { k ->
            val spot = dockFreeSpot()
            if (spot != null) dock[spot.first].items.add(Item("a", k, spot.second.toFloat(), spot.third.toFloat(), 1f, 1f))
        }
        saveDock()
    }

    fun chooseCols(n: Int) {
        HomeConfig.cols = n.coerceIn(3, 8)
        saveHome()
        refitItems()
    }

    /** 0 = automatic. */
    fun chooseRows(n: Int) {
        HomeConfig.rowsSetting = if (n <= 0) 0 else n.coerceIn(3, 14)
        saveHome()
        refitItems()
    }

    fun choosePreset(cols: Int, rows: Int) {
        HomeConfig.cols = cols
        HomeConfig.rowsSetting = rows
        saveHome()
        refitItems()
    }

    /** After the grid changes size: pulls widgets back inside it and moves apps that no longer fit to the nearest free cell. */
    fun refitItems() {
        val cols = GRID_COLS
        val rows = maxOf(gridRows, 1)
        pages.forEach { p ->
            p.items.filter { it.kind == "w" }.forEach {
                val w = it.w.coerceIn(MIN_SIZE, cols.toFloat())
                val h = it.h.coerceIn(MIN_SIZE, rows.toFloat())
                it.w = w
                it.h = h
                it.col = it.col.coerceIn(0f, cols - w)
                it.row = it.row.coerceIn(0f, rows - h)
            }
            if (freeIcons) {
                p.items.filter { it.kind == "a" }.forEach {
                    it.col = it.col.coerceIn(0f, cols - 1f)
                    it.row = it.row.coerceIn(0f, rows - 1f)
                }
            }
        }
        if (!freeIcons) snapAppsToGrid() else savePages()
    }
    val hidden = mutableStateListOf<String>().also { it.addAll(prefs.hidden) }
    val overrides = mutableStateMapOf<String, String>().also { it.putAll(prefs.overrides) }

    // ---- saving and loading
    private fun loadPages(): List<PageData> {
        val raw = prefs.pagesJson
        if (raw.isBlank()) return listOf(PageData(prefs.pinned, prefs.widgets))
        return try {
            val root = JSONTokener(raw).nextValue()
            if (root is JSONObject) {
                val arr = root.getJSONArray("pages")
                (0 until arr.length()).map { i ->
                    val page = PageData()
                    val items = arr.getJSONObject(i).getJSONArray("items")
                    for (j in 0 until items.length()) {
                        val o = items.getJSONObject(j)
                        page.items.add(
                            Item(
                                o.getString("t"), o.getString("k"),
                                o.getDouble("c").toFloat(), o.getDouble("r").toFloat(),
                                o.getDouble("w").toFloat(), o.getDouble("h").toFloat(),
                                o.optInt("z", 0),
                            ),
                        )
                    }
                    page
                }.ifEmpty { listOf(PageData()) }
            } else {
                // v0.5 to v0.8 format: plain lists per page
                val arr = root as JSONArray
                (0 until arr.length()).map { i ->
                    val o = arr.getJSONObject(i)
                    PageData(o.getJSONArray("pinned").strings(), o.getJSONArray("widgets").ints())
                }.ifEmpty { listOf(PageData()) }
            }
        } catch (_: Exception) {
            listOf(PageData(prefs.pinned, prefs.widgets))
        }
    }

    private fun savePages() {
        val pagesArr = JSONArray()
        pages.forEach { p ->
            val items = JSONArray()
            p.items.forEach { i ->
                items.put(
                    JSONObject().put("t", i.kind).put("k", i.key)
                        .put("c", i.col.toDouble()).put("r", i.row.toDouble()).put("w", i.w.toDouble()).put("h", i.h.toDouble())
                        .put("z", i.z),
                )
            }
            pagesArr.put(JSONObject().put("items", items))
        }
        prefs.pagesJson = JSONObject().put("v", 2).put("pages", pagesArr).toString()
    }

    /** Moves data from older versions onto the grid: widgets first, then apps, in the order they had. */
    fun migrate(sizeOf: (Int) -> Pair<Int, Int>) {
        var changed = false
        pages.forEach { p ->
            if (p.legacyWidgets.isNotEmpty() || p.legacyPinned.isNotEmpty()) {
                changed = true
                p.legacyWidgets.forEach { id ->
                    val (w, h) = sizeOf(id)
                    place(p, "w", id.toString(), w, h, 20)
                }
                p.legacyPinned.forEach { k -> place(p, "a", k, 1, 1, 20) }
                p.legacyWidgets = emptyList()
                p.legacyPinned = emptyList()
            }
        }
        if (changed) savePages()
    }

    fun chooseLook(value: String) {
        look = value
        prefs.look = value
    }

    /** Whether snapping to whole cells is on while editing widgets. */
    var snapToGrid by mutableStateOf(prefs.snapToGrid)
        private set

    fun chooseSnap(on: Boolean) {
        snapToGrid = on
        prefs.snapToGrid = on
    }

    /** True when app icons can be placed anywhere; false when they sit on grid cells. */
    var freeIcons by mutableStateOf(prefs.freeIcons)
        private set

    fun chooseFreeIcons(on: Boolean) {
        freeIcons = on
        prefs.freeIcons = on
        if (!on) snapAppsToGrid()
    }

    /** The search pill's centre as a share of the grid's width and height. searchY < 0 means the default spot. */
    var searchX by mutableStateOf(prefs.searchX)
        private set
    var searchY by mutableStateOf(prefs.searchY)
        private set
    var searchHidden by mutableStateOf(prefs.searchHidden)
        private set

    fun setSearchPos(x: Float, y: Float) {
        searchX = x
        searchY = y
    }

    fun commitSearch() {
        prefs.searchX = searchX
        prefs.searchY = searchY
    }

    fun resetSearch() {
        searchX = 0.5f
        searchY = -1f
        commitSearch()
    }

    fun chooseSearchHidden(hidden: Boolean) {
        searchHidden = hidden
        prefs.searchHidden = hidden
    }

    /** Key of what is being edited on the home screen (a widget's key, or "search" for the search pill), or null. */
    var editing by mutableStateOf<String?>(null)

    // ---- grid helpers
    private fun fits(p: PageData, c: Float, r: Float, w: Float, h: Float, rows: Int, ignore: Item? = null): Boolean {
        val e = 0.001f
        if (c < -e || r < -e || w < MIN_SIZE - e || h < MIN_SIZE - e || c + w > GRID_COLS + e || r + h > rows + e) return false
        return p.items.none {
            it !== ignore && c < it.col + it.w - e && c + w > it.col + e && r < it.row + it.h - e && r + h > it.row + e
        }
    }

    private fun firstFree(p: PageData, w: Int, h: Int, rows: Int): Pair<Int, Int>? {
        for (r in 0..(rows - h)) {
            for (c in 0..(GRID_COLS - w)) {
                if (fits(p, c.toFloat(), r.toFloat(), w.toFloat(), h.toFloat(), rows)) return c to r
            }
        }
        return null
    }

    private fun place(p: PageData, kind: String, key: String, w: Int, h: Int, rows: Int = gridRows): Boolean {
        val spot = firstFree(p, w, h, rows) ?: return false
        p.items.add(Item(kind, key, spot.first.toFloat(), spot.second.toFloat(), w.toFloat(), h.toFloat()))
        return true
    }

    // ---- apps on pages
    fun isPinned(key: String): Boolean = pages.any { p -> p.items.any { it.kind == "a" && it.key == key } }

    /** Pins or unpins an app. Returns false when there is no free cell on the current page. */
    fun togglePin(key: String): Boolean {
        val holder = pages.firstOrNull { p -> p.items.any { it.kind == "a" && it.key == key } }
        if (holder != null) {
            holder.items.removeAll { it.kind == "a" && it.key == key }
            savePages()
            return true
        }
        val page = pages.getOrNull(currentPage) ?: return false
        val ok = place(page, "a", key, 1, 1)
        if (ok) savePages()
        return ok
    }

    /** Drops an app on a cell: moves it if the cell is free, swaps with another app, ignores widgets. */
    fun moveApp(pageIndex: Int, key: String, col: Int, row: Int) {
        val page = pages.getOrNull(pageIndex) ?: return
        val me = page.items.firstOrNull { it.kind == "a" && it.key == key } ?: return
        val cx = col + 0.5f
        val cy = row + 0.5f
        val other = page.items.firstOrNull {
            it !== me && cx >= it.col && cx < it.col + it.w && cy >= it.row && cy < it.row + it.h
        }
        when {
            other == null -> {
                me.col = col.toFloat()
                me.row = row.toFloat()
            }
            other.kind == "a" -> {
                other.col = me.col
                other.row = me.row
                me.col = col.toFloat()
                me.row = row.toFloat()
            }
            else -> return
        }
        savePages()
    }

    /** Free placement: drops an app at an exact spot. Ignored if it would land on top of another app. */
    fun dropApp(pageIndex: Int, key: String, col: Float, row: Float) {
        val page = pages.getOrNull(pageIndex) ?: return
        val me = page.items.firstOrNull { it.kind == "a" && it.key == key } ?: return
        val c = snapValue(col.coerceIn(0f, GRID_COLS - 1f), false)
        val r = snapValue(row.coerceIn(0f, maxOf(gridRows, 1) - 1f), false)
        val crowded = page.items.any { it !== me && it.kind == "a" && abs(it.col - c) < 0.6f && abs(it.row - r) < 0.6f }
        if (crowded) return
        me.col = c
        me.row = r
        savePages()
    }

    /** Back to grid placement: every app goes to the nearest free cell. */
    private fun snapAppsToGrid() {
        val rows = maxOf(gridRows, 1)
        pages.forEach { p ->
            p.items.filter { it.kind == "a" }.forEach { me ->
                val tc = me.col.roundToInt().coerceIn(0, GRID_COLS - 1)
                val tr = me.row.roundToInt().coerceIn(0, rows - 1)
                if (fits(p, tc.toFloat(), tr.toFloat(), 1f, 1f, rows, me)) {
                    me.col = tc.toFloat()
                    me.row = tr.toFloat()
                } else {
                    var best: Pair<Int, Int>? = null
                    var bestD = Int.MAX_VALUE
                    for (r in 0 until rows) {
                        for (c in 0 until GRID_COLS) {
                            if (fits(p, c.toFloat(), r.toFloat(), 1f, 1f, rows, me)) {
                                val d = (c - tc) * (c - tc) + (r - tr) * (r - tr)
                                if (d < bestD) {
                                    bestD = d
                                    best = c to r
                                }
                            }
                        }
                    }
                    best?.let {
                        me.col = it.first.toFloat()
                        me.row = it.second.toFloat()
                    }
                }
            }
        }
        savePages()
    }

    // ---- widgets
    fun widgetItems(): List<Item> = pages.getOrNull(currentPage)?.items?.filter { it.kind == "w" } ?: emptyList()

    fun allWidgets(): List<Int> =
        pages.flatMap { p -> p.items.filter { it.kind == "w" }.mapNotNull { it.key.toIntOrNull() } }

    /** Returns false when the current page has no room for a widget of this size. */
    fun addWidget(id: Int, w: Int, h: Int): Boolean {
        val page = pages.getOrNull(currentPage) ?: return false
        if (page.items.any { it.kind == "w" && it.key == id.toString() }) return true
        val ok = place(page, "w", id.toString(), w, h)
        if (ok) savePages()
        return ok
    }

    fun removeWidget(id: Int) {
        pages.forEach { p -> p.items.removeAll { it.kind == "w" && it.key == id.toString() } }
        savePages()
    }

    fun nudgeWidget(key: String, dc: Int, dr: Int) {
        val p = pages.getOrNull(currentPage) ?: return
        val it = p.items.firstOrNull { x -> x.kind == "w" && x.key == key } ?: return
        if (fits(p, it.col + dc, it.row + dr, it.w, it.h, gridRows, it)) {
            it.col += dc
            it.row += dr
            savePages()
        }
    }

    fun resizeWidget(key: String, dw: Int, dh: Int) {
        val p = pages.getOrNull(currentPage) ?: return
        val it = p.items.firstOrNull { x -> x.kind == "w" && x.key == key } ?: return
        val w = (it.w + dw).coerceIn(1f, GRID_COLS.toFloat())
        val h = (it.h + dh).coerceIn(1f, 4f)
        if (fits(p, it.col, it.row, w, h, gridRows, it)) {
            it.w = w
            it.h = h
            savePages()
        }
    }

    /** Sets a widget's position and size in cells, keeping it inside the page. */
    fun setRect(item: Item, col: Float, row: Float, w: Float, h: Float) {
        val ww = w.coerceIn(MIN_SIZE, GRID_COLS.toFloat())
        val hh = h.coerceIn(MIN_SIZE, maxOf(gridRows, 1).toFloat())
        item.w = ww
        item.h = hh
        item.col = col.coerceIn(0f, GRID_COLS - ww)
        item.row = row.coerceIn(0f, maxOf(gridRows, 1) - hh)
    }

    /** Draw order of overlapping items: higher is on top. */
    fun raise(item: Item, by: Int) {
        item.z = (item.z + by).coerceIn(-99, 99)
        savePages()
    }

    /** Saves after a drag or a button press while editing. */
    fun commitLayout() = savePages()

    // ---- pages
    fun addPage(index: Int) {
        pages.add(index.coerceIn(0, pages.size), PageData())
        savePages()
    }

    fun removePage(index: Int) {
        if (pages.size > 1 && index in pages.indices && pages[index].items.isEmpty()) {
            pages.removeAt(index)
            savePages()
        }
    }

    // ---- hidden apps and categories
    fun hide(pkg: String) {
        if (pkg !in hidden) hidden.add(pkg)
        prefs.hidden = hidden.toSet()
    }

    fun showAllApps() {
        hidden.clear()
        prefs.hidden = emptySet()
    }

    fun setCategory(pkg: String, category: String) {
        overrides[pkg] = category
        prefs.overrides = overrides.toMap()
    }
}
