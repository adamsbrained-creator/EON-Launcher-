package ix.app.eon

import android.app.WallpaperManager
import android.graphics.Canvas
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.Choreographer
import android.view.MotionEvent
import android.view.SurfaceHolder
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.CanvasDrawScope
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.min

/**
 * Eon's live wallpaper. Set it from Settings > Wallpaper and the same moving picture (with the same settings
 * and effects) shows on the home screen and the lock screen, not just inside Eon.
 */
class GyroWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = GyroEngine()

    private inner class GyroEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private val choreographer = Choreographer.getInstance()
        private val tilt = TiltState()
        private val fx = WallpaperFx()
        private val drawScope = CanvasDrawScope()
        private val density = resources.displayMetrics.density

        private var width = 0
        private var height = 0
        private var shown = false

        private var image: ImageBitmap? = null
        private var previous: ImageBitmap? = null
        private var progress = 1f
        private var loadedFile = ""
        private var loadedQuality = -1
        private var loadedW = 0
        private var loadedH = 0
        private var loading = false

        // Where the home screen says the pages are (0..1); 0.5 when nobody says, as on the lock screen.
        private var xOffset = 0.5f
        private var smoothX = 0.5f
        private var lastNanos = 0L
        private var lastSig = 0

        private val frame = Choreographer.FrameCallback { nanos -> onFrame(nanos) }
        private val wake = Runnable { choreographer.postFrameCallback(frame) }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            WallpaperConfig.ensureLoaded(Prefs(this@GyroWallpaperService))
            setTouchEventsEnabled(true)
        }

        override fun onDestroy() {
            shown = false
            stopFrames()
            tilt.stop()
            super.onDestroy()
        }

        override fun onVisibilityChanged(visible: Boolean) {
            shown = visible
            if (visible) {
                val saver = isPowerSave(this@GyroWallpaperService)
                if (!(WallpaperConfig.powerSaver && saver)) tilt.start(this@GyroWallpaperService)
                lastNanos = 0L
                lastSig = 0
                ensureImage()
                scheduleFrame()
            } else {
                stopFrames()
                tilt.stop()
            }
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            this.width = width
            this.height = height
            lastSig = 0
            ensureImage()
            if (shown) scheduleFrame()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            shown = false
            stopFrames()
            tilt.stop()
            super.onSurfaceDestroyed(holder)
        }

        override fun onOffsetsChanged(
            xOffset: Float, yOffset: Float, xOffsetStep: Float, yOffsetStep: Float, xPixelOffset: Int, yPixelOffset: Int,
        ) {
            this.xOffset = xOffset.coerceIn(0f, 1f)
        }

        override fun onTouchEvent(event: MotionEvent) {
            if (event.actionMasked == MotionEvent.ACTION_DOWN) fx.touch(event.x, event.y)
            super.onTouchEvent(event)
        }

        // The home screen reports taps here (Eon does), which is how Ripple starts under your finger.
        override fun onCommand(action: String?, x: Int, y: Int, z: Int, extras: Bundle?, resultRequested: Boolean): Bundle? {
            if (action == WallpaperManager.COMMAND_TAP) fx.touch(x.toFloat(), y.toFloat())
            return super.onCommand(action, x, y, z, extras, resultRequested)
        }

        private fun scheduleFrame() {
            stopFrames()
            if (shown) choreographer.postFrameCallback(frame)
        }

        private fun stopFrames() {
            handler.removeCallbacks(wake)
            choreographer.removeFrameCallback(frame)
        }

        /** Loads the picture on a background thread when the file, quality or screen size changed. */
        private fun ensureImage() {
            val file = WallpaperConfig.current
            val quality = WallpaperConfig.quality
            if (file.isBlank() || width == 0 || height == 0 || loading) return
            if (file == loadedFile && quality == loadedQuality && width == loadedW && height == loadedH) return
            loading = true
            val w = width
            val h = height
            val ctx = this@GyroWallpaperService
            thread {
                val bmp = WallpaperStore.load(ctx, file, w, h, quality)
                handler.post {
                    loading = false
                    loadedFile = file
                    loadedQuality = quality
                    loadedW = w
                    loadedH = h
                    if (bmp != null) {
                        previous = image
                        image = bmp.asImageBitmap()
                        progress = if (previous != null) 0f else 1f
                    }
                    lastSig = 0
                    if (shown) scheduleFrame()
                }
            }
        }

        /** Changes whenever a setting that alters how the picture looks changes, so a still wallpaper redraws. */
        private fun signature(): Int = arrayOf<Any>(
            WallpaperConfig.current, WallpaperConfig.mode, WallpaperConfig.range, WallpaperConfig.dim,
            WallpaperConfig.invert, WallpaperConfig.scrolling, WallpaperConfig.fxOn,
        ).contentHashCode()

        private fun onFrame(nanos: Long) {
            if (!shown) return
            ensureImage()
            val dt = if (lastNanos == 0L) 0.016f else ((nanos - lastNanos) / 1_000_000_000f).coerceIn(0.001f, 0.1f)
            lastNanos = nanos
            val moving = tilt.step(dt, WallpaperConfig.speed)
            fx.step(dt, width.toFloat(), height.toFloat())
            smoothX += (xOffset - smoothX) * (1f - exp(-dt / 0.12f))
            val sliding = abs(xOffset - smoothX) > 0.001f
            var changing = false
            if (progress < 1f) {
                progress = min(1f, progress + dt * WallpaperConfig.animSpeed / 0.6f)
                if (progress >= 1f) previous = null else changing = true
            }
            val sig = signature()
            val busy = moving || sliding || changing || fx.running
            if (busy || sig != lastSig) {
                draw()
                lastSig = sig
            }
            // Nothing is moving: check again in a moment instead of every frame.
            if (busy) choreographer.postFrameCallback(frame) else handler.postDelayed(wake, 80)
        }

        private fun draw() {
            if (width == 0 || height == 0) return
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                // A hardware canvas is needed because the picture is a hardware bitmap.
                canvas = holder.lockHardwareCanvas() ?: return
                val target = androidx.compose.ui.graphics.Canvas(canvas)
                drawScope.draw(Density(density), LayoutDirection.Ltr, target, Size(width.toFloat(), height.toFloat())) {
                    drawWallpaperFrame(image, previous, progress, tilt.outX, tilt.outY, smoothX, 2, fx, density)
                }
            } catch (e: Exception) {
                // The surface went away mid-frame; the next frame will try again.
            } finally {
                if (canvas != null) {
                    try {
                        holder.unlockCanvasAndPost(canvas)
                    } catch (e: Exception) {
                    }
                }
            }
        }
    }
}
