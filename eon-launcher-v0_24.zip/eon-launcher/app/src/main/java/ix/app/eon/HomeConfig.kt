package ix.app.eon

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * The home screen's grid and icon settings. Everything here is Compose state, so changing a value
 * (for example in Grid properties) updates the home screen behind it straight away.
 */
object HomeConfig {
    /** Columns in the grid. */
    var cols by mutableIntStateOf(4)

    /** Rows in the grid; 0 means automatic (as many rows as fit). */
    var rowsSetting by mutableIntStateOf(0)

    /** Size of icons on the home screen, in dp. */
    var iconDp by mutableIntStateOf(60)

    var showLabels by mutableStateOf(true)
    var labelSp by mutableStateOf(12f)
    var twoLine by mutableStateOf(false)

    var customPad by mutableStateOf(false)
    var padSide by mutableIntStateOf(16)
    var padTop by mutableIntStateOf(8)
    var padBottom by mutableIntStateOf(0)

    /** The dock at the bottom of the home screen. */
    var dockOn by mutableStateOf(false)
    var dockCols by mutableIntStateOf(4)
    var dockRows by mutableIntStateOf(1)
    var dockIconDp by mutableIntStateOf(60)
    var dockPages by mutableIntStateOf(1)
    var dockLabels by mutableStateOf(false)

    /** The page dots at the bottom. */
    var indicator by mutableStateOf(true)

    val sidePad: Int get() = if (customPad) padSide else 16
    val topPad: Int get() = if (customPad) padTop else 8
    val bottomPad: Int get() = if (customPad) padBottom else 0

    fun load(p: Prefs) {
        cols = p.getInt("gridCols", 4)
        rowsSetting = p.getInt("gridRows", 0)
        iconDp = p.getInt("homeIcon", 60)
        showLabels = p.getBool("homeLabels", true)
        labelSp = p.getFloat("labelSp", 12f)
        twoLine = p.getBool("twoLine", false)
        customPad = p.getBool("customPad", false)
        padSide = p.getInt("padSide", 16)
        padTop = p.getInt("padTop", 8)
        padBottom = p.getInt("padBottom", 0)
        indicator = p.getBool("indicator", true)
        dockOn = p.getBool("dockOn", false)
        dockCols = p.getInt("dockCols", 4)
        dockRows = p.getInt("dockRows", 1)
        dockIconDp = p.getInt("dockIcon", 60)
        dockPages = p.getInt("dockPages", 1)
        dockLabels = p.getBool("dockLabels", false)
    }

    fun save(p: Prefs) {
        p.putInt("gridCols", cols)
        p.putInt("gridRows", rowsSetting)
        p.putInt("homeIcon", iconDp)
        p.putBool("homeLabels", showLabels)
        p.putFloat("labelSp", labelSp)
        p.putBool("twoLine", twoLine)
        p.putBool("customPad", customPad)
        p.putInt("padSide", padSide)
        p.putInt("padTop", padTop)
        p.putInt("padBottom", padBottom)
        p.putBool("indicator", indicator)
        p.putBool("dockOn", dockOn)
        p.putInt("dockCols", dockCols)
        p.putInt("dockRows", dockRows)
        p.putInt("dockIcon", dockIconDp)
        p.putInt("dockPages", dockPages)
        p.putBool("dockLabels", dockLabels)
    }
}
