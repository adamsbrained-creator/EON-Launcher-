package ix.app.eon

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Settings for the gyro wallpaper: a picture drawn behind the home screen that moves as you tilt the phone.
 * Everything is Compose state, so changing a value updates the wallpaper straight away.
 */
object WallpaperConfig {
    const val MODE_HORIZONTAL = 0
    const val MODE_VERTICAL = 1
    const val MODE_BOTH = 2

    const val QUALITY_HIGH = 0
    const val QUALITY_STANDARD = 1
    const val QUALITY_LOW = 2

    const val TRANSITION_FADE = 0
    const val TRANSITION_DISSOLVE = 1
    const val TRANSITION_PIXELATE = 2
    const val TRANSITION_WIPE = 3
    const val TRANSITION_BLUR = 4
    const val TRANSITION_ZOOM = 5

    val ANIM_SPEEDS = floatArrayOf(0.25f, 0.5f, 1f, 2f, 3f, 4f)
    val ANIM_SPEED_LABELS = listOf("0.25x", "0.5x", "1x", "2x", "3x", "4x")

    const val FX_RAIN = 0
    const val FX_RIPPLE = 1
    const val FX_SNOW = 2

    /** Off means Eon shows the normal system wallpaper, as before. */
    var enabled by mutableStateOf(false)

    /** File name (inside the wallpapers folder) of the picture in use. */
    var current by mutableStateOf("")

    var mode by mutableIntStateOf(MODE_BOTH)

    /** 0..1: how far the picture may travel. */
    var range by mutableFloatStateOf(0.5f)

    /** 0..1: how quickly the picture follows the phone. */
    var speed by mutableFloatStateOf(0.5f)
    var invert by mutableStateOf(false)

    /** Also shift the picture when you swipe between home pages. */
    var scrolling by mutableStateOf(true)

    /** Stop reading the motion sensor while the phone is in battery saver. */
    var powerSaver by mutableStateOf(true)

    /** 0..0.6: how much the picture is darkened. */
    var dim by mutableFloatStateOf(0.15f)
    var quality by mutableIntStateOf(QUALITY_HIGH)

    /** How the picture changes when you pick another one. */
    var transition by mutableIntStateOf(TRANSITION_FADE)

    /** Index into [ANIM_SPEEDS]: speeds up or slows down all effects and transitions. */
    var animSpeedIdx by mutableIntStateOf(2)
    val animSpeed: Float get() = ANIM_SPEEDS[animSpeedIdx.coerceIn(0, ANIM_SPEEDS.size - 1)]

    // Overlay effects. All sliders are 0..1.
    var fxOn by mutableStateOf(false)
    var fxType by mutableIntStateOf(FX_RAIN)

    var rainIntensity by mutableFloatStateOf(0.5f)
    var rainSpeed by mutableFloatStateOf(0.5f)
    var rainBrightness by mutableFloatStateOf(0.35f)
    var rainStreaks by mutableStateOf(true)
    var rainDrops by mutableStateOf(true)
    var dropAmount by mutableFloatStateOf(0.5f)
    var dropSize by mutableFloatStateOf(0.6f)
    var dropSpeed by mutableFloatStateOf(0.4f)
    var lightning by mutableStateOf(false)

    var rippleTouchOnly by mutableStateOf(false)
    var rippleRainLines by mutableStateOf(false)
    var rippleSpeed by mutableFloatStateOf(0.3f)
    var rippleSize by mutableFloatStateOf(0.7f)
    var rippleStrength by mutableFloatStateOf(0.45f)

    var snowSpeed by mutableFloatStateOf(0.25f)
    var snowDensity by mutableFloatStateOf(0.35f)
    var snowSize by mutableFloatStateOf(0.55f)
    var snowOpacity by mutableFloatStateOf(0.7f)

    /** True when there is a picture to show and the switch is on. */
    val active: Boolean get() = enabled && current.isNotBlank()

    private var loaded = false

    /** For the live wallpaper, which can start before the launcher screen has loaded anything. */
    fun ensureLoaded(p: Prefs) {
        if (!loaded) load(p)
    }

    fun load(p: Prefs) {
        loaded = true
        enabled = p.getBool("wpOn", false)
        current = p.getString("wpFile")
        mode = p.getInt("wpMode", MODE_BOTH).coerceIn(0, 2)
        range = p.getFloat("wpRange", 0.5f)
        speed = p.getFloat("wpSpeed", 0.5f)
        invert = p.getBool("wpInvert", false)
        scrolling = p.getBool("wpScroll", true)
        powerSaver = p.getBool("wpSaver", true)
        dim = p.getFloat("wpDim", 0.15f)
        quality = p.getInt("wpQuality", QUALITY_HIGH).coerceIn(0, 2)
        transition = p.getInt("wpTransition", TRANSITION_FADE).coerceIn(0, 5)
        animSpeedIdx = p.getInt("wpAnimSpeed", 2).coerceIn(0, ANIM_SPEEDS.size - 1)
        fxOn = p.getBool("fxOn", false)
        fxType = p.getInt("fxType", FX_RAIN).coerceIn(0, 2)
        rainIntensity = p.getFloat("rainIntensity", 0.5f)
        rainSpeed = p.getFloat("rainSpeed", 0.5f)
        rainBrightness = p.getFloat("rainBrightness", 0.35f)
        rainStreaks = p.getBool("rainStreaks", true)
        rainDrops = p.getBool("rainDrops", true)
        dropAmount = p.getFloat("dropAmount", 0.5f)
        dropSize = p.getFloat("dropSize", 0.6f)
        dropSpeed = p.getFloat("dropSpeed", 0.4f)
        lightning = p.getBool("lightning", false)
        rippleTouchOnly = p.getBool("rippleTouchOnly", false)
        rippleRainLines = p.getBool("rippleRainLines", false)
        rippleSpeed = p.getFloat("rippleSpeed", 0.3f)
        rippleSize = p.getFloat("rippleSize", 0.7f)
        rippleStrength = p.getFloat("rippleStrength", 0.45f)
        snowSpeed = p.getFloat("snowSpeed", 0.25f)
        snowDensity = p.getFloat("snowDensity", 0.35f)
        snowSize = p.getFloat("snowSize", 0.55f)
        snowOpacity = p.getFloat("snowOpacity", 0.7f)
    }

    fun save(p: Prefs) {
        p.putBool("wpOn", enabled)
        p.putString("wpFile", current)
        p.putInt("wpMode", mode)
        p.putFloat("wpRange", range)
        p.putFloat("wpSpeed", speed)
        p.putBool("wpInvert", invert)
        p.putBool("wpScroll", scrolling)
        p.putBool("wpSaver", powerSaver)
        p.putFloat("wpDim", dim)
        p.putInt("wpQuality", quality)
        p.putInt("wpTransition", transition)
        p.putInt("wpAnimSpeed", animSpeedIdx)
        p.putBool("fxOn", fxOn)
        p.putInt("fxType", fxType)
        p.putFloat("rainIntensity", rainIntensity)
        p.putFloat("rainSpeed", rainSpeed)
        p.putFloat("rainBrightness", rainBrightness)
        p.putBool("rainStreaks", rainStreaks)
        p.putBool("rainDrops", rainDrops)
        p.putFloat("dropAmount", dropAmount)
        p.putFloat("dropSize", dropSize)
        p.putFloat("dropSpeed", dropSpeed)
        p.putBool("lightning", lightning)
        p.putBool("rippleTouchOnly", rippleTouchOnly)
        p.putBool("rippleRainLines", rippleRainLines)
        p.putFloat("rippleSpeed", rippleSpeed)
        p.putFloat("rippleSize", rippleSize)
        p.putFloat("rippleStrength", rippleStrength)
        p.putFloat("snowSpeed", snowSpeed)
        p.putFloat("snowDensity", snowDensity)
        p.putFloat("snowSize", snowSize)
        p.putFloat("snowOpacity", snowOpacity)
    }
}

/** The pictures you added, kept as JPEG copies inside Eon's own storage so they never depend on the gallery. */
object WallpaperStore {
    /** Longest side of a stored picture, in pixels. Bigger pictures are shrunk when added. */
    private const val MAX_SIDE = 3200

    private fun dir(ctx: Context): File = File(ctx.filesDir, "wallpapers").also { it.mkdirs() }

    /** File names, newest first. */
    fun list(ctx: Context): List<String> =
        (dir(ctx).listFiles { f -> f.isFile && f.extension == "jpg" } ?: emptyArray())
            .sortedByDescending { it.lastModified() }
            .map { it.name }

    fun file(ctx: Context, name: String): File = File(dir(ctx), File(name).name)

    fun delete(ctx: Context, name: String) {
        file(ctx, name).delete()
    }

    /** Copies the picture at [uri] into Eon's storage and returns its file name, or null if it could not be read. */
    suspend fun import(ctx: Context, uri: Uri): String? = withContext(Dispatchers.IO) {
        try {
            val source = ImageDecoder.createSource(ctx.contentResolver, uri)
            val bmp = ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE)
                val w = info.size.width
                val h = info.size.height
                val longest = max(w, h)
                if (longest > MAX_SIDE) {
                    val k = MAX_SIDE.toFloat() / longest
                    decoder.setTargetSize(max(1, (w * k).roundToInt()), max(1, (h * k).roundToInt()))
                }
            }
            val name = "w_${System.currentTimeMillis()}.jpg"
            FileOutputStream(File(dir(ctx), name)).use { out ->
                bmp.compress(Bitmap.CompressFormat.JPEG, 94, out)
            }
            bmp.recycle()
            name
        } catch (e: Exception) {
            null
        } catch (e: OutOfMemoryError) {
            null
        }
    }

    /**
     * Decodes a stored picture for drawing. It is shrunk so it only just covers the screen with room to move
     * ([factor] times the screen), which keeps memory low. Low quality also uses 16-bit colour.
     */
    fun load(ctx: Context, name: String, screenW: Int, screenH: Int, quality: Int, software: Boolean = false): Bitmap? {
        val factor = if (quality == WallpaperConfig.QUALITY_HIGH) 1.4f else 1.2f
        val low = quality == WallpaperConfig.QUALITY_LOW
        return try {
            val source = ImageDecoder.createSource(file(ctx, name))
            var bmp = ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                val iw = info.size.width
                val ih = info.size.height
                val cover = max(screenW.toFloat() / iw, screenH.toFloat() / ih) * factor
                if (cover < 1f) {
                    decoder.setTargetSize(max(1, (iw * cover).roundToInt()), max(1, (ih * cover).roundToInt()))
                }
                if (low || software) decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE)
            }
            if (low) {
                val small = bmp.copy(Bitmap.Config.RGB_565, false)
                if (small != null) {
                    bmp.recycle()
                    bmp = small
                }
            }
            bmp
        } catch (e: Exception) {
            null
        } catch (e: OutOfMemoryError) {
            null
        }
    }

    /** A small version for the picker grid. */
    fun thumb(ctx: Context, name: String, maxSide: Int = 360): Bitmap? {
        return try {
            val source = ImageDecoder.createSource(file(ctx, name))
            ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                val w = info.size.width
                val h = info.size.height
                val k = maxSide.toFloat() / max(w, h)
                if (k < 1f) decoder.setTargetSize(max(1, (w * k).roundToInt()), max(1, (h * k).roundToInt()))
            }
        } catch (e: Exception) {
            null
        } catch (e: OutOfMemoryError) {
            null
        }
    }
}
