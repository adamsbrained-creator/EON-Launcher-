package ix.app.eon

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap

/** The AI pill. Tap it to open the AI it shows; tap the arrow to pick another one. */
const val W_AI = -8

/**
 * One assistant the pill can open.
 *
 * [activity] is the exact activity to start (the one you find in Activity Launcher). It is tried first;
 * if the phone has no such activity, the app's normal launch intent is used instead.
 */
private class AiApp(val id: String, val label: String, val pkg: String, val activity: String? = null)

private val AI_APPS = listOf(
    // BardEntryPointActivity is what Gemini's own entry points use.
    AiApp("gemini", "Gemini", "com.google.android.apps.bard", "com.google.android.apps.bard.shellapp.BardEntryPointActivity"),
    AiApp("claude", "Claude", "com.anthropic.claude"),
    AiApp("chatgpt", "ChatGPT", "com.openai.chatgpt"),
    AiApp("grok", "Grok", "ai.x.grok"),
)

private fun aiPrefs(ctx: Context) = ctx.getSharedPreferences("eon", Context.MODE_PRIVATE)

private fun installed(ctx: Context, a: AiApp): Boolean =
    runCatching { ctx.packageManager.getApplicationInfo(a.pkg, 0); true }.getOrDefault(false)

private fun launchIntent(ctx: Context, a: AiApp): Intent? {
    if (a.activity != null) {
        val i = Intent(Intent.ACTION_MAIN).setComponent(ComponentName(a.pkg, a.activity))
        if (i.resolveActivity(ctx.packageManager) != null) return i
    }
    return ctx.packageManager.getLaunchIntentForPackage(a.pkg)
}

private fun openAi(ctx: Context, a: AiApp) {
    val i = launchIntent(ctx, a)
    if (i == null) {
        Toast.makeText(ctx, a.label + " is not installed", Toast.LENGTH_SHORT).show()
        return
    }
    try {
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        Toast.makeText(ctx, "Could not open " + a.label, Toast.LENGTH_SHORT).show()
    }
}

private fun iconOf(ctx: Context, a: AiApp): ImageBitmap? = try {
    val d: Drawable = ctx.packageManager.getApplicationIcon(a.pkg)
    d.toBitmap(96, 96).asImageBitmap()
} catch (e: Exception) {
    null
}

@Composable
fun AiWidget() {
    val ctx = LocalContext.current
    val available = remember { AI_APPS.filter { installed(ctx, it) } }
    val shown = available.ifEmpty { AI_APPS }
    var selectedId by remember { mutableStateOf(aiPrefs(ctx).getString("ai_widget_pick", "gemini") ?: "gemini") }
    var menu by remember { mutableStateOf(false) }
    val current = shown.firstOrNull { it.id == selectedId } ?: shown.first()
    val icon = remember(current.id) { iconOf(ctx, current) }
    val pillShape = CircleShape

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Row(
            Modifier.fillMaxSize().clip(pillShape)
                .background(Color(0x99202124))
                .border(1.dp, Color(0x33FFFFFF), pillShape),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            // Left part: open the AI.
            Row(
                Modifier.weight(1f).fillMaxHeight().clickable { openAi(ctx, current) }.padding(start = 18.dp, end = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
            ) {
                if (icon != null) {
                    Image(icon, null, Modifier.size(22.dp).clip(CircleShape))
                    Spacer(Modifier.width(10.dp))
                }
                Text(
                    current.label, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
            // Right part: choose another AI.
            Box(Modifier.fillMaxHeight().width(48.dp).clickable { menu = true }, contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.KeyboardArrowDown, "Choose AI", tint = Color(0xFFC8CAD0), modifier = Modifier.size(22.dp))
                DropdownMenu(
                    expanded = menu, onDismissRequest = { menu = false },
                    containerColor = Color(0xFF0D0D0F),
                ) {
                    shown.forEach { a ->
                        val ic = remember(a.id) { iconOf(ctx, a) }
                        DropdownMenuItem(
                            text = {
                                Text(
                                    a.label + if (installed(ctx, a)) "" else "  (not installed)",
                                    color = if (a.id == current.id) Color.White else Color(0xFFC8CAD0),
                                    fontWeight = if (a.id == current.id) FontWeight.Bold else FontWeight.Normal,
                                )
                            },
                            leadingIcon = {
                                if (ic != null) Image(ic, null, Modifier.size(24.dp).clip(CircleShape))
                                else Box(Modifier.size(24.dp).clip(CircleShape).background(Color(0xFF34363B)))
                            },
                            onClick = {
                                menu = false
                                selectedId = a.id
                                aiPrefs(ctx).edit().putString("ai_widget_pick", a.id).apply()
                                openAi(ctx, a)
                            },
                        )
                    }
                }
            }
        }
    }
}
