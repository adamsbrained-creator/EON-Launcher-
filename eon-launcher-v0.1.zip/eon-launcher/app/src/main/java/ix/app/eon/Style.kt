package ix.app.eon

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp

object Eon {
    val Ink = Color(0xFF070B24)
    val Blue = Color(0xFF2B45B8)
    val BlueLight = Color(0xFF5470D6)
    val Periwinkle = Color(0xFF8FA6FF)
    val Text = Color(0xFFF4F6FF)
    val Muted = Color(0xFFA9B4E6)
    val Faint = Color(0xFF8E9BD6)
    val Good = Color(0xFF9FE8C4)
    val Button = Brush.verticalGradient(listOf(Color(0xFF9FB2FF), Color(0xFF4560CC)))
    val Tile = Brush.verticalGradient(listOf(Color(0xFF3A478C), Color(0xFF2B44A8), Color(0xFF5470D6)))
    val Sheen = Brush.verticalGradient(listOf(Color(0x33FFFFFF), Color(0x0DFFFFFF)))
}

/** Frosted blue panel with a light top edge and border. */
fun Modifier.glass(shape: Shape): Modifier =
    this.clip(shape)
        .background(Color(0x6B1A2880))
        .background(Eon.Sheen)
        .border(1.dp, Color(0x80C8D4FF), shape)
