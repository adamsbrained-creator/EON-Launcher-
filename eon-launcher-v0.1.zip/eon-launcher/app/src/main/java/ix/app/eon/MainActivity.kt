package ix.app.eon

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue

class MainActivity : ComponentActivity() {
    private var homeTick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        val prefs = Prefs(this)
        val repo = AppRepo(this)
        setContent { EonApp(prefs, repo, homeTick) }
    }

    // Pressing Home while Eon is already open comes back here: close the drawer.
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN && intent.hasCategory(Intent.CATEGORY_HOME)) homeTick++
    }
}

@Composable
fun EonApp(prefs: Prefs, repo: AppRepo, homeTick: Int) {
    var onboarded by remember { mutableStateOf(prefs.onboarded) }
    var apps by remember { mutableStateOf(emptyList<AppEntry>()) }
    var reload by remember { mutableIntStateOf(0) }

    LaunchedEffect(reload) { apps = repo.load() }
    DisposableEffect(Unit) {
        val stop = repo.watch { reload++ }
        onDispose { stop() }
    }

    MaterialTheme(colorScheme = darkColorScheme()) {
        if (onboarded) Home(repo, apps, homeTick) else Onboarding(prefs) { onboarded = true }
    }
}
