package ix.app.eon

import android.text.format.DateFormat
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun Home(repo: AppRepo, apps: List<AppEntry>, homeTick: Int) {
    val ctx = LocalContext.current
    var drawer by rememberSaveable { mutableStateOf(false) }
    var focusSearch by remember { mutableStateOf(false) }
    val dock = remember(apps) { repo.defaultDock(apps) }
    val now by produceState(LocalDateTime.now()) {
        while (true) {
            value = LocalDateTime.now()
            delay(60_000L - System.currentTimeMillis() % 60_000L)
        }
    }
    val is24 = remember { DateFormat.is24HourFormat(ctx) }
    val time = now.format(DateTimeFormatter.ofPattern(if (is24) "HH:mm" else "h:mm"))
    val date = now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.getDefault()))
    val shadow = Shadow(Color(0x73000000), Offset(0f, 2f), 8f)

    LaunchedEffect(homeTick) { if (homeTick > 0) drawer = false }
    BackHandler(enabled = drawer) { drawer = false }

    Box(
        Modifier.fillMaxSize().pointerInput(Unit) {
            var total = 0f
            detectVerticalDragGestures(
                onDragStart = { total = 0f },
                onDragEnd = { if (total < -160f) { focusSearch = false; drawer = true } },
                onDragCancel = { total = 0f },
                onVerticalDrag = { _, dy -> total += dy },
            )
        },
    ) {
        Box(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(340.dp)
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xA6070B24)))),
        )

        Column(Modifier.systemBarsPadding().padding(start = 28.dp, top = 40.dp)) {
            Text(
                time,
                style = TextStyle(
                    color = Eon.Text, fontSize = 72.sp, fontWeight = FontWeight.Light,
                    letterSpacing = (-2).sp, shadow = shadow,
                ),
            )
            Text(date, style = TextStyle(color = Color(0xFFDDE3FF), fontSize = 15.sp, shadow = shadow))
        }

        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().systemBarsPadding()
                .padding(start = 16.dp, end = 16.dp, bottom = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(
                Modifier.glass(CircleShape).clickable { focusSearch = true; drawer = true }
                    .padding(horizontal = 20.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                EonMark(Modifier.size(16.dp), brush = SolidColor(Eon.Periwinkle))
                Spacer(Modifier.width(10.dp))
                Text("Search apps", color = Color(0xFFC9D1F5), fontSize = 14.sp)
            }
            Gap(12)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                EonMark(Modifier.size(16.dp), brush = SolidColor(Eon.Text))
                Box(Modifier.size(6.dp).clip(CircleShape).background(Color(0x73A0B2FF)))
            }
            Gap(12)
            Row(
                Modifier.fillMaxWidth().glass(RoundedCornerShape(34.dp)).padding(horizontal = 14.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                dock.forEach { app ->
                    Image(
                        bitmap = app.icon, contentDescription = app.label,
                        modifier = Modifier.size(56.dp).clip(RoundedCornerShape(16.dp)).clickable { repo.launch(app) },
                    )
                }
            }
        }

        AnimatedVisibility(
            visible = drawer,
            enter = slideInVertically { it / 3 } + fadeIn(),
            exit = slideOutVertically { it / 3 } + fadeOut(),
        ) {
            Drawer(apps, focusSearch) { app ->
                repo.launch(app)
                drawer = false
            }
        }
    }
}

@Composable
private fun Drawer(apps: List<AppEntry>, focusSearch: Boolean, onLaunch: (AppEntry) -> Unit) {
    var query by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    val list = remember(apps, query) {
        val q = query.trim()
        if (q.isEmpty()) apps else apps.filter { it.label.contains(q, ignoreCase = true) }
    }
    LaunchedEffect(focusSearch) { if (focusSearch) focus.requestFocus() }

    Column(
        Modifier.fillMaxSize().background(Color(0xE8070B24)).systemBarsPadding().imePadding()
            .padding(horizontal = 16.dp),
    ) {
        Gap(12)
        Box(Modifier.fillMaxWidth().glass(CircleShape).padding(horizontal = 20.dp, vertical = 14.dp)) {
            if (query.isEmpty()) Text("Search apps", color = Eon.Faint, fontSize = 16.sp)
            BasicTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                textStyle = TextStyle(color = Eon.Text, fontSize = 16.sp),
                cursorBrush = SolidColor(Eon.Periwinkle),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { list.firstOrNull()?.let(onLaunch) }),
                modifier = Modifier.fillMaxWidth().focusRequester(focus),
            )
        }
        Gap(12)
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            items(list, key = { "${it.component.flattenToString()}#${it.user.hashCode()}" }) { app ->
                AppCell(app) { onLaunch(app) }
            }
        }
    }
}

@Composable
private fun AppCell(app: AppEntry, onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Image(bitmap = app.icon, contentDescription = app.label, modifier = Modifier.size(56.dp))
        Gap(6)
        Text(
            app.label, color = Eon.Text, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 2.dp),
        )
    }
}
