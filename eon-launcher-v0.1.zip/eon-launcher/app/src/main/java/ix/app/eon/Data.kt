package ix.app.eon

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.net.Uri
import android.os.UserHandle
import android.provider.MediaStore
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("eon", Context.MODE_PRIVATE)

    var onboarded: Boolean
        get() = sp.getBoolean("onboarded", false)
        set(v) { sp.edit().putBoolean("onboarded", v).apply() }

    /** "glassy" or "flat" */
    var look: String
        get() = sp.getString("look", "glassy") ?: "glassy"
        set(v) { sp.edit().putString("look", v).apply() }

    /** "dark", "light" or "auto" */
    var theme: String
        get() = sp.getString("theme", "dark") ?: "dark"
        set(v) { sp.edit().putString("theme", v).apply() }
}

data class AppEntry(
    val label: String,
    val packageName: String,
    val component: ComponentName,
    val user: UserHandle,
    val icon: ImageBitmap,
)

class AppRepo(private val context: Context) {
    private val launcherApps =
        context.getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps

    suspend fun load(): List<AppEntry> = withContext(Dispatchers.Default) {
        val px = (context.resources.displayMetrics.density * 56f).toInt().coerceAtLeast(96)
        launcherApps.profiles
            .flatMap { user ->
                launcherApps.getActivityList(null, user).map { info ->
                    AppEntry(
                        label = info.label.toString(),
                        packageName = info.componentName.packageName,
                        component = info.componentName,
                        user = user,
                        icon = info.getBadgedIcon(0).toBitmap(px, px).asImageBitmap(),
                    )
                }
            }
            .filter { it.packageName != context.packageName }
            .sortedBy { it.label.lowercase() }
    }

    fun launch(app: AppEntry) {
        try {
            launcherApps.startMainActivity(app.component, app.user, null, null)
        } catch (_: Exception) {
        }
    }

    /** Phone, messages, browser and camera if they can be found; otherwise the first apps. */
    fun defaultDock(apps: List<AppEntry>): List<AppEntry> {
        val pm = context.packageManager
        val probes = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")),
            Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA),
        )
        val packages = probes.mapNotNull {
            pm.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
        }
        val picked = packages
            .mapNotNull { p -> apps.firstOrNull { it.packageName == p } }
            .distinctBy { it.packageName }
            .toMutableList()
        for (a in apps) {
            if (picked.size >= 4) break
            if (picked.none { it.packageName == a.packageName }) picked.add(a)
        }
        return picked.take(4)
    }

    /** Calls [onChange] when apps are installed, removed or updated. Returns an unregister function. */
    fun watch(onChange: () -> Unit): () -> Unit {
        val callback = object : LauncherApps.Callback() {
            override fun onPackageRemoved(packageName: String, user: UserHandle) = onChange()
            override fun onPackageAdded(packageName: String, user: UserHandle) = onChange()
            override fun onPackageChanged(packageName: String, user: UserHandle) = onChange()
            override fun onPackagesAvailable(
                packageNames: Array<out String>, user: UserHandle, replacing: Boolean,
            ) = onChange()
            override fun onPackagesUnavailable(
                packageNames: Array<out String>, user: UserHandle, replacing: Boolean,
            ) = onChange()
        }
        launcherApps.registerCallback(callback)
        return { launcherApps.unregisterCallback(callback) }
    }
}
