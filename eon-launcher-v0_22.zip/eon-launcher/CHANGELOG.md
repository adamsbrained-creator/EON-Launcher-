# Eon: what's new

## v0.10.0
- New: gyro wallpaper. Pick a picture and Eon draws it behind the home screen and slides it as you tilt the phone (it reads the accelerometer, so no extra permission). Nothing changes until you turn it on: with it off Eon still shows your normal system wallpaper.
- Open it from Settings > Wallpaper, or long-press empty space on the home screen and choose Wallpaper. Add pictures with the + tile (they are copied into Eon, so they stay even if you delete them from the gallery), tap one to use it, long-press one to delete it.
- Wallpaper settings, with the wallpaper visible above the panel so you can tilt and watch: Direction (Horizontal, Vertical or Both), Range, Speed, Dim, Reverse direction, Wallpaper scrolling (the picture also shifts as you swipe between pages), Power saver mode (stop reading the sensor in battery saver) and Quality (High, Standard, Low = 16-bit colour).
- The centre follows where you hold the phone, so the picture settles back to the middle if you keep it at a new angle or put it down.
- Effects: an optional overlay of Rain, Ripple (starts where you touch, or also at random) or Snow, each with its own sliders.
- Not yet: slideshow, other transition animations, the lock screen.

## v0.9.13
- New: the Dock. A rounded, see-through bar at the bottom of the home screen, like iOS, that stays put while you swipe between pages. It is off until you turn it on in Settings > Home screen > Dock.
- Dock settings: Enable, Columns (1 to 6), Rows (1 to 3), Icon size, Pages (1 to 5, swipe the dock sideways) and Icon label visibility. The home screen stays visible below the panel, so you watch the dock change as you set it up.
- Add an app by long-pressing it and choosing Move to dock. In the dock, long-press and drag an icon to rearrange; long-press an icon without moving for Move to home or Remove from dock.
- The home grid gives up the space the dock uses. Icons that no longer fit are moved to the nearest free cell, nothing is deleted.

## v0.9.12
- New Settings > Home screen, with Grid properties and a Show indicator switch (hides the page dots).
- Grid properties, in Eon's own look. The home screen stays visible above the panel so you see every change live:
  - Presets 4x7, 5x8 and 6x10, plus Columns (3 to 8) and Rows (Auto or 3 to 14). With a chosen number of rows the grid stretches to fill the screen.
  - Icon size (40 to 84 dp), with a reset button.
  - Icon label visibility, Label size (8 to 16 pt) and Allow two-line labels.
  - Use custom padding: side, top and bottom space around the grid.
- When you change the grid, widgets are pulled back inside it and any icon that no longer fits moves to the nearest free cell. Nothing is deleted.
- The drawer keeps its own icon size, so changing the home screen does not change it.

## v0.9.11
- The Search apps pill now floats and can go anywhere. Long-press it to edit: drag it, nudge it with the arrows (half a cell with Snap to grid on, 0.05 cell with it off), reset it to the bottom, or hide it. Open it with a tap as before.
- The home grid now reaches all the way down to the page dots, so you can put icons where the search pill used to be (a dock-style row at the bottom, like in Smart Launcher). Icons you already placed stay where they are.
- If you hide the pill, long-press empty space on the home screen and choose "Show search pill" to bring it back.
- Page swiping is paused while you edit a widget or the pill.

## v0.9.10
- Smoother icons: an icon now settles from where you let go instead of jumping back first, lifts with a little spring when you pick it up, and swaps glide. The grid fades in and out instead of popping.
- More precise placing: while you drag, a ghost outline shows exactly where the icon will land (the cell in Grid mode, the exact spot in Free mode). In Free mode, and when moving or resizing widgets with Snap to grid off, positions click onto a whole cell when you are close.
- You feel it too: a small tick each time the icon moves into a new cell, and when a widget lands exactly on a cell.
- The edit panel now shows the widget's position and size all the time, and updates as you drag.

## v0.9.9
- Quick switch: long-press empty space on the home screen and choose "Place icons freely" or "Snap icons to grid". It is the same setting as in Eon settings.

## v0.9.8
- New setting, Icon placement: Grid (icons snap to cells, as before) or Free (drop an icon anywhere on the home screen; positions go in steps of 0.05 cell, and a drop that would land on top of another icon is ignored). Switching back to Grid moves each icon to the nearest free cell.
- Fixed three type errors in the app-drag code that came in with v0.9.7 and would have stopped the build.

## v0.9.7
- Edit widgets right on the home screen: long-press a widget. A faint grid appears, you drag the widget to move it and drag the dots on its edges to resize it. A small panel gives you exact steps (Resize, Move, Elevation), a Snap to grid switch and Remove. Tap anywhere else, press Done or go back to finish.
- Widgets can now sit anywhere, not just on whole cells. With Snap to grid off, moves and resizes go in steps of 0.05 cell; with it on they snap to whole cells (this is the default).
- Elevation: when widgets overlap, the one with the higher Z number is on top.
- The grid also shows while you drag an app, so you can see where it will land.
- While a widget is being edited, swiping between pages and swiping up for the drawer are paused.

## v0.9.6
- App icon: the glyph is back to its original size (it was too big in 0.9.5) and sits comfortably inside the black background. Same rainbow colours.

## v0.9.5
- New app icon: the Eon symbol in a rainbow gradient (green, cyan, violet, magenta, coral, orange) on a pure black background. The welcome screen logo matches it.
- Removed the built-in clock and date from the top of the home screen, since it could not be moved or removed like a widget. The home grid now starts at the top, so apps you placed earlier sit about two rows higher; drag them back if you want.

## v0.9.4
- New icon shape: every app icon is now the same rounded square (about 26% rounded corners, measured from Smart Launcher), in the drawer, on the home grid and in the app menu. Adaptive icons are cut to the shape; old icons with a transparent margin sit centred on a light or dark plate so the grid looks even.
- Icons are a little bigger (60 dp instead of 56 dp). The size and corner radius are two values at the top of IconShape.kt.

## v0.9.3
- New colours: Eon moves from blue to near-black with soft grey text and a green accent (selected chips, badges, toggles, the playing dot). Panels are smoked black glass instead of blue, the welcome screen and the app icon are charcoal, and the Week widget and cover art match.

## v0.9.2
- Removed the dock: the home screen is now just the clock, your pages and the search pill. "Add to dock" is gone from the app menu. The dark fade at the bottom is shorter now that there is no dock behind it.

## v0.9.1
- Fixed: the build failed on one line in the home menu that still used the old way of checking whether a page is empty. Nothing else changed, so v0.9.1 has everything from v0.9.

## v0.9.0
- Free home grid: apps and widgets now sit on a 4-column grid. Long-press an app and drag it to any empty spot (or onto another app to swap); a highlight shows where it will land. Your existing home screen is moved onto the grid automatically.
- Widgets on the grid: each widget takes a number of cells. In the Widgets screen, the "On this page" tab lets you nudge a widget left, right, up or down and make it taller, shorter, wider or narrower. If a page is full, Eon says there is no space.
- Fixed: weather said "Allow location" even when location was allowed. It now asks the phone for a fresh coarse location itself, and says "No location fix" if there is none. Now playing also shows how many players it can see, to help find out why it stays empty.
- Not yet: dragging widgets directly, moving apps between pages.

## v0.8.0
- Fixed: long-pressing empty space on the home screen did nothing since pages arrived in v0.5, because the page swiper was catching the touch; it now opens the home menu (widgets, pages, settings) again, and long-pressing an app no longer risks opening it twice.
- New: tapping the page marker at the bottom also opens the home menu, as a second way in.

## v0.7.1
- Fixed: the build failed because two functions in the settings state had the same internal name (a naming clash on the look setting). Nothing else changed, so v0.7.1 has everything from v0.5 to v0.7, including home pages, the Eon widgets and weather.

## v0.7.0
- Weather and quote: a new Eon widget with the local weather on the left (angular icon, temperature, feels like) and a daily quote on the right; tap the weather to refresh or to allow location, tap the quote for another one. Weather comes from Open-Meteo using your last known coarse location, so Eon now asks for internet access.
- Not yet: your own quotes, folders, dragging apps between pages.

## v0.6.0
- Eon widgets: two built-in widgets under "EON" in the widget picker. Now playing shows the track and artist as plain text with a round cover and a green dot while playing (tap to open the player; needs notification access), and Week shows seven days around today with the month and the time.
- Gesture: swipe down on the home screen to pull the notification shade.
- Not yet: weather, folders, dragging apps between pages.

## v0.5.0
- Home pages: swipe sideways between pages, each with its own pinned apps and widgets; the marker at the bottom shows where you are, with the Eon glyph always standing for page one.
- Page controls: long-press empty space to add a page to the left or right, or to remove an empty one; pressing Home takes you back to page one.
- Changed: pinning an app or adding a widget now goes to the page you are on, and the widget manager shows that page's widgets.
- Not yet: dragging apps between pages, resizing widgets, folders.

## v0.4.0
- Widgets: long-press empty space and choose Widgets to add any widget from any app, then move or remove them in the "On this page" tab; they sit above your pinned apps.

## v0.3.0
- Drag to rearrange: long-press a pinned app or a dock app and drag it to a new spot; long-press and release still opens the app menu, which can now add or remove dock apps.

## v0.2.0
- Every app now shows in the drawer, Eon appears in the notification access list, and icons get notification counts.
- The drawer has category chips with search across all apps; long-press an app to pin, recategorize, hide, open app info or uninstall.
- Eon settings (Glassy or Flat look, notification access, hidden apps) and a more solid drawer background.

## v0.1.0
- First build: greeting flow, home with clock and dock, app drawer with search.
