package ix.app.eon

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.PowerManager
import androidx.activity.ComponentActivity
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Reads the accelerometer and turns it into a smooth tilt: [outX] and [outY] go from -1 to 1.
 *
 * The "centre" is wherever you hold the phone when the home screen appears, and it follows slowly, so
 * the picture settles back to the middle if you hold the phone at a new angle or put it down.
 */
class TiltState {
    private var manager: SensorManager? = null

    @Volatile private var ax = 0f
    @Volatile private var ay = 0f
    @Volatile private var az = 0f
    @Volatile private var has = false

    private val listener = object : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent) {
            ax = event.values[0]
            ay = event.values[1]
            az = event.values[2]
            has = true
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }

    /** Smoothed tilt, read from the draw phase so only the drawing is redone when it changes. */
    var outX by mutableFloatStateOf(0f)
        private set
    var outY by mutableFloatStateOf(0f)
        private set

    private var baseRoll = 0f
    private var basePitch = 0f
    private var baseSet = false
    private var curX = 0f
    private var curY = 0f

    fun start(ctx: Context) {
        stop()
        val m = ctx.getSystemService(Context.SENSOR_SERVICE) as? SensorManager ?: return
        val s = m.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return
        m.registerListener(listener, s, SensorManager.SENSOR_DELAY_GAME)
        manager = m
        baseSet = false
    }

    fun stop() {
        manager?.unregisterListener(listener)
        manager = null
        has = false
        baseSet = false
    }

    /** Moves the smoothed tilt a step closer to the phone's real tilt. Returns true while it is still moving. */
    fun step(dt: Float, speed: Float): Boolean {
        var targetX = 0f
        var targetY = 0f
        val x = ax
        val y = ay
        val z = az
        val g = sqrt(x * x + y * y + z * z)
        if (has && g > 3f) {
            // roll: positive when the right edge goes down. pitch: 0 held upright, positive as the screen turns up.
            val roll = asin((-x / g).coerceIn(-1f, 1f))
            val pitch = atan2(z, y)
            if (!baseSet) {
                baseRoll = roll
                basePitch = pitch
                baseSet = true
            }
            val k = 1f - exp(-dt / RECENTRE_SECONDS)
            baseRoll += wrap(roll - baseRoll) * k
            basePitch += wrap(pitch - basePitch) * k
            targetX = (wrap(roll - baseRoll) / FULL_TILT).coerceIn(-1f, 1f)
            targetY = (wrap(pitch - basePitch) / FULL_TILT).coerceIn(-1f, 1f)
        }
        val tau = 0.30f - 0.27f * speed.coerceIn(0f, 1f)
        val a = 1f - exp(-dt / tau)
        curX += (targetX - curX) * a
        curY += (targetY - curY) * a
        outX = curX
        outY = curY
        return abs(targetX - curX) > 0.002f || abs(targetY - curY) > 0.002f
    }

    private fun wrap(a: Float): Float {
        var r = a
        val twoPi = (2.0 * PI).toFloat()
        while (r > PI) r -= twoPi
        while (r < -PI) r += twoPi
        return r
    }

    private companion object {
        /** Tilt (in radians, about 22 degrees) that moves the picture all the way to its edge. */
        const val FULL_TILT = 0.38f
        const val RECENTRE_SECONDS = 8f
    }
}

/** The overlay effects (rain, ripples, snow). Particles live in plain arrays; [tick] makes the canvas redraw. */
class WallpaperFx {
    var tick by mutableLongStateOf(0L)
        private set

    private val maxParticles = 480
    private val px = FloatArray(maxParticles) { Random.nextFloat() }
    private val py = FloatArray(maxParticles) { Random.nextFloat() }
    private val pr = FloatArray(maxParticles) { Random.nextFloat() }
    private val pp = FloatArray(maxParticles) { Random.nextFloat() * 6.2832f }

    private val maxRipples = 24
    private val rx = FloatArray(maxRipples)
    private val ry = FloatArray(maxRipples)
    private val rage = FloatArray(maxRipples) { -1f }
    private var spawnTimer = 0f
    private var time = 0f

    /** True while something is being drawn that needs a new frame every time. */
    val running: Boolean get() = WallpaperConfig.fxOn

    private fun snowCount() = (24 + 400 * WallpaperConfig.snowDensity).toInt().coerceIn(1, maxParticles)
    private fun rainCount() = (30 + 450 * WallpaperConfig.rainIntensity).toInt().coerceIn(1, maxParticles)

    fun touch(x: Float, y: Float) {
        if (!WallpaperConfig.fxOn || WallpaperConfig.fxType != WallpaperConfig.FX_RIPPLE) return
        spawn(x, y)
    }

    private fun spawn(x: Float, y: Float) {
        for (i in 0 until maxRipples) {
            if (rage[i] < 0f) {
                rx[i] = x
                ry[i] = y
                rage[i] = 0f
                return
            }
        }
    }

    fun step(dt: Float, w: Float, h: Float) {
        if (!WallpaperConfig.fxOn || w <= 0f || h <= 0f) return
        time += dt
        when (WallpaperConfig.fxType) {
            WallpaperConfig.FX_SNOW -> {
                val fall = 0.03f + 0.14f * WallpaperConfig.snowSpeed
                for (i in 0 until snowCount()) {
                    py[i] += fall * (0.5f + pr[i]) * dt
                    if (py[i] > 1.05f) {
                        py[i] = -0.05f
                        px[i] = Random.nextFloat()
                    }
                }
            }
            WallpaperConfig.FX_RAIN -> {
                val fall = 0.8f + 1.6f * WallpaperConfig.rainSpeed
                for (i in 0 until rainCount()) {
                    py[i] += fall * (0.7f + pr[i] * 0.6f) * dt
                    px[i] -= 0.05f * fall * dt
                    if (px[i] < 0f) px[i] += 1f
                    if (py[i] > 1.1f) {
                        py[i] = -0.1f
                        px[i] = Random.nextFloat()
                    }
                }
            }
            WallpaperConfig.FX_RIPPLE -> {
                val rate = 0.25f + 1.0f * WallpaperConfig.rippleSpeed
                for (i in 0 until maxRipples) {
                    if (rage[i] >= 0f) {
                        rage[i] += dt * rate
                        if (rage[i] > 1f) rage[i] = -1f
                    }
                }
                if (!WallpaperConfig.rippleTouchOnly) {
                    spawnTimer -= dt
                    if (spawnTimer <= 0f) {
                        spawn(Random.nextFloat() * w, Random.nextFloat() * h)
                        spawnTimer = 1.3f - 1.0f * WallpaperConfig.rippleSpeed + Random.nextFloat() * 0.4f
                    }
                }
            }
        }
        tick += 1L
    }

    fun draw(ds: DrawScope, density: Float) {
        if (tick < 0L || !WallpaperConfig.fxOn) return
        val w = ds.size.width
        val h = ds.size.height
        when (WallpaperConfig.fxType) {
            WallpaperConfig.FX_SNOW -> {
                val base = (1.5f + 5f * WallpaperConfig.snowSize) * density
                for (i in 0 until snowCount()) {
                    val sway = sin(time * 0.6f + pp[i]) * 0.02f
                    val r = base * (0.45f + 0.8f * pr[i])
                    val a = WallpaperConfig.snowOpacity * (0.45f + 0.55f * pr[i])
                    ds.drawCircle(Color.White.copy(alpha = a.coerceIn(0f, 1f)), r, Offset((px[i] + sway) * w, py[i] * h))
                }
            }
            WallpaperConfig.FX_RAIN -> {
                val a0 = 0.12f + 0.6f * WallpaperConfig.rainBrightness
                for (i in 0 until rainCount()) {
                    val len = (16f + 34f * pr[i]) * density
                    val x = px[i] * w
                    val y = py[i] * h
                    val a = a0 * (0.5f + 0.5f * pr[i])
                    ds.drawLine(
                        Color.White.copy(alpha = a.coerceIn(0f, 1f)),
                        Offset(x, y), Offset(x - len * 0.1f, y - len),
                        strokeWidth = 1.3f * density,
                    )
                }
            }
            WallpaperConfig.FX_RIPPLE -> {
                val maxR = (70f + 300f * WallpaperConfig.rippleSize) * density
                for (i in 0 until maxRipples) {
                    val age = rage[i]
                    if (age < 0f) continue
                    val fade = (1f - age)
                    val a = (WallpaperConfig.rippleStrength * 0.9f * fade * fade).coerceIn(0f, 1f)
                    val c = Offset(rx[i], ry[i])
                    ds.drawCircle(Color.White.copy(alpha = a), age * maxR, c, style = Stroke(width = 2.2f * density))
                    ds.drawCircle(Color.White.copy(alpha = a * 0.55f), age * maxR * 0.7f, c, style = Stroke(width = 1.4f * density))
                }
            }
        }
    }
}

private fun isPowerSave(ctx: Context): Boolean =
    (ctx.getSystemService(Context.POWER_SERVICE) as? PowerManager)?.isPowerSaveMode == true

/**
 * The wallpaper layer: sits behind the whole home screen. It draws the chosen picture a little larger than the
 * screen and slides it as the phone tilts and as you swipe between pages. Only call this when
 * [WallpaperConfig.active] is true; otherwise the normal system wallpaper shows through.
 *
 * [page] is the current pager position (page index plus the swipe fraction), [pageCount] the number of pages.
 */
@Composable
fun GyroWallpaper(fx: WallpaperFx, page: () -> Float, pageCount: () -> Int) {
    val ctx = LocalContext.current
    val density = LocalDensity.current.density
    val dm = ctx.resources.displayMetrics
    val screenW = dm.widthPixels
    val screenH = dm.heightPixels

    var image by remember { mutableStateOf<ImageBitmap?>(null) }
    var previous by remember { mutableStateOf<ImageBitmap?>(null) }
    val fade = remember { Animatable(1f) }

    val file = WallpaperConfig.current
    val quality = WallpaperConfig.quality
    LaunchedEffect(file, quality) {
        val bmp = withContext(Dispatchers.IO) { WallpaperStore.load(ctx, file, screenW, screenH, quality) }
        if (bmp != null) {
            val old = image
            previous = old
            image = bmp.asImageBitmap()
            if (old != null) {
                fade.snapTo(0f)
                fade.animateTo(1f, tween(450))
            } else {
                fade.snapTo(1f)
            }
            previous = null
        }
    }

    // Only run while the home screen is on screen.
    val lifecycle = (ctx as ComponentActivity).lifecycle
    var resumed by remember { mutableStateOf(lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) }
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) resumed = true
            if (event == Lifecycle.Event.ON_PAUSE) resumed = false
        }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer) }
    }

    var saver by remember { mutableStateOf(isPowerSave(ctx)) }
    DisposableEffect(Unit) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, intent: Intent?) {
                saver = isPowerSave(ctx)
            }
        }
        ContextCompat.registerReceiver(
            ctx, receiver, IntentFilter(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED), ContextCompat.RECEIVER_EXPORTED,
        )
        onDispose { ctx.unregisterReceiver(receiver) }
    }

    val tilt = remember { TiltState() }
    val sensing = resumed && !(WallpaperConfig.powerSaver && saver)
    DisposableEffect(sensing) {
        if (sensing) tilt.start(ctx)
        onDispose { tilt.stop() }
    }

    LaunchedEffect(resumed) {
        if (!resumed) return@LaunchedEffect
        var last = 0L
        while (isActive) {
            val now = withFrameNanos { it }
            val dt = if (last == 0L) 0.016f else ((now - last) / 1_000_000_000f).coerceIn(0.001f, 0.1f)
            last = now
            val moving = tilt.step(dt, WallpaperConfig.speed)
            fx.step(dt, screenW.toFloat(), screenH.toFloat())
            // Nothing is moving: wake up less often until the sensor or an effect needs a frame again.
            if (!moving && !fx.running) delay(60)
        }
    }

    Canvas(Modifier.fillMaxSize()) {
        drawRect(Eon.Ink)
        val img = image
        if (img != null) {
            val old = previous
            if (old != null && fade.value < 1f) drawWallpaper(old, 1f, tilt.outX, tilt.outY, page(), pageCount())
            drawWallpaper(img, fade.value, tilt.outX, tilt.outY, page(), pageCount())
        }
        if (WallpaperConfig.dim > 0.01f) drawRect(Color.Black.copy(alpha = WallpaperConfig.dim.coerceIn(0f, 0.6f)))
        fx.draw(this, density)
    }
}

private fun DrawScope.drawWallpaper(img: ImageBitmap, alpha: Float, tx: Float, ty: Float, page: Float, pages: Int) {
    val w = size.width
    val h = size.height
    val iw = img.width.toFloat()
    val ih = img.height.toFloat()
    // Draw a little larger than the screen: the extra is the room the picture has to move in.
    val s = max(w / iw, h / ih) * (1.04f + 0.16f * WallpaperConfig.range)
    val dw = iw * s
    val dh = ih * s
    val roomX = (dw - w) / 2f
    val roomY = (dh - h) / 2f
    val mode = WallpaperConfig.mode
    val dir = if (WallpaperConfig.invert) -1f else 1f
    val pageShift = WallpaperConfig.scrolling && pages > 1
    // With page scrolling on, half of the sideways room is kept for swiping between pages.
    val tiltShare = if (pageShift && mode != WallpaperConfig.MODE_VERTICAL) 0.5f else 1f

    var ox = 0f
    var oy = 0f
    if (mode != WallpaperConfig.MODE_VERTICAL) ox += tx * dir * roomX * tiltShare
    if (mode != WallpaperConfig.MODE_HORIZONTAL) oy += ty * dir * roomY
    if (pageShift) {
        val pageShare = if (mode != WallpaperConfig.MODE_VERTICAL) 0.5f else 1f
        val p = (page / (pages - 1)).coerceIn(0f, 1f)
        ox += (0.5f - p) * 2f * roomX * pageShare
    }
    val x = ((w - dw) / 2f + ox).coerceIn(w - dw, 0f)
    val y = ((h - dh) / 2f + oy).coerceIn(h - dh, 0f)
    translate(x, y) {
        scale(s, s, pivot = Offset.Zero) {
            drawImage(img, alpha = alpha.coerceIn(0f, 1f))
        }
    }
}
