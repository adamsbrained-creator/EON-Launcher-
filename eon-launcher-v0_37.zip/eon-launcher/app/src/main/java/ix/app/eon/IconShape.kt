package ix.app.eon

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap

/** How big an app icon is drawn on the home screen and in the drawer. */
val ICON_SIZE: Dp = 60.dp

/**
 * Corner radius as a share of the icon's side. Measured from the Smart Launcher screenshots:
 * a plain rounded square with round corners of about 26% of the side.
 */
const val ICON_CORNER = 0.26f

/** The icon shapes you can pick in Settings > Drawer. Number 1 (Rounded) is the default. */
val ICON_SHAPES = listOf(
    "Square", "Rounded", "Squircle", "Circle", "Hexagon", "Octagon", "Pentagon", "Diamond", "Teardrop", "Leaf", "Flower",
)

/** The outline of icon shape [index] in a box [s] pixels wide and tall. */
fun iconShapePath(index: Int, s: Float): Path {
    val p = Path()
    val box = RectF(0f, 0f, s, s)
    when (index) {
        0 -> p.addRoundRect(box, s * 0.06f, s * 0.06f, Path.Direction.CW)
        2 -> {
            val n = 96
            for (i in 0 until n) {
                val t = 2.0 * Math.PI * i / n
                val c = Math.cos(t)
                val sn = Math.sin(t)
                val x = s / 2f + (s / 2f) * (Math.signum(c) * Math.pow(Math.abs(c), 0.45)).toFloat()
                val y = s / 2f + (s / 2f) * (Math.signum(sn) * Math.pow(Math.abs(sn), 0.45)).toFloat()
                if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
            }
            p.close()
        }
        3 -> p.addCircle(s / 2f, s / 2f, s / 2f, Path.Direction.CW)
        4 -> roundedPolygon(p, 6, -90.0, s, 0.18f)
        5 -> roundedPolygon(p, 8, -22.5, s, 0.12f)
        6 -> roundedPolygon(p, 5, -90.0, s, 0.16f)
        7 -> roundedPolygon(p, 4, -90.0, s, 0.24f)
        8 -> {
            val b = s * 0.5f
            val m = s * 0.08f
            p.addRoundRect(box, floatArrayOf(b, b, b, b, m, m, b, b), Path.Direction.CW)
        }
        9 -> {
            val b = s * 0.5f
            val m = s * 0.1f
            p.addRoundRect(box, floatArrayOf(b, b, m, m, b, b, m, m), Path.Direction.CW)
        }
        10 -> {
            val n = 160
            for (i in 0 until n) {
                val t = 2.0 * Math.PI * i / n
                val r = (s / 2f) * (0.9f + 0.1f * Math.cos(8.0 * t).toFloat())
                val x = s / 2f + r * Math.cos(t).toFloat()
                val y = s / 2f + r * Math.sin(t).toFloat()
                if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
            }
            p.close()
        }
        else -> p.addRoundRect(box, s * ICON_CORNER, s * ICON_CORNER, Path.Direction.CW)
    }
    return p
}

/** A regular polygon with [n] corners, each rounded by [corner] (a share of the side). */
private fun roundedPolygon(p: Path, n: Int, startDeg: Double, s: Float, corner: Float) {
    val c = s / 2f
    val vx = FloatArray(n)
    val vy = FloatArray(n)
    for (i in 0 until n) {
        val a = Math.toRadians(startDeg + 360.0 * i / n)
        vx[i] = c + c * Math.cos(a).toFloat()
        vy[i] = c + c * Math.sin(a).toFloat()
    }
    for (i in 0 until n) {
        val prev = (i + n - 1) % n
        val next = (i + 1) % n
        val ax = vx[i] + (vx[prev] - vx[i]) * corner
        val ay = vy[i] + (vy[prev] - vy[i]) * corner
        val bx = vx[i] + (vx[next] - vx[i]) * corner
        val by = vy[i] + (vy[next] - vy[i]) * corner
        if (i == 0) p.moveTo(ax, ay) else p.lineTo(ax, ay)
        p.quadTo(vx[i], vy[i], bx, by)
    }
    p.close()
}

private val PlateLight = Color.rgb(245, 245, 246)
private val PlateDark = Color.rgb(27, 28, 31)

/**
 * Turns any app icon into the same rounded square, so the whole grid looks uniform:
 * - adaptive icons are drawn full size and cut to the shape;
 * - old square-ish icons that fill their frame are cut to the shape;
 * - old icons with a transparent margin are centred on a light or dark plate.
 */
object IconShaper {
    /** Which of [ICON_SHAPES] icons are cut to. Set from Settings; icons are rebuilt when it changes. */
    @Volatile var shapeIndex: Int = 1

    fun shape(src: Drawable, px: Int): Bitmap {
        val content = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val c = Canvas(content)
        if (src is AdaptiveIconDrawable) {
            val bg = src.background
            if (bg == null) c.drawColor(PlateDark)
            // Adaptive layers are 108dp wide but only the middle 72dp is visible.
            val inset = (px * 0.25f).toInt()
            bg?.let { it.setBounds(-inset, -inset, px + inset, px + inset); it.draw(c) }
            src.foreground?.let { it.setBounds(-inset, -inset, px + inset, px + inset); it.draw(c) }
        } else {
            val glyph = src.toBitmap(px, px)
            val (edge, light) = measure(glyph)
            if (edge >= 0.9f) {
                c.drawBitmap(glyph, 0f, 0f, null)
            } else {
                c.drawColor(if (light < 0.6f) PlateLight else PlateDark)
                val pad = px * 0.14f
                c.drawBitmap(glyph, null, RectF(pad, pad, px - pad, px - pad), Paint(Paint.FILTER_BITMAP_FLAG))
            }
        }
        // Cut the shape with a shader so the edge is smooth.
        val out = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = BitmapShader(content, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        }
        Canvas(out).drawPath(iconShapePath(shapeIndex, px.toFloat()), paint)
        content.recycle()
        return out
    }

    /** Returns (how opaque the outer edge is, 0..1; how light the visible pixels are, 0..1). */
    private fun measure(bmp: Bitmap): Pair<Float, Float> {
        val n = 24
        val small = Bitmap.createScaledBitmap(bmp, n, n, true)
        var edgeAlpha = 0f
        var edgeCount = 0
        var lum = 0f
        var weight = 0f
        for (y in 0 until n) for (x in 0 until n) {
            val p = small.getPixel(x, y)
            val a = Color.alpha(p) / 255f
            if (x == 0 || y == 0 || x == n - 1 || y == n - 1) {
                edgeAlpha += a
                edgeCount++
            }
            lum += a * (0.299f * Color.red(p) + 0.587f * Color.green(p) + 0.114f * Color.blue(p)) / 255f
            weight += a
        }
        if (small !== bmp) small.recycle()
        return (edgeAlpha / edgeCount) to (if (weight > 0f) lum / weight else 0.5f)
    }
}
