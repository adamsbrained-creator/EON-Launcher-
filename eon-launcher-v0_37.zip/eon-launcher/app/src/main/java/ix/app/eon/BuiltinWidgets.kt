package ix.app.eon

import android.text.format.DateFormat
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Ids below zero are Eon's own widgets; positive ids belong to Android's widget host. */
const val W_NOW_PLAYING = -1
const val W_WEEK = -2

fun builtinLabel(id: Int): String? = when (id) {
    W_NOW_PLAYING -> "Now playing"
    W_WEEK -> "Week"
    W_WEATHER -> "Weather and quote"
    else -> null
}

private val textShadow = Shadow(Color(0x99000000), Offset(0f, 2f), 6f)

/** Track and artist from the music app, as plain text with a round cover. */
@Composable
fun NowPlayingWidget() {
    val ctx = LocalContext.current
    val title = NowPlaying.title
    val artist = NowPlaying.artist
    val art = NowPlaying.art
    val hasAccess = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    Row(
        Modifier.fillMaxSize()
            .clickable {
                if (NowPlaying.pkg.isNotEmpty()) {
                    ctx.packageManager.getLaunchIntentForPackage(NowPlaying.pkg)?.let { ctx.startActivity(it) }
                }
            },
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(1f, fill = false)) {
            Text(
                title.ifBlank { "Nothing playing" },
                style = TextStyle(color = Eon.Text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, shadow = textShadow),
                maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.End,
            )
            Text(
                when {
                    artist.isNotBlank() -> artist
                    !hasAccess -> "Needs notification access"
                    else -> "No active player (${NowPlaying.sessions} found)"
                },
                style = TextStyle(color = Color(0xFFE2E3E6), fontSize = 14.sp, shadow = textShadow),
                maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.End,
            )
        }
        Spacer(Modifier.width(12.dp))
        Box(Modifier.size(46.dp)) {
            Box(
                Modifier.fillMaxSize().clip(CircleShape)
                    .background(Brush.linearGradient(listOf(Color(0xFF4A4D52), Color(0xFF1A1B1E)))),
            ) {
                if (art != null) {
                    Image(art, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                }
            }
            if (NowPlaying.playing) {
                Box(
                    Modifier.align(Alignment.BottomEnd).size(12.dp).clip(CircleShape).background(Eon.Button),
                )
            }
        }
    }
}

private val SlantShape = GenericShape { size, _ ->
    val k = size.width * 0.18f
    moveTo(k, 0f)
    lineTo(size.width, 0f)
    lineTo(size.width - k, size.height)
    lineTo(0f, size.height)
    close()
}

/** Seven days around today, with the month and the time. */
@Composable
fun WeekWidget() {
    val ctx = LocalContext.current
    val now by produceState(LocalDateTime.now()) {
        while (true) {
            value = LocalDateTime.now()
            delay(60_000L - System.currentTimeMillis() % 60_000L)
        }
    }
    val is24 = remember { DateFormat.is24HourFormat(ctx) }
    val today = now.toLocalDate()
    val shape = RoundedCornerShape(30.dp)
    Column(
        Modifier.fillMaxSize().clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFF1E1F22), Color(0xFF0E0F10))))
            .border(1.dp, Color(0x40FFFFFF), shape)
            .padding(horizontal = 18.dp, vertical = 12.dp),
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            for (offset in -2L..4L) {
                val day = today.plusDays(offset)
                val selected = offset == 0L
                Column(
                    Modifier.width(40.dp)
                        .then(if (selected) Modifier.clip(SlantShape).background(Eon.Button) else Modifier)
                        .padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        "${day.dayOfMonth}", color = if (selected) Color.White else Color(0xFFE2E3E6),
                        fontSize = 20.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                    )
                    Text(
                        day.dayOfWeek.getDisplayName(java.time.format.TextStyle.SHORT, Locale.getDefault()),
                        color = if (selected) Color.White else Color(0xFFB5B8BF), fontSize = 11.sp,
                    )
                }
            }
        }
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
            Text(
                today.month.getDisplayName(java.time.format.TextStyle.FULL, Locale.getDefault()) + " " + today.year,
                color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold,
            )
            Spacer(Modifier.weight(1f))
            Text(
                now.format(DateTimeFormatter.ofPattern(if (is24) "HH:mm" else "h:mm a")),
                color = Color(0xFFE2E3E6), fontSize = 14.sp,
            )
        }
    }
}
