package ix.app.eon

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Category
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.OpenWith
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.KeyboardArrowLeft
import androidx.compose.material.icons.outlined.KeyboardArrowRight
import androidx.compose.material.icons.outlined.Settings as SettingsIcon
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material.icons.outlined.Widgets
import androidx.compose.material.icons.outlined.Wallpaper
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog

@Composable
private fun MenuRow(icon: ImageVector, text: String, color: Color = Eon.Text, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Icon(icon, null, tint = if (color == Eon.Text) Eon.Soft else color, modifier = Modifier.size(20.dp))
        Text(text, color = color, fontSize = 15.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun MenuDivider() {
    Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp).height(1.dp).background(Color(0x24FFFFFF)))
}

/** Long-press menu for an app icon. */
@Composable
fun AppMenu(
    app: AppEntry, state: EonState, onDismiss: () -> Unit,
) {
    val ctx = LocalContext.current
    var picking by remember { mutableStateOf(false) }
    val category = state.overrides[app.packageName] ?: app.autoCategory
    val pinned = state.isPinned(app.key)
    val inDock = state.isInDock(app.key)

    Dialog(onDismissRequest = onDismiss) {
        Column(Modifier.width(300.dp).glass(RoundedCornerShape(26.dp)).padding(vertical = 8.dp)) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Image(app.icon, null, Modifier.size(44.dp))
                Column {
                    Text(app.label, color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    Text(state.categoryName(category), color = Eon.Muted, fontSize = 12.sp)
                }
            }
            MenuDivider()
            // The app's own shortcuts (only when Eon is the home app, since Android hides them from other apps).
            val shortcuts by produceState(emptyList<AppShortcut>(), app.key) { value = loadShortcuts(ctx, app) }
            if (!picking && shortcuts.isNotEmpty()) {
                shortcuts.forEach { sc -> ShortcutRow(sc) { startShortcut(ctx, sc); onDismiss() } }
                MenuDivider()
            }
            if (!picking) {
                if (inDock) {
                    MenuRow(Icons.Outlined.Home, "Move to home") {
                        if (!state.dockToHome(app.key)) {
                            android.widget.Toast.makeText(ctx, "No space on this page", android.widget.Toast.LENGTH_SHORT).show()
                        }
                        onDismiss()
                    }
                    MenuRow(Icons.Outlined.GridView, "Remove from dock") {
                        state.removeFromDock(app.key)
                        onDismiss()
                    }
                } else {
                    if (state.folderOf(app.key) != null) {
                        MenuRow(Icons.Outlined.GridView, "Take out of folder") {
                            if (!state.takeOutOfFolder(app.key)) {
                                android.widget.Toast.makeText(ctx, "No space on this page", android.widget.Toast.LENGTH_SHORT).show()
                            }
                            onDismiss()
                        }
                    }
                    MenuRow(Icons.Outlined.Home, if (pinned) "Remove from home" else "Pin to home") {
                        if (!state.togglePin(app.key)) {
                            android.widget.Toast.makeText(ctx, "No space on this page", android.widget.Toast.LENGTH_SHORT).show()
                        }
                        onDismiss()
                    }
                    if (HomeConfig.dockOn) {
                        MenuRow(Icons.Outlined.GridView, "Move to dock") {
                            if (!state.moveToDock(app.key)) {
                                android.widget.Toast.makeText(ctx, "The dock is full", android.widget.Toast.LENGTH_SHORT).show()
                            }
                            onDismiss()
                        }
                    }
                }
                MenuRow(Icons.Outlined.Category, "Change category") { picking = true }
                MenuRow(Icons.Outlined.VisibilityOff, "Hide from drawer") {
                    state.hide(app.packageName); onDismiss()
                }
                MenuRow(Icons.Outlined.Info, "App info") {
                    ctx.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.packageName}"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    )
                    onDismiss()
                }
                MenuRow(Icons.Outlined.Delete, "Uninstall", Eon.Danger) {
                    ctx.startActivity(
                        Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.packageName}"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    )
                    onDismiss()
                }
            } else {
                Column(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState())) {
                    state.categories.filter { it.id != CAT_ALL }.forEach { c ->
                        Text(
                            c.name, color = if (c.id == category) Eon.Accent else Eon.Text, fontSize = 15.sp,
                            fontWeight = if (c.id == category) FontWeight.Bold else FontWeight.Medium,
                            modifier = Modifier.fillMaxWidth()
                                .clickable { state.setCategory(app.packageName, c.id); onDismiss() }
                                .padding(horizontal = 20.dp, vertical = 12.dp),
                        )
                    }
                    if (state.overrides.containsKey(app.packageName)) {
                        Text(
                            "Automatic", color = Eon.Muted, fontSize = 15.sp, fontWeight = FontWeight.Medium,
                            modifier = Modifier.fillMaxWidth()
                                .clickable { state.clearCategory(app.packageName); onDismiss() }
                                .padding(horizontal = 20.dp, vertical = 12.dp),
                        )
                    }
                }
            }
        }
    }
}

/** Long-press menu for the empty home screen. */
@Composable
fun HomeMenu(
    onDismiss: () -> Unit, onWidgets: () -> Unit,
    onAddLeft: () -> Unit, onAddRight: () -> Unit,
    canRemove: Boolean, onRemove: () -> Unit,
    onSettings: () -> Unit, onWallpaper: () -> Unit,
    freeIcons: Boolean, onTogglePlacement: () -> Unit,
    searchHidden: Boolean, onShowSearch: () -> Unit,
) {
    Dialog(onDismissRequest = onDismiss) {
        Column(Modifier.width(280.dp).glass(RoundedCornerShape(26.dp)).padding(vertical = 8.dp)) {
            MenuRow(Icons.Outlined.Wallpaper, "Wallpaper", onClick = onWallpaper)
            MenuRow(Icons.Outlined.Widgets, "Widgets", onClick = onWidgets)
            MenuRow(
                if (freeIcons) Icons.Outlined.GridView else Icons.Outlined.OpenWith,
                if (freeIcons) "Snap icons to grid" else "Place icons freely",
                onClick = onTogglePlacement,
            )
            if (searchHidden) MenuRow(Icons.Outlined.Search, "Show search pill", onClick = onShowSearch)
            MenuRow(Icons.Outlined.KeyboardArrowLeft, "Add page to the left", onClick = onAddLeft)
            MenuRow(Icons.Outlined.KeyboardArrowRight, "Add page to the right", onClick = onAddRight)
            if (canRemove) MenuRow(Icons.Outlined.Delete, "Remove this page", Eon.Danger, onRemove)
            MenuRow(Icons.Outlined.SettingsIcon, "Eon settings", onClick = onSettings)
        }
    }
}
