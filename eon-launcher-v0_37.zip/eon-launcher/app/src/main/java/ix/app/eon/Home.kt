package ix.app.eon

import android.app.WallpaperManager
import android.widget.Toast
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.unit.toSize
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.changedToDown
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState

@Composable
fun Home(
    repo: AppRepo, state: EonState, widgets: WidgetHolder, apps: List<AppEntry>, homeTick: Int,
    onResetGreeting: () -> Unit,
) {
    val ctx = LocalContext.current
    val density = LocalDensity.current.density
    var drawer by rememberSaveable { mutableStateOf(false) }
    var settings by rememberSaveable { mutableStateOf(false) }
    var focusSearch by remember { mutableStateOf(false) }
    var menuApp by remember { mutableStateOf<AppEntry?>(null) }
    var homeMenu by remember { mutableStateOf(false) }
    var widgetScreen by rememberSaveable { mutableStateOf(false) }
    var settingsStart by remember { mutableStateOf("") }
    val drag = remember { DragState() }
    var gridBox by remember { mutableStateOf(Rect.Zero) }
    var dockBox by remember { mutableStateOf(Rect.Zero) }
    var homeOrigin by remember { mutableStateOf(Offset.Zero) }
    val fx = remember { WallpaperFx() }
    // When Eon's live wallpaper is the system wallpaper it draws the picture itself (home and lock screen).
    val live = rememberLiveWallpaperActive()
    val rootView = LocalView.current
    val pagerState = rememberPagerState(pageCount = { state.pages.size })
    var scrollTo by remember { mutableIntStateOf(-1) }
    LaunchedEffect(pagerState) { snapshotFlow { pagerState.currentPage }.collect { state.currentPage = it } }
    LaunchedEffect(scrollTo) {
        if (scrollTo >= 0) {
            pagerState.animateScrollToPage(scrollTo)
            scrollTo = -1
        }
    }

    val dockRect = if (HomeConfig.dockOn) dockBox else Rect.Zero
    val visible = remember(apps, state.hidden.size, DrawerConfig.hidePlayStore, DrawerConfig.hideIconPacks) {
        apps.filter { it.packageName !in state.hidden && !DrawerConfig.hiddenByRules(it) }
    }
    val shadow = Shadow(Color(0x73000000), Offset(0f, 2f), 8f)

    DisposableEffect(Unit) {
        widgets.host.startListening()
        onDispose { widgets.host.stopListening() }
    }
    // Tell the live wallpaper which page you are on, so the picture shifts as you swipe.
    LaunchedEffect(live) {
        if (live) {
            snapshotFlow { pagerState.currentPage + pagerState.currentPageOffsetFraction to state.pages.size }.collect { (pos, n) ->
                val offset = if (n > 1) (pos / (n - 1)).coerceIn(0f, 1f) else 0.5f
                try {
                    WallpaperManager.getInstance(ctx).setWallpaperOffsets(rootView.windowToken, offset, 0.5f)
                } catch (_: Exception) {
                }
            }
        }
    }
    // A page made by holding at the edge while dragging goes away again if nothing was dropped on it.
    LaunchedEffect(drag.app) {
        if (drag.app == null && drag.addedPage >= 0) {
            val i = drag.addedPage
            drag.addedPage = -1
            state.removePage(i)
        }
    }
    // Apps that were uninstalled leave their folders. (An empty list means the apps have not loaded yet.)
    LaunchedEffect(apps) {
        if (apps.isNotEmpty()) state.pruneFolders(apps.map { it.key }.toSet())
    }
    // Move home screens saved by older versions onto the grid.
    LaunchedEffect(Unit) {
        state.migrate { id ->
            builtinSize(id)
                ?: widgets.manager.getAppWidgetInfo(id)?.let { suggestSize(ctx, it) }
                ?: (4 to 2)
        }
    }
    // Forget widgets whose provider app was removed.
    LaunchedEffect(Unit) {
        state.allWidgets().filter { it > 0 && widgets.manager.getAppWidgetInfo(it) == null }.forEach { state.removeWidget(it) }
    }
    LaunchedEffect(homeTick) {
        if (homeTick > 0) {
            drawer = false
            settings = false
            widgetScreen = false
            state.editing = null
            state.openFolder = null
            pagerState.animateScrollToPage(0)
        }
    }
    // What a gesture does (see Settings > Gestures).
    val runGesture: (Int) -> Unit = { action ->
        when (action) {
            ACTION_LOCK -> lockScreen(ctx)
            ACTION_DRAWER -> { focusSearch = false; drawer = true }
            ACTION_SEARCH -> { focusSearch = true; drawer = true }
            ACTION_NOTIFICATIONS -> expandNotifications(ctx)
            ACTION_SETTINGS -> { settingsStart = ""; settings = true }
            else -> {}
        }
    }
    BackHandler(enabled = drawer) { drawer = false }
    BackHandler(enabled = state.editing != null) { state.editing = null }
    BackHandler(enabled = state.openFolder != null) { state.commitLayout(); state.openFolder = null }

    Box(
        Modifier
            .fillMaxSize()
            .onGloballyPositioned { homeOrigin = it.positionInRoot() }
            // Watches touches (without using them) so the Ripple effect can start where you touch.
            .pointerInput(live) {
                awaitPointerEventScope {
                    while (true) {
                        val event = awaitPointerEvent(PointerEventPass.Initial)
                        event.changes.forEach {
                            if (it.changedToDown()) {
                                if (live) {
                                    // The live wallpaper draws the effect, so tell it where you touched.
                                    try {
                                        WallpaperManager.getInstance(ctx).sendWallpaperCommand(
                                            rootView.windowToken, WallpaperManager.COMMAND_TAP,
                                            it.position.x.toInt(), it.position.y.toInt(), 0, null,
                                        )
                                    } catch (_: Exception) {
                                    }
                                } else {
                                    fx.touch(it.position.x, it.position.y)
                                }
                            }
                        }
                    }
                }
            }
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = {
                        val free = !drawer && !settings && !widgetScreen
                        if (state.editing != null) {
                            // finishing a widget edit: swipes do nothing
                        } else if (total < -160f) {
                            focusSearch = false
                            drawer = true
                        } else if (total > 240f && free) {
                            runGesture(GestureConfig.swipeDown)
                        }
                    },
                    onDragCancel = { total = 0f },
                    onVerticalDrag = { _, dy -> total += dy },
                )
            },
    ) {
        // The gyro wallpaper, when it is on, sits behind everything. Otherwise the system wallpaper shows through.
        if (WallpaperConfig.active && !live) {
            GyroWallpaper(
                fx = fx,
                page = { pagerState.currentPage + pagerState.currentPageOffsetFraction },
                pageCount = { state.pages.size },
            )
        }
        // Empty-space layer: long-press here opens the home menu.
        Box(
            Modifier.fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures(
                        onLongPress = { if (state.editing == null && !state.widgetTouch) homeMenu = true },
                        onDoubleTap = { runGesture(GestureConfig.doubleTap) },
                    )
                },
        )
        Box(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(160.dp)
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xA6000000)))),
        )

        Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = HomeConfig.sidePad.dp)) {
            Gap(HomeConfig.topPad)
            Box(
                Modifier.weight(1f).fillMaxWidth()
                    .onGloballyPositioned { c -> gridBox = Rect(c.positionInRoot(), c.size.toSize()) },
            ) {
            HorizontalPager(
                pagerState,
                Modifier.fillMaxSize().onSizeChanged { size ->
                    state.setArea(size.height.toFloat(), CELL_HEIGHT.value * density)
                },
                userScrollEnabled = state.editing == null,
            ) { index ->
                val page = state.pages.getOrNull(index)
                if (page != null) {
                    Box(Modifier.fillMaxSize()) {
                        PageGrid(
                            page = page, pageIndex = index, state = state, apps = apps, widgets = widgets,
                            onTap = { repo.launch(it) },
                            onMenu = { menuApp = it },
                            onEmptyLongPress = { homeMenu = true },
                            onDoubleTap = { runGesture(GestureConfig.doubleTap) },
                        )
                        if (index == 0 && page.items.isEmpty() && page.legacyPinned.isEmpty() && page.legacyWidgets.isEmpty()) {
                            Text(
                                "Long-press an app in the drawer and drag it here.",
                                style = TextStyle(color = Color(0xFFE2E3E6), fontSize = 13.sp, shadow = shadow),
                                modifier = Modifier.padding(start = 12.dp, top = 8.dp),
                            )
                        }
                    }
                }
            }
            // The search pill floats over the grid, so icons can sit anywhere, including the bottom.
            if (!state.searchHidden) SearchLayer(state, onOpen = { focusSearch = true; drawer = true })
            }
            if (HomeConfig.dockOn) {
                Dock(
                    state, apps, onTap = { repo.launch(it) }, onMenu = { menuApp = it },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
                        .onGloballyPositioned { c -> dockBox = Rect(c.positionInRoot(), c.size.toSize()) },
                )
            }
            if (HomeConfig.indicator) Column(
                Modifier.fillMaxWidth().padding(bottom = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Row(
                    Modifier.clip(CircleShape).clickable { homeMenu = true }
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    state.pages.forEachIndexed { i, _ ->
                        val on = i == pagerState.currentPage
                        if (i == 0) {
                            EonMark(Modifier.size(16.dp), brush = SolidColor(if (on) Eon.Text else Color(0x80FFFFFF)))
                        } else {
                            Box(
                                Modifier.size(if (on) 8.dp else 6.dp).clip(CircleShape)
                                    .background(if (on) Eon.Text else Color(0x66FFFFFF)),
                            )
                        }
                    }
                }
            }
            Gap(HomeConfig.bottomPad)
        }

        AnimatedVisibility(
            visible = drawer,
            enter = slideInVertically { it / 3 } + fadeIn(),
            exit = slideOutVertically { it / 3 } + fadeOut(),
        ) {
            // The drawer fades out while an icon is being dragged, so the home screen shows through.
            val drawerAlpha by animateFloatAsState(if (drag.app != null) 0f else 1f, tween(140), label = "drawerAlpha")
            Box(Modifier.fillMaxSize().graphicsLayer { alpha = drawerAlpha }) {
                val dropOnHome: (AppEntry, Offset) -> Unit = { app, pos ->
                    when (val t = dropTarget(pos, gridBox, dockRect, density, state)) {
                        is DropTarget.Home -> {
                            if (state.placeApp(pagerState.targetPage, app.key, t.col, t.row)) {
                                drawer = false
                            } else {
                                Toast.makeText(ctx, "No room on this page", Toast.LENGTH_SHORT).show()
                            }
                        }
                        is DropTarget.Dock -> {
                            if (state.dropToDock(app.key, t.page, t.col, t.row)) {
                                drawer = false
                            } else {
                                Toast.makeText(ctx, "The dock is full", Toast.LENGTH_SHORT).show()
                            }
                        }
                        null -> {}
                    }
                }
                val drawerApps = remember(visible, DrawerConfig.sort) { sortApps(visible, DrawerConfig.sort) }
                val openDrawerSettings = { drawer = false; settingsStart = "drawer"; settings = true }
                if (state.drawerStyle == "library") {
                    AppLibrary(
                        apps = drawerApps, state = state, focusSearch = focusSearch,
                        onLaunch = { app -> repo.launch(app); if (DrawerConfig.closeAfterLaunch) drawer = false },
                        onMenu = { app -> menuApp = app },
                        onClose = { drawer = false },
                        drag = drag, onDrop = dropOnHome, onSettings = openDrawerSettings,
                    )
                } else {
                    Drawer(
                        apps = drawerApps, state = state, focusSearch = focusSearch,
                        onLaunch = { app -> repo.launch(app); if (DrawerConfig.closeAfterLaunch) drawer = false },
                        onMenu = { app -> menuApp = app },
                        onClose = { drawer = false },
                        drag = drag, onDrop = dropOnHome, onSettings = openDrawerSettings,
                    )
                }
            }
        }
        DragLayer(drag, state, gridBox, dockRect, homeOrigin, pagerState)

        val openFolder = state.openFolder?.let { state.findFolder(it) }
        LaunchedEffect(state.openFolder, openFolder == null) {
            if (state.openFolder != null && openFolder == null) state.openFolder = null
        }
        if (openFolder != null) {
            FolderPopup(
                state, openFolder, apps,
                onLaunch = { app -> state.commitLayout(); state.openFolder = null; repo.launch(app) },
                onMenu = { app -> menuApp = app },
                onClose = { state.commitLayout(); state.openFolder = null },
            )
        }

        if (settings) SettingsScreen(state, { settings = false; settingsStart = "" }, onResetGreeting, settingsStart)
        if (widgetScreen) WidgetsScreen(state, widgets) { widgetScreen = false }
    }

    menuApp?.let { app ->
        AppMenu(app, state) { menuApp = null }
    }
    if (homeMenu) {
        val cur = pagerState.currentPage
        HomeMenu(
            onDismiss = { homeMenu = false },
            onWidgets = { homeMenu = false; widgetScreen = true },
            onAddLeft = { homeMenu = false; state.addPage(cur) },
            onAddRight = { homeMenu = false; state.addPage(cur + 1); scrollTo = cur + 1 },
            canRemove = state.pages.size > 1 && state.pages.getOrNull(cur)?.items?.isEmpty() == true,
            onRemove = { homeMenu = false; state.removePage(cur) },
            onSettings = { homeMenu = false; settingsStart = ""; settings = true },
            onWallpaper = { homeMenu = false; settingsStart = "wallpaper"; settings = true },
            freeIcons = state.freeIcons,
            onTogglePlacement = { homeMenu = false; state.chooseFreeIcons(!state.freeIcons) },
            searchHidden = state.searchHidden,
            onShowSearch = { homeMenu = false; state.resetSearch(); state.chooseSearchHidden(false) },
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppIcon(
    app: AppEntry, iconSize: Dp, showLabel: Boolean,
    onClick: () -> Unit, onLongClick: () -> Unit,
) {
    Box(
        Modifier.clip(RoundedCornerShape(16.dp))
            .combinedClickable(onClick = onClick, onLongClick = onLongClick),
    ) { AppIconBody(app, iconSize, showLabel) }
}

/** The icon, badge and label, without any touch handling. */
@Composable
fun AppIconBody(
    app: AppEntry, iconSize: Dp, showLabel: Boolean,
    labelSp: Float = 12f, twoLine: Boolean = false, labelColor: Color = Eon.Text,
) {
    val count = Badges.counts[app.packageName] ?: 0
    Column(
        Modifier.padding(vertical = 4.dp, horizontal = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box {
            Image(bitmap = app.icon, contentDescription = app.label, modifier = Modifier.size(iconSize))
            if (count > 0) {
                Box(
                    Modifier.align(Alignment.TopEnd).offset(x = 5.dp, y = (-4).dp)
                        .defaultMinSize(minWidth = 18.dp, minHeight = 18.dp)
                        .clip(CircleShape).background(Eon.Button)
                        .border(1.5.dp, Eon.Text, CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        if (count > 99) "99+" else "$count", color = Eon.OnAccent,
                        fontSize = 10.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 4.dp),
                    )
                }
            }
        }
        if (showLabel) {
            Gap(6)
            Text(
                app.label, color = labelColor, fontSize = labelSp.sp, maxLines = if (twoLine) 2 else 1, overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                style = TextStyle(shadow = Shadow(Color(0x99000000), Offset(0f, 1f), 4f)),
            )
        }
    }
}

/** Pulls down the system notification shade (needs the EXPAND_STATUS_BAR permission). */
fun expandNotifications(ctx: android.content.Context) {
    try {
        val service = ctx.getSystemService("statusbar") ?: return
        service.javaClass.getMethod("expandNotificationsPanel").invoke(service)
    } catch (_: Exception) {
    }
}
