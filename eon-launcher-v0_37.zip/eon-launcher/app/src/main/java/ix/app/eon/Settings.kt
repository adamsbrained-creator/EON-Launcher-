package ix.app.eon

import android.content.Intent
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.TouchApp
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.ViewDay
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material.icons.outlined.Wallpaper
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver

// The rainbow from the Eon icon. Each category tile has one of these colours.
private val Blue = Color(0xFF4F8CFF)
private val Cyan = Color(0xFF35D6F0)
private val Violet = Color(0xFF9B7BFF)
private val Magenta = Color(0xFFF25CCB)
private val Coral = Color(0xFFFF7A66)
private val Orange = Color(0xFFFFA63D)
private val Rainbow = Brush.horizontalGradient(listOf(Cyan, Blue, Violet, Magenta, Coral, Orange))

private val PanelBg = Color(0xFF0D0D0F)

/** One category tile on the settings hub. */
private class HubTile(
    val title: String,
    val status: String,
    val icon: ImageVector,
    val from: Color,
    val to: Color,
    val ink: Color,
    val keywords: String,
    val onClick: () -> Unit,
)

@Composable
fun SettingsScreen(state: EonState, onClose: () -> Unit, onResetGreeting: () -> Unit, startSub: String = "") {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    DisposableEffect(Unit) {
        val owner = (ctx as ComponentActivity).lifecycle
        val observer = LifecycleEventObserver { _, event -> if (event == Lifecycle.Event.ON_RESUME) tick++ }
        owner.addObserver(observer)
        onDispose { owner.removeObserver(observer) }
    }
    val notifications = remember(tick) {
        NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    }
    val version = remember {
        runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: ""
    }
    // "" is the hub. The others are its pages: grid, dock, wallpaper, wpsettings, hidden, about.
    var sub by remember { mutableStateOf(startSub) }
    BackHandler {
        when (sub) {
            "wpsettings" -> {
                sub = "wallpaper"
            }
            "wallpaper" -> {
                if (startSub == "wallpaper") onClose() else sub = ""
            }
            "drawer" -> {
                if (startSub == "drawer") onClose() else sub = ""
            }
            "grid", "dock", "hidden", "about", "gestures" -> {
                sub = ""
            }
            else -> {
                onClose()
            }
        }
    }
    when (sub) {
        "wallpaper" -> {
            WallpaperScreen(
                state,
                onBack = { if (startSub == "wallpaper") onClose() else sub = "" },
                onSettings = { sub = "wpsettings" },
            )
            return
        }
        "wpsettings" -> {
            WallpaperSettingsScreen(state, onBack = { sub = "wallpaper" })
            return
        }
        "dock" -> {
            DockSettingsScreen(state, onBack = { sub = "" })
            return
        }
        "drawer" -> {
            DrawerSettingsScreen(state, onBack = { if (startSub == "drawer") onClose() else sub = "" })
            return
        }
        "grid" -> {
            GridSettingsScreen(state, onBack = { sub = "" })
            return
        }
        "hidden" -> {
            HiddenAppsPage(state, onBack = { sub = "" })
            return
        }
        "gestures" -> {
            GesturesPage(state, onBack = { sub = "" })
            return
        }
        "about" -> {
            AboutPage(version, onResetGreeting, onBack = { sub = "" })
            return
        }
    }

    var query by remember { mutableStateOf("") }
    val q = query.trim().lowercase()

    val tiles = listOf(
        HubTile(
            "Grid and icons", "${HomeConfig.cols} × " + (if (HomeConfig.rowsSetting > 0) "${HomeConfig.rowsSetting}" else "auto") +
                " · ${HomeConfig.iconDp} dp",
            Icons.Outlined.GridView, Blue, Cyan, Color(0xFF04140B),
            "grid columns rows icon size labels padding home screen",
        ) { sub = "grid" },
        HubTile(
            "Dock", if (HomeConfig.dockOn) "${HomeConfig.dockCols} × ${HomeConfig.dockRows}" else "Off",
            Icons.Outlined.ViewDay, Cyan, Color(0xFF5C9DFF), Color(0xFF031418),
            "dock bar bottom",
        ) { sub = "dock" },
        HubTile(
            "Drawer", (if (state.drawerStyle == "library") "Library" else "Bar") + " · " +
                "${(DrawerConfig.bgOpacity * 100).toInt()}% dim",
            Icons.Outlined.Apps, Orange, Coral, Color(0xFF2A1000),
            "drawer app library bar categories opacity transparency colour color background icons labels sort search folders tiles",
        ) { sub = "drawer" },
        HubTile(
            "Wallpaper", if (WallpaperConfig.active) "Gyro on" else "System wallpaper",
            Icons.Outlined.Wallpaper, Violet, Color(0xFFC77DFF), Color(0xFF0C0620),
            "wallpaper gyro rain snow ripple lock screen live effects",
        ) { sub = "wallpaper" },
        HubTile(
            "Gestures", "Double tap · ${GESTURE_ACTIONS[GestureConfig.doubleTap]}",
            Icons.Outlined.TouchApp, Color(0xFF5C9DFF), Violet, Color(0xFF05102A),
            "gestures double tap swipe down lock screen notifications search",
        ) { sub = "gestures" },
        HubTile(
            "Notifications", if (notifications) "Access granted" else "Access off",
            Icons.Outlined.Notifications, Magenta, Color(0xFFFF7A9E), Color(0xFF240315),
            "notifications dots counts badges access",
        ) { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) },
        HubTile(
            "Hidden apps", "${state.hidden.size} hidden",
            Icons.Outlined.VisibilityOff, Coral, Color(0xFFFF9A5C), Color(0xFF2A0B05),
            "hidden apps hide show",
        ) { sub = "hidden" },
        HubTile(
            "About Eon", "$version · greeting",
            Icons.Outlined.AutoAwesome, Orange, Color(0xFFFFD23D), Color(0xFF2A1700),
            "about version greeting welcome",
        ) { sub = "about" },
    )
    val shown = tiles.filter { q.isEmpty() || it.title.lowercase().contains(q) || it.keywords.contains(q) }
    val quickWords = "look glassy flat panel icon placement grid free page indicator dots quick"
    val showQuick = q.isEmpty() || quickWords.contains(q)

    Column(
        Modifier.fillMaxSize().background(Color(0xF7000000)).systemBarsPadding().padding(horizontal = 16.dp)
            .verticalScroll(rememberScrollState()),
    ) {
        Gap(12)
        HubHeader("Settings", onClose)
        Gap(18)

        // Search
        Row(
            Modifier.fillMaxWidth().height(48.dp).clip(CircleShape).background(Color(0xFF111113))
                .border(1.dp, Color(0xFF232327), CircleShape).padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Icon(Icons.Outlined.Search, null, tint = Eon.Muted, modifier = Modifier.size(20.dp))
            BasicTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                textStyle = TextStyle(color = Eon.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold),
                cursorBrush = SolidColor(Cyan),
                modifier = Modifier.weight(1f),
                decorationBox = { inner ->
                    Box(contentAlignment = Alignment.CenterStart) {
                        if (query.isEmpty()) Text("Search settings", color = Eon.Muted, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                        inner()
                    }
                },
            )
        }
        Gap(22)

        // Category tiles, two per row
        shown.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { t -> Box(Modifier.weight(1f)) { HubTileView(t) } }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        if (shown.isEmpty() && !showQuick) {
            Text("Nothing matches \"$query\".", color = Eon.Muted, fontSize = 14.sp, modifier = Modifier.padding(4.dp))
        }

        if (showQuick) {
            Gap(10)
            Text(
                "QUICK SETTINGS", color = Color(0xFF8A8C93), fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.6.sp,
                modifier = Modifier.padding(start = 4.dp, bottom = 10.dp),
            )
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(PanelBg).border(1.dp, Color(0xFF1E1E22), RoundedCornerShape(24.dp))) {
                QuickRow("Look") {
                    Segmented(listOf("Glassy", "Flat"), if (state.look == "flat") 1 else 0) { state.chooseLook(if (it == 1) "flat" else "glassy") }
                }
                QuickDivider()
                QuickRow("Icon placement") {
                    Segmented(listOf("Grid", "Free"), if (state.freeIcons) 1 else 0) { state.chooseFreeIcons(it == 1) }
                }
                QuickDivider()
                QuickRow("Drawer style") {
                    Segmented(listOf("Bar", "Library"), if (state.drawerStyle == "library") 1 else 0) { state.chooseDrawerStyle(if (it == 1) "library" else "bar") }
                }
                QuickDivider()
                QuickRow("Page indicator") {
                    GradientSwitch(HomeConfig.indicator) {
                        HomeConfig.indicator = it
                        state.saveHome()
                    }
                }
            }
        }

        Gap(22)
        Row(
            Modifier.align(Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Box(Modifier.size(width = 36.dp, height = 3.dp).clip(CircleShape).background(Rainbow))
            Text("Eon $version", color = Color(0xFF8A8C93), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
        Gap(28)
    }
}

@Composable
private fun HubHeader(title: String, onBack: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        Box(
            Modifier.size(44.dp).clip(CircleShape).background(Color(0xFF161618)).border(1.dp, Color(0xFF28282C), CircleShape)
                .clickable(onClick = onBack),
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Outlined.ArrowBack, "Back", tint = Eon.Text, modifier = Modifier.size(22.dp)) }
        Text(title, color = Eon.Text, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
private fun HubTileView(t: HubTile) {
    val shape = RoundedCornerShape(24.dp)
    Column(
        Modifier.fillMaxWidth().height(132.dp).clip(shape).background(PanelBg)
            .border(1.dp, t.from.copy(alpha = 0.4f), shape)
            .clickable(onClick = t.onClick).padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
            Box(
                Modifier.size(42.dp).clip(RoundedCornerShape(14.dp))
                    .background(Brush.linearGradient(listOf(t.from, t.to))),
                contentAlignment = Alignment.Center,
            ) { Icon(t.icon, null, tint = t.ink, modifier = Modifier.size(22.dp)) }
            Text("›", color = t.from, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Column {
            Text(t.title, color = Eon.Text, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
            Text(t.status, color = Eon.Muted, fontSize = 13.sp, maxLines = 1, modifier = Modifier.padding(top = 2.dp))
        }
    }
}

@Composable
private fun QuickRow(title: String, control: @Composable () -> Unit) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 66.dp).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(title, color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        control()
    }
}

@Composable
private fun QuickDivider() {
    Box(Modifier.padding(horizontal = 16.dp).fillMaxWidth().height(1.dp).background(Color(0xFF1A1A1E)))
}

/** A small switch between two or three options; the chosen one is filled with the rainbow gradient. */
@Composable
private fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier.clip(RoundedCornerShape(15.dp)).background(Color(0xFF18181B)).padding(3.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        options.forEachIndexed { i, label ->
            val on = i == selected
            Box(
                Modifier.height(40.dp).clip(RoundedCornerShape(12.dp))
                    .then(if (on) Modifier.background(Eon.Button) else Modifier)
                    .clickable { onSelect(i) }.padding(horizontal = 17.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    label, color = if (on) Color(0xFF0A0A0C) else Color(0xFFB8BCC4), fontSize = 13.sp,
                    fontWeight = if (on) FontWeight.ExtraBold else FontWeight.Bold,
                )
            }
        }
    }
}

@Composable
private fun GradientSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    Box(
        Modifier.size(width = 52.dp, height = 32.dp).clip(CircleShape)
            .background(if (checked) Eon.Button else SolidColor(Color(0xFF2A2A2E)))
            .clickable { onChange(!checked) }.padding(4.dp),
        contentAlignment = if (checked) Alignment.CenterEnd else Alignment.CenterStart,
    ) {
        Box(Modifier.size(24.dp).clip(CircleShape).background(if (checked) Color.White else Color(0xFF8A8C93)))
    }
}

/** Hub > Gestures. */
@Composable
private fun GesturesPage(state: EonState, onBack: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Color(0xF7000000)).systemBarsPadding().padding(horizontal = 16.dp)
            .verticalScroll(rememberScrollState()),
    ) {
        Gap(12)
        HubHeader("Gestures", onBack)
        Gap(22)
        GestureChoice("Double tap", "Double-tap empty space on the home screen.", GestureConfig.doubleTap) {
            GestureConfig.doubleTap = it
            state.saveGestures()
        }
        GestureChoice("Swipe down", "Swipe down on the home screen.", GestureConfig.swipeDown) {
            GestureConfig.swipeDown = it
            state.saveGestures()
        }
        Text(
            "Swiping up always opens the app drawer.", color = Eon.Muted, fontSize = 13.sp,
            modifier = Modifier.padding(start = 4.dp, bottom = 14.dp),
        )
        if (GestureConfig.doubleTap == ACTION_LOCK || GestureConfig.swipeDown == ACTION_LOCK) {
            Text(
                "Lock screen needs Eon to be a device administrator. Android asks the first time you use the gesture. " +
                    "To undo it, turn Eon off under Settings > Security > Device admin apps.",
                color = Eon.Muted, fontSize = 13.sp, lineHeight = 18.sp,
                modifier = Modifier.padding(start = 4.dp, bottom = 14.dp),
            )
        }
        Gap(20)
    }
}

/** A titled group of chips, one per action. */
@Composable
private fun GestureChoice(title: String, subtitle: String, selected: Int, onSelect: (Int) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(bottom = 18.dp)) {
        SettingsSectionLabel(title.uppercase())
        Text(subtitle, color = Eon.Muted, fontSize = 13.sp, modifier = Modifier.padding(start = 4.dp, bottom = 10.dp))
        GESTURE_ACTIONS.chunked(3).forEachIndexed { row, chunk ->
            Row(Modifier.padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                chunk.forEachIndexed { i, label ->
                    val index = row * 3 + i
                    Box(
                        Modifier.weight(1f).height(42.dp).clip(CircleShape)
                            .accentFill(index == selected, Color(0xFF18181B))
                            .clickable { onSelect(index) },
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            label, color = if (index == selected) Eon.OnAccent else Eon.Text, fontSize = 13.sp,
                            fontWeight = FontWeight.Bold, maxLines = 1,
                        )
                    }
                }
            }
        }
    }
}

/** Hub > Hidden apps. */
@Composable
private fun HiddenAppsPage(state: EonState, onBack: () -> Unit) {
    BackHandler { onBack() }
    Column(Modifier.fillMaxSize().background(Color(0xF7000000)).systemBarsPadding().padding(horizontal = 16.dp)) {
        Gap(12)
        HubHeader("Hidden apps", onBack)
        Gap(22)
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(PanelBg)
                .border(1.dp, Coral.copy(alpha = 0.4f), RoundedCornerShape(24.dp)).padding(16.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Hidden apps", color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text("${state.hidden.size} hidden", color = Eon.Muted, fontSize = 13.sp)
                }
                if (state.hidden.isNotEmpty()) {
                    Box(
                        Modifier.height(40.dp).clip(CircleShape).background(Brush.horizontalGradient(listOf(Coral, Orange)))
                            .clickable { state.showAllApps() }.padding(horizontal = 18.dp),
                        contentAlignment = Alignment.Center,
                    ) { Text("Show all", color = Color(0xFF2A0B05), fontSize = 14.sp, fontWeight = FontWeight.ExtraBold) }
                }
            }
            Gap(10)
            Text(
                "Hide an app by long-pressing it in the drawer. Hidden apps stay installed; they just do not show in Eon.",
                color = Eon.Faint, fontSize = 12.sp, lineHeight = 17.sp,
            )
        }
    }
}

/** Hub > About Eon. */
@Composable
private fun AboutPage(version: String, onResetGreeting: () -> Unit, onBack: () -> Unit) {
    BackHandler { onBack() }
    Column(Modifier.fillMaxSize().background(Color(0xF7000000)).systemBarsPadding().padding(horizontal = 16.dp)) {
        Gap(12)
        HubHeader("About Eon", onBack)
        Gap(22)
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(PanelBg)
                .border(1.dp, Orange.copy(alpha = 0.4f), RoundedCornerShape(24.dp)),
        ) {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Version", color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text(version, color = Eon.Muted, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
            QuickDivider()
            Row(
                Modifier.fillMaxWidth().clickable(onClick = onResetGreeting).padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Show the greeting again", color = Eon.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text("Replay the welcome", color = Eon.Muted, fontSize = 13.sp)
                }
                Text("›", color = Orange, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
        }
        Gap(18)
        Box(Modifier.align(Alignment.CenterHorizontally).size(width = 96.dp, height = 3.dp).clip(CircleShape).background(Rainbow))
    }
}
