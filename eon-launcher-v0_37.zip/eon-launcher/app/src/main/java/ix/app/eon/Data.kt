package ix.app.eon

import android.content.ComponentName
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.LauncherApps
import android.os.UserHandle
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Words that put an app in a category by its package name or label. Matching is loose on purpose: an app can
 * fit several categories. Favorites and your own categories are never filled this way.
 */
private val KEYWORDS: List<Pair<String, List<String>>> = listOf(
    "contacts" to listOf("dialer", "contact", "messag", "mms", "sms"),
    "internet" to listOf("browser", "chrome", "firefox", "brave", "opera", "vivaldi", "duckduckgo", "msedge"),
    "photography" to listOf("camera", "gallery", "photos", "snapseed", "lightroom"),
    "music" to listOf("music", "spotify", "podcast", "radio", "soundcloud", "deezer", "shazam"),
    "entertainment" to listOf("netflix", "youtube", "twitch", "disney", "hbo", "movie", "cinema", "plex", "kodi"),
    "weather" to listOf("weather", "meteo"),
    "finance" to listOf("bank", "wallet", "paypal", "revolut", "finance", "invest", "crypto", "money"),
    "fitness" to listOf("fitness", "health", "workout", "strava", "gym", "steps"),
    "medical" to listOf("medic", "pharma", "doctor", "clinic"),
    "navigation" to listOf("maps", "navigation", "waze", "transit", "citymapper"),
    "shopping" to listOf("shop", "amazon", "ebay", "aliexpress", "etsy", "zalando"),
    "travel" to listOf("booking", "airbnb", "flight", "hotel", "skyscanner", "uber", "trainline", "airline"),
    "education" to listOf("duolingo", "khan", "coursera", "udemy", "dictionary", "translate", "quizlet", "anki"),
    "lifestyle" to listOf("recipe", "food", "restaurant", "delivery", "fashion", "dating", "cooking"),
    "personalization" to listOf("wallpaper", "launcher", "theme", "widget"),
    "reading" to listOf("kindle", "book", "news"),
    "productivity" to listOf("calendar", "note", "docs", "sheets", "slides", "office", "drive", "gmail", "outlook", "todo", "task"),
    "social" to listOf("whatsapp", "telegram", "instagram", "facebook", "twitter", "reddit", "snapchat", "tiktok", "discord", "signal", "messenger", "linkedin", "mastodon", "bluesky"),
    "games" to listOf("game", "puzzle"),
    "tools" to listOf("calculator", "clock", "flashlight", "files", "documentsui", "recorder", "scanner", "vpn", "backup"),
)

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("eon", Context.MODE_PRIVATE)

    fun getString(key: String): String = sp.getString(key, "") ?: ""
    fun putString(key: String, v: String) { sp.edit().putString(key, v).apply() }
    fun getInt(key: String, def: Int): Int = sp.getInt(key, def)
    fun putInt(key: String, v: Int) { sp.edit().putInt(key, v).apply() }
    fun getFloat(key: String, def: Float): Float = sp.getFloat(key, def)
    fun putFloat(key: String, v: Float) { sp.edit().putFloat(key, v).apply() }
    fun getBool(key: String, def: Boolean): Boolean = sp.getBoolean(key, def)
    fun putBool(key: String, v: Boolean) { sp.edit().putBoolean(key, v).apply() }

    var onboarded: Boolean
        get() = sp.getBoolean("onboarded", false)
        set(v) { sp.edit().putBoolean("onboarded", v).apply() }

    /** "glassy" or "flat" */
    var look: String
        get() = sp.getString("look", "glassy") ?: "glassy"
        set(v) { sp.edit().putString("look", v).apply() }

    /** "dark", "light" or "auto" (stored, not applied yet) */
    var theme: String
        get() = sp.getString("theme", "dark") ?: "dark"
        set(v) { sp.edit().putString("theme", v).apply() }

    /** Component names of apps pinned to the home screen, in order. */
    var pinned: List<String>
        get() = (sp.getString("pinned", "") ?: "").split("\n").filter { it.isNotBlank() }
        set(v) { sp.edit().putString("pinned", v.joinToString("\n")).apply() }

    /** Home pages as JSON: [{"pinned":[...],"widgets":[...]}]. Empty means "not migrated yet". */
    var pagesJson: String
        get() = sp.getString("pages", "") ?: ""
        set(v) { sp.edit().putString("pages", v).apply() }

    /** App widget ids shown on the home screen, in order. */
    var widgets: List<Int>
        get() = (sp.getString("widgets", "") ?: "").split(",").mapNotNull { it.trim().toIntOrNull() }
        set(v) { sp.edit().putString("widgets", v.joinToString(",")).apply() }

    /** Where the search pill sits, as a share of the grid's width and height (Y -1 = the default spot at the bottom). */
    var searchX: Float
        get() = sp.getFloat("searchX", 0.5f)
        set(v) { sp.edit().putFloat("searchX", v).apply() }
    var searchY: Float
        get() = sp.getFloat("searchY", -1f)
        set(v) { sp.edit().putFloat("searchY", v).apply() }
    var searchHidden: Boolean
        get() = sp.getBoolean("searchHidden", false)
        set(v) { sp.edit().putBoolean("searchHidden", v).apply() }

    /** Apps can be dropped anywhere on the home screen instead of on grid cells. */
    var freeIcons: Boolean
        get() = sp.getBoolean("freeIcons", false)
        set(v) { sp.edit().putBoolean("freeIcons", v).apply() }

    /** Snap widgets to whole grid cells while editing them. */
    var snapToGrid: Boolean
        get() = sp.getBoolean("snap", true)
        set(v) { sp.edit().putBoolean("snap", v).apply() }

    /** Package names hidden from the drawer. */
    var hidden: Set<String>
        get() = sp.getStringSet("hidden", emptySet()) ?: emptySet()
        set(v) { sp.edit().putStringSet("hidden", HashSet(v)).apply() }

    /** Manual category per package. */
    var overrides: Map<String, String>
        get() = (sp.getStringSet("cats", emptySet()) ?: emptySet()).mapNotNull {
            val i = it.indexOf('|')
            if (i > 0) it.substring(0, i) to it.substring(i + 1) else null
        }.toMap()
        set(v) { sp.edit().putStringSet("cats", v.map { "${it.key}|${it.value}" }.toHashSet()).apply() }
}

data class AppEntry(
    val label: String,
    val packageName: String,
    val component: ComponentName,
    val user: UserHandle,
    val icon: ImageBitmap,
    /** The main category Eon found: social, media, games, productivity, reading, navigation, tools or other. */
    val autoCategory: String,
    /** Every category Eon thinks the app fits (the main one plus matches by name). */
    val autoCategories: Set<String>,
    /** When the app was first installed (milliseconds), for the App Library's "Recently added" folder. */
    val firstInstall: Long = 0L,
) {
    val key: String = component.flattenToString()
}

class AppRepo(private val context: Context) {
    private val launcherApps =
        context.getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps

    /** The app's main category, and every category it also fits. */
    private fun categoriesOf(pkg: String, label: String): Pair<String, Set<String>> {
        val info = try {
            context.packageManager.getApplicationInfo(pkg, 0)
        } catch (_: Exception) {
            return "other" to setOf("other")
        }
        val extra = LinkedHashSet<String>()
        val main = when (info.category) {
            ApplicationInfo.CATEGORY_SOCIAL -> "social"
            ApplicationInfo.CATEGORY_AUDIO -> {
                extra.add("music")
                "media"
            }
            ApplicationInfo.CATEGORY_VIDEO -> "media"
            ApplicationInfo.CATEGORY_IMAGE -> {
                extra.add("photography")
                "media"
            }
            ApplicationInfo.CATEGORY_GAME -> "games"
            ApplicationInfo.CATEGORY_PRODUCTIVITY -> "productivity"
            ApplicationInfo.CATEGORY_NEWS -> "reading"
            ApplicationInfo.CATEGORY_MAPS -> "navigation"
            else -> if (info.flags and ApplicationInfo.FLAG_SYSTEM != 0) "tools" else "other"
        }
        val hay = "$pkg $label".lowercase()
        for ((id, words) in KEYWORDS) {
            if (words.any { hay.contains(it) }) extra.add(id)
        }
        val all = LinkedHashSet<String>()
        // "Other" only when nothing better was found.
        if (!(main == "other" && extra.isNotEmpty())) all.add(main)
        all.addAll(extra)
        return main to all
    }

    suspend fun load(): List<AppEntry> = withContext(Dispatchers.Default) {
        // Big enough for the largest home screen icon size (84 dp), so changing the size never makes icons blurry.
        val px = (context.resources.displayMetrics.density * 84f).toInt().coerceAtLeast(128)
        launcherApps.profiles
            .flatMap { user ->
                launcherApps.getActivityList(null, user).map { info ->
                    val pkg = info.componentName.packageName
                    val label = info.label.toString()
                    val (main, matches) = categoriesOf(pkg, label)
                    AppEntry(
                        label = label,
                        packageName = pkg,
                        component = info.componentName,
                        user = user,
                        icon = IconShaper.shape(info.getBadgedIcon(0), px).asImageBitmap(),
                        autoCategory = main,
                        autoCategories = matches,
                        firstInstall = try {
                            context.packageManager.getPackageInfo(pkg, 0).firstInstallTime
                        } catch (_: Exception) {
                            0L
                        },
                    )
                }
            }
            .filter { it.packageName != context.packageName }
            .sortedBy { it.label.lowercase() }
    }

    fun launch(app: AppEntry) {
        try {
            launcherApps.startMainActivity(app.component, app.user, null, null)
        } catch (_: Exception) {
        }
    }

    /** Calls [onChange] when apps are installed, removed or updated. Returns an unregister function. */
    fun watch(onChange: () -> Unit): () -> Unit {
        val callback = object : LauncherApps.Callback() {
            override fun onPackageRemoved(packageName: String, user: UserHandle) = onChange()
            override fun onPackageAdded(packageName: String, user: UserHandle) = onChange()
            override fun onPackageChanged(packageName: String, user: UserHandle) = onChange()
            override fun onPackagesAvailable(
                packageNames: Array<out String>, user: UserHandle, replacing: Boolean,
            ) = onChange()
            override fun onPackagesUnavailable(
                packageNames: Array<out String>, user: UserHandle, replacing: Boolean,
            ) = onChange()
        }
        launcherApps.registerCallback(callback)
        return { launcherApps.unregisterCallback(callback) }
    }
}
